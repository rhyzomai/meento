<?php
// -- constants ------------------------------------------------------------------
define('FILES_DIR',      __DIR__ . '/files');
define('INFO_DIR',       __DIR__ . '/info');
define('FILES_INDEX',    __DIR__ . '/files.txt');
define('SERVERS_FILE',   __DIR__ . '/servers.txt');
define('PUB_KEY_FILE',   __DIR__ . '/public_key.txt');
define('NODE_INFO_FILE', __DIR__ . '/node_info.txt');
define('MAX_FILE',       1073741824); // 1 GB
define('MAX_FIELD',      512);        // bytes for all text/json fields
define('BLOCKED_EXT',    ['php','php3','php4','php5','php7','phtml','phar']);

// -- optional user_files include (buffered so it never pollutes JSON output) ----
if (file_exists(__DIR__ . '/user_files.php')) {
    ob_start();
    require __DIR__ . '/user_files.php';
    ob_end_clean();
}

// -- bootstrap ------------------------------------------------------------------
foreach ([FILES_DIR, INFO_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}
if (!file_exists(FILES_INDEX)) file_put_contents(FILES_INDEX, '');

// -- helpers -------------------------------------------------------------------

function blockedExt(string $ext): bool {
    return in_array(strtolower($ext), BLOCKED_EXT, true);
}

function safeExt(string $filename): string {
    return preg_replace('/[^a-z0-9]/', '', strtolower(pathinfo($filename, PATHINFO_EXTENSION)));
}

function jsonOut(array $data, int $code = 200): void {
    while (ob_get_level()) ob_end_clean(); // ensure nothing leaks before JSON
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Truncate string to $max bytes without breaking UTF-8 sequences. */
function clip(string $s, int $max = MAX_FIELD): string {
    $s = trim($s);
    if (strlen($s) <= $max) return $s;
    $out = '';
    $i   = 0;
    while ($i < strlen($s)) {
        $b   = ord($s[$i]);
        $len = $b < 0x80 ? 1 : ($b < 0xE0 ? 2 : ($b < 0xF0 ? 3 : 4));
        if ($i + $len > $max) break;
        $out .= substr($s, $i, $len);
        $i   += $len;
    }
    return $out;
}

function readOptionalFile(string $path): string {
    return file_exists($path) ? trim((string) file_get_contents($path)) : '';
}

function appendIndex(string $entry): void {
    $lines = file_exists(FILES_INDEX)
        ? array_map('trim', file(FILES_INDEX, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
        : [];
    if (!in_array($entry, $lines, true))
        file_put_contents(FILES_INDEX, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $out = [];
    foreach (file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        $l = trim($l);
        if ($l === '') continue;
        if (!preg_match('#^https?://#i', $l)) $l = 'http://' . $l;
        $out[] = rtrim($l, '/');
    }
    return array_unique($out);
}

// -- append entry to data.json -------------------------------------------------
function appendDataJson(string $hash): void {
    $raw = @file_get_contents(INFO_DIR . '/' . $hash . '.json');
    if ($raw === false) return;
    $info = json_decode($raw, true);
    if (!is_array($info)) return;

    $ext      = $info['extension'] ?? '';
    $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
    appendIndex($baseName);

    $entry    = array_merge(['hash' => $hash], $info);
    $dataJson = __DIR__ . '/data.json';
    if (!file_exists($dataJson)) file_put_contents($dataJson, "[\n]", LOCK_EX);

    $fp = @fopen($dataJson, 'c+');
    if (!$fp) return;
    if (!flock($fp, LOCK_EX)) { fclose($fp); return; }

    $content  = rtrim((string) stream_get_contents($fp));
    $closing  = strrpos($content, ']');
    $encoded  = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $indented = implode("\n", array_map(function ($l) { return '    ' . $l; }, explode("\n", $encoded)));

    if ($closing === false || trim(substr($content, 1, max(0, $closing - 1))) === '') {
        $new = "[\n{$indented}\n]";
    } else {
        $new = rtrim(substr($content, 0, $closing)) . ",\n{$indented}\n]";
    }

    rewind($fp); ftruncate($fp, 0); fwrite($fp, $new);
    flock($fp, LOCK_UN); fclose($fp);
}

// -- store file + write info JSON -----------------------------------------------
function storeLocally(string $tmp, string $origName, string $desc, string $pubKey, string $nodeInfo): array {
    $ext = safeExt($origName);
    if (blockedExt($ext)) return ['ok' => false, 'error' => 'PHP files are not accepted.'];

    $hash     = hash_file('sha256', $tmp);
    $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
    $destFile = FILES_DIR . '/' . $baseName;
    $destInfo = INFO_DIR  . '/' . $hash . '.json';
    $existed  = file_exists($destFile);

    if (!$existed) {
        if (!copy($tmp, $destFile)) return ['ok' => false, 'error' => 'Could not write file to disk.'];
        appendIndex($baseName);
    }

    if (!file_exists($destInfo)) {
        file_put_contents($destInfo, json_encode([
            'filename'          => $origName,
            'size'              => (int) filesize($destFile),
            'extension'         => $ext,
            'date'              => date('c'),
            'public_key'        => $pubKey,
            'server_public_key' => readOptionalFile(PUB_KEY_FILE),
            'node_info'         => $nodeInfo,
            'description'       => $desc,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    return ['ok' => true, 'hash' => $hash, 'filename' => $baseName, 'existed' => $existed];
}

// -- push file to one peer -----------------------------------------------------
function pushToServer(string $server, string $filePath, string $filename, string $desc, string $pubKey, string $nodeInfo): array {
    $boundary = '----MeshBoundary' . bin2hex(random_bytes(12));
    $mime     = @mime_content_type($filePath) ?: 'application/octet-stream';
    $body     = "--{$boundary}\r\n"
              . 'Content-Disposition: form-data; name="file"; filename="' . addslashes($filename) . "\"\r\n"
              . "Content-Type: {$mime}\r\n\r\n"
              . file_get_contents($filePath) . "\r\n";

    foreach (['description' => $desc, 'public_key' => $pubKey, 'node_info' => $nodeInfo, 'peer_push' => '1'] as $n => $v) {
        $body .= "--{$boundary}\r\nContent-Disposition: form-data; name=\"{$n}\"\r\n\r\n{$v}\r\n";
    }
    $body .= "--{$boundary}--\r\n";

    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: multipart/form-data; boundary={$boundary}\r\n"
                             . "Content-Length: " . strlen($body) . "\r\n"
                             . "X-Mesh-Node: 1",
            'content'       => $body,
            'timeout'       => 20,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);

    $raw = @file_get_contents($server . '/' . basename(__FILE__), false, $ctx);
    if ($raw === false) return ['ok' => false, 'server' => $server, 'error' => 'Connection failed.'];

    $decoded = json_decode($raw, true);
    return is_array($decoded)
        ? array_merge($decoded, ['server' => $server])
        : ['ok' => false, 'server' => $server, 'error' => 'Bad response: ' . substr($raw, 0, 120)];
}

// -----------------------------------------------------------------------------
//  ENDPOINTS
// -----------------------------------------------------------------------------

// -- peer_push receive ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'], $_POST['peer_push']) && $_POST['peer_push'] === '1') {
    $up = $_FILES['file'];
    if ($up['error'] !== UPLOAD_ERR_OK)      jsonOut(['ok' => false, 'error' => 'Upload error ' . $up['error']], 400);
    if ($up['size'] > MAX_FILE)              jsonOut(['ok' => false, 'error' => 'File exceeds 1 GB limit.'], 413);
    if (blockedExt(safeExt($up['name'])))   jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);

    $result = storeLocally(
        $up['tmp_name'],
        $up['name'],
        clip((string) ($_POST['description'] ?? '')),
        clip((string) ($_POST['public_key']  ?? '')),
        clip((string) ($_POST['node_info']   ?? ''))
    );

    if ($result['ok'] && !$result['existed']) appendDataJson($result['hash']);
    jsonOut($result, $result['ok'] ? 200 : 500);
}

// -- browser upload ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && !isset($_POST['peer_push'])) {
    $up = $_FILES['file'];
    if ($up['error'] !== UPLOAD_ERR_OK)      jsonOut(['ok' => false, 'error' => 'Upload error ' . $up['error']], 400);
    if ($up['size'] > MAX_FILE)              jsonOut(['ok' => false, 'error' => 'File exceeds 1 GB limit.'], 413);
    if (blockedExt(safeExt($up['name'])))   jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);

    $desc    = clip((string) ($_POST['comment']    ?? ''));
    $pubKey  = clip((string) ($_POST['public_key'] ?? ''));  // user-supplied key from form
    $nodeInf = readOptionalFile(NODE_INFO_FILE);

    $local = storeLocally($up['tmp_name'], $up['name'], $desc, $pubKey, $nodeInf);
    if (!$local['ok']) jsonOut($local, 500);

    if ($local['existed']) {
        jsonOut(['ok' => true, 'hash' => $local['hash'], 'filename' => $local['filename'], 'existed' => true]);
    }

    appendDataJson($local['hash']);

    $servers = loadServers();
    $stored  = FILES_DIR . '/' . $local['filename'];
    $payload = json_encode([
        'ok'          => true,
        'hash'        => $local['hash'],
        'filename'    => $local['filename'],
        'existed'     => false,
        'peers_total' => count($servers),
    ], JSON_UNESCAPED_UNICODE);

    while (ob_get_level()) ob_end_clean();
    http_response_code(200);
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Length: ' . strlen($payload));
    header('Connection: close');
    echo $payload;
    flush();

    ignore_user_abort(true);
    foreach ($servers as $srv) {
        pushToServer($srv, $stored, $up['name'], $desc, $pubKey, $nodeInf);
    }
    exit;
}

// -- node status ---------------------------------------------------------------
if (isset($_GET['node_status'])) {
    jsonOut([
        'public_key' => readOptionalFile(PUB_KEY_FILE) !== '',
        'node_info'  => readOptionalFile(NODE_INFO_FILE) !== '',
        'peers'      => count(loadServers()),
    ]);
}

// -----------------------------------------------------------------------------
//  HTML
// -----------------------------------------------------------------------------
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:#fff;color:#111;font-family:system-ui,-apple-system,sans-serif;font-size:15px}
body{display:flex;flex-direction:column;align-items:center;padding:2rem 1.25rem}
.page{max-width:34rem;width:100%}
a{color:#0044cc;text-decoration:none}
a:hover{text-decoration:underline}

/* header */
header{display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:.6rem;margin-bottom:1.75rem}
h1{font-size:1.3rem;font-weight:700;letter-spacing:-.02em}
h1 em{font-weight:400;color:#666;font-style:normal}
nav{display:flex;gap:.8rem;flex-wrap:wrap;font-size:.82rem;font-weight:500}

/* status bar */
#node-bar{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem;font-size:.78rem;color:#555}
.pill{display:flex;align-items:center;gap:.3rem;padding:.2rem .55rem;background:#f5f5f5;border:1px solid #e0e0e0;border-radius:4px}
.dot{width:7px;height:7px;border-radius:50%;background:#bbb;flex-shrink:0}
.dot.ok{background:#1a8e3f} .dot.blue{background:#0044cc}

/* drop zone */
#drop-zone{border:2px dashed #ccc;border-radius:6px;padding:2rem 1rem;text-align:center;cursor:pointer;transition:border-color .2s,background .2s}
#drop-zone:hover,#drop-zone:focus,#drop-zone.over{background:#fafafa;border-color:#0044cc}
#drop-zone p:first-child{font-weight:600;margin-bottom:.3rem}
#drop-zone p:last-child{font-size:.8rem;color:#666}
#drop-zone p:last-child b{color:#0044cc}
#file-input{display:none}

/* panel */
#panel{display:none;margin-top:1rem;border:1px solid #ddd;border-radius:6px;overflow:hidden}
.p-top{display:flex;align-items:center;gap:.7rem;padding:.7rem 1rem;border-bottom:1px solid #eee}
#f-name{flex:1;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#f-size{font-size:.78rem;color:#777;flex-shrink:0}
.x-btn{background:none;border:none;cursor:pointer;font-size:1.1rem;color:#aaa;padding:0 .2rem}
.x-btn:hover{color:#c00}

/* fields */
.p-fields{padding:.9rem;display:flex;flex-direction:column;gap:.7rem;border-bottom:1px solid #eee}
.field-row{display:flex;flex-direction:column;gap:.3rem}
.field-row label{font-size:.73rem;color:#777}
.field-row input,.field-row textarea{width:100%;padding:.45rem .65rem;border:1px solid #ccc;border-radius:4px;font:inherit;font-size:.88rem;outline:none;transition:border-color .2s;background:#fff;color:#111}
.field-row input:focus,.field-row textarea:focus{border-color:#0044cc}
.field-row textarea{min-height:4rem;resize:vertical}
.field-hint{display:flex;justify-content:space-between;font-size:.71rem;color:#aaa;margin-top:.2rem}
.over{color:#c00 !important}

/* server key badge (shown when public_key.txt exists) */
#server-key-badge{display:none;font-size:.73rem;padding:.3rem .6rem;border-radius:4px;border:1px solid #1a8e3f;color:#1a8e3f;background:#f0fff0}

/* panel footer */
.p-bot{display:flex;align-items:center;justify-content:space-between;gap:.7rem;padding:.7rem 1rem}
.peer-info{font-size:.78rem;color:#555}
.btn{padding:.45rem 1.1rem;background:#0044cc;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:.83rem;cursor:pointer;display:flex;align-items:center;gap:.35rem;transition:opacity .15s}
.btn:hover{opacity:.88} .btn.busy{opacity:.45;pointer-events:none}
.btn svg{width:.9rem;height:.9rem;stroke:#fff;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

/* progress */
#prog-wrap{height:3px;background:#eee;border-radius:3px;overflow:hidden;display:none;margin-top:.9rem}
#prog-bar{height:100%;width:0%;background:#0044cc;transition:width .1s linear}

/* status */
#status{display:none;margin-top:.9rem;padding:.7rem .9rem;border-radius:4px;font-size:.88rem;line-height:1.5;animation:fu .22s ease}
#status.ok{background:#f0fff0;border:1px solid #b8e0b8;color:#1a8e3f}
#status.fail{background:#fff0f0;border:1px solid #e0b8b8;color:#c00}
.file-link{display:inline-flex;align-items:center;gap:.35rem;margin-top:.5rem;padding:.35rem .9rem;font-size:.83rem;color:#0044cc;border:1px solid #0044cc;border-radius:4px}
.file-link:hover{background:#f0f4ff}
.file-link svg{width:.85rem;height:.85rem;stroke:currentColor;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

/* json preview */
.jbox{margin-top:2rem;border:1px solid #ddd;border-radius:4px;overflow:hidden}
.jbox-head{padding:.4rem .9rem;border-bottom:1px solid #eee;font-size:.73rem;color:#888;background:#fafafa}
pre{padding:.9rem;font-family:"Fira Code","SF Mono","Roboto Mono",monospace;font-size:.77rem;line-height:1.65;color:#333;overflow-x:auto;margin:0}
.jk{color:#0044cc} .js{color:#1a8e3f} .jn{color:#b04000}

footer{border-top:1px solid #eee;padding-top:1rem;margin-top:2rem;font-size:.73rem;color:#bbb;display:flex;justify-content:space-between;flex-wrap:wrap;gap:.4rem}
@keyframes fu{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="page">

<header>
  <div><h1>Mesh <em>Node</em></h1></div>
  <nav>
    <a href="index.php">Upload</a>
    <a href="view.php">Search</a>
    <a href="user_files.php">Users</a>
    <a href="servers.php">Servers</a>
    <a href="panel.php">Panel</a>
    <a href="sync.php">Sync</a>
    <a href="dashboard.php">Dashboard</a>
    <a href="indexer.php">Indexer</a>
    <a href="feed_full.php">Feed</a>
    <a href="index_full.php">Account</a>
  </nav>
</header>

<div id="node-bar">
  <div class="pill"><span class="dot blue"></span>peers <b id="nb-peers">�</b></div>
  <div class="pill"><span class="dot" id="nb-pk-dot"></span>public_key.txt <b id="nb-pk">�</b></div>
  <div class="pill"><span class="dot" id="nb-ni-dot"></span>node_info.txt <b id="nb-ni">�</b></div>
</div>

<div id="drop-zone" tabindex="0" role="button" aria-label="Select or drop a file">
  <p>? Drop a file or click to select</p>
  <p>Stored as <b>sha256.ext</b> � pushed to all peers � <b>.php</b> blocked � max <b>1 GB</b></p>
</div>
<input type="file" id="file-input">

<div id="panel">
  <div class="p-top">
    <span id="f-name">�</span>
    <span id="f-size"></span>
    <button class="x-btn" id="x-btn" aria-label="Remove file">?</button>
  </div>

  <div class="p-fields">

    <!-- public key: input always shown; badge appears when server key exists -->
    <div class="field-row">
      <label for="pk-input">Public key <span style="color:#aaa">(optional � max 512 B)</span></label>
      <div style="display:flex;gap:.5rem;align-items:center">
        <input type="text" id="pk-input" maxlength="512" placeholder="Paste your public key here�">
        <span id="server-key-badge" title="server public_key.txt is set">?? server key set</span>
      </div>
      <div class="field-hint">
        <span>Stored as "public_key" field in JSON</span>
        <span id="pk-count">0 / 512</span>
      </div>
    </div>

    <!-- description -->
    <div class="field-row">
      <label for="comment-box">Description <span style="color:#aaa">(optional � max 512 B)</span></label>
      <textarea id="comment-box" placeholder="Add an optional description for this file�"></textarea>
      <div class="field-hint">
        <span>Stored as "description" field in JSON</span>
        <span id="ccount">0 / 512</span>
      </div>
    </div>

  </div>

  <div class="p-bot">
    <span class="peer-info">Sending to <b id="peer-count">�</b> peer(s)</span>
    <button class="btn" id="send-btn">
      <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      Send to network
    </button>
  </div>
</div>

<div id="prog-wrap"><div id="prog-bar"></div></div>
<div id="status"></div>

<div class="jbox">
  <div class="jbox-head">info/&lt;hash&gt;.json � stored structure</div>
  <pre>{
  <span class="jk">"filename"</span>:          <span class="js">"photo.jpg"</span>,
  <span class="jk">"size"</span>:              <span class="jn">204800</span>,
  <span class="jk">"extension"</span>:        <span class="js">"jpg"</span>,
  <span class="jk">"date"</span>:              <span class="js">"2025-01-01T00:00:00+00:00"</span>,
  <span class="jk">"public_key"</span>:       <span class="js">"&lt;user-supplied or empty&gt;"</span>,
  <span class="jk">"server_public_key"</span>: <span class="js">"&lt;contents of public_key.txt or empty&gt;"</span>,
  <span class="jk">"node_info"</span>:        <span class="js">"&lt;contents of node_info.txt or empty&gt;"</span>,
  <span class="jk">"description"</span>:      <span class="js">"&lt;user comment or empty&gt;"</span>
}</pre>
</div>

</div><!-- .page -->

<footer>
  <span>Mesh Node � SHA-256 storage � PHP <?php echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION; ?></span>
  <span>max file 1 GB � max fields 512 B</span>
</footer>

<script>
(function(){
'use strict';

var MAX_FILE  = 1073741824;
var MAX_FIELD = 512;
var BLOCKED   = ['php','php3','php4','php5','php7','phtml','phar'];

var dz         = document.getElementById('drop-zone');
var fi         = document.getElementById('file-input');
var panel      = document.getElementById('panel');
var fName      = document.getElementById('f-name');
var fSize      = document.getElementById('f-size');
var xBtn       = document.getElementById('x-btn');
var pkInput    = document.getElementById('pk-input');
var pkCount    = document.getElementById('pk-count');
var srvBadge   = document.getElementById('server-key-badge');
var commentB   = document.getElementById('comment-box');
var ccount     = document.getElementById('ccount');
var sendBtn    = document.getElementById('send-btn');
var peerCnt    = document.getElementById('peer-count');
var status     = document.getElementById('status');
var progWrap   = document.getElementById('prog-wrap');
var progBar    = document.getElementById('prog-bar');

var file = null;
var serverHasKey = false;

// -- node status ---------------------------------------------------------------
fetch(window.location.href + '?node_status=1')
  .then(function(r){ return r.json(); })
  .then(function(d){
    serverHasKey = !!d.public_key;
    document.getElementById('nb-peers').textContent = d.peers;
    peerCnt.textContent = d.peers;

    var dot = function(id, ok){
      var el = document.getElementById(id);
      if (el) el.className = 'dot' + (ok ? ' ok' : '');
    };
    dot('nb-pk-dot', d.public_key);
    dot('nb-ni-dot', d.node_info);
    document.getElementById('nb-pk').textContent = d.public_key ? '? found' : '� missing';
    document.getElementById('nb-ni').textContent = d.node_info  ? '? found' : '� missing';

    // show badge if server already has a key (user key still accepted as extra field)
    srvBadge.style.display = serverHasKey ? '' : 'none';
  })
  .catch(function(){
    ['nb-peers','nb-pk','nb-ni'].forEach(function(id){
      var el = document.getElementById(id); if (el) el.textContent = '?';
    });
    peerCnt.textContent = '?';
  });

// -- utils ---------------------------------------------------------------------
function byteLen(s){ return (new TextEncoder()).encode(s).length; }

function fmt(b){
  if (b < 1024)    return b + ' B';
  if (b < 1048576) return (b/1024).toFixed(1) + ' KB';
  return (b/1048576).toFixed(2) + ' MB';
}

function extOf(n){ return n.split('.').pop().toLowerCase(); }

function show(type, html){ status.className = type; status.innerHTML = html; status.style.display = 'block'; }
function hideStatus(){ status.style.display = 'none'; }

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// -- file handling -------------------------------------------------------------
function setFile(f){
  if (!f) return;
  if (BLOCKED.indexOf(extOf(f.name)) !== -1){ show('fail', 'PHP files are not accepted.'); return; }
  if (f.size > MAX_FILE){ show('fail', 'File exceeds the 1 GB limit.'); return; }
  file = f;
  fName.textContent = f.name;
  fSize.textContent = fmt(f.size);
  panel.style.display = 'block';
  commentB.value = '';
  pkInput.value  = '';
  updateCounts();
  hideStatus();
}

function clearFile(){
  file = null;
  fi.value = '';
  panel.style.display = 'none';
  commentB.value = '';
  pkInput.value  = '';
}

function updateCounts(){
  var dl = byteLen(commentB.value);
  ccount.textContent = dl + ' / ' + MAX_FIELD;
  ccount.className   = dl > MAX_FIELD ? 'over' : '';

  var pl = byteLen(pkInput.value);
  pkCount.textContent = pl + ' / ' + MAX_FIELD;
  pkCount.className   = pl > MAX_FIELD ? 'over' : '';
}

// -- events --------------------------------------------------------------------
dz.addEventListener('click',   function(){ fi.click(); });
dz.addEventListener('keydown', function(e){ if (e.key==='Enter'||e.key===' ') fi.click(); });
fi.addEventListener('change',  function(){ if (fi.files[0]) setFile(fi.files[0]); });
xBtn.addEventListener('click', clearFile);

['dragenter','dragover'].forEach(function(ev){
  dz.addEventListener(ev, function(e){ e.preventDefault(); dz.classList.add('over'); });
});
['dragleave','drop'].forEach(function(ev){
  dz.addEventListener(ev, function(e){ e.preventDefault(); dz.classList.remove('over'); });
});
dz.addEventListener('drop', function(e){ if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

commentB.addEventListener('input', updateCounts);
pkInput.addEventListener('input',  updateCounts);

// -- send ----------------------------------------------------------------------
sendBtn.addEventListener('click', function(){
  if (!file) return;
  if (byteLen(commentB.value) > MAX_FIELD){ show('fail', 'Description exceeds 512 B limit.'); return; }
  if (byteLen(pkInput.value)  > MAX_FIELD){ show('fail', 'Public key exceeds 512 B limit.');  return; }

  var fd = new FormData();
  fd.append('file',       file);
  fd.append('comment',    commentB.value);
  fd.append('public_key', pkInput.value.trim());

  var xhr = new XMLHttpRequest();
  sendBtn.classList.add('busy');
  sendBtn.lastChild.textContent = ' Transmitting�';
  progWrap.style.display = 'block';
  progBar.style.width    = '0%';
  hideStatus();

  xhr.upload.addEventListener('progress', function(e){
    if (e.lengthComputable) progBar.style.width = Math.round(e.loaded / e.total * 100) + '%';
  });

  xhr.addEventListener('load', function(){
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    progBar.style.width = '100%';
    setTimeout(function(){ progWrap.style.display = 'none'; progBar.style.width = '0%'; }, 700);

    var res;
    try {
      res = JSON.parse(xhr.responseText);
    } catch(e) {
      show('fail', '? Unexpected server response: ' + esc(xhr.responseText.slice(0, 200)));
      return;
    }
    if (!res.ok){ show('fail', '? ' + (res.error || 'Unknown error')); return; }
    showLink(res.filename, !!res.existed);
    clearFile();
  });

  xhr.addEventListener('error', function(){
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    show('fail', '? Network error.');
    progWrap.style.display = 'none';
  });

  xhr.open('POST', window.location.href);
  xhr.send(fd);
});

function showLink(filename, existed){
  var url  = 'files/' + esc(filename);
  var note = existed ? ' <span style="opacity:.6">(already stored)</span>' : '';
  show('ok',
    '? File stored' + note +
    '<br><a class="file-link" href="' + url + '" target="_blank" rel="noopener noreferrer">' +
      '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>' +
      '<polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
      'Open file' +
    '</a>'
  );
}

})();
</script>
</body>
</html>