﻿# Meento Blocks

An Android app for splitting, encoding, and distributing files across multiple servers using a block-based chunking system with MD5 integrity verification.

---

## Features

- **PIX Key & Public Key storage** — saved locally on the device
- **Node information** — additional metadata saved to `nodes_info.txt`
- **File chunking** — files are Base64-encoded and split into 1000-byte blocks, each named using MD5 hashes for integrity
- **Multi-server distribution** — send all chunks to multiple servers simultaneously via HTTP GET requests
- **Chunk metadata** — a manifest file per original file lists all its chunks
- **Server management** — add, edit, and remove destination servers at any time

---

## Installation

1. Transfer `MeentoBlocks.apk` to your Android device
2. Go to **Settings → Security** (or **Privacy**) and enable **Install from unknown sources** (or "Allow installs from this source")
3. Open the APK file using your file manager and tap **Install**
4. Launch the app from your home screen

> **Minimum Android version:** 5.0 (API 21)

---

## How to Use

The app has four tabs:

### CONFIG
Fill in your information and tap **Save Settings**:

| Field | Saved to |
|---|---|
| PIX Key | `pix.txt` |
| Public Key | `public_key.txt` |
| Node Info | `nodes_info.txt` |

### FILES
- Tap **+ Add File** to pick any file from your device
- Long-press a file in the list to remove it

### SERVERS
- The default server `http://meento.atwebpages.com/blocks.php` is pre-configured
- Tap a server to **edit** its URL
- Long-press a server to **remove** it
- Tap **+ Add Server** to add a new destination
- All servers are saved to `servers.txt`

### SEND
Tap **▶ SEND** to start the transmission. The app will:

1. Read each selected file and encode it in **Base64**
2. Calculate the **MD5 hash** of the original file
3. Split the Base64 content into **1000-byte chunks**
4. Name each chunk as: `md5_original.N.md5_chunk` (e.g. `a1b2c3...1.f4e5d6...`)
5. Save chunks to the internal `chunks/` directory
6. Save a manifest (list of chunk names) to `chunks_info/` named after the original file
7. Send each chunk to **all servers** via HTTP GET
8. After all chunks, send each manifest to **all servers** via HTTP GET
9. Display a real-time log of every request and its HTTP response code

---

## HTTP GET Request Parameters

### Chunk upload
```
GET {server}?type=chunk&name={chunk_name}&content={chunk_content}&public_key={key}&pix={pix}
```

### Manifest upload
```
GET {server}?type=chunks_info&name={original_filename}&content={chunk_list}&public_key={key}&pix={pix}
```

| Parameter | Description |
|---|---|
| `type` | `chunk` or `chunks_info` |
| `name` | Chunk filename or original filename |
| `content` | Chunk data (Base64) or newline-separated chunk names |
| `public_key` | Contents of `public_key.txt` |
| `pix` | Contents of `pix.txt` |

---

## File Structure (internal storage)

```
/data/data/com.meento.blocks/files/
├── pix.txt               ← PIX key
├── public_key.txt        ← Public key
├── nodes_info.txt        ← Node information
├── servers.txt           ← Server list (one URL per line)
├── chunks/               ← Individual chunk files
│   ├── abc123.1.def456
│   ├── abc123.2.789ghi
│   └── ...
└── chunks_info/          ← Chunk manifests
    └── myfile.pdf        ← Lists all chunks for myfile.pdf
```

---

## Chunk Naming Convention

Each chunk is named using three parts separated by dots:

```
{md5_of_original_file}.{chunk_number}.{md5_of_chunk_content}
```

**Example:** `a3f1bc2e...1.9d4c7f0a...`

This allows any server to verify the integrity of each individual chunk and trace it back to its source file.

---

## Build from Source

Requirements: **Android Studio** (Hedgehog or newer) or the Android SDK command-line tools.

```bash
# Clone / extract the project folder, then:
./gradlew assembleDebug

# Output:
# app/build/outputs/apk/debug/app-debug.apk
```

**Dependencies:** none beyond the standard Android SDK (no third-party libraries). The app targets API 23 and is compatible with Android 5.0+.

---

## Notes

- The APK is signed with a **debug certificate** (self-signed). It is safe to install directly but cannot be published to the Google Play Store without a production keystore.
- All data is stored in the app's **private internal storage** and is not accessible to other apps.
- HTTP (non-HTTPS) servers are supported via the `usesCleartextTraffic` flag in the manifest.