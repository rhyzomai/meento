# Meento Blocks — Android App

## Como compilar o APK

### Pré-requisitos
- Android Studio (Hedgehog ou mais recente) — https://developer.android.com/studio
- JDK 11 ou superior
- Android SDK API 34

### Passos para compilar

1. **Abra o projeto no Android Studio**
   - File → Open → selecione a pasta `MeentoBlocks`

2. **Sincronize o Gradle**
   - Clique em "Sync Now" quando aparecer a notificação
   - Aguarde o download das dependências

3. **Gere o APK**
   - Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - O APK será gerado em: `app/build/outputs/apk/debug/app-debug.apk`

### Compilar via linha de comando (sem IDE)

```bash
# Linux/macOS
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

O APK estará em: `app/build/outputs/apk/debug/app-debug.apk`

---

## Estrutura do projeto

```
MeentoBlocks/
├── app/
│   └── src/main/
│       ├── java/com/meento/blocks/
│       │   └── MainActivity.java        ← Código principal
│       ├── res/
│       │   ├── layout/
│       │   │   ├── activity_main.xml    ← UI principal (4 abas)
│       │   │   └── dialog_server.xml    ← Diálogo de servidor
│       │   ├── values/
│       │   │   ├── colors.xml           ← Paleta escura + verde neon
│       │   │   ├── strings.xml
│       │   │   └── themes.xml
│       │   ├── drawable/                ← Ícones e fundos
│       │   └── xml/
│       │       └── file_paths.xml       ← FileProvider
│       └── AndroidManifest.xml
└── build.gradle
```

---

## Funcionalidades implementadas

### Aba CONFIG
- Campo **Chave PIX** → salvo em `pix.txt`
- Campo **Chave Pública** → salvo em `public_key.txt`
- Campo **Informações do Nó** → salvo em `nodes_info.txt`
- Botão "Salvar Configurações"

### Aba ARQUIVOS
- Botão para selecionar qualquer arquivo do dispositivo
- Lista os arquivos selecionados
- Toque longo para remover

### Aba SERVIDORES
- Servidor padrão: `http://meento.atwebpages.com/blocks.php`
- Toque para editar, toque longo para remover
- Botão para adicionar novos servidores
- Persistido em `servers.txt`

### Aba ENVIAR
- Processa cada arquivo:
  1. Lê os bytes do arquivo
  2. Codifica em **Base64**
  3. Calcula **MD5** do arquivo original
  4. Divide em pedaços de **1000 bytes**
  5. Cada pedaço nomeado: `md5original.N.md5pedaco`
  6. Salva pedaços em `/chunks/`
  7. Salva lista de pedaços em `/chunks_info/nomeoriginal`
- Envia via **GET** para todos os servidores:
  - Cada chunk: `?type=chunk&name=...&content=...&public_key=...&pix=...`
  - Cada info: `?type=chunks_info&name=...&content=...&public_key=...&pix=...`
- Log em tempo real na tela

---

## Parâmetros da requisição GET

### Para cada chunk:
| Parâmetro | Valor |
|-----------|-------|
| `type` | `chunk` |
| `name` | Nome do pedaço (ex: `abc123.1.def456`) |
| `content` | Conteúdo do pedaço (base64) |
| `public_key` | Conteúdo de `public_key.txt` |
| `pix` | Conteúdo de `pix.txt` |

### Para cada chunks_info:
| Parâmetro | Valor |
|-----------|-------|
| `type` | `chunks_info` |
| `name` | Nome original do arquivo |
| `content` | Lista de pedaços (um por linha) |
| `public_key` | Conteúdo de `public_key.txt` |
| `pix` | Conteúdo de `pix.txt` |
