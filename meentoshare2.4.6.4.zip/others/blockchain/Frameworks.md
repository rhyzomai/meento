﻿# Java Frameworks for MeshChainCore Modules

A practical guide to the Java ecosystem tools best suited for implementing each
feature that MeshChainCore deliberately leaves out. Every section maps to one
extension point or module category, explains why the framework fits, and shows
a minimal wiring snippet.

---

## Table of Contents

1. [Web Layer & REST API](#1-web-layer--rest-api)
2. [Persistence & Block Storage](#2-persistence--block-storage)
3. [Consensus — Proof of Storage](#3-consensus--proof-of-storage)
4. [P2P Network & Block Propagation](#4-p2p-network--block-propagation)
5. [Coin Wallet & Reward Accounting](#5-coin-wallet--reward-accounting)
6. [Scheduled Tasks & Background Jobs](#6-scheduled-tasks--background-jobs)
7. [Security & Authentication](#7-security--authentication)
8. [Blockchain Explorer UI](#8-blockchain-explorer-ui)
9. [Distributed / Cloud Storage](#9-distributed--cloud-storage)
10. [Testing](#10-testing)
11. [Quick-Reference Matrix](#11-quick-reference-matrix)

---

## 1. Web Layer & REST API

Expose `mintBlock()`, `verifyChain()`, and block queries over HTTP.

### Spring Boot + Spring Web MVC

The most widely used Java web framework. Provides `@RestController`,
`@GetMapping`, validation, exception handling, and embedded Tomcat — all
auto-configured from a single dependency.

```xml
<!-- pom.xml -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <version>3.3.x</version>
</dependency>
```

```java
@RestController
@RequestMapping("/api/v1/blocks")
public class BlockController {

    @Autowired MeshChainCore core;

    @PostMapping
    public ResponseEntity<Block> mint(@RequestParam String fileRef,
                                      @RequestParam(required = false) String metadata)
            throws Exception {
        Block b = core.mintBlock(fileRef, metadata);
        return ResponseEntity.status(HttpStatus.CREATED).body(b);
    }

    @GetMapping("/verify")
    public ResponseEntity<List<String>> verify() throws Exception {
        List<String> errors = core.verifyChain();
        return ResponseEntity.ok(errors);
    }
}
```

**Best for:** teams already in the Spring ecosystem; full-stack monolith or microservice.

---

### Spring WebFlux (Reactive)

Reactive alternative to Spring MVC. Non-blocking I/O based on Project Reactor.
Useful when the mesh server polling (many concurrent HTTP calls) is in the web
tier as well.

```java
@GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<Block> streamBlocks() {
    return Flux.fromIterable(core.getBlockStore().loadAll());
}
```

**Best for:** high-concurrency nodes; streaming block events to browser clients
via Server-Sent Events.

---

### Quarkus

Compile-time dependency injection (no reflection at startup), native image via
GraalVM, sub-second cold start. Drop-in JAX-RS annotations (`@GET`, `@POST`).

```java
@Path("/blocks")
@Produces(MediaType.APPLICATION_JSON)
public class BlockResource {

    @Inject MeshChainCore core;

    @POST
    public Response mint(@QueryParam("fileRef") String fileRef) throws Exception {
        return Response.ok(core.mintBlock(fileRef, null)).build();
    }
}
```

**Best for:** containerised / serverless deployments where startup time and
memory footprint matter.

---

### Micronaut

Annotation-based like Spring but processes annotations at compile time (no
reflection). Excellent fit for Java 8 targets.

```java
@Controller("/blocks")
public class BlockController {

    private final MeshChainCore core;
    public BlockController(MeshChainCore core) { this.core = core; }

    @Post
    public HttpResponse<Block> mint(@QueryValue String fileRef) throws Exception {
        return HttpResponse.created(core.mintBlock(fileRef, null));
    }
}
```

**Best for:** Java 8 compatibility requirement with low startup overhead.

---

## 2. Persistence & Block Storage

Implement `MeshChainCore.BlockStore` with a durable backend.

### Spring Data JPA + Hibernate

Maps the `Block` value object to a relational table. Provides CRUD repositories,
pagination, and query derivation out of the box.

```java
@Entity
@Table(name = "blocks")
public class BlockEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private Long blockIndex;

    @Column(length = 64, nullable = false, unique = true)
    private String blockHash;

    @Lob
    private String json;          // store the full canonical JSON
    // … getters / setters
}

@Repository
public interface BlockRepository extends JpaRepository<BlockEntity, Long> {
    Optional<BlockEntity> findTopByOrderByBlockIndexDesc();
}

// Adapter — implements MeshChainCore.BlockStore
@Service
public class JpaBlockStore implements MeshChainCore.BlockStore {

    @Autowired BlockRepository repo;

    @Override
    public void save(MeshChainCore.Block block) {
        BlockEntity e = new BlockEntity();
        e.setBlockIndex(block.index);
        e.setBlockHash(block.blockHash);
        e.setJson(block.toJson());
        repo.save(e);
    }

    @Override
    public List<MeshChainCore.Block> loadAll() {
        return repo.findAll(Sort.by("blockIndex"))
                   .stream()
                   .map(e -> MeshChainCore.parseBlock(e.getJson()))
                   .collect(Collectors.toList());
    }

    @Override
    public MeshChainCore.Block loadLatest() {
        return repo.findTopByOrderByBlockIndexDesc()
                   .map(e -> MeshChainCore.parseBlock(e.getJson()))
                   .orElse(null);
    }

    @Override
    public long count() { return repo.count(); }
}
```

**Best for:** relational databases (PostgreSQL, MySQL, H2 for tests).

---

### Spring Data MongoDB

Document-oriented store — the block JSON maps naturally to a BSON document
without any ORM mapping layer.

```java
@Document(collection = "blocks")
public class BlockDocument {
    @Id private String blockHash;
    private long index;
    private String json;
}

@Repository
public interface BlockMongoRepository extends MongoRepository<BlockDocument, String> {
    Optional<BlockDocument> findTopByOrderByIndexDesc();
}
```

**Best for:** append-only workloads; JSON-native queries; no fixed schema migration.

---

### Jdbi / jOOQ

Lightweight SQL mappers that give full control over queries without the overhead
of a full ORM. Good when Hibernate feels like too much for a simple ledger table.

```java
// jOOQ example
DSLContext ctx = DSL.using(dataSource, SQLDialect.POSTGRES);

public void save(MeshChainCore.Block block) {
    ctx.insertInto(BLOCKS)
       .set(BLOCKS.BLOCK_INDEX, block.index)
       .set(BLOCKS.BLOCK_HASH,  block.blockHash)
       .set(BLOCKS.JSON,        block.toJson())
       .execute();
}
```

**Best for:** teams who want SQL control without JPA magic.

---

## 3. Consensus — Proof of Storage

Implement `MeshChainCore.ConsensusMechanism` to gate block minting.

### Java Concurrency Utilities (`java.util.concurrent`)

Already available in Java 8. The built-in `ExecutorService` + `Future` pattern
(same as the core uses for server polling) is the right base for a
proof-of-storage loop that downloads and verifies files in parallel.

```java
public class ProofOfStorageConsensus implements MeshChainCore.ConsensusMechanism {

    private final FileDownloadService downloader;

    @Override
    public boolean check(String fileRef, List<String> servers) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(16);
        List<Future<Boolean>> futures = new ArrayList<>();

        for (String server : servers) {
            futures.add(pool.submit(() -> downloader.verifyFile(server, fileRef)));
        }
        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.MINUTES);

        long passing = futures.stream()
            .filter(f -> { try { return f.get(); } catch (Exception e) { return false; } })
            .count();

        return passing > servers.size() / 2;   // strict majority
    }
}
```

No extra framework needed — but the following can enrich it:

### Spring Retry

Automatically retry failed server verifications with back-off, without
hand-rolling retry loops.

```java
@Retryable(maxAttempts = 3, backoff = @Backoff(delay = 1000, multiplier = 2))
public boolean verifyFile(String server, String fileRef) { … }
```

### Resilience4j

Circuit breaker + rate limiter for server calls during consensus. Prevents a
slow/dead server from blocking the entire round.

```java
CircuitBreaker cb = CircuitBreaker.ofDefaults("mesh-server");
Supplier<Boolean> decorated = CircuitBreaker.decorateSupplier(cb,
    () -> downloader.verifyFile(server, fileRef));
```

---

## 4. P2P Network & Block Propagation

Broadcast newly minted blocks to peer nodes and receive theirs.

### Spring WebFlux WebSocket

Reactive WebSocket server and client in one dependency. Peers connect, and each
`BLOCK_ADDED` event is pushed to all subscribers.

```java
@Component
public class BlockWebSocketHandler implements WebSocketHandler {

    @Autowired MeshChainCore core;

    @Override
    public Mono<Void> handle(WebSocketSession session) {
        // Receive blocks from peer
        Mono<Void> receive = session.receive()
            .map(msg -> MeshChainCore.parseBlock(msg.getPayloadAsText()))
            .doOnNext(block -> { try { core.getBlockStore().save(block); }
                                 catch (Exception e) { /* log */ } })
            .then();

        // Send new blocks to peer via EventSink
        Flux<WebSocketMessage> send = Flux.create(sink ->
            core.setEventSink(json -> sink.next(session.textMessage(json))));

        return session.send(send).and(receive);
    }
}
```

### Netty (via Vert.x or direct)

Lower-level but extremely high-throughput. Vert.x wraps Netty with an
event-loop model and a simple `EventBus` that maps well to `EventSink`.

```java
Vertx vertx = Vertx.vertx();
vertx.createHttpServer()
     .webSocketHandler(ws -> ws.textMessageHandler(json -> {
         MeshChainCore.Block b = MeshChainCore.parseBlock(json);
         try { core.getBlockStore().save(b); } catch (Exception e) { }
     }))
     .listen(8080);

// Wire EventSink to broadcast
core.setEventSink(json ->
    vertx.eventBus().publish("mesh.blocks", json));
```

### gRPC (grpc-java)

Strongly typed binary protocol; ideal for internal cluster communication where
all nodes speak Java. Define a `BlockService` proto and generate stubs.

```protobuf
service BlockService {
    rpc PropagateBlock (BlockRequest) returns (BlockResponse);
    rpc StreamBlocks   (google.protobuf.Empty) returns (stream BlockRequest);
}
```

**Best for:** high-volume multi-node deployments; protobuf schema enforces the
block contract across language boundaries.

---

## 5. Coin Wallet & Reward Accounting

Tally rewards from `metadata.reward` per public key by listening to `EventSink`.

### Spring Data JPA (Wallet Table)

A simple `wallets` table keyed by public key hash with a balance column.
The `EventSink` fires on every `BLOCK_ADDED`; the wallet service updates the
balance transactionally.

```java
@Service
@Transactional
public class WalletService {

    @Autowired WalletRepository repo;

    public void onBlockAdded(String eventJson) {
        String minerKey = MeshChainCore.extractField(eventJson, "miner_key");
        long reward     = MeshChainCore.parseLong(
                              MeshChainCore.extractField(eventJson, "reward"));
        if (reward <= 0) return;

        String keyHash = MeshChainCore.sha256Hex(
                             minerKey.getBytes(StandardCharsets.UTF_8));
        repo.findById(keyHash).ifPresentOrElse(
            w -> { w.setBalance(w.getBalance() + reward); repo.save(w); },
            () -> repo.save(new Wallet(keyHash, minerKey, reward))
        );
    }
}
```

### Spring Events (`ApplicationEventPublisher`)

Bridge between `EventSink` and any Spring `@EventListener` without coupling
the core to Spring.

```java
// In @Configuration
core.setEventSink(json ->
    publisher.publishEvent(new BlockAddedEvent(this, json)));

// In WalletService
@EventListener
public void handleBlockAdded(BlockAddedEvent event) {
    onBlockAdded(event.getJson());
}
```

---

## 6. Scheduled Tasks & Background Jobs

Periodic consensus checks, server-list refresh, chain re-validation.

### Spring `@Scheduled`

Zero-config cron/rate-based scheduling inside a Spring Boot app.

```java
@Component
public class ChainMaintenanceTask {

    @Autowired MeshChainCore core;

    // Re-verify chain integrity every hour
    @Scheduled(fixedRate = 3_600_000)
    public void verifyChain() throws Exception {
        List<String> errors = core.verifyChain();
        if (!errors.isEmpty()) {
            log.error("Chain integrity failures: {}", errors);
        }
    }

    // Refresh server list and trigger key election every 10 minutes
    @Scheduled(fixedRate = 600_000)
    public void refreshElection() {
        // call electServerPublicKey() for tracked file hashes
    }
}
```

### Quartz Scheduler

Persistent job store (jobs survive restarts), clustering, and fine-grained
misfire handling — useful when the consensus check must not be skipped even
after a node restart.

```java
JobDetail job = JobBuilder.newJob(ConsensusCheckJob.class)
    .withIdentity("consensusCheck")
    .build();

Trigger trigger = TriggerBuilder.newTrigger()
    .withSchedule(CronScheduleBuilder.cronSchedule("0 */10 * * * ?"))
    .build();

scheduler.scheduleJob(job, trigger);
```

---

## 7. Security & Authentication

Protect the REST API and admin operations.

### Spring Security

Industry-standard authentication and authorisation for Spring Boot. Pair with
JWT so stateless nodes can authenticate each other using their RSA keys —
the same keys the blockchain already manages.

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.GET,  "/api/v1/blocks/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/v1/blocks").authenticated()
                .anyRequest().denyAll()
            )
            .addFilterBefore(jwtFilter(), UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
```

### JJWT (Java JWT)

Lightweight JWT creation and parsing. The miner's existing RSA private key can
sign JWT tokens, so the blockchain key pair doubles as the node's API identity.

```java
// Sign a JWT with the miner's RSA private key
String token = Jwts.builder()
    .setSubject(minerPublicKeyBase64)
    .setExpiration(Date.from(Instant.now().plusSeconds(3600)))
    .signWith(keyPair.getPrivate(), SignatureAlgorithm.RS256)
    .compact();

// Verify using the miner's public key
Claims claims = Jwts.parserBuilder()
    .setSigningKey(keyPair.getPublic())
    .build()
    .parseClaimsJws(token)
    .getBody();
```

### Bouncy Castle

Extends the JVM with additional algorithms (Ed25519, ECDSA, AES-GCM) when
RSA-2048 is not sufficient for a particular security profile. Drop-in JCE
provider — MeshChainCore's crypto helpers (`sha256Hex`, `signBase64`) remain
unchanged; only the key generation changes.

```java
Security.addProvider(new BouncyCastleProvider());
KeyPairGenerator kpg = KeyPairGenerator.getInstance("Ed25519", "BC");
```

---

## 8. Blockchain Explorer UI

Human-readable view of the chain, blocks, balances, and server health.

### Spring MVC + Thymeleaf

Server-side rendering. Each block JSON is parsed with `MeshChainCore.parseBlock()`
and passed to a Thymeleaf template.

```java
@Controller
public class ExplorerController {

    @Autowired MeshChainCore core;

    @GetMapping("/explorer")
    public String explorer(Model model) throws Exception {
        model.addAttribute("blocks", core.getBlockStore().loadAll());
        model.addAttribute("errors", core.verifyChain());
        return "explorer";
    }
}
```

```html
<!-- explorer.html -->
<tr th:each="block : ${blocks}">
    <td th:text="${block.index}"></td>
    <td th:text="${#strings.abbreviate(block.blockHash, 16)}"></td>
    <td th:text="${block.fileRef}"></td>
    <td th:text="${block.minerKey.substring(0,20) + '…'}"></td>
</tr>
```

### Vaadin

Full-stack Java UI framework — write the entire frontend in Java, no HTML/JS
required. Ideal for internal dashboards where developer productivity matters
more than bundle size.

```java
@Route("explorer")
public class ExplorerView extends VerticalLayout {

    public ExplorerView(MeshChainCore core) throws Exception {
        Grid<MeshChainCore.Block> grid = new Grid<>();
        grid.addColumn(b -> b.index).setHeader("Index");
        grid.addColumn(b -> b.fileRef).setHeader("File Ref");
        grid.addColumn(b -> b.blockHash.substring(0, 16) + "…").setHeader("Hash");
        grid.setItems(core.getBlockStore().loadAll());
        add(grid);
    }
}
```

### Spring Boot + REST + React / Vue (SPA)

Serve the REST API from Spring Boot and build the explorer as a standalone
Single-Page Application. The frontend consumes `/api/v1/blocks` and renders
the chain. This is the cleanest separation for teams with dedicated frontend
developers.

---

## 9. Distributed / Cloud Storage

Alternative `BlockStore` implementations for production environments.

### AWS SDK for Java (S3)

Store each block JSON as an S3 object keyed by `<index>_<fileHash>.json`.
S3 provides durability, versioning, and replication with no server management.

```java
public class S3BlockStore implements MeshChainCore.BlockStore {

    private final S3Client s3;
    private final String bucket;

    @Override
    public void save(MeshChainCore.Block block) {
        String key  = String.format("%020d_%s.json", block.index, block.fileHash);
        byte[] body = block.toJson().getBytes(StandardCharsets.UTF_8);
        s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).build(),
                     RequestBody.fromBytes(body));
    }

    @Override
    public List<MeshChainCore.Block> loadAll() {
        return s3.listObjectsV2Paginator(r -> r.bucket(bucket))
                 .contents().stream()
                 .sorted(Comparator.comparing(S3Object::key))
                 .map(obj -> {
                     ResponseBytes<GetObjectResponse> resp =
                         s3.getObjectAsBytes(r -> r.bucket(bucket).key(obj.key()));
                     return MeshChainCore.parseBlock(resp.asUtf8String());
                 })
                 .collect(Collectors.toList());
    }
    // … loadLatest(), count()
}
```

### IPFS (java-ipfs-http-client)

Pin each block JSON to IPFS. The CID becomes an immutable content address that
any node can retrieve — natural fit for a decentralised mesh network.

```java
IPFS ipfs = new IPFS("/ip4/127.0.0.1/tcp/5001");

public void save(MeshChainCore.Block block) throws Exception {
    NamedStreamable.ByteArrayWrapper file =
        new NamedStreamable.ByteArrayWrapper(
            block.fileHash + ".json",
            block.toJson().getBytes(StandardCharsets.UTF_8));
    MerkleNode result = ipfs.add(file).get(0);
    // persist result.hash (CID) alongside block index in a local index file
}
```

### Redis (Lettuce / Spring Data Redis)

High-speed in-memory store useful for the latest-block cache or for a real-time
leaderboard of miner balances. Not a primary store — use alongside a durable
backend.

```java
@Autowired StringRedisTemplate redis;

// Cache the latest block hash for fast chain-tip queries
public void cacheLatest(MeshChainCore.Block b) {
    redis.opsForValue().set("chain:latest:hash",  b.blockHash);
    redis.opsForValue().set("chain:latest:index", String.valueOf(b.index));
}
```

---

## 10. Testing

### JUnit 5 + Mockito

Unit-test each `BlockStore` or `ConsensusMechanism` implementation in isolation.
Mock the `MeshChainCore` itself to test dependent services.

```java
@ExtendWith(MockitoExtension.class)
class JpaBlockStoreTest {

    @Mock BlockRepository repo;
    @InjectMocks JpaBlockStore store;

    @Test
    void save_persists_block() throws Exception {
        MeshChainCore core = new MeshChainCore();
        core.init();
        MeshChainCore.Block block = core.mintBlock("abc123.jpg", null);

        store.save(block);

        ArgumentCaptor<BlockEntity> captor = ArgumentCaptor.forClass(BlockEntity.class);
        verify(repo).save(captor.capture());
        assertEquals(block.blockHash, captor.getValue().getBlockHash());
    }
}
```

### Spring Boot Test (`@SpringBootTest`)

Integration test the full stack — REST controller → core → block store — with
an embedded H2 database and MockMvc for HTTP assertions.

```java
@SpringBootTest
@AutoConfigureMockMvc
class BlockControllerIntegrationTest {

    @Autowired MockMvc mvc;

    @Test
    void mint_returns_201() throws Exception {
        mvc.perform(post("/api/v1/blocks?fileRef=abc123.jpg"))
           .andExpect(status().isCreated())
           .andExpect(jsonPath("$.index").value(1))
           .andExpect(jsonPath("$.blockHash").isNotEmpty());
    }
}
```

### Testcontainers

Spin up real PostgreSQL, MongoDB, or Redis containers inside unit tests so that
`BlockStore` integration tests run against the actual database engine.

```java
@Testcontainers
class PostgresBlockStoreTest {

    @Container
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:16");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", pg::getJdbcUrl);
        r.add("spring.datasource.username", pg::getUsername);
        r.add("spring.datasource.password", pg::getPassword);
    }
    // … tests
}
```

### WireMock

Simulate mesh server HTTP responses (files.txt, /info/*.json) in consensus and
key-election tests without needing a real server network.

```java
WireMockServer server = new WireMockServer(8089);
server.start();

server.stubFor(get(urlEqualTo("/info/abc123.json"))
    .willReturn(okJson("{\"public_key\":\"MIIBIjAN…\"}")));

// Now electServerPublicKey() will call localhost:8089 instead of a real peer
List<String> servers = List.of("http://localhost:8089");
String key = core.electServerPublicKey("abc123", servers);
assertEquals("MIIBIjAN…", key);
```

---

## 11. Quick-Reference Matrix

| Module | Recommended Framework | Extension Point | Notes |
|---|---|---|---|
| REST API | Spring Boot Web MVC | — | Most ecosystem support |
| REST API (reactive) | Spring WebFlux | — | SSE / WebSocket streaming |
| REST API (native) | Quarkus / Micronaut | — | Fast startup, small image |
| Relational storage | Spring Data JPA + Hibernate | `BlockStore` | PostgreSQL / MySQL |
| Document storage | Spring Data MongoDB | `BlockStore` | JSON-native |
| SQL (no ORM) | jOOQ / Jdbi | `BlockStore` | Full SQL control |
| Cloud storage | AWS SDK S3 | `BlockStore` | Durable, managed |
| Decentralised storage | IPFS java-client | `BlockStore` | Content-addressed |
| Cache / leaderboard | Spring Data Redis (Lettuce) | — | Complement to primary store |
| Proof of storage | `java.util.concurrent` | `ConsensusMechanism` | No extra dep needed |
| Retry / circuit breaker | Resilience4j / Spring Retry | `ConsensusMechanism` | Fault-tolerant server calls |
| P2P WebSocket | Spring WebFlux WebSocket | `EventSink` | Per-peer streams |
| P2P high-throughput | Vert.x / Netty | `EventSink` | Event-loop model |
| P2P typed protocol | gRPC (grpc-java) | `EventSink` | Protobuf schema |
| Event bus | Spring `ApplicationEventPublisher` | `EventSink` | In-process fan-out |
| Coin wallet | Spring Data JPA + `@EventListener` | `EventSink` | Balance ledger |
| API authentication | Spring Security + JJWT | — | RSA key reuse for JWT |
| Extended crypto | Bouncy Castle | — | Ed25519, ECDSA, AES-GCM |
| Scheduling | Spring `@Scheduled` | — | Simple; in-process |
| Scheduling (persistent) | Quartz | — | Survives restarts |
| Explorer UI (server) | Spring MVC + Thymeleaf | — | Server-side templates |
| Explorer UI (Java) | Vaadin | — | No HTML/JS needed |
| Explorer UI (SPA) | Spring Boot REST + React/Vue | — | Frontend team separation |
| Unit tests | JUnit 5 + Mockito | — | All modules |
| Integration tests | Spring Boot Test + MockMvc | — | Full stack |
| DB integration tests | Testcontainers | — | Real engine in CI |
| HTTP mock tests | WireMock | — | Simulate mesh servers |