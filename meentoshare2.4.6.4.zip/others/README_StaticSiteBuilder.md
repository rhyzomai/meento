# Static Site Builder

A zero-dependency Java 8 tool that reads a flat folder of media files and their JSON metadata, then generates a fully static, paginated HTML gallery organised by auto-detected categories.

No frameworks, no external libraries � just the standard Java library and plain HTML/CSS/JS output.

---

## Requirements

- Java 8 or later (`javac` / `java`)
- No third-party dependencies

---

## Input directory layout

```
<base>/
+-- files/          ? your media files (any extension)
�   +-- abc123.mp4
�   +-- xyz456.jpg
�   +-- ...
+-- info/           ? one JSON file per media file, named <stem>.json
�   +-- abc123.json
�   +-- xyz456.json
�   +-- ...
+-- thumbs/         ? optional JPEG thumbnails for video files, named <stem>.jpg
    +-- abc123.jpg
    +-- ...
```

### info JSON format

Each JSON file must live in `info/` with the same base name as the media file it describes. The only required field is `original_filename`; all other fields are displayed as metadata on hover.

```json
{
  "original_filename": "Some_Cool_Movie_720p.mp4",
  "title": "Some Cool Movie",
  "year": "2023",
  "director": "Jane Doe"
}
```

The value of `original_filename` is used to derive category tags. All other key/value pairs are shown as an info overlay when hovering over a tile.

---

## Output directory layout

```
<base>/
+-- index.html                        ? root gallery, page 1
+-- pages/
�   +-- index_2.html                  ? root gallery, page 2
�   +-- index_3.html                  ? root gallery, page 3 �
+-- categories/
    +-- movie/
    �   +-- index.html                ? category page 1
    �   +-- index_2.html              ? category page 2 �
    +-- mp4/
    �   +-- index.html
    +-- ...
```

All paths are relative � the output can be served from any static host or opened directly from the filesystem.

---

## Compile and run

```bash
# Compile
javac StaticSiteBuilder.java

# Run in the current directory
java StaticSiteBuilder

# Run pointing at a specific base directory
java StaticSiteBuilder /path/to/your/gallery
```

If the `files/` directory does not exist, the tool creates a skeleton structure (`files/`, `info/`, `thumbs/`) and exits so you can populate it before running again.

---

## How categories are built

Each file gets assigned to one or more categories derived in two steps.

**Step 1 � filename tokens.** The `original_filename` field from the JSON is cleaned (`_` ? space, trimmed) and split on any non-letter character (spaces, dots, digits, dashes). Each resulting token is evaluated:

| Rule | Example skipped |
|---|---|
| Length = 2 characters | `"of"`, `"a"` |
| Contains any digit | `"720p"`, `"1080p"`, `"s01e03"` |
| Is a known file extension | `"mkv"`, `"png"`, `"mp3"` |

Tokens that pass all filters are slugified (lowercased, non-letters replaced by `-`) and used as category folder names. A maximum of **10 tags** are extracted per file.

**Step 2 � extension category.** The actual file extension on disk (`mp4`, `jpg`, `mkv`, �) is always added as an additional category, unconditionally. This guarantees every file appears in at least one type-based category even if no useful tokens survive step 1.

### Examples

| `original_filename` field | Categories created |
|---|---|
| `Some_Cool_Movie_1080p.mkv` | `some`, `cool`, `movie`, `mkv` |
| `5If9DHYL_720p.mp4` | `dhyl`, `mp4` |
| `nature_photo.jpg` | `nature`, `photo`, `jpg` |
| `podcast_episode_42.mp3` | `podcast`, `episode`, `mp3` |
| `beach_sunset_4k.png` | `beach`, `sunset`, `png` |

---

## Pagination

Pages are split when **either** of these limits is reached:

- **18 items** per page
- **100 KB** of estimated HTML per page

Root pages beyond page 1 are saved inside `pages/` so the root `index.html` is always the entry point. Category pages beyond page 1 stay inside their own `categories/<tag>/` folder.

---

## Search bar

Every generated page includes a sticky search bar at the top. Typing a term and pressing **Go** slugifies the input the same way category names are built and redirects to `categories/<slug>/index.html`. The redirect works correctly regardless of whether the current page is the root, a `pages/` page, or a category page.

---

## Sidebar

Every page shows a sidebar on the right (hidden on screens narrower than 768 px) listing up to **100 categories** in alphabetical order. Clicking any entry navigates to that category. The currently active category (on category pages) is highlighted.

---

## Video thumbnails

If a file has a video extension (`mp4`, `mkv`, `avi`, `mov`, `wmv`, `flv`, `webm`, `m4v`, `mpg`, `mpeg`, `3gp`, `ts`, `m2ts`) the builder looks for a JPEG thumbnail at `thumbs/<stem>.jpg`. If found, it is used as the tile image. If not found, a generic file placeholder is shown instead.

---

## Configuration constants

These are defined at the top of `StaticSiteBuilder.java` and can be changed before compiling:

| Constant | Default | Description |
|---|---|---|
| `PER_PAGE` | `18` | Maximum items per page |
| `MAX_PAGE_KB` | `100 � 1024` | Maximum page size in bytes |
| `MAX_TAGS` | `10` | Maximum categories derived from one filename |
| `SIDEBAR_MAX` | `100` | Maximum categories shown in the sidebar |