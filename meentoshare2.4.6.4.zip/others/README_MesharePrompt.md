# MesharePrompt

A single-file, console/prompt-based Java program (Java 8 compatible, no
external dependencies) that searches and downloads files distributed
across multiple file-sharing servers.

Each server exposes:

- `<server>/files.txt` � a list of stored filenames, one per line, each
  named `<sha256>.<ext>` (the SHA-256 hash of the file's contents plus
  its original extension).
- `<server>/files/<sha256>.<ext>` � the binary file itself.
- `<server>/info/<sha256>.json` � metadata about that file (e.g.
  `filename`, `size`, `extension`, `description`, `date`, ...).

MesharePrompt reads a local `servers.txt` (one server base URL per
line), queries every server, and lets you search and download matching
files from a single prompt.

## Requirements

- Java 8 or newer (JDK to compile, JRE to run).
- No external libraries � only the Java standard library.
- Network access to the servers listed in `servers.txt`.

## Setup

Place `MesharePrompt.java` in a folder together with a `servers.txt`
file listing the servers to query, one base URL per line:

```
http://localhost:8001
http://example-node.com
```

Trailing slashes are optional and stripped automatically.

## Compiling

```bash
javac MesharePrompt.java
```

This produces `MesharePrompt.class` plus a few inner-class `.class`
files (e.g. `MesharePrompt$FileEntry.class`). Keep them all together �
all are required to run the program.

## Running

```bash
java MesharePrompt
```

Run it from the folder containing `servers.txt`. On first run it will
create three subfolders next to itself if they don't already exist:

```
./files/   downloaded binary files, named <hash>.<ext>
./info/    downloaded JSON metadata, named <hash>.json
./log/     one JSON file per successful download, recording the
           downloaded filename and the date/time it was saved
```

Files are stored flat in `files/` and `info/` � there is no
per-server subfolder, since files are addressed by content hash.

## Using the prompt

You'll see a `>` prompt. Everything you type falls into one of these
cases:

### Search

Type any plain text and press Enter:

```
> cat
```

This searches every configured server. Matching is a case-insensitive
substring match against **any** field of a file's JSON metadata
(including the hash and extension). Results stream to the screen as
they're found � you don't have to wait for every server to finish
before seeing the first matches. At most 200 results are shown per
search (configurable down via `-options`, see below).

Each result looks like:

```
[3] 18ee59c08d88ea415fb77b688f154ce24338ee4942f364ccfe2bdf9776e7fbef.jpg  (server: http://localhost:8001)
      filename: cute_cat.jpg
      description: a very cute cat picture
      size: 34 bytes
```

If a result was already downloaded in a previous session (or earlier
in this one), it's labeled `[ALREADY DOWNLOADED]` and its metadata is
read from your local `info/` cache instead of being re-requested from
the server.

### Downloading a single result

After a search, type the result's number:

```
> 3
```

This downloads the binary from `<server>/files/<hash>.<ext>` and its
JSON sidecar, verifies the binary's actual SHA-256 hash matches the
hash in its filename, and only then saves both files locally and
writes a log entry. If the hash does **not** match, nothing is saved
and a warning is printed � this guards against corrupted or
tampered files.

### Downloading all results from the last search

```
> all
```

Downloads every result currently shown (applying the same hash
verification per file), skipping any that are already downloaded.

### `-getall`: download everything from every server

```
> -getall
```

Ignores search/matching entirely and attempts to download every
valid entry listed in every server's `files.txt`, applying the same
hash verification and already-downloaded skip logic.

### `-options`: settings menu

```
> -options
```

Opens a small menu:

1. **Random tries** (off by default) � when enabled, instead of
   checking every line of a server's `files.txt`, only a random
   subset of lines is checked per server. Useful for large servers
   where you want a quick sample instead of a full scan.
2. **Random tries count** � how many random lines to check per
   server when random tries is enabled (default: 10).
3. **Result limit** � maximum results shown per search, from 1 up to
   the hard cap of 200 (default: 200).

### Other commands

| Command         | Effect                                   |
|------------------|-------------------------------------------|
| `-help`          | Show the command list again               |
| `-exit` / `-quit`| Quit the program                          |

## Behavior notes / rules

- **Filename validation:** a line in `files.txt` is only accepted if
  it matches `<64-character-hex-sha256>.<extension>`. Malformed
  lines are silently skipped.
- **Hash verification on download:** a binary is only kept if its
  computed SHA-256 matches the hash encoded in its filename. On
  mismatch, neither the binary nor its JSON sidecar is saved.
- **Skip already-downloaded files:** if a hash is already present
  locally (both `files/<hash>.*` and `info/<hash>.json` exist), the
  program does not re-request its info JSON or re-download it � it's
  still shown in search results, using the cached local metadata.
- **Field truncation:** every JSON metadata field value is truncated
  to a maximum of 512 characters, both on screen and in the saved
  `info/<hash>.json` file.
- **Result cap:** a single search shows at most 200 results (or
  fewer, if you've lowered the limit in `-options`).
- **Download log:** every successful download writes
  `log/<hash>.<ext>.json` containing the filename and the date/time
  it was downloaded.

## Example session

```
=========================================
 MesharePrompt
=========================================
Loaded 2 server(s) from servers.txt.

> cat
Searching for "cat" across 2 server(s)...
[1] 18ee59c0...fbef.jpg  (server: http://localhost:8001)
      filename: cute_cat.jpg
      description: a very cute cat picture
      size: 34 bytes
[2] 29335551...d622.jpg  (server: http://localhost:8002)
      filename: another_cat.jpg
      description: another cat picture on server 2
      size: 32 bytes

2 result(s) shown. Type a number to download it, or "all" to download all of them.

> 1
OK: saved files/18ee59c0...fbef.jpg and info/18ee59c0...fbef.json

> -exit
Bye.
```