﻿<?php
// ============================================================
// CONFIGURATION
// ============================================================
define('SERVERS_FILE', 'servers.txt');
define('IP_CHECK_DIR', 'ip_check');
define('SALT', 'MeentoShare_s3cr3t_salt_2024');
define('CHECK_ONLINE', false); // Set to true to enable URL online check before adding

// ============================================================
// ALLOWED FILE EXTENSIONS
// ============================================================
$allowed_extensions = [
    'jpg','jpeg','png','gif','webp','bmp','svg','tiff','ico',
    'mp4','mkv','avi','mov','wmv','flv','webm','m4v',
    'mp3','wav','ogg','flac','aac','wma','m4a',
    'zip','rar','7z','tar','gz','bz2','xz',
    'pdf','doc','docx','xls','xlsx','ppt','pptx',
    'txt','csv','json','xml',
    'apk','exe','dmg','iso','torrent'
];

// ============================================================
// HELPER: Check if URL ends with a valid filename/extension
// ============================================================
function has_valid_extension(string $url, array $allowed): bool {
    $path = parse_url($url, PHP_URL_PATH);
    if (!$path) return false;
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    return $ext !== '' && in_array($ext, $allowed, true);
}

// ============================================================
// HELPER: Check if URL is reachable
// ============================================================
function is_url_online(string $url): bool {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_NOBODY         => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'MeentoShare/1.0',
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 400;
}

// ============================================================
// HELPER: Get IP hash filename for today
// ============================================================
function get_ip_file(): string {
    $ip   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $ip   = explode(',', $ip)[0];
    $date = date('Ymd');
    $hash = hash('sha256', $ip . $date . SALT);
    return IP_CHECK_DIR . DIRECTORY_SEPARATOR . $hash;
}

// ============================================================
// PROCESS FORM SUBMISSION
// ============================================================
$message      = '';
$message_type = ''; // 'success' | 'error' | 'warning'

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $raw_url = trim($_POST['url']);

    do {
        // Basic URL validation
        if ($raw_url === '') {
            $message      = 'Please enter a URL.';
            $message_type = 'error';
            break;
        }

        if (mb_strlen($raw_url) > 500) {
            $message      = 'URL must not exceed 500 characters.';
            $message_type = 'error';
            break;
        }

        if (!filter_var($raw_url, FILTER_VALIDATE_URL)) {
            $message      = 'The URL you entered is not valid.';
            $message_type = 'error';
            break;
        }

        // Extension check
        if (!has_valid_extension($raw_url, $allowed_extensions)) {
            $message      = 'The URL must point to a file with a valid extension (e.g. .zip, .mp4, .jpg …).';
            $message_type = 'error';
            break;
        }

        // IP-per-day check — create ip_check dir if missing
        if (!is_dir(IP_CHECK_DIR)) {
            mkdir(IP_CHECK_DIR, 0750, true);
        }

        $ip_file = get_ip_file();

        if (file_exists($ip_file)) {
            $message      = 'You have already submitted a URL today. Please come back tomorrow.';
            $message_type = 'warning';
            break;
        }

        // Online check (optional)
        if (CHECK_ONLINE && !is_url_online($raw_url)) {
            $message      = 'The URL does not appear to be reachable. Please check it and try again.';
            $message_type = 'error';
            break;
        }

        // Write to servers.txt with exclusive lock (avoid race conditions & duplicates)
        $fp = fopen(SERVERS_FILE, 'c+');
        if (!$fp) {
            $message      = 'Server error: could not open storage file.';
            $message_type = 'error';
            break;
        }

        if (!flock($fp, LOCK_EX)) {
            fclose($fp);
            $message      = 'Server busy. Please try again in a moment.';
            $message_type = 'error';
            break;
        }

        // Read existing lines
        $existing = [];
        while (($line = fgets($fp)) !== false) {
            $trimmed = trim($line);
            if ($trimmed !== '') {
                $existing[] = $trimmed;
            }
        }

        if (in_array($raw_url, $existing, true)) {
            flock($fp, LOCK_UN);
            fclose($fp);
            $message      = 'This URL is already in our list.';
            $message_type = 'warning';
            break;
        }

        // Append the new URL
        fseek($fp, 0, SEEK_END);
        fwrite($fp, $raw_url . PHP_EOL);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        // Mark this IP for today (create empty file)
        $fh = fopen($ip_file, 'x'); // 'x' fails if file exists — safe
        if ($fh) {
            fclose($fh);
        }

        $message      = 'Your URL has been added successfully. Thank you!';
        $message_type = 'success';

    } while (false);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meento Share — Easy File Sharing</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
  /* ===================== RESET & BASE ===================== */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --green:      #22c55e;
    --green-dark: #16a34a;
    --green-glow: rgba(34,197,94,.35);
    --white:      #ffffff;
    --white-dim:  rgba(255,255,255,.70);
    --overlay:    rgba(0,0,0,.52);
    --glass:      rgba(255,255,255,.08);
    --glass-border: rgba(255,255,255,.15);
    --radius:     14px;
    --font-title: 'Bebas Neue', sans-serif;
    --font-body:  'Nunito', sans-serif;
  }

  html, body {
    height: 100%;
    font-family: var(--font-body);
    color: var(--white);
    background: #0a0a0a;
  }

  /* ===================== HERO / BACKGROUND ===================== */
  .hero {
    position: relative;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 40px 20px 100px;
    overflow: hidden;
  }

  .hero-bg {
    position: absolute;
    inset: 0;
    background-image: url('https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1600&q=80');
    background-size: contain;   /* preserve image proportion */
    background-repeat: no-repeat;
    background-position: center center;
    z-index: 0;
  }

  /* Dark overlay so text is legible */
  .hero-bg::after {
    content: '';
    position: absolute;
    inset: 0;
    background: var(--overlay);
  }

  /* Ambient glow blobs */
  .blob {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: .35;
    z-index: 0;
    pointer-events: none;
  }
  .blob-1 { width: 500px; height: 500px; background: #065f46; top: -150px; left: -150px; }
  .blob-2 { width: 400px; height: 400px; background: #14532d; bottom: -100px; right: -100px; }

  .hero-content {
    position: relative;
    z-index: 1;
    max-width: 700px;
  }

  /* ===================== TYPOGRAPHY ===================== */
  .brand-title {
    font-family: var(--font-title);
    font-size: clamp(72px, 14vw, 160px);
    line-height: .92;
    letter-spacing: .03em;
    color: var(--white);
    text-shadow: 0 4px 40px rgba(0,0,0,.6);
    animation: fadeDown .7s ease both;
  }

  .brand-subtitle {
    font-size: clamp(15px, 2.5vw, 22px);
    font-weight: 300;
    color: var(--white-dim);
    letter-spacing: .25em;
    text-transform: uppercase;
    margin-top: 6px;
    animation: fadeDown .7s .15s ease both;
  }

  /* ===================== FORM SECTION ===================== */
  .form-section {
    margin-top: 38px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 14px;
    width: 100%;
    animation: fadeUp .7s .25s ease both;
  }

  .url-field-wrap {
    display: flex;
    width: 100%;
    max-width: 560px;
    gap: 0;
    background: var(--glass);
    border: 1.5px solid var(--glass-border);
    border-radius: 50px;
    overflow: hidden;
    backdrop-filter: blur(12px);
    transition: border-color .25s, box-shadow .25s;
  }
  .url-field-wrap:focus-within {
    border-color: var(--green);
    box-shadow: 0 0 0 4px var(--green-glow);
  }

  .url-input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    padding: 15px 22px;
    font-family: var(--font-body);
    font-size: 15px;
    color: var(--white);
  }
  .url-input::placeholder { color: rgba(255,255,255,.4); }

  .submit-btn {
    background: var(--green);
    border: none;
    padding: 13px 28px;
    font-family: var(--font-body);
    font-size: 15px;
    font-weight: 700;
    color: #0a0a0a;
    cursor: pointer;
    transition: background .2s, transform .1s;
    white-space: nowrap;
    border-radius: 0 50px 50px 0;
  }
  .submit-btn:hover  { background: var(--green-dark); }
  .submit-btn:active { transform: scale(.97); }

  /* ===================== MESSAGE TOAST ===================== */
  .toast {
    max-width: 560px;
    width: 100%;
    padding: 12px 20px;
    border-radius: var(--radius);
    font-size: 14px;
    font-weight: 600;
    backdrop-filter: blur(12px);
    animation: fadeUp .4s ease both;
  }
  .toast.success { background: rgba(34,197,94,.2);  border: 1px solid rgba(34,197,94,.4);  color: #86efac; }
  .toast.error   { background: rgba(239,68,68,.2);  border: 1px solid rgba(239,68,68,.4);  color: #fca5a5; }
  .toast.warning { background: rgba(234,179,8,.15); border: 1px solid rgba(234,179,8,.35); color: #fde68a; }

  /* ===================== CTA BUTTON ===================== */
  .cta-btn {
    display: inline-block;
    margin-top: 10px;
    padding: 16px 48px;
    background: var(--green);
    color: #0a0a0a;
    font-family: var(--font-body);
    font-size: 17px;
    font-weight: 700;
    border-radius: 50px;
    text-decoration: none;
    letter-spacing: .04em;
    box-shadow: 0 8px 32px var(--green-glow);
    transition: background .2s, transform .15s, box-shadow .2s;
    animation: fadeUp .7s .35s ease both;
  }
  .cta-btn:hover {
    background: var(--green-dark);
    transform: translateY(-3px);
    box-shadow: 0 12px 40px var(--green-glow);
  }
  .cta-btn:active { transform: translateY(0); }

  /* ===================== ALT DOWNLOAD LINKS ===================== */
  .alt-links {
    margin-top: 20px;
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
    justify-content: center;
    animation: fadeUp .7s .45s ease both;
  }
  .alt-link {
    color: var(--white-dim);
    font-size: 13px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color .2s;
    letter-spacing: .03em;
  }
  .alt-link:hover { color: var(--green); }
  .alt-link svg { flex-shrink: 0; }

  /* ===================== FOOTER ===================== */
  footer {
    position: relative;
    z-index: 1;
    width: 100%;
    text-align: center;
    padding: 20px;
    font-size: 12px;
    color: rgba(255,255,255,.3);
    letter-spacing: .08em;
    text-transform: uppercase;
    border-top: 1px solid rgba(255,255,255,.06);
    margin-top: auto;
  }

  /* ===================== ANIMATIONS ===================== */
  @keyframes fadeDown {
    from { opacity: 0; transform: translateY(-24px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  /* ===================== RESPONSIVE ===================== */
  @media (max-width: 520px) {
    .url-field-wrap { flex-direction: column; border-radius: var(--radius); }
    .url-input      { padding: 14px 18px; }
    .submit-btn     { border-radius: 0 0 var(--radius) var(--radius); padding: 14px; }
    .alt-links      { gap: 16px; }
  }

  /* ===================== CHAR COUNTER ===================== */
  .char-counter {
    font-size: 12px;
    color: rgba(255,255,255,.35);
    letter-spacing: .04em;
    transition: color .2s;
    align-self: flex-end;
    margin-right: 4px;
  }
  .char-counter.warn  { color: #fde68a; }
  .char-counter.limit { color: #fca5a5; }

</style>
</head>
<body>

<section class="hero">
  <div class="hero-bg"></div>
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <div class="hero-content">

    <h1 class="brand-title">Meento Share</h1>
    <p class="brand-subtitle">Easy file sharing</p>

    <!-- URL Submission Form -->
    <div class="form-section">
      <?php if ($message !== ''): ?>
        <div class="toast <?= htmlspecialchars($message_type) ?>">
          <?= htmlspecialchars($message) ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="" style="width:100%;display:flex;flex-direction:column;align-items:center;gap:14px;">
        <div class="url-field-wrap">
          <input
            class="url-input"
            type="url"
            id="url-input"
            name="url"
            placeholder="Paste a direct file URL — e.g. https://example.com/file.zip"
            value="<?= isset($_POST['url']) ? htmlspecialchars($_POST['url']) : '' ?>"
            maxlength="500"
            autocomplete="off"
            spellcheck="false"
            oninput="updateCounter(this)"
          >
          <button class="submit-btn" type="submit">Share Link</button>
        </div>
        <div class="char-counter" id="char-counter">0 / 500</div>
      </form>
    </div>

    <!-- Primary CTA -->
    <a href="#" class="cta-btn">⬇ Download Now</a>

    <!-- Alternative download links -->
    <div class="alt-links">
      <a class="alt-link" href="#">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12" y2="18"/></svg>
        Android APK
      </a>
      <a class="alt-link" href="#">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 0 1 0 20A10 10 0 0 1 12 2z"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10A15.3 15.3 0 0 1 12 2z"/></svg>
        Web Version
      </a>
      <a class="alt-link" href="#">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><polyline points="8 21 12 17 16 21"/></svg>
        Windows / Mac
      </a>
      <a class="alt-link" href="#">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
        Source Code
      </a>
    </div>

  </div><!-- .hero-content -->

  <footer>
    &copy; <?= date('Y') ?> Meento Share &mdash; All rights reserved
  </footer>
</section>


<script>
function updateCounter(input) {
  var counter = document.getElementById('char-counter');
  var len = input.value.length;
  counter.textContent = len + ' / 500';
  counter.className = 'char-counter' + (len >= 500 ? ' limit' : len >= 400 ? ' warn' : '');
}
// Init counter on page load if field has a value (e.g. after failed POST)
window.addEventListener('DOMContentLoaded', function() {
  var input = document.getElementById('url-input');
  if (input) updateCounter(input);
});
</script>
</body>
</html>