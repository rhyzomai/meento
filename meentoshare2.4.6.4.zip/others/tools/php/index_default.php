﻿<?php
/**
 * Meento Share – Easy file sharing (submission form)
 * All in one file: config, logic & presentation.
 * 
 * Requirements:
 *   - Only URLs ending with allowed file extensions (e.g. .jpg, .mp4)
 *   - One submission per IP per day (folder "ip_check", atomic creation)
 *   - Duplicate URL prevention in servers.txt with locking
 *   - Optional online check (disabled by default)
 *   - URL length limited to 500 characters (client + server)
 */

/* ═══════════════════════════════════════════
   CONFIGURATION
   ═══════════════════════════════════════════ */

$check_url_online = false;   // Enable (true) to verify URL is reachable before adding
$servers_file     = 'servers.txt';
$ip_check_dir     = 'ip_check';               // Folder for daily per‑IP lock files
$hash_salt        = 'Meento_2025_SecureSalt!'; // Salt used for the IP hash filename

// Allowed file extensions (lowercase, without leading dot). Add/remove as needed.
$allowed_extensions = [
    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg',
    'mp4', 'avi', 'mkv', 'mov', 'wmv',
    'mp3', 'wav', 'flac', 'ogg', 'aac',
    'zip', 'rar', '7z', 'tar', 'gz',
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    'txt', 'csv', 'json', 'xml', 'log'
];


/* ── Helper: check if URL is online ── */
function is_url_online(string $url): bool {
    $headers = @get_headers($url);
    if ($headers === false) {
        return false;
    }
    preg_match('/\d{3}/', $headers[0], $matches);
    $code = (int)($matches[0] ?? 0);
    return ($code >= 200 && $code < 400);
}

/* ── Helper: add URL to servers.txt safely (locking + duplicate check) ── */
function add_url_to_file(string $url, string $file) {
    $fp = fopen($file, 'c+');
    if (!$fp) {
        return false;
    }

    if (flock($fp, LOCK_EX)) {
        $lines = [];
        while (($line = fgets($fp)) !== false) {
            $lines[] = trim($line);
        }

        if (in_array($url, $lines, true)) {
            flock($fp, LOCK_UN);
            fclose($fp);
            return 'duplicate';
        }

        fseek($fp, 0, SEEK_END);
        fwrite($fp, $url . PHP_EOL);
        fflush($fp);

        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }

    fclose($fp);
    return false;
}

/* ── Helper: get user IP (handle forwarded headers cautiously) ── */
function get_user_ip(): string {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // In case of multiple proxies, take the first IP
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

/* ── Process form submission ── */
$message      = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = trim($_POST['url']);

    // 0. Length limit check (max 500 characters)
    if (strlen($url) > 500) {
        $message      = 'URL exceeds maximum length of 500 characters.';
        $message_type = 'error';
    }
    // 1. Basic validation
    elseif ($url === '') {
        $message      = 'Please enter a URL.';
        $message_type = 'error';
    } elseif (!filter_var($url, FILTER_VALIDATE_URL)) {
        $message      = 'Invalid URL format.';
        $message_type = 'error';
    } else {
        // 2. Extract filename extension and check it’s allowed
        $path     = parse_url($url, PHP_URL_PATH);
        $filename = $path ? basename($path) : '';
        $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($ext === '' || !in_array($ext, $allowed_extensions, true)) {
            $message      = 'Only direct links to files are allowed. '
                          . 'Valid extensions: ' . implode(', ', $allowed_extensions) . '.';
            $message_type = 'error';
        } else {
            // 3. Optional online check (when enabled)
            if ($check_url_online && !is_url_online($url)) {
                $message      = 'The URL is not reachable right now. It was not added.';
                $message_type = 'error';
            } else {
                // 4. Enforce one submission per IP per day (atomic file creation)
                $ip        = get_user_ip();
                $date_ymd  = date('Ymd');
                $hash      = hash('sha256', $ip . $date_ymd . $hash_salt);
                $lock_file = $ip_check_dir . '/' . $hash . '.lock';

                // Ensure the directory exists
                if (!is_dir($ip_check_dir)) {
                    if (!mkdir($ip_check_dir, 0755, true)) {
                        $message      = 'Server configuration error. Please try again later.';
                        $message_type = 'error';
                        // Stop processing
                        goto render_page;
                    }
                }

                // Try to create the file exclusively (atomic check+create)
                $fp = @fopen($lock_file, 'x');
                if ($fp === false) {
                    // File already exists → today's limit already used
                    $message      = 'You can only submit one URL per day from this IP address.';
                    $message_type = 'error';
                } else {
                    // File created successfully → close it and proceed to add the URL
                    fclose($fp);

                    $result = add_url_to_file($url, $servers_file);
                    if ($result === true) {
                        $message      = 'Server URL added successfully!';
                        $message_type = 'success';
                    } elseif ($result === 'duplicate') {
                        $message      = 'This URL already exists in the list.';
                        $message_type = 'error';
                        // The daily lock file remains – no further submissions today
                    } else {
                        $message      = 'Could not write to the servers file. Please try again.';
                        $message_type = 'error';
                        // Delete the lock file to allow another attempt?
                        // (keep it – a write error is rare and the file prevents spam)
                    }
                }
            }
        }
    }
}

render_page:
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meento Share – Easy File Sharing</title>
    <style>
        :root {
            --green-btn: #2ecc71;
            --green-btn-hover: #27ae60;
            --text-color: #ffffff;
            --overlay-dark: rgba(0, 0, 0, 0.55);
            --input-bg: rgba(255, 255, 255, 0.12);
            --input-border: rgba(255, 255, 255, 0.45);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        html, body {
            height: 100%; width: 100%;
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            color: var(--text-color);
        }

        .background-wrapper {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -2;
            background-image: url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1950&q=80');
            background-size: cover; background-position: center; background-repeat: no-repeat;
            background-color: #1a1a2e;
        }

        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1;
            background: var(--overlay-dark); pointer-events: none;
        }

        .page-container {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            min-height: 100vh; padding: 2rem 1.5rem; text-align: center;
        }

        .hero-content {
            flex: 1; display: flex; flex-direction: column; align-items: center;
            justify-content: center; width: 100%; max-width: 650px;
            animation: fadeInUp 1s ease-out;
        }

        .brand-name {
            font-size: clamp(3.2rem, 8vw, 6.5rem); font-weight: 800;
            letter-spacing: 2px; line-height: 1.1; margin-bottom: 0.35rem;
            text-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }

        .tagline {
            font-size: clamp(1.1rem, 2.5vw, 1.55rem); font-weight: 400;
            letter-spacing: 1px; opacity: 0.9; margin-bottom: 2.2rem;
            text-shadow: 0 2px 10px rgba(0,0,0,0.35);
        }

        .server-form {
            width: 100%; display: flex; flex-direction: column; align-items: center; gap: 1.3rem;
        }

        .url-input {
            width: 100%; max-width: 500px; padding: 1rem 1.8rem; font-size: 1.3rem;
            font-weight: 500; color: #fff; background: var(--input-bg);
            border: 2px solid var(--input-border); border-radius: 50px; outline: none;
            transition: all 0.3s ease; backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px); text-align: center;
        }

        .url-input::placeholder { color: rgba(255,255,255,0.55); font-weight: 400; }
        .url-input:focus { border-color: #fff; background: rgba(255,255,255,0.18); }

        .btn-green {
            display: inline-block; background-color: var(--green-btn); color: #fff;
            font-size: 1.25rem; font-weight: 700; letter-spacing: 0.6px;
            padding: 0.9rem 3.2rem; border: none; border-radius: 50px; cursor: pointer;
            box-shadow: 0 8px 28px rgba(46,204,113,0.45); transition: all 0.3s ease;
        }

        .btn-green:hover {
            background-color: var(--green-btn-hover); transform: translateY(-3px);
            box-shadow: 0 14px 34px rgba(39,174,96,0.55);
        }

        .btn-green:active { transform: translateY(0); box-shadow: 0 6px 20px rgba(46,204,113,0.4); }

        .message-box {
            margin-top: 1.3rem; padding: 0.65rem 1.5rem; border-radius: 40px;
            font-weight: 600; font-size: 0.95rem; letter-spacing: 0.4px;
        }

        .message-success {
            background: rgba(46,204,113,0.25); border: 1px solid rgba(46,204,113,0.7);
            color: #ccffd0;
        }

        .message-error {
            background: rgba(231,76,60,0.25); border: 1px solid rgba(231,76,60,0.7);
            color: #ffd6d0;
        }

        .footer {
            width: 100%; text-align: center; padding: 1.4rem 1rem 1.2rem;
            font-size: 0.85rem; color: rgba(255,255,255,0.6); letter-spacing: 0.4px;
        }

        .footer span {
            border-top: 1px solid rgba(255,255,255,0.2); padding-top: 0.7rem; display: inline-block;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 480px) {
            .url-input { font-size: 1.1rem; padding: 0.85rem 1.5rem; }
            .btn-green { padding: 0.8rem 2.4rem; font-size: 1.1rem; }
        }

        /* ── Alternative download links ── */
        .alt-links {
            display: flex;
            flex-wrap: wrap;
            gap: 1.4rem;
            justify-content: center;
            margin-bottom: 1rem;
        }

        .alt-link {
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            font-size: 0.95rem;
            font-weight: 500;
            letter-spacing: 0.3px;
            border-bottom: 1.5px solid rgba(255, 255, 255, 0.4);
            padding-bottom: 3px;
            transition: all 0.25s ease;
        }

        .alt-link:hover {
            color: #ffffff;
            border-bottom-color: #ffffff;
            text-shadow: 0 0 12px rgba(255, 255, 255, 0.5);
        }

        .alt-separator {
            color: rgba(255, 255, 255, 0.45);
            font-weight: 300;
            display: none;
            /* hidden on mobile, visible on desktop via media query */;
        }

    </style>
</head>
<body>
    <div class="background-wrapper" aria-hidden="true"></div>
    <div class="overlay" aria-hidden="true"></div>

    <div class="page-container">
        <main class="hero-content">
            <h1 class="brand-name">Meento Share</h1>
            <p class="tagline">easy file sharing</p>

            <form method="post" action="" class="server-form" novalidate>
                <input 
                    type="url" 
                    name="url" 
                    class="url-input" 
                    placeholder="Paste your file URL here…" 
                    required 
                    aria-label="Server URL"
                    maxlength="500"
                    value="<?php echo isset($_POST['url']) ? htmlspecialchars($_POST['url'], ENT_QUOTES, 'UTF-8') : ''; ?>"
                >
                <button type="submit" class="btn-green">Add File</button>
            </form>

            <?php if ($message !== ''): ?>
                <div class="message-box <?php echo $message_type === 'success' ? 'message-success' : 'message-error'; ?>">
                    <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>
            <br>
            <!-- Alternative download links -->
            <div class="alt-links">
                <a href="upload.php" class="alt-link">Upload</a>
                <span class="alt-separator">|</span>
                <a href="README_meentophp.md" class="alt-link">About</a>
            </div>
        </main>

        <footer class="footer">
            <span>All rights reserved.</span>
        </footer>
    </div>
</body>
</html>