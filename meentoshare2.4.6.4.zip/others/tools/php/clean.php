﻿<?php
// The secret key that must match for cleaning to happen
$correct_key = 'blackcat';  // Change this to your own secret key

// Check if the GET parameter 'key' is present and matches the correct key
if (isset($_GET['key']) && $_GET['key'] === $correct_key) {
    // Open the file in write mode ('w') – this truncates the file to zero length
    $file_handle = fopen('servers.txt', 'w');
    
    if ($file_handle !== false) {
        // Close the file handle (no need to write anything extra)
        fclose($file_handle);
        // Output success message exactly as requested
        echo "the file was clean with success";
    }
    // If fopen fails, nothing is output (silent failure)
}
// For any wrong or missing key, the script outputs nothing
?>