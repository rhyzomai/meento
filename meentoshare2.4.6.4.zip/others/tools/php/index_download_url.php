﻿<?php
/**
 * Meento Share – Download & host files with original extensions
 * 
 * - Downloads a file from a given URL, stores it locally using SHA256 hash + original extension.
 * - Shows a link to open the file in a new tab.
 * - Prevents PHP files and executable files (by MIME type & content sniffing).
 * - One submission per IP per day, duplicate URL prevention.
 * - URL length limited to 500 characters.
 * 
 * All in one file: config, logic & presentation.
 */

/* ═══════════════════════════════════════════
   CONFIGURATION
   ═══════════════════════════════════════════ */

$check_url_online = false;          // Optional: verify URL reachable before download
$download_dir     = 'download';     // Folder where downloaded files are stored
$urls_map_file    = 'downloaded_urls.txt'; // Maps URL → hash + extension (tab-separated)
$ip_check_dir     = 'ip_check';     // Folder for daily per‑IP lock files
$hash_salt        = 'Meento_2025_SecureSalt!';
$max_file_size    = 200 * 1024 * 1024; // 200 MB max download size

// Disallowed MIME types (PHP scripts, executables, etc.)
$disallowed_mime = [
    'application/x-httpd-php',
    'text/x-php',
    'application/x-php',
    'application/x-msdownload',
    'application/x-executable',
    'application/x-dosexec',
    'application/vnd.microsoft.portable-executable',
    'application/x-elf',
    'application/x-sharedlib',
    'application/x-object',
    'text/x-shellscript',
    'application/x-bat',
    'application/x-msdos-program',
    'application/x-perl',
    'application/x-python',
];

/* ── Helper: serve a downloaded file (when ?file=hash is requested) ── */
if (isset($_GET['file']) && preg_match('/^[a-f0-9]{64}$/', $_GET['file'])) {
    $hash = $_GET['file'];
    // Look up extension from mapping file
    $extension = '';
    if (file_exists($urls_map_file)) {
        $fp = fopen($urls_map_file, 'r');
        if ($fp) {
            while (($line = fgets($fp)) !== false) {
                $line = trim($line);
                if ($line === '') continue;
                $parts = explode("\t", $line, 3);
                if (count($parts) >= 2 && $parts[1] === $hash) {
                    $extension = $parts[2] ?? '';
                    break;
                }
            }
            fclose($fp);
        }
    }
    // Build file path
    $filename = $hash . ($extension ? '.' . $extension : '');
    $file_path = $download_dir . '/' . $filename;
    if (file_exists($file_path) && is_file($file_path)) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file_path);
        finfo_close($finfo);
        header('Content-Type: ' . $mime);
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    } else {
        http_response_code(404);
        echo 'File not found.';
        exit;
    }
}

/* ── Helper: get user IP ── */
function get_user_ip(): string {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

/* ── Helper: check if URL is online (optional) ── */
function is_url_online(string $url): bool {
    $headers = @get_headers($url);
    if ($headers === false) return false;
    preg_match('/\d{3}/', $headers[0], $matches);
    $code = (int)($matches[0] ?? 0);
    return ($code >= 200 && $code < 400);
}

/* ── Helper: extract file extension from URL (sanitized) ── */
function get_extension_from_url(string $url): string {
    $path = parse_url($url, PHP_URL_PATH);
    if (!$path) return '';
    $basename = basename($path);
    $ext = pathinfo($basename, PATHINFO_EXTENSION);
    // Sanitize: allow only letters, numbers, dot, dash (basic)
    $ext = preg_replace('/[^a-zA-Z0-9\-]/', '', $ext);
    return strtolower($ext);
}

/* ── Helper: download URL to a temporary file, with size limit and follow redirects ── */
function download_to_temp(string $url, int $max_size, &$error = ''): ?string {
    $temp_file = tempnam(sys_get_temp_dir(), 'meento_');
    $fp = fopen($temp_file, 'wb');
    if (!$fp) {
        $error = 'Unable to create temporary file.';
        return null;
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE           => $fp,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_BUFFERSIZE     => 8192,
        CURLOPT_NOPROGRESS     => false,
        CURLOPT_PROGRESSFUNCTION => function($ch, $dload_size, $downloaded, $uload_size, $uploaded) use ($max_size, &$error) {
            if ($downloaded > $max_size) {
                $error = 'File exceeds maximum allowed size (' . ($max_size / 1024 / 1024) . ' MB).';
                return 1; // abort
            }
            return 0;
        },
    ]);

    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);

    if ($result === false) {
        unlink($temp_file);
        $error = 'Download failed: ' . curl_error($ch);
        return null;
    }
    if ($http_code < 200 || $http_code >= 400) {
        unlink($temp_file);
        $error = "HTTP error $http_code";
        return null;
    }

    // Check final file size
    $actual_size = filesize($temp_file);
    if ($actual_size > $max_size) {
        unlink($temp_file);
        $error = 'File exceeds maximum allowed size.';
        return null;
    }

    return $temp_file;
}

/* ── Helper: check if file content is a PHP script or executable ── */
function is_dangerous_file(string $filepath, array $disallowed_mime): bool {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $filepath);
    finfo_close($finfo);

    if (in_array($mime, $disallowed_mime, true)) {
        return true;
    }

    // Additional check for PHP tags in first 1KB (defense in depth)
    $handle = fopen($filepath, 'rb');
    $first_kb = fread($handle, 1024);
    fclose($handle);
    if (preg_match('/<\?php|<\?=/', $first_kb)) {
        return true;
    }

    return false;
}

/* ── Helper: store URL → hash + extension mapping (with locking) ── */
function record_url_info(string $url, string $hash, string $extension, string $map_file): bool {
    $fp = fopen($map_file, 'c+');
    if (!$fp) return false;

    if (flock($fp, LOCK_EX)) {
        // Read existing lines
        $lines = [];
        while (($line = fgets($fp)) !== false) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = explode("\t", $line, 3);
            if (count($parts) >= 2) {
                $lines[$parts[0]] = ['hash' => $parts[1], 'ext' => $parts[2] ?? ''];
            }
        }
        // Check if URL already exists
        if (isset($lines[$url])) {
            flock($fp, LOCK_UN);
            fclose($fp);
            return false; // duplicate URL
        }
        // Append new entry
        fseek($fp, 0, SEEK_END);
        fwrite($fp, $url . "\t" . $hash . "\t" . $extension . PHP_EOL);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }
    fclose($fp);
    return false;
}

/* ── Helper: get hash and extension for a given URL (if already downloaded) ── */
function get_url_info(string $url, string $map_file): ?array {
    if (!file_exists($map_file)) return null;
    $fp = fopen($map_file, 'r');
    if (!$fp) return null;
    while (($line = fgets($fp)) !== false) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode("\t", $line, 3);
        if (count($parts) >= 2 && $parts[0] === $url) {
            fclose($fp);
            return [
                'hash' => $parts[1],
                'ext'  => $parts[2] ?? '',
            ];
        }
    }
    fclose($fp);
    return null;
}

/* ═══════════════════════════════════════════
   PROCESS FORM SUBMISSION
   ═══════════════════════════════════════════ */
$message      = '';
$message_type = '';
$success_hash = null;
$success_ext  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = trim($_POST['url']);

    // 0. Length limit
    if (strlen($url) > 500) {
        $message = 'URL exceeds maximum length of 500 characters.';
        $message_type = 'error';
    }
    // 1. Basic validation
    elseif ($url === '') {
        $message = 'Please enter a URL.';
        $message_type = 'error';
    } elseif (!filter_var($url, FILTER_VALIDATE_URL)) {
        $message = 'Invalid URL format.';
        $message_type = 'error';
    } else {
        // 2. Optional online check
        if ($check_url_online && !is_url_online($url)) {
            $message = 'The URL is not reachable right now.';
            $message_type = 'error';
        } else {
            // 3. Enforce one submission per IP per day
            $ip = get_user_ip();
            $date_ymd = date('Ymd');
            $hash = hash('sha256', $ip . $date_ymd . $hash_salt);
            $lock_file = $ip_check_dir . '/' . $hash . '.lock';

            if (!is_dir($ip_check_dir)) {
                if (!mkdir($ip_check_dir, 0755, true)) {
                    $message = 'Server configuration error. Please try again later.';
                    $message_type = 'error';
                    goto render_page;
                }
            }

            $fp = @fopen($lock_file, 'x');
            if ($fp === false) {
                $message = 'You can only submit one URL per day from this IP address.';
                $message_type = 'error';
            } else {
                fclose($fp);

                // 4. Check if this URL was already downloaded
                $existing = get_url_info($url, $urls_map_file);
                if ($existing !== null) {
                    $success_hash = $existing['hash'];
                    $success_ext  = $existing['ext'];
                    $message = 'This URL was already downloaded. Link below.';
                    $message_type = 'success';
                    goto render_page;
                }

                // 5. Download the file
                $temp_file = download_to_temp($url, $max_file_size, $download_error);
                if ($temp_file === null) {
                    $message = 'Download failed: ' . $download_error;
                    $message_type = 'error';
                    @unlink($lock_file);
                } else {
                    // 6. Compute SHA256 hash of file content
                    $file_hash = hash_file('sha256', $temp_file);
                    // 7. Get file extension from original URL (sanitized)
                    $extension = get_extension_from_url($url);
                    $final_filename = $file_hash . ($extension ? '.' . $extension : '');
                    $final_path = $download_dir . '/' . $final_filename;

                    // 8. Check if a file with same hash already exists (duplicate content, possibly different URL)
                    if (file_exists($final_path)) {
                        // Already stored, just clean up temp and record mapping
                        unlink($temp_file);
                        if (record_url_info($url, $file_hash, $extension, $urls_map_file)) {
                            $success_hash = $file_hash;
                            $success_ext  = $extension;
                            $message = 'File already exists (identical content). Link below.';
                            $message_type = 'success';
                        } else {
                            $message = 'Could not save URL mapping. Please try again.';
                            $message_type = 'error';
                            @unlink($lock_file);
                        }
                    } else {
                        // 9. Security: reject PHP/executable files
                        if (is_dangerous_file($temp_file, $disallowed_mime)) {
                            unlink($temp_file);
                            $message = 'This file type is not allowed (PHP script or executable).';
                            $message_type = 'error';
                            @unlink($lock_file);
                        } else {
                            // 10. Create download directory if needed
                            if (!is_dir($download_dir)) {
                                mkdir($download_dir, 0755, true);
                            }
                            // Move temp file to final destination (with extension)
                            if (rename($temp_file, $final_path)) {
                                if (record_url_info($url, $file_hash, $extension, $urls_map_file)) {
                                    $success_hash = $file_hash;
                                    $success_ext  = $extension;
                                    $message = 'File downloaded and stored successfully!';
                                    $message_type = 'success';
                                } else {
                                    // Mapping failed, but file exists – still show link
                                    $success_hash = $file_hash;
                                    $success_ext  = $extension;
                                    $message = 'File stored, but duplicate record issue. Link below.';
                                    $message_type = 'success';
                                }
                            } else {
                                unlink($temp_file);
                                $message = 'Failed to save file on server.';
                                $message_type = 'error';
                                @unlink($lock_file);
                            }
                        }
                    }
                }
            }
        }
    }
}
render_page:
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meento Share – Download & Host Files</title>
    <style>
        :root {
            --green-btn: #2ecc71;
            --green-btn-hover: #27ae60;
            --text-color: #ffffff;
            --overlay-dark: rgba(0, 0, 0, 0.55);
            --input-bg: rgba(255, 255, 255, 0.12);
            --input-border: rgba(255, 255, 255, 0.45);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body {
            height: 100%; width: 100%;
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            color: var(--text-color);
        }
        .background-wrapper {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -2;
            background-image: url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1950&q=80');
            background-size: cover; background-position: center; background-repeat: no-repeat;
            background-color: #1a1a2e;
        }
        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1;
            background: var(--overlay-dark); pointer-events: none;
        }
        .page-container {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            min-height: 100vh; padding: 2rem 1.5rem; text-align: center;
        }
        .hero-content {
            flex: 1; display: flex; flex-direction: column; align-items: center;
            justify-content: center; width: 100%; max-width: 650px;
            animation: fadeInUp 1s ease-out;
        }
        .brand-name {
            font-size: clamp(3.2rem, 8vw, 6.5rem); font-weight: 800;
            letter-spacing: 2px; line-height: 1.1; margin-bottom: 0.35rem;
            text-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }
        .tagline {
            font-size: clamp(1.1rem, 2.5vw, 1.55rem); font-weight: 400;
            letter-spacing: 1px; opacity: 0.9; margin-bottom: 2.2rem;
            text-shadow: 0 2px 10px rgba(0,0,0,0.35);
        }
        .server-form {
            width: 100%; display: flex; flex-direction: column; align-items: center; gap: 1.3rem;
        }
        .url-input {
            width: 100%; max-width: 500px; padding: 1rem 1.8rem; font-size: 1.3rem;
            font-weight: 500; color: #fff; background: var(--input-bg);
            border: 2px solid var(--input-border); border-radius: 50px; outline: none;
            transition: all 0.3s ease; backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px); text-align: center;
        }
        .url-input::placeholder { color: rgba(255,255,255,0.55); font-weight: 400; }
        .url-input:focus { border-color: #fff; background: rgba(255,255,255,0.18); }
        .btn-green {
            display: inline-block; background-color: var(--green-btn); color: #fff;
            font-size: 1.25rem; font-weight: 700; letter-spacing: 0.6px;
            padding: 0.9rem 3.2rem; border: none; border-radius: 50px; cursor: pointer;
            box-shadow: 0 8px 28px rgba(46,204,113,0.45); transition: all 0.3s ease;
        }
        .btn-green:hover {
            background-color: var(--green-btn-hover); transform: translateY(-3px);
            box-shadow: 0 14px 34px rgba(39,174,96,0.55);
        }
        .btn-green:active { transform: translateY(0); box-shadow: 0 6px 20px rgba(46,204,113,0.4); }
        .message-box {
            margin-top: 1.3rem; padding: 0.65rem 1.5rem; border-radius: 40px;
            font-weight: 600; font-size: 0.95rem; letter-spacing: 0.4px;
        }
        .message-success {
            background: rgba(46,204,113,0.25); border: 1px solid rgba(46,204,113,0.7);
            color: #ccffd0;
        }
        .message-error {
            background: rgba(231,76,60,0.25); border: 1px solid rgba(231,76,60,0.7);
            color: #ffd6d0;
        }
        .file-link {
            margin-top: 1rem;
            background: rgba(255,255,255,0.1);
            padding: 0.7rem 1.5rem;
            border-radius: 50px;
            backdrop-filter: blur(4px);
        }
        .file-link a {
            color: #fff;
            font-weight: bold;
            text-decoration: none;
            border-bottom: 2px solid #2ecc71;
            padding-bottom: 2px;
        }
        .file-link a:hover {
            border-bottom-color: #fff;
        }
        .footer {
            width: 100%; text-align: center; padding: 1.4rem 1rem 1.2rem;
            font-size: 0.85rem; color: rgba(255,255,255,0.6); letter-spacing: 0.4px;
        }
        .footer span {
            border-top: 1px solid rgba(255,255,255,0.2); padding-top: 0.7rem; display: inline-block;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @media (max-width: 480px) {
            .url-input { font-size: 1.1rem; padding: 0.85rem 1.5rem; }
            .btn-green { padding: 0.8rem 2.4rem; font-size: 1.1rem; }
        }
        .alt-links {
            display: flex;
            flex-wrap: wrap;
            gap: 1.4rem;
            justify-content: center;
            margin-bottom: 1rem;
        }
        .alt-link {
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            font-size: 0.95rem;
            font-weight: 500;
            letter-spacing: 0.3px;
            border-bottom: 1.5px solid rgba(255, 255, 255, 0.4);
            padding-bottom: 3px;
            transition: all 0.25s ease;
        }
        .alt-link:hover {
            color: #ffffff;
            border-bottom-color: #ffffff;
            text-shadow: 0 0 12px rgba(255, 255, 255, 0.5);
        }
    </style>
</head>
<body>
    <div class="background-wrapper" aria-hidden="true"></div>
    <div class="overlay" aria-hidden="true"></div>

    <div class="page-container">
        <main class="hero-content">
            <h1 class="brand-name">Meento Share</h1>
            <p class="tagline">download & host your files</p>

            <form method="post" action="" class="server-form" novalidate>
                <input 
                    type="url" 
                    name="url" 
                    class="url-input" 
                    placeholder="Paste file URL here (max 500 chars)…" 
                    required 
                    maxlength="500"
                    aria-label="File URL"
                    value="<?php echo isset($_POST['url']) ? htmlspecialchars($_POST['url'], ENT_QUOTES, 'UTF-8') : ''; ?>"
                >
                <button type="submit" class="btn-green">Download & Store</button>
            </form>

            <?php if ($message !== ''): ?>
                <div class="message-box <?php echo $message_type === 'success' ? 'message-success' : 'message-error'; ?>">
                    <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <?php if ($success_hash !== null): ?>
                <div class="file-link">
                    📁 <a href="?file=<?php echo $success_hash; ?>" target="_blank">Open the file (<?php echo $success_ext ?: 'no extension'; ?>) in new tab</a>
                </div>
            <?php endif; ?>

            <br>
            <div class="alt-links">
                <a href="upload.php" class="alt-link">Upload</a>
                <span style="color: rgba(255,255,255,0.45);">|</span>
                <a href="README_meentophp.md" class="alt-link">About</a>
            </div>
        </main>

        <footer class="footer">
            <span>All rights reserved. PHP/executable files are blocked. Files stored as hash.extension.</span>
        </footer>
    </div>
</body>
</html>