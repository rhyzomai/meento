﻿<?php
// ─── Output buffer: prevents PHP warnings from corrupting JSON responses ──────
ob_start();

// ─── Configuration ────────────────────────────────────────────────────────────
define('UPLOAD_DIR',  __DIR__ . '/download/');
define('JSON_BASE',   __DIR__ . '/files');       // files.json, files_2.json, …
define('JSON_EXT',    '.json');
define('JSON_MAX',    512 * 1024);               // 500 KB per shard
define('MAX_SIZE',    1 * 1024 * 1024 * 1024);  // 1 GB max upload
define('FORBIDDEN',   ['php','phtml','php3','php4','php5','php7','phps','phar']);

// ─── JSON shard helpers ───────────────────────────────────────────────────────

/** Filesystem path for shard N.  1 → files.json, 2 → files_2.json, … */
function shard_path(int $n): string {
    return JSON_BASE . ($n === 1 ? '' : '_' . $n) . JSON_EXT;
}

/** Web-accessible filename for shard N (relative, for fetch() in JS). */
function shard_name(int $n): string {
    return 'files' . ($n === 1 ? '' : '_' . $n) . '.json';
}

/** Highest existing shard number (returns 1 even if nothing exists yet). */
function last_shard(): int {
    $n = 1;
    while (file_exists(shard_path($n + 1))) $n++;
    return $n;
}

/** Read one shard with a shared lock. Returns [] on missing / empty / invalid. */
function read_shard(int $n): array {
    $path = shard_path($n);
    if (!file_exists($path)) return [];
    $fh = fopen($path, 'r');
    if (!$fh) return [];
    flock($fh, LOCK_SH);
    $content = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    if (!trim($content)) return [];
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

/** Write $entries to shard $n with an exclusive lock. */
function write_shard(int $n, array $entries): void {
    $fh = fopen(shard_path($n), 'c+');
    if (!$fh) return;
    flock($fh, LOCK_EX);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode(array_values($entries),
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
}

/**
 * Append one entry to the right shard.
 * Starts a new shard whenever the current last one is at/over JSON_MAX bytes.
 * Returns the shard number where the entry was written.
 */
function append_entry(array $entry): int {
    $n    = last_shard();
    $path = shard_path($n);
    if (file_exists($path) && filesize($path) >= JSON_MAX) {
        $n++;
    }
    $entries   = read_shard($n);
    $entries[] = $entry;
    write_shard($n, $entries);
    return $n;
}

/**
 * Recursively scan UPLOAD_DIR, rename files to <sha256>.<ext>,
 * then distribute all entries across shards respecting JSON_MAX.
 */
function scan_and_rebuild(): void {
    ensure_dir();
    $all  = [];
    $iter = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(UPLOAD_DIR, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iter as $fi) {
        if (!$fi->isFile()) continue;
        $abs      = $fi->getPathname();
        $dir      = $fi->getPath() . DIRECTORY_SEPARATOR;
        $ext      = strtolower($fi->getExtension());
        $hash     = hash_file('sha256', $abs);
        $hashName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        $hashAbs  = $dir . $hashName;
        if ($fi->getFilename() !== $hashName) {
            if (!file_exists($hashAbs)) rename($abs, $hashAbs);
            else                        unlink($abs);
            $abs = $hashAbs;
        }
        $abs_norm  = str_replace('\\', '/', $abs);
        $base_norm = str_replace('\\', '/', UPLOAD_DIR);
        $relative  = ltrim(substr($abs_norm, strlen($base_norm)), '/');
        $all[] = [
            'original_name' => basename($relative),
            'filename'      => $relative,
            'date'          => date('Y-m-d H:i:s', filemtime($abs)),
            'filesize'      => filesize($abs),
            'filehash'      => $hash,
        ];
    }

    // Distribute into size-capped shards
    $shardNum  = 1;
    $shard     = [];
    $shardSize = 0;
    foreach ($all as $entry) {
        $sz = strlen(json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) + 4;
        if (!empty($shard) && ($shardSize + $sz) >= JSON_MAX) {
            write_shard($shardNum, $shard);
            $shardNum++;
            $shard     = [];
            $shardSize = 0;
        }
        $shard[]    = $entry;
        $shardSize += $sz;
    }
    write_shard($shardNum, $shard); // flush last (or only) shard

    // Remove stale shards left over from a previous larger index
    for ($k = $shardNum + 1; file_exists(shard_path($k)); $k++) {
        unlink(shard_path($k));
    }
}

/** Ensure shard 1 exists (triggers rebuild if missing/empty). */
function bootstrap(): void {
    if (!file_exists(shard_path(1)) || filesize(shard_path(1)) === 0) {
        scan_and_rebuild();
    }
}

function ensure_dir(): void {
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
}

function fmt_size(int $bytes): string {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 2)    . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 2)       . ' KB';
    return $bytes . ' B';
}

// ─── XHR detection ───────────────────────────────────────────────────────────
$isXhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
         strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

// ─── Upload handler ───────────────────────────────────────────────────────────
$uploadError  = null;
$uploadedFile = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    ensure_dir();
    $file = $_FILES['file'];

    do {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $msgs = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds server limit.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds form limit.',
                UPLOAD_ERR_PARTIAL    => 'Upload was partial.',
                UPLOAD_ERR_NO_FILE    => 'No file received.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder.',
                UPLOAD_ERR_CANT_WRITE => 'Cannot write to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload blocked by extension.',
            ];
            $uploadError = $msgs[$file['error']] ?? 'Unknown upload error.';
            break;
        }
        if ($file['size'] > MAX_SIZE) { $uploadError = 'File exceeds the 1 GB limit.'; break; }

        $originalName = basename($file['name']);
        $ext          = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (in_array($ext, FORBIDDEN, true)) { $uploadError = 'PHP files are not allowed.'; break; }

        $hash     = hash_file('sha256', $file['tmp_name']);
        $hashName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        $dest     = UPLOAD_DIR . $hashName;

        if (file_exists($dest)) { $uploadError = 'This file already exists (identical content is already stored).'; break; }
        if (!move_uploaded_file($file['tmp_name'], $dest)) { $uploadError = 'Failed to save the file. Check folder permissions.'; break; }

        $newEntry = [
            'original_name' => $originalName,
            'filename'      => $hashName,
            'date'          => date('Y-m-d H:i:s'),
            'filesize'      => filesize($dest),
            'filehash'      => $hash,
        ];

        bootstrap();
        append_entry($newEntry);
        $uploadedFile = $newEntry;

    } while (false);

    // XHR: return JSON only
    if ($isXhr) {
        // Discard any stray PHP warnings/notices buffered above —
        // even one extra byte breaks JSON.parse() on the client.
        ob_end_clean();
        ini_set('display_errors', '0');

        header('Content-Type: application/json; charset=utf-8');
        if ($uploadError) {
            echo json_encode(['ok' => false, 'error' => $uploadError]);
        } else {
            $dir = dirname($_SERVER['REQUEST_URI']);
            $dir = ($dir === '/' || $dir === '\\') ? '' : rtrim($dir, '/');
            $bu = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
                . '://' . $_SERVER['HTTP_HOST']
                . $dir . '/download/';
            $url_path = implode('/', array_map('rawurlencode', explode('/', $uploadedFile['filename'])));
            $sz = $uploadedFile['filesize'];
            echo json_encode([
                'ok'            => true,
                'original_name' => $uploadedFile['original_name'],
                'filename'      => $uploadedFile['filename'],
                'date'          => $uploadedFile['date'],
                'filesize'      => fmt_size($sz),
                'filehash'      => $uploadedFile['filehash'],
                'url'           => $bu . $url_path,
            ]);
        }
        exit;
    }
}

// ─── Bootstrap index & build page data ───────────────────────────────────────
bootstrap();

$_req_dir = dirname($_SERVER['REQUEST_URI']);
$_req_dir = ($_req_dir === '/' || $_req_dir === '\\') ? '' : rtrim($_req_dir, '/');
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
          . '://' . $_SERVER['HTTP_HOST']
          . $_req_dir . '/download/';

// Only shard 1 is injected into the page; JS fetches subsequent shards itself
$shard1 = read_shard(1);
$js_shard1 = json_encode(array_map(function($e) use ($base_url) {
    $url_path = implode('/', array_map('rawurlencode', explode('/', $e['filename'])));
    return [
        'original_name' => $e['original_name'] ?? $e['filename'],
        'filename'      => $e['filename'],
        'date'          => $e['date'],
        'filesize'      => fmt_size((int)$e['filesize']),
        'filehash'      => $e['filehash'],
        'url'           => $base_url . $url_path,
    ];
}, $shard1), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES);

// Pass the base URL to JS so it can build shard URLs itself
$js_base_url = json_encode(
    (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . $_req_dir
    . '/'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Meento | File Storage</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  [hidden] { display: none !important; }
  html, body { height: 100%; }

  :root {
    /* Modern Color Palette */
    --brand:     #f97316; /* Orange 500 */
    --brand-d:   #ea580c; /* Orange 600 */
    --brand-bg:  #ffedd5; /* Orange 100 */
    --bg:        #f8fafc; /* Slate 50 */
    --surface:   #ffffff;
    --border:    #e2e8f0; /* Slate 200 */
    --text:      #0f172a; /* Slate 900 */
    --muted:     #64748b; /* Slate 500 */
    --link:      #2563eb; /* Blue 600 */
    --green:     #10b981; /* Emerald 500 */
    --red:       #ef4444; /* Red 500 */
    
    /* Geometry & Shadows */
    --radius-sm: 8px;
    --radius-md: 16px;
    --radius-lg: 24px;
    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
  }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: var(--text);
    background: var(--bg);
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    -webkit-font-smoothing: antialiased;
  }

  /* ── Header / Search ── */
  .search-bar {
    background: rgba(255, 255, 255, 0.85);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    padding: 16px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid var(--border);
    position: sticky;
    top: 0;
    z-index: 50;
  }
  
  .brand { 
    color: var(--brand); 
    font-weight: 800; 
    font-size: 22px; 
    letter-spacing: -0.5px; 
    margin-right: 8px; 
    white-space: nowrap; 
    flex-shrink: 0; 
    text-decoration: none;
    display: flex;
    align-items: baseline;
  }
  .brand span { 
    color: var(--muted);
    font-weight: 500; 
    font-size: 14px; 
    margin-left: 6px; 
    letter-spacing: 0;
  }

  .search-input-wrapper {
    flex: 1;
    position: relative;
    max-width: 600px;
  }

  .search-bar input[type="text"] {
    width: 100%;
    padding: 12px 16px 12px 42px;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 99px;
    font-size: 15px;
    outline: none;
    color: var(--text);
    transition: all 0.2s ease;
  }
  
  .search-bar input[type="text"]:focus {
    background: var(--surface);
    border-color: var(--brand);
    box-shadow: 0 0 0 4px var(--brand-bg);
  }

  .search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--muted);
    width: 18px;
    height: 18px;
    pointer-events: none;
  }

  .search-bar .btn-search {
    background: var(--text); 
    color: var(--surface); 
    border: none; 
    padding: 12px 24px;
    font-size: 14px; 
    font-weight: 600; 
    border-radius: 99px;
    cursor: pointer; 
    transition: all 0.2s ease; 
    white-space: nowrap; 
    flex-shrink: 0;
  }
  .search-bar .btn-search:hover { background: #000; box-shadow: var(--shadow-md); transform: translateY(-1px); }

  /* ── Main Layout ── */
  main { flex: 1; max-width: 1200px; width: 100%; margin: 0 auto; padding: 48px 24px; }

  /* ── Hero / Upload ── */
  .hero { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; margin-bottom: 48px; }
  .hero.hidden-by-search { display: none; }
  
  .hero-art {
    display: flex; align-items: center; justify-content: center;
    background: linear-gradient(145deg, #ffffff 0%, var(--bg) 100%);
    border: 2px dashed var(--border);
    border-radius: var(--radius-lg); 
    padding: 64px 32px; 
    min-height: 300px;
    transition: all 0.2s ease;
    cursor: pointer;
  }
  .hero-art svg { width: 160px; height: auto; transition: transform 0.3s ease; }
  .hero-art:hover svg { transform: scale(1.05) translateY(-5px); }
  .hero-art.drag-over { 
    border-color: var(--brand); 
    background: var(--brand-bg); 
    transform: scale(1.02);
  }
  
  .hero-text h1 { font-size: 48px; font-weight: 800; letter-spacing: -1.5px; line-height: 1.1; margin-bottom: 20px; color: var(--text); }
  .hero-text h1 span { color: var(--brand); }
  .hero-text p { font-size: 18px; line-height: 1.6; color: var(--muted); margin-bottom: 32px; font-weight: 400; }
  
  #fileInput { display: none; }
  .upload-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    background: var(--brand); color: #fff;
    padding: 16px 32px; border-radius: 99px; font-size: 16px; font-weight: 600;
    cursor: pointer; border: none; transition: all 0.2s ease;
    box-shadow: 0 4px 14px rgba(249, 115, 22, 0.3);
  }
  .upload-btn:hover:not(:disabled) { background: var(--brand-d); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(249, 115, 22, 0.4); }
  .upload-btn:disabled { opacity: 0.65; cursor: not-allowed; }

  /* ── Notices & Progress ── */
  .notice {
    display: flex; align-items: flex-start; gap: 12px; padding: 16px 20px;
    border-radius: var(--radius-md); margin-bottom: 32px; font-size: 15px; font-weight: 500;
    box-shadow: var(--shadow-sm); border: 1px solid transparent;
  }
  .notice.error   { background: #fef2f2; border-color: #fecaca; color: var(--red);   }
  .notice.success { background: #ecfdf5; border-color: #a7f3d0; color: var(--green); }
  .notice .icon   { font-size: 20px; flex-shrink: 0; line-height: 1.2; }

  #progressWrap  { margin-bottom: 32px; display: none; background: var(--surface); padding: 24px; border-radius: var(--radius-md); box-shadow: var(--shadow-sm); border: 1px solid var(--border); }
  #progressLabel { font-size: 14px; font-weight: 600; color: var(--text); margin-bottom: 12px; display: flex; justify-content: space-between; }
  #progressBar   { width: 100%; height: 8px; background: var(--bg); border-radius: 99px; overflow: hidden; box-shadow: inset 0 1px 2px rgba(0,0,0,0.05); }
  #progressFill  { height: 100%; width: 0%; background: linear-gradient(90deg, var(--brand), #fb923c); border-radius: 99px; transition: width 0.15s ease-out; }

  /* ── Results Grid ── */
  #listWrap { display: none; }
  .results {
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 24px;
    padding: 16px 0;
  }

  .results li {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transition: all 0.2s ease;
    position: relative;
  }
  .results li:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); border-color: #cbd5e1; }

  .card-thumb {
    width: 100%;
    aspect-ratio: 16/10;
    background: var(--bg);
    overflow: hidden;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-bottom: 1px solid var(--border);
  }
  .card-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.3s ease; }
  .results li:hover .card-thumb img:not(.generic) { transform: scale(1.05); }
  .card-thumb img.generic { width: 64px; height: 64px; object-fit: contain; opacity: 0.3; }

  .card-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; flex: 1; }

  .card-filename {
    color: var(--text);
    text-decoration: none;
    font-size: 15px;
    font-weight: 600;
    word-break: break-all;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: color 0.15s ease;
  }
  .card-filename:hover { color: var(--link); }

  .card-meta-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .card-badge {
    background: var(--bg);
    border: 1px solid var(--border);
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 500;
    color: var(--muted);
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .card-badge.hash {
    font-family: 'SFMono-Regular', Consolas, "Liberation Mono", Menlo, monospace;
    font-size: 10px;
    background: #f1f5f9;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: block;
  }

  .btn-comment {
    display: block;
    margin: 4px 16px 16px;
    background: var(--bg); 
    color: var(--text); 
    border: 1px solid var(--border);
    padding: 10px 0; 
    font-size: 13px; 
    font-weight: 600; 
    border-radius: 8px;
    cursor: pointer; 
    text-decoration: none; 
    text-align: center; 
    white-space: nowrap;
    transition: all 0.2s ease;
  }
  .btn-comment:hover { background: var(--border); color: #000; }

  /* ── Pagination / Empty ── */
  #nextWrap { display: none; text-align: center; margin-top: 40px; }
  #nextWrap a {
    display: inline-block;
    background: var(--surface); border: 1px solid var(--border); box-shadow: var(--shadow-sm);
    padding: 12px 24px; border-radius: 99px;
    color: var(--text); font-size: 14px; font-weight: 600;
    text-decoration: none; transition: all 0.2s ease;
  }
  #nextWrap a:hover { background: var(--bg); box-shadow: var(--shadow-md); transform: translateY(-1px); }

  .empty { text-align: center; color: var(--muted); padding: 64px 0; font-size: 16px; font-weight: 500; }

  /* ── Footer ── */
  footer { margin-top: auto; border-top: 1px solid var(--border); background: var(--surface); color: var(--muted); text-align: center; padding: 24px; font-size: 14px; font-weight: 500; }

  /* ── Responsive ── */
  @media (max-width: 768px) {
    .hero { grid-template-columns: 1fr; text-align: center; gap: 32px; }
    .hero-art { min-height: 200px; padding: 32px 24px; }
    .hero-text h1 { font-size: 36px; }
    .brand { font-size: 20px; }
    .brand span { display: none; }
    .search-bar { padding: 12px 16px; }
    .search-bar input[type="text"] { font-size: 16px; } /* Prevents iOS zoom */
    .results { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 16px; }
    .card-body { padding: 12px; }
    .btn-comment { margin: 0 12px 12px; }
  }
</style>
</head>
<body>

<header class="search-bar">
  <a href="index.php" class="brand">Meento <span>Storage</span></a>
  <div class="search-input-wrapper">
    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
    <input id="searchInput" type="text" placeholder="Search files, hashes, or extensions…" autocomplete="off" />
  </div>
  <button type="button" class="btn-search" id="searchBtn">Search</button>
</header>

<main>

  <?php if ($uploadError): ?>
  <div class="notice error" role="alert">
    <span class="icon">✕</span>
    <div><?= htmlspecialchars