﻿<?php
// ============================================================
// View Meento - Single-file PHP 7 application
// ============================================================

$infoDir   = __DIR__ . '/info/';
$thumbsDir = __DIR__ . '/thumbs/';
$dataFile  = __DIR__ . '/data.json';

// ---------- Build data.json (only if it does not exist) ----------
$buildMessage = '';

if (!file_exists($dataFile)) {
    $files = glob($infoDir . '*.json');
    $index = [];
    foreach ($files as $file) {
        $raw = file_get_contents($file);
        $decoded = json_decode($raw, true);
        if ($decoded !== null) {
            $basename = basename($file, '.json');
            $decoded['_file'] = $basename;
            $index[] = $decoded;
        }
    }
    file_put_contents($dataFile, json_encode($index, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $buildMessage = 'data.json created with ' . count($index) . ' entr' . (count($index) === 1 ? 'y' : 'ies') . '.';
} else {
    $buildMessage = 'data.json already exists — index was not rebuilt.';
}

// ---------- Load data for search (served as JSON endpoint) ----------
if (isset($_GET['q'])) {
    header('Content-Type: application/json; charset=utf-8');
    $q    = strtolower(trim($_GET['q']));
    $data = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];    
    $results = [];
    if ($q !== '' && is_array($data)) {
        foreach ($data as $item) {
            $haystack = strtolower(json_encode($item));
            if (strpos($haystack, $q) !== false) {
                $results[] = $item;
            }
        }
    }
    echo json_encode($results);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Meento</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  /* ── Reset & base ──────────────────────────────────────────── */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --ink:    #0d0d0d;
    --paper:  #f9f8f6;
    --bar:    #111111;
    --bar-tx: #e8e4dc;
    --accent: #c8a96e;
    --muted:  #888880;
    --border: #e0ddd6;
    --radius: 6px;
    --font-display: 'DM Serif Display', Georgia, serif;
    --font-body:    'DM Sans', system-ui, sans-serif;
  }

  html, body {
    min-height: 100vh;
    background: var(--paper);
    color: var(--ink);
    font-family: var(--font-body);
    font-size: 15px;
    line-height: 1.6;
  }

  /* ── Top bar ───────────────────────────────────────────────── */
  header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: var(--bar);
    color: var(--bar-tx);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 2.5rem;
    height: 56px;
    letter-spacing: .01em;
    box-shadow: 0 1px 0 rgba(255,255,255,.06);
  }

  .logo {
    font-family: var(--font-display);
    font-size: 1.35rem;
    color: var(--bar-tx);
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: .5rem;
  }
  .logo span { color: var(--accent); }

  nav a {
    color: var(--bar-tx);
    text-decoration: none;
    font-size: .85rem;
    font-weight: 500;
    letter-spacing: .08em;
    text-transform: uppercase;
    padding: .35rem .9rem;
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 3px;
    transition: background .18s, color .18s;
  }
  nav a:hover {
    background: var(--accent);
    border-color: var(--accent);
    color: var(--bar);
  }

  /* ── Main layout ───────────────────────────────────────────── */
  main {
    max-width: 880px;
    margin: 0 auto;
    padding: 3.5rem 2rem 5rem;
  }

  .hero {
    text-align: center;
    margin-bottom: 2.8rem;
  }
  .hero h1 {
    font-family: var(--font-display);
    font-size: clamp(2rem, 5vw, 2.8rem);
    font-weight: 400;
    line-height: 1.15;
    margin-bottom: .55rem;
  }
  .hero p {
    color: var(--muted);
    font-size: .92rem;
    font-weight: 300;
  }

  /* ── Search ────────────────────────────────────────────────── */
  .search-wrap {
    position: relative;
    max-width: 560px;
    margin: 0 auto 2.5rem;
  }
  .search-wrap svg {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--muted);
    pointer-events: none;
  }
  #searchInput {
    width: 100%;
    padding: .82rem 1rem .82rem 2.85rem;
    border: 1.5px solid var(--border);
    border-radius: var(--radius);
    background: #fff;
    font-family: var(--font-body);
    font-size: .95rem;
    color: var(--ink);
    outline: none;
    transition: border-color .18s, box-shadow .18s;
  }
  #searchInput:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(200,169,110,.15);
  }
  #searchInput::placeholder { color: #bbb9b3; }

  /* ── Results grid ──────────────────────────────────────────── */
  #resultsGrid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 1.25rem;
  }

  .card {
    background: #fff;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    text-decoration: none;
    color: var(--ink);
    transition: transform .18s, box-shadow .18s;
  }
  .card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(0,0,0,.09);
  }

  .thumb-wrap {
    width: 100%;
    aspect-ratio: 16 / 9;
    background: #f0ede8;
    overflow: hidden;
    flex-shrink: 0;
    position: relative;
  }
  .thumb-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform .3s ease;
  }
  .card:hover .thumb-wrap img { transform: scale(1.04); }

  .thumb-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ccc9c2;
  }

  .card-body {
    padding: .75rem 1rem .9rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: .3rem;
  }
  .card-title {
    font-weight: 500;
    font-size: .9rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--ink);
  }
  .card-meta {
    font-size: .75rem;
    color: var(--muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .card-desc {
    font-size: .78rem;
    color: #666;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  /* ── Empty / hint states ───────────────────────────────────── */
  .state-msg {
    text-align: center;
    color: var(--muted);
    font-size: .9rem;
    padding: 3rem 0;
    grid-column: 1 / -1;
  }
  .state-msg svg { margin-bottom: .6rem; opacity: .4; }

  /* ── Status banner ─────────────────────────────────────────── */
  .status-bar {
    background: #1a1a1a;
    color: #9a9690;
    font-size: .75rem;
    text-align: center;
    padding: .35rem 1rem;
    letter-spacing: .03em;
  }

  /* ── Footer ────────────────────────────────────────────────── */
  footer {
    background: var(--bar);
    color: #555;
    text-align: center;
    font-size: .75rem;
    letter-spacing: .04em;
    padding: 1.1rem 1rem;
  }
  footer span { color: var(--accent); }
</style>
</head>
<body>

<!-- ── Status bar ── -->
<div class="status-bar"><?= htmlspecialchars($buildMessage) ?></div>

<!-- ── Top bar ── -->
<header>
  <a class="logo" href="?">View <span>Meento</span></a>
  <nav>
    <a href="index.php">&#8593; Upload</a>
  </nav>
</header>

<!-- ── Main ── -->
<main>
  <div class="hero">
    <h1><em>Meento</em></h1>
    <p>Search your media catalogue — type anything to explore.</p>
  </div>

  <div class="search-wrap">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    <input id="searchInput" type="text" placeholder="Search by name, description, key…" autocomplete="off" autofocus>
  </div>

  <div id="resultsGrid">
    <div class="state-msg">
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <div>Start typing to search the catalogue.</div>
    </div>
  </div>
</main>

<!-- ── Footer ── -->
<footer>
  &copy; <?= date('Y') ?> &nbsp;<span>View Meento</span> &nbsp;·&nbsp; All rights reserved.
</footer>



<script>
const grid = document.getElementById('resultsGrid');

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function buildCard(item) {
  const file = item._file || '';
  // Open the actual file in "files/" using the extension field from the JSON
  const ext  = (item.extension || 'jpg').toLowerCase();
  const href = 'files/' + encodeURIComponent(file) + '.' + ext;
  // Use the actual file as thumbnail if it's an image, otherwise use thumbs/
  const imageExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif'];
  const thumb = imageExts.includes(ext)
    ? 'files/' + encodeURIComponent(file) + '.' + ext
    : 'thumbs/' + encodeURIComponent(file) + '.jpg';
  const title = item.original_filename || file || 'Untitled';
  const meta  = [item.extension, item.size ? (Math.round(item.size/1024) + ' KB') : ''].filter(Boolean).join(' · ');
  const desc  = item.description || '';

  return `
  <a class="card" href="${href}" target="_blank" rel="noopener">
    <div class="thumb-wrap">
      <img src="${thumb}" alt="${escHtml(title)}"
           onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
      <div class="thumb-placeholder" style="display:none">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
          <polyline points="21 15 16 10 5 21"/>
        </svg>
      </div>
    </div>
    <div class="card-body">
      <div class="card-title">${escHtml(title)}</div>
      ${meta  ? `<div class="card-meta">${escHtml(meta)}</div>` : ''}
      ${desc  ? `<div class="card-desc">${escHtml(desc)}</div>` : ''}
    </div>
  </a>`;
}

let timer;
document.getElementById('searchInput').addEventListener('input', function() {
  clearTimeout(timer);
  const q = this.value.trim();
  if (!q) {
    grid.innerHTML = `
      <div class="state-msg">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <div>Start typing to search the catalogue.</div>
      </div>`;
    return;
  }
  timer = setTimeout(() => {
    fetch('?q=' + encodeURIComponent(q))
      .then(r => r.json())
      .then(items => {
        if (!items.length) {
          grid.innerHTML = `
            <div class="state-msg">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <div>No results for <strong>${escHtml(q)}</strong>.</div>
            </div>`;
          return;
        }
        grid.innerHTML = items.map(buildCard).join('');
      })
      .catch(() => {
        grid.innerHTML = '<div class="state-msg">Search error — please try again.</div>';
      });
  }, 220);
});
</script>
</body>
</html>