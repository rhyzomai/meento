﻿<?php
/**
 * rank_to_stats.php
 *
 * Reads rank.txt, converts its data into the stats.json format expected by
 * dashboard.html, and appends/updates entries.  Deduplication is handled by
 * writing an empty sentinel file named after the SHA-256 hash of rank.txt
 * inside the tmp_rank/ directory — if that file already exists the script
 * exits immediately without touching stats.json.
 *
 * Usage:
 *   php rank_to_stats.php [--rank rank.txt] [--stats stats.json] [--tmp tmp_rank]
 *
 * All three paths default to the values shown above and are relative to the
 * directory where this script lives.
 */

// ---------------------------------------------------------------------------
// 1. CLI options / defaults
// ---------------------------------------------------------------------------

$opts = getopt('', ['rank::', 'stats::', 'tmp::']);

$rankFile  = $opts['rank']  ?? __DIR__ . '/rank.txt';
$statsFile = $opts['stats'] ?? __DIR__ . '/stats.json';
$tmpDir    = $opts['tmp']   ?? __DIR__ . '/tmp_rank';

// ---------------------------------------------------------------------------
// 2. Read rank.txt
// ---------------------------------------------------------------------------

if (!file_exists($rankFile) || !is_readable($rankFile)) {
    fwrite(STDERR, "ERROR: Cannot read rank file: $rankFile\n");
    exit(1);
}

$rankContent = file_get_contents($rankFile);
if ($rankContent === false) {
    fwrite(STDERR, "ERROR: file_get_contents failed for $rankFile\n");
    exit(1);
}

// ---------------------------------------------------------------------------
// 3. Deduplication — SHA-256 sentinel file
// ---------------------------------------------------------------------------

$hash      = hash('sha256', $rankContent);           // 64-char hex string
$sentinelPath = rtrim($tmpDir, '/\\') . DIRECTORY_SEPARATOR . $hash;

// Ensure tmp_rank/ exists
if (!is_dir($tmpDir)) {
    if (!mkdir($tmpDir, 0755, true)) {
        fwrite(STDERR, "ERROR: Could not create tmp directory: $tmpDir\n");
        exit(1);
    }
}

// Try to create the sentinel with fopen — 'x' mode fails if file already exists
$fh = fopen($sentinelPath, 'x');   // 'x' = write-only, error if exists

if ($fh === false) {
    // File already existed → this rank.txt was already processed
    echo "INFO: rank.txt (sha256=$hash) was already imported. Nothing to do.\n";
    exit(0);
}

// File was just created; close immediately — we only need it as a flag
fclose($fh);
echo "INFO: Sentinel created: $sentinelPath\n";

// ---------------------------------------------------------------------------
// 4. Parse rank.txt
// ---------------------------------------------------------------------------

/**
 * Palette used when assigning a colour to a newly seen public key.
 * The dashboard HTML already uses these four; extend as needed.
 */
$palette = ['#ff6384', '#36a2eb', '#4bc0c0', '#ff9f40',
            '#9966ff', '#c9cbcf', '#f7dc6f', '#58d68d'];

$servers    = [];   // [url => fileCount]
$publicKeys = [];   // [key => serverCount]

foreach (explode("\n", $rankContent) as $line) {

    // -- Servers section: "    N. http://...   M file(s)"
    if (preg_match('/^\s+\d+\.\s+(https?:\/\/\S+)\s+(\d+)\s+file/', $line, $m)) {
        $servers[$m[1]] = (int)$m[2];
        continue;
    }

    // -- Public keys section: "    N. <key>   M server(s)"
    if (preg_match('/^\s+\d+\.\s+(\S+)\s+(\d+)\s+server/', $line, $m)) {
        $publicKeys[$m[1]] = (int)$m[2];
    }
}

if (empty($publicKeys)) {
    echo "WARNING: No public keys found in $rankFile. stats.json not modified.\n";
    exit(0);
}

// ---------------------------------------------------------------------------
// 5. Load (or initialise) stats.json
// ---------------------------------------------------------------------------

$stats = [];

if (file_exists($statsFile) && is_readable($statsFile)) {
    $raw = file_get_contents($statsFile);
    if ($raw !== false && trim($raw) !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $stats = $decoded;
        } else {
            echo "WARNING: Existing stats.json is invalid JSON — starting fresh.\n";
        }
    }
}

// Build a quick lookup: id => array index
$indexById = [];
foreach ($stats as $i => $entry) {
    $indexById[$entry['id']] = $i;
}

// ---------------------------------------------------------------------------
// 6. Merge parsed data into stats structure
// ---------------------------------------------------------------------------

/**
 * Build a small random-walk history array (identical logic to the dashboard's
 * generateWalk function) so the line chart has something to show immediately.
 * In production you would accumulate real history across runs.
 */
function generateWalk(float $start, int $steps, float $volatility): array
{
    $data    = [$start];
    $current = $start;
    for ($i = 1; $i < $steps; $i++) {
        $current += (mt_rand() / mt_getrandmax() - 0.5) * $volatility;
        $data[]   = round($current, 2);
    }
    return $data;
}

$colorIndex = count($stats);   // pick up where the existing colours left off

foreach ($publicKeys as $keyId => $serverCount) {

    $currentValue = (float)$serverCount;   // use server-count as the metric

    if (isset($indexById[$keyId])) {
        // ---- Existing entry: append a new "current" sample to every window ----
        $idx   = $indexById[$keyId];
        $entry = &$stats[$idx];

        foreach (['day', 'week', 'month'] as $window) {
            $entry['history'][$window][] = $currentValue;

            // Enforce window lengths: 24 / 7 / 30
            $limits = ['day' => 24, 'week' => 7, 'month' => 30];
            $limit  = $limits[$window];
            if (count($entry['history'][$window]) > $limit) {
                $entry['history'][$window] = array_slice(
                    $entry['history'][$window], -$limit
                );
            }
        }

    } else {
        // ---- New entry: synthesise seed history from the current value --------
        $color = $palette[$colorIndex % count($palette)];
        $colorIndex++;

        $allTimeStart = max(1.0, $currentValue * 0.5);  // seed 50 % below current

        $monthData = generateWalk($allTimeStart, 30, max(0.5, $currentValue * 0.1));
        // Force the last point to match the real current value
        $monthData[count($monthData) - 1] = $currentValue;

        $weekData  = array_slice($monthData, -7);

        $dayStart  = $currentValue + (mt_rand() / mt_getrandmax() - 0.5) * max(0.5, $currentValue * 0.05);
        $dayData   = generateWalk($dayStart, 23, max(0.1, $currentValue * 0.02));
        $dayData[] = $currentValue;

        $newEntry = [
            'id'              => $keyId,
            'color'           => $color,
            'allTimeStartValue' => $allTimeStart,
            'history'         => [
                'day'   => $dayData,
                'week'  => $weekData,
                'month' => $monthData,
            ],
        ];

        $stats[]            = $newEntry;
        $indexById[$keyId]  = count($stats) - 1;

        echo "INFO: Added new key: $keyId (servers=$serverCount, color=$color)\n";
    }
}

// ---------------------------------------------------------------------------
// 7. Write stats.json
// ---------------------------------------------------------------------------

$json = json_encode(array_values($stats), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
if ($json === false) {
    fwrite(STDERR, "ERROR: json_encode failed: " . json_last_error_msg() . "\n");
    exit(1);
}

if (file_put_contents($statsFile, $json) === false) {
    fwrite(STDERR, "ERROR: Could not write stats file: $statsFile\n");
    exit(1);
}

echo "INFO: stats.json updated successfully ($statsFile).\n";
echo "INFO: Keys processed: " . implode(', ', array_keys($publicKeys)) . "\n";

exit(0);