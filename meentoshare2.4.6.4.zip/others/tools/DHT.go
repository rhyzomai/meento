package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

var fileMutex sync.Mutex

func main() {
	// Define the ports this local node will listen on
	httpPort := ":8080"
	tcpPort := ":9090"

	// 1. Read the static list of known servers
	knownServers := readKnownServers("servers.txt")
	fmt.Printf("Loaded %d known servers from servers.txt\n", len(knownServers))

	// 2. Start servers to handle incoming DHT discovery checks
	go startHTTPServer(httpPort)
	go startTCPServer(tcpPort)

	// 3. Start the continuous loop to check known servers and update active_servers.txt
	go discoveryLoop(knownServers)

	// Block the main thread so the servers keep running
	select {}
}

// readKnownServers reads the known servers file. It expects prefixes: http://, https://, or tcp://
func readKnownServers(filename string) []string {
	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("Warning: Could not open %s. Starting with empty list.\n", filename)
		return []string{}
	}
	defer file.Close()

	var servers []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			servers = append(servers, line)
		}
	}
	return servers
}

// startHTTPServer handles incoming HTTP(S) pings
func startHTTPServer(port string) {
	http.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("PONG"))
	})
	
	fmt.Println("Listening for HTTP/HTTPS pings on port", port)
	
	// Note: To serve HTTPS locally, replace the line below with:
	// err := http.ListenAndServeTLS(port, "server.crt", "server.key", nil)
	err := http.ListenAndServe(port, nil)
	if err != nil {
		fmt.Println("HTTP Server error:", err)
	}
}

// startTCPServer handles incoming TCP socket pings
func startTCPServer(port string) {
	listener, err := net.Listen("tcp", port)
	if err != nil {
		fmt.Println("TCP Server error:", err)
		return
	}
	defer listener.Close()
	
	fmt.Println("Listening for TCP Socket pings on port", port)

	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		// Handle connection in a lightweight goroutine
		go func(c net.Conn) {
			defer c.Close()
			c.Write([]byte("PONG\n"))
		}(conn)
	}
}

// discoveryLoop continuously pings known servers every 5 seconds
func discoveryLoop(knownServers []string) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	// Create an HTTP client that skips TLS verification to easily support local HTTPS self-signed certs
	client := &http.Client{
		Timeout: 3 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		},
	}

	for {
		// Using a map guarantees uniqueness (no repeated lines)
		currentActive := make(map[string]bool)

		for _, server := range knownServers {
			if checkServerHealth(client, server) {
				currentActive[server] = true
			}
		}

		updateActiveServersFile(currentActive)
		<-ticker.C
	}
}

// checkServerHealth dials the server depending on its protocol prefix
func checkServerHealth(client *http.Client, server string) bool {
	server = strings.ToLower(server)

	if strings.HasPrefix(server, "http://") || strings.HasPrefix(server, "https://") {
		// HTTP/HTTPS check
		resp, err := client.Get(server + "/ping")
		if err == nil && resp.StatusCode == http.StatusOK {
			resp.Body.Close()
			return true
		}
	} else if strings.HasPrefix(server, "tcp://") {
		// TCP Socket check
		address := strings.TrimPrefix(server, "tcp://")
		conn, err := net.DialTimeout("tcp", address, 3*time.Second)
		if err == nil {
			conn.Close()
			return true
		}
	}
	return false
}

// updateActiveServersFile overwrites active_servers.txt safely
func updateActiveServersFile(activeServers map[string]bool) {
	fileMutex.Lock()
	defer fileMutex.Unlock()

	// os.O_TRUNC ensures the file is overwritten entirely each time
	file, err := os.OpenFile("active_servers.txt", os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		fmt.Println("Error writing to active_servers.txt:", err)
		return
	}
	defer file.Close()

	writer := bufio.NewWriter(file)
	for server := range activeServers {
		writer.WriteString(server + "\n")
	}
	writer.Flush()
}