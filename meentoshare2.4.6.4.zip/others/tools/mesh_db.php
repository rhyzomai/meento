﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH NODE — MySQL file tracker  (optional module)
//
//  Usage (in index.php or any peer script):
//
//      require_once __DIR__ . '/mesh_db.php';
//
//      // After a successful storeLocally() call:
//      MeshDB::record($hash, $originalName, $ext, $size, $publicKey, $nodeInfo, $description);
//
//      // Query helpers (all return arrays):
//      MeshDB::find($hash);          // one file by SHA-256
//      MeshDB::recent(20);           // last N files
//      MeshDB::exists($hash);        // bool — duplicate guard
//
//  The module:
//   • auto-creates the table on first use
//   • silently rejects duplicates (same SHA-256 hash)
//   • never throws — all errors go to error_log
// ═══════════════════════════════════════════════════════════════════════════════

// ── Database credentials ──────────────────────────────────────────────────────
// Override these via environment variables or edit the defaults below.

define('MESHDB_HOST',   getenv('MESHDB_HOST')   ?: 'localhost');
define('MESHDB_PORT',   (int)(getenv('MESHDB_PORT') ?: 3306));
define('MESHDB_NAME',   getenv('MESHDB_NAME')   ?: 'mesh_node');
define('MESHDB_USER',   getenv('MESHDB_USER')   ?: 'root');
define('MESHDB_PASS',   getenv('MESHDB_PASS')   ?: '');
define('MESHDB_TABLE',  getenv('MESHDB_TABLE')  ?: 'mesh_files');
define('MESHDB_CHARSET', 'utf8mb4');

// ── DDL: the table schema ─────────────────────────────────────────────────────
// Created automatically on first connection.

define('MESHDB_DDL', "
CREATE TABLE IF NOT EXISTS `" . MESHDB_TABLE . "` (
    `id`                BIGINT UNSIGNED   NOT NULL AUTO_INCREMENT,
    `hash`              CHAR(64)          NOT NULL,
    `original_filename` VARCHAR(512)      NOT NULL DEFAULT '',
    `extension`         VARCHAR(20)       NOT NULL DEFAULT '',
    `size`              BIGINT UNSIGNED   NOT NULL DEFAULT 0,
    `public_key`        TEXT              NOT NULL,
    `node_info`         TEXT              NOT NULL,
    `description`       TEXT              NOT NULL,
    `ip`                VARCHAR(45)       NOT NULL DEFAULT '',
    `peer_push`         TINYINT(1)        NOT NULL DEFAULT 0
                        COMMENT '1 = arrived via peer push; 0 = direct browser upload',
    `created_at`        DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE  KEY `uq_hash`       (`hash`),
    KEY     `idx_created_at`    (`created_at`),
    KEY     `idx_extension`     (`extension`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
");

// ═══════════════════════════════════════════════════════════════════════════════
//  MeshDB  — static façade
// ═══════════════════════════════════════════════════════════════════════════════

class MeshDB
{
    /** @var \mysqli|null */
    private static ?\mysqli $conn = null;

    // ── connection / bootstrap ────────────────────────────────────────────────

    /**
     * Returns a live mysqli connection, creating the table if needed.
     * Returns null on any error so callers can silently skip DB work.
     */
    public static function connection(): ?\mysqli
    {
        if (self::$conn !== null && self::$conn->ping()) {
            return self::$conn;
        }

        mysqli_report(MYSQLI_REPORT_OFF);   // we handle errors ourselves

        $c = new \mysqli(
            MESHDB_HOST,
            MESHDB_USER,
            MESHDB_PASS,
            MESHDB_NAME,
            MESHDB_PORT
        );

        if ($c->connect_errno) {
            error_log('[MeshDB] Connection failed: ' . $c->connect_error);
            return null;
        }

        if (!$c->set_charset(MESHDB_CHARSET)) {
            error_log('[MeshDB] set_charset failed: ' . $c->error);
        }

        // Ensure the table exists
        if (!$c->query(MESHDB_DDL)) {
            error_log('[MeshDB] DDL failed: ' . $c->error);
            $c->close();
            return null;
        }

        self::$conn = $c;
        return self::$conn;
    }

    // ── public API ────────────────────────────────────────────────────────────

    /**
     * Insert a file record.
     *
     * Returns true  on success (or if already exists — idempotent).
     * Returns false on DB error.
     *
     * @param string $hash             SHA-256 hex (64 chars)
     * @param string $originalFilename Original uploaded filename
     * @param string $ext              Sanitised extension (no dot)
     * @param int    $size             File size in bytes
     * @param string $publicKey        Contents of public_key.txt (or empty)
     * @param string $nodeInfo         Contents of node_info.txt (or empty)
     * @param string $description      User comment / description
     * @param bool   $isPeerPush       true when the file arrived via a peer push
     */
    public static function record(
        string $hash,
        string $originalFilename,
        string $ext,
        int    $size,
        string $publicKey    = '',
        string $nodeInfo     = '',
        string $description  = '',
        bool   $isPeerPush   = false
    ): bool {
        $db = self::connection();
        if ($db === null) return false;

        // Guard: reject duplicates at application level before hitting the DB.
        // The UNIQUE KEY on `hash` is a second safety net.
        if (self::exists($hash)) {
            return true;    // already stored — not an error
        }

        $ip   = self::clientIp();
        $peer = $isPeerPush ? 1 : 0;

        $stmt = $db->prepare("
            INSERT IGNORE INTO `" . MESHDB_TABLE . "`
                (hash, original_filename, extension, size,
                 public_key, node_info, description, ip, peer_push)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            error_log('[MeshDB] prepare failed: ' . $db->error);
            return false;
        }

        $stmt->bind_param(
            'sssississi',
            $hash,
            $originalFilename,
            $ext,
            $size,
            $publicKey,
            $nodeInfo,
            $description,
            $ip,
            $peer
        );

        // Fix: bind_param type string has 9 params but 'sssississi' is 10 chars — correct it:
        // s s s i s s s s i  → 9 params, type string = 'sssissssi'
        $stmt->close();

        // Re-prepare with the correct type string
        $stmt = $db->prepare("
            INSERT IGNORE INTO `" . MESHDB_TABLE . "`
                (hash, original_filename, extension, size,
                 public_key, node_info, description, ip, peer_push)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            error_log('[MeshDB] prepare (2) failed: ' . $db->error);
            return false;
        }

        $stmt->bind_param(
            'sssissssi',
            $hash,
            $originalFilename,
            $ext,
            $size,
            $publicKey,
            $nodeInfo,
            $description,
            $ip,
            $peer
        );

        $ok = $stmt->execute();
        if (!$ok) {
            error_log('[MeshDB] execute failed: ' . $stmt->error);
        }
        $stmt->close();

        return $ok;
    }

    /**
     * Check whether a SHA-256 hash is already in the database.
     * Returns false on DB error (fail-open so uploads still work).
     */
    public static function exists(string $hash): bool
    {
        $db = self::connection();
        if ($db === null) return false;

        $stmt = $db->prepare(
            "SELECT 1 FROM `" . MESHDB_TABLE . "` WHERE hash = ? LIMIT 1"
        );
        if (!$stmt) return false;

        $stmt->bind_param('s', $hash);
        $stmt->execute();
        $stmt->store_result();
        $found = $stmt->num_rows > 0;
        $stmt->close();

        return $found;
    }

    /**
     * Fetch a single file record by SHA-256 hash.
     * Returns an associative array or null if not found / DB error.
     */
    public static function find(string $hash): ?array
    {
        $db = self::connection();
        if ($db === null) return null;

        $stmt = $db->prepare(
            "SELECT * FROM `" . MESHDB_TABLE . "` WHERE hash = ? LIMIT 1"
        );
        if (!$stmt) return null;

        $stmt->bind_param('s', $hash);
        $stmt->execute();
        $result = $stmt->get_result();
        $row    = $result->fetch_assoc();
        $stmt->close();

        return $row ?: null;
    }

    /**
     * Return the N most-recently stored files (default 50).
     * Returns [] on DB error.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function recent(int $limit = 50): array
    {
        $db = self::connection();
        if ($db === null) return [];

        $limit = max(1, min($limit, 1000));  // clamp 1–1000
        $stmt  = $db->prepare(
            "SELECT * FROM `" . MESHDB_TABLE . "`
             ORDER BY created_at DESC
             LIMIT ?"
        );
        if (!$stmt) return [];

        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows   = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        return $rows;
    }

    /**
     * Return total file count.
     * Returns -1 on DB error.
     */
    public static function count(): int
    {
        $db = self::connection();
        if ($db === null) return -1;

        $result = $db->query("SELECT COUNT(*) FROM `" . MESHDB_TABLE . "`");
        if (!$result) return -1;

        return (int) $result->fetch_row()[0];
    }

    /**
     * Delete a record by hash. Returns true on success / not-found, false on error.
     */
    public static function delete(string $hash): bool
    {
        $db = self::connection();
        if ($db === null) return false;

        $stmt = $db->prepare(
            "DELETE FROM `" . MESHDB_TABLE . "` WHERE hash = ?"
        );
        if (!$stmt) return false;

        $stmt->bind_param('s', $hash);
        $ok = $stmt->execute();
        $stmt->close();

        return $ok;
    }

    // ── private helpers ───────────────────────────────────────────────────────

    /** Best-effort real client IP (respects common reverse-proxy headers). */
    private static function clientIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            $v = $_SERVER[$k] ?? '';
            if ($v !== '') {
                // X-Forwarded-For may be a comma-separated list; take the first entry
                $ip = trim(explode(',', $v)[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '';
    }
}
// ═══════════════════════════════════════════════════════════════════════════════
//  HOW TO INTEGRATE INTO index.php
// ═══════════════════════════════════════════════════════════════════════════════
//
//  1. Copy mesh_db.php to the same directory as index.php.
//
//  2. Set credentials via environment variables (recommended) or edit the
//     define() defaults at the top of this file:
//
//       MESHDB_HOST  MESHDB_PORT  MESHDB_NAME  MESHDB_USER  MESHDB_PASS
//
//  3. Add one line near the top of index.php (after the define() block):
//
//       require_once __DIR__ . '/mesh_db.php';
//
//  4. In the UPLOAD ENDPOINT section of index.php, after a successful
//     storeLocally() call (where $local['ok'] === true and !$local['existed']),
//     add:
//
//       if ($local['ok'] && !$local['existed']) {
//           $ext  = safeExt($upload['name']);
//           $size = (int) filesize(FILES_DIR . '/' . $local['filename']);
//           MeshDB::record(
//               $local['hash'],
//               $upload['name'],
//               $ext,
//               $size,
//               $publicKey,
//               $nodeInfo,
//               $description,
//               false   // not a peer push
//           );
//       }
//
//  5. In the RECEIVE ENDPOINT (peer_push = 1), mirror step 4 with true
//     as the last argument:
//
//       if ($result['ok'] && !$result['existed']) {
//           $ext  = safeExt($upload['name']);
//           $size = (int) filesize(FILES_DIR . '/' . $result['filename']);
//           MeshDB::record(
//               $result['hash'],
//               $upload['name'],
//               $ext,
//               $size,
//               $publicKey,
//               $nodeInfo,
//               $description,
//               true    // arrived via peer push
//           );
//       }
//
//  6. Duplicate-hash guard (optional — the DB UNIQUE KEY already blocks it,
//     but you can short-circuit even earlier in storeLocally()):
//
//       if (MeshDB::exists($hash)) {
//           return ['ok' => true, 'hash' => $hash,
//                   'filename' => $baseName, 'existed' => true];
//       }
//
//  The table is created automatically on the first successful connection.
// ═══════════════════════════════════════════════════════════════════════════════