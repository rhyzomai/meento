# DHT meento

**Distributed Hash Table — Peer Discovery & File Index System**

A self-contained DHT implementation written in a single Java file with no external libraries.  
Nodes discover each other automatically, exchange peer lists transitively, and maintain a shared index of announced files — all persisted locally in plain text files.

---

## Requirements

- Java Development Kit (JDK) 8 or newer
- No external libraries or build tools required

---

## Quick Start

```bash
# 1. Compile
javac DHTMeento.java

# 2. Seed your peer list (add at least one known node)
echo "192.168.1.10:4480" >> servers.txt

# 3. Start your own node
java DHTMeento node 4480

# 4. In another terminal — discover peers and sync file index
java DHTMeento discover
```

---

## Commands

| Command | Description |
|---|---|
| `node [port]` | Start a DHT node. Registers itself in `servers.txt`. Default port: **4480** |
| `discover` | Ping all known peers, crawl transitively for new ones, pull their file lists, prune dead peers |
| `share <filename>` | Announce a file to all known nodes (saves to `files.txt` locally and remotely) |
| `search <query>` | Search filenames across local index and all reachable peers |
| `list` | Print all entries currently in `files.txt` |
| `peers` | Print all entries currently in `servers.txt` |
| `help` | Show usage summary |

---

## Storage Files

Both files are plain text, one entry per line, **no duplicate lines ever written**.

### `servers.txt` — Known Peers

```
192.168.1.10:4480
192.168.1.20:4480
10.0.0.5:4481
```

Each line is a peer address in `host:port` format.  
You can edit this file manually to add seed nodes before running `discover`.

### `files.txt` — Distributed File Index

```
document.pdf|192.168.1.10:4480|e559416820765be4...
music_album.zip|192.168.1.20:4480|a3f2819c04bd92e1...
movie.mkv|10.0.0.5:4481|78bc340fde127a09...
```

Each line has three pipe-separated fields:

| Field | Description |
|---|---|
| `filename` | Name of the announced file |
| `host:port` | Address of the node that shared it |
| `nodeId` | SHA-1 hex ID of that node |

---

## How It Works

### Node Identity

When a node starts, it computes a **Node ID** as the SHA-1 hash of its `host:port` string (Kademlia-inspired). This ID uniquely identifies the node in the network without requiring a central registry.

### Wire Protocol

All communication is **plain TCP**, newline-terminated. Every message is a single line:

- Fields within a command are separated by `|`
- Record lists in responses are separated by `;;`

| Command | Direction | Description |
|---|---|---|
| `DHT_PING\|senderAddr` | client → node | Liveness check; sender registers itself |
| `DHT_PONG\|addr\|nodeId` | node → client | Acknowledgement with node identity |
| `DHT_GET_PEERS` | client → node | Request peer list |
| `DHT_PEERS;;peer1;;peer2…` | node → client | Response with known peers |
| `DHT_GET_FILES` | client → node | Request file index |
| `DHT_FILES;;entry1;;entry2…` | node → client | Response with indexed files |
| `DHT_ANNOUNCE\|file\|addr\|id` | client → node | Register a file on a remote node |
| `DHT_ACK` | node → client | Announce accepted |
| `DHT_SEARCH\|query` | client → node | Search files by name |
| `DHT_SEARCH_RES;;entry1…` | node → client | Matching file entries |

### Peer Discovery (`discover`)

1. Reads all peers from `servers.txt` as the initial visit queue
2. PINGs each peer — unreachable ones are removed
3. Calls `DHT_GET_PEERS` on each alive peer — new addresses are enqueued for visiting
4. Calls `DHT_GET_FILES` on each alive peer — new file entries are appended to `files.txt`
5. Repeats transitively until all reachable nodes have been visited
6. Writes the final deduplicated, alive-only peer list back to `servers.txt`

### Periodic Peer Refresh

Running nodes perform a background sweep every **60 seconds** (first run after 30 s):  
each known peer is PINGed, and any that fail to respond are removed from `servers.txt`.

### Concurrency

- The node uses a fixed thread pool (`MAX_THREADS = 20`) to handle connections in parallel
- All file read/write operations are `synchronized` to prevent race conditions when a node and a client run in the same working directory

---

## Example Workflow — Two Machines on a LAN

**Machine A** (`192.168.1.10`):
```bash
java DHTMeento node 4480
```

**Machine B** (`192.168.1.20`):
```bash
# Tell B about A
echo "192.168.1.10:4480" > servers.txt

# Start B's node
java DHTMeento node 4480 &

# Announce a file
java DHTMeento share "project_backup.tar.gz"

# Run discovery — B finds A, A learns about B, both sync file lists
java DHTMeento discover
```

**Machine A** (after B has announced):
```bash
java DHTMeento search "backup"
# FILENAME                          SOURCE                      NODE-ID
# --------------------------------------------------------------------------------
# project_backup.tar.gz             192.168.1.20:4480           3bc7a921f04d...
```

---

## Default Configuration

| Setting | Value |
|---|---|
| Default port | `4480` |
| Connection timeout | `3000 ms` |
| Max concurrent connections | `20` |
| Peer refresh interval | `60 s` |
| Peer list file | `servers.txt` |
| File index file | `files.txt` |

All of these are constants at the top of `DHTMeento.java` and can be changed before compiling.

---

## Notes

- `servers.txt` and `files.txt` are created automatically in the **current working directory** when the program first runs. Run all commands from the same directory so they share the same state.
- The `share` command only announces a filename to the network — it does **not** transfer file content. DHT meento is a discovery and index system, not a file transfer protocol.
- To run multiple nodes on the same machine, use different ports: `java DHTMeento node 4481`
- When compiled, Java produces inner class files (`DHTMeento$DHTNode.class`, `DHTMeento$DHTClient.class`). Keep all `.class` files in the same directory.

---

## License

This project is provided as-is for educational and personal use.
