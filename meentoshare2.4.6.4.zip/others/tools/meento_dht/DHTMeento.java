import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.security.*;
import java.math.BigInteger;

/**
 * +--------------------------------------------------------------+
 *  DHT meento - Distributed Hash Table
 *  Peer Discovery & File Index System  v1.0.0
 * +--------------------------------------------------------------+
 *
 * Single-file DHT implementation using Kademlia-inspired routing.
 *  � servers.txt  -- known peer addresses (host:port), one per line
 *  � files.txt    -- indexed files (filename|host:port|nodeId), one per line
 *
 * Wire protocol (TCP, newline-terminated):
 *   Fields within a command : | separator
 *   Record lists in responses: ;; separator (safe: never appears in filenames)
 *
 * Usage:
 *   Compile:  javac DHTMeento.java
 *   Run node: java DHTMeento node [port]       (default port 4480)
 *   Discover: java DHTMeento discover
 *   Share:    java DHTMeento share <filename>
 *   Search:   java DHTMeento search <query>
 *   List:     java DHTMeento list
 *   Peers:    java DHTMeento peers
 *   Help:     java DHTMeento help
 */
public class DHTMeento {

    // -----------------------------------------------
    //  Constants
    // -----------------------------------------------
    static final String SERVERS_FILE = "servers.txt";
    static final String FILES_FILE   = "files.txt";
    static final int    DEFAULT_PORT = 4480;
    static final int    TIMEOUT_MS   = 3000;
    static final int    MAX_THREADS  = 20;
    static final String VERSION      = "1.0.0";

    // Protocol commands (sent as first field of every message)
    static final String CMD_PING       = "DHT_PING";
    static final String CMD_PONG       = "DHT_PONG";
    static final String CMD_GET_PEERS  = "DHT_GET_PEERS";
    static final String CMD_PEERS      = "DHT_PEERS";
    static final String CMD_GET_FILES  = "DHT_GET_FILES";
    static final String CMD_FILES      = "DHT_FILES";
    static final String CMD_ANNOUNCE   = "DHT_ANNOUNCE";
    static final String CMD_ACK        = "DHT_ACK";
    static final String CMD_SEARCH     = "DHT_SEARCH";
    static final String CMD_SEARCH_RES = "DHT_SEARCH_RES";

    // Record separator used in list responses (not a valid char in host:port or filenames)
    static final String ENTRY_SEP = ";;";

    // -----------------------------------------------
    //  Entry Point
    // -----------------------------------------------
    public static void main(String[] args) throws Exception {
        printBanner();
        if (args.length == 0) { printHelp(); return; }

        switch (args[0].toLowerCase()) {
            case "node":
                int p = args.length > 1 ? Integer.parseInt(args[1]) : DEFAULT_PORT;
                new DHTNode(p).start();
                break;
            case "discover":
                new DHTClient().discover();
                break;
            case "share":
                if (args.length < 2) { System.out.println("  Usage: share <filename>"); return; }
                new DHTClient().shareFile(args[1]);
                break;
            case "search":
                if (args.length < 2) { System.out.println("  Usage: search <query>"); return; }
                new DHTClient().searchFile(args[1]);
                break;
            case "list":
                new DHTClient().listFiles();
                break;
            case "peers":
                new DHTClient().listPeers();
                break;
            default:
                printHelp();
        }
    }

    // -----------------------------------------------
    //  Banner & Help
    // -----------------------------------------------
    static void printBanner() {
        System.out.println();
        System.out.println("  +----------------------------------------------------+");
        System.out.println("  |  DHT meento  --  Distributed Hash Table  v" + VERSION + "    |");
        System.out.println("  |  Peer Discovery & Distributed File Index           |");
        System.out.println("  +----------------------------------------------------+");
        System.out.println();
    }

    static void printHelp() {
        System.out.println("  COMMANDS");
        System.out.println("    node [port]      Start a DHT node (default port: " + DEFAULT_PORT + ")");
        System.out.println("    discover         Ping all known peers, crawl for new ones");
        System.out.println("    share <file>     Announce a file to the network");
        System.out.println("    search <query>   Search for files across the network");
        System.out.println("    list             List all files indexed in files.txt");
        System.out.println("    peers            List all peers stored in servers.txt");
        System.out.println("    help             Show this help");
        System.out.println();
        System.out.println("  STORAGE FILES");
        System.out.println("    servers.txt    Peer addresses  (host:port), one per line, no duplicates");
        System.out.println("    files.txt      File entries  (filename|host:port|nodeId), no duplicates");
        System.out.println();
    }

    // -----------------------------------------------
    //  Node ID  --  SHA-1 hex of "host:port"
    // -----------------------------------------------
    static String computeNodeId(String address) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] hash = md.digest(address.getBytes("UTF-8"));
            return new BigInteger(1, hash).toString(16);
        } catch (Exception e) {
            return Integer.toHexString(address.hashCode());
        }
    }

    // -----------------------------------------------
    //  File I/O  --  thread-safe, no duplicates
    // -----------------------------------------------

    /** Read all non-blank, non-comment lines preserving insertion order. */
    static synchronized Set<String> readLines(String filename) {
        Set<String> set = new LinkedHashSet<>();
        File f = new File(filename);
        if (!f.exists()) return set;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) set.add(line);
            }
        } catch (IOException e) {
            System.err.println("  [WARN] Cannot read " + filename + ": " + e.getMessage());
        }
        return set;
    }

    /** Append a line only when it is not already present. Returns true if written. */
    static synchronized boolean addLine(String filename, String entry) {
        if (entry == null) return false;
        entry = entry.trim();
        if (entry.isEmpty()) return false;
        if (readLines(filename).contains(entry)) return false;
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename, true))) {
            pw.println(entry);
            return true;
        } catch (IOException e) {
            System.err.println("  [WARN] Cannot write " + filename + ": " + e.getMessage());
            return false;
        }
    }

    /** Overwrite file with the supplied collection (caller is responsible for dedup). */
    static synchronized void writeLines(String filename, Collection<String> lines) {
        Set<String> seen = new LinkedHashSet<>();
        for (String l : lines)
            if (l != null && !l.trim().isEmpty()) seen.add(l.trim());
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename, false))) {
            for (String l : seen) pw.println(l);
        } catch (IOException e) {
            System.err.println("  [WARN] Cannot write " + filename + ": " + e.getMessage());
        }
    }

    // -----------------------------------------------
    //  Network helpers
    // -----------------------------------------------

    /** Detect this machine's best outbound IP. Falls back to loopback. */
    static String getLocalAddress(int port) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("8.8.8.8", 80), 1000);
            return s.getLocalAddress().getHostAddress() + ":" + port;
        } catch (Exception e) {
            return "127.0.0.1:" + port;
        }
    }

    /** Split "host:port" -- supports IPv4 and hostnames. Returns null on bad input. */
    static String[] splitHostPort(String peer) {
        if (peer == null) return null;
        int idx = peer.lastIndexOf(':');
        if (idx <= 0) return null;
        return new String[]{ peer.substring(0, idx), peer.substring(idx + 1) };
    }

    // -----------------------------------------------
    //  DHT Node  --  TCP server
    // -----------------------------------------------
    static class DHTNode {

        final int    port;
        final String address;  // "host:port"
        final String nodeId;   // SHA-1 hex
        final ExecutorService pool = Executors.newFixedThreadPool(MAX_THREADS);
        volatile boolean running = true;

        DHTNode(int port) {
            this.port    = port;
            this.address = getLocalAddress(port);
            this.nodeId  = computeNodeId(address);
        }

        void start() throws IOException {
            boolean isNew = addLine(SERVERS_FILE, address);
            System.out.println("  [NODE] Address  : " + address);
            System.out.println("  [NODE] Node ID  : " + nodeId);
            System.out.println("  [NODE] Port     : " + port);
            System.out.println("  [NODE] Registry : " + (isNew ? "registered in servers.txt" : "already in servers.txt"));
            System.out.println();

            // Periodic liveness sweep every 60 s (first run after 30 s)
            ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
            scheduler.scheduleAtFixedRate(this::refreshPeers, 30, 60, TimeUnit.SECONDS);

            ServerSocket server = new ServerSocket(port);
            System.out.println("  [NODE] Listening on port " + port + "  (Ctrl+C to stop)");
            System.out.println();

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                running = false;
                scheduler.shutdownNow();
                pool.shutdownNow();
                try { server.close(); } catch (IOException ignored) {}
                System.out.println("\n  [NODE] Node stopped.");
            }));

            while (running) {
                try {
                    Socket client = server.accept();
                    pool.submit(() -> handleClient(client));
                } catch (IOException e) {
                    if (running) System.err.println("  [ERROR] Accept failed: " + e.getMessage());
                }
            }
        }

        // ---- per-connection handler ----
        void handleClient(Socket socket) {
            try {
                socket.setSoTimeout(TIMEOUT_MS);
                BufferedReader in  = new BufferedReader(new InputStreamReader(socket.getInputStream(),  "UTF-8"));
                PrintWriter    out = new PrintWriter(  new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

                String raw = in.readLine();
                if (raw == null || raw.isEmpty()) return;

                String[] parts   = raw.split("\\|", -1);
                String   command = parts[0];
                String   remote  = socket.getInetAddress().getHostAddress();
                System.out.println("  [NODE] " + command + " from " + remote);

                switch (command) {

                    case CMD_PING: {
                        // parts[1] = sender "host:port"
                        if (parts.length > 1 && !parts[1].isEmpty()) {
                            boolean added = addLine(SERVERS_FILE, parts[1]);
                            if (added) System.out.println("  [NODE] New peer registered: " + parts[1]);
                        }
                        out.println(CMD_PONG + "|" + address + "|" + nodeId);
                        break;
                    }

                    case CMD_GET_PEERS: {
                        Set<String> peers = readLines(SERVERS_FILE);
                        StringBuilder sb = new StringBuilder(CMD_PEERS);
                        for (String peer : peers) sb.append(ENTRY_SEP).append(peer);
                        out.println(sb.toString());
                        break;
                    }

                    case CMD_GET_FILES: {
                        Set<String> files = readLines(FILES_FILE);
                        StringBuilder sb = new StringBuilder(CMD_FILES);
                        for (String file : files) sb.append(ENTRY_SEP).append(file);
                        out.println(sb.toString());
                        break;
                    }

                    case CMD_ANNOUNCE: {
                        // parts[1]=filename  parts[2]=sourceAddr  [parts[3]=sourceNodeId]
                        if (parts.length >= 3) {
                            String fname = parts[1];
                            String src   = parts[2];
                            String srcId = parts.length > 3 ? parts[3] : computeNodeId(src);
                            boolean added = addLine(FILES_FILE, fname + "|" + src + "|" + srcId);
                            System.out.println("  [NODE] File " + (added ? "indexed" : "known  ")
                                + ": " + fname + " @ " + src);
                        }
                        out.println(CMD_ACK);
                        break;
                    }

                    case CMD_SEARCH: {
                        // parts[1] = search query
                        String query = parts.length > 1 ? parts[1].toLowerCase() : "";
                        StringBuilder sb = new StringBuilder(CMD_SEARCH_RES);
                        for (String file : readLines(FILES_FILE)) {
                            // file = "filename|host:port|nodeId"
                            String fname = file.split("\\|", 2)[0].toLowerCase();
                            if (fname.contains(query)) sb.append(ENTRY_SEP).append(file);
                        }
                        out.println(sb.toString());
                        break;
                    }

                    default:
                        out.println("DHT_ERR|Unknown command: " + command);
                }
            } catch (Exception ignored) {
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        // ---- periodic peer health check ----
        void refreshPeers() {
            Set<String> peers = readLines(SERVERS_FILE);
            System.out.println("  [NODE] Refreshing " + peers.size() + " peer(s)...");
            Set<String> alive = new LinkedHashSet<>();

            for (String peer : peers) {
                if (peer.equals(address)) { alive.add(peer); continue; }
                String[] hp = splitHostPort(peer);
                if (hp == null) continue;
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress(hp[0], Integer.parseInt(hp[1])), TIMEOUT_MS);
                    s.setSoTimeout(TIMEOUT_MS);
                    PrintWriter    out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"), true);
                    BufferedReader in  = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                    out.println(CMD_PING + "|" + address);
                    String resp = in.readLine();
                    if (resp != null && resp.startsWith(CMD_PONG)) alive.add(peer);
                    else System.out.println("  [NODE] Bad response, removing: " + peer);
                } catch (Exception e) {
                    System.out.println("  [NODE] Unreachable, removing: " + peer);
                }
            }

            writeLines(SERVERS_FILE, alive);
            System.out.println("  [NODE] Refresh done: " + alive.size() + "/" + peers.size() + " alive.");
        }
    }

    // -----------------------------------------------
    //  DHT Client  --  CLI operations
    // -----------------------------------------------
    static class DHTClient {

        /** Open a TCP connection, send one line, receive one line. Returns null on any failure. */
        String sendRequest(String host, int port, String message) {
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), TIMEOUT_MS);
                s.setSoTimeout(TIMEOUT_MS);
                PrintWriter    out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"), true);
                BufferedReader in  = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                out.println(message);
                return in.readLine();
            } catch (Exception e) {
                return null;
            }
        }

        /** Split a list response (uses ENTRY_SEP). Skips the command token at index 0. */
        List<String> splitEntries(String response) {
            List<String> list = new ArrayList<>();
            if (response == null) return list;
            String[] parts = response.split(java.util.regex.Pattern.quote(ENTRY_SEP), -1);
            for (int i = 1; i < parts.length; i++) {
                String e = parts[i].trim();
                if (!e.isEmpty()) list.add(e);
            }
            return list;
        }

        // ---- discover ----
        void discover() {
            System.out.println("  [DISCOVER] Starting peer discovery...");
            Set<String> initial = readLines(SERVERS_FILE);
            if (initial.isEmpty()) {
                System.out.println("  [DISCOVER] servers.txt is empty.");
                System.out.println("  [DISCOVER] Add at least one seed peer (host:port) to get started.");
                System.out.println();
                return;
            }
            System.out.println("  [DISCOVER] Seed peers : " + initial.size());

            Queue<String> toVisit  = new LinkedList<>(initial);
            Set<String>   visited  = new LinkedHashSet<>();
            Set<String>   alive    = new LinkedHashSet<>();
            Set<String>   newPeers = new LinkedHashSet<>();
            int           newFiles = 0;

            while (!toVisit.isEmpty()) {
                String peer = toVisit.poll();
                if (visited.contains(peer)) continue;
                visited.add(peer);

                String[] hp = splitHostPort(peer);
                if (hp == null) continue;
                int port;
                try { port = Integer.parseInt(hp[1]); } catch (NumberFormatException e) { continue; }

                // PING
                String pong = sendRequest(hp[0], port,
                        CMD_PING + "|" + getLocalAddress(DEFAULT_PORT));
                if (pong == null || !pong.startsWith(CMD_PONG)) {
                    System.out.println("  [DISCOVER] x Unreachable : " + peer);
                    continue;
                }
                System.out.println("  [DISCOVER] + Alive       : " + peer);
                alive.add(peer);

                // GET_PEERS -- crawl transitively
                for (String rp : splitEntries(sendRequest(hp[0], port, CMD_GET_PEERS))) {
                    if (!visited.contains(rp)) {
                        toVisit.add(rp);
                        if (!initial.contains(rp)) newPeers.add(rp);
                    }
                }

                // GET_FILES -- merge into local files.txt
                for (String rf : splitEntries(sendRequest(hp[0], port, CMD_GET_FILES))) {
                    if (addLine(FILES_FILE, rf)) newFiles++;
                }
            }

            // Persist new peers and prune dead ones
            for (String np : newPeers) addLine(SERVERS_FILE, np);
            Set<String> toWrite = new LinkedHashSet<>(alive);
            toWrite.addAll(newPeers);
            writeLines(SERVERS_FILE, toWrite);

            System.out.println();
            System.out.println("  [DISCOVER] Alive peers   : " + alive.size());
            System.out.println("  [DISCOVER] New peers     : " + newPeers.size());
            System.out.println("  [DISCOVER] New files     : " + newFiles);
            System.out.println("  [DISCOVER] servers.txt   : updated (no duplicates)");
            System.out.println("  [DISCOVER] files.txt     : updated (no duplicates)");
            System.out.println("  [DISCOVER] Done.");
            System.out.println();
        }

        // ---- shareFile ----
        void shareFile(String filename) {
            String localAddr = getLocalAddress(DEFAULT_PORT);
            String localId   = computeNodeId(localAddr);
            String entry     = filename + "|" + localAddr + "|" + localId;

            System.out.println("  [SHARE] Announcing: " + filename);

            boolean local = addLine(FILES_FILE, entry);
            System.out.println("  [SHARE] Local index  : " + (local ? "added" : "already present"));

            Set<String> peers = readLines(SERVERS_FILE);
            int ok = 0;
            for (String peer : peers) {
                String[] hp = splitHostPort(peer);
                if (hp == null) continue;
                try {
                    int port = Integer.parseInt(hp[1]);
                    String resp = sendRequest(hp[0], port,
                            CMD_ANNOUNCE + "|" + filename + "|" + localAddr + "|" + localId);
                    if (CMD_ACK.equals(resp)) {
                        System.out.println("  [SHARE] + Announced  : " + peer);
                        ok++;
                    } else {
                        System.out.println("  [SHARE] x Failed     : " + peer);
                    }
                } catch (Exception ignored) {}
            }

            System.out.println();
            System.out.println("  [SHARE] Announced to " + ok + "/" + peers.size() + " peer(s).");
            System.out.println();
        }

        // ---- searchFile ----
        void searchFile(String query) {
            System.out.println("  [SEARCH] Query: \"" + query + "\"");
            System.out.println();

            Set<String> results = new LinkedHashSet<>();

            // Local index
            for (String f : readLines(FILES_FILE)) {
                if (f.split("\\|", 2)[0].toLowerCase().contains(query.toLowerCase()))
                    results.add(f);
            }

            // Remote peers
            for (String peer : readLines(SERVERS_FILE)) {
                String[] hp = splitHostPort(peer);
                if (hp == null) continue;
                try {
                    int port = Integer.parseInt(hp[1]);
                    List<String> found = splitEntries(
                            sendRequest(hp[0], port, CMD_SEARCH + "|" + query));
                    results.addAll(found);
                } catch (Exception ignored) {}
            }

            if (results.isEmpty()) {
                System.out.println("  [SEARCH] No results found.");
            } else {
                System.out.println("  [SEARCH] " + results.size() + " result(s):");
                System.out.println();
                printFileTable(results);
            }
            System.out.println();
        }

        // ---- listFiles ----
        void listFiles() {
            Set<String> files = readLines(FILES_FILE);
            System.out.println("  [LIST] " + files.size() + " file(s) in " + FILES_FILE);
            System.out.println();
            if (files.isEmpty()) {
                System.out.println("  (empty -- run 'share' or 'discover' to populate)");
            } else {
                printFileTable(files);
            }
            System.out.println();
        }

        // ---- listPeers ----
        void listPeers() {
            Set<String> peers = readLines(SERVERS_FILE);
            System.out.println("  [PEERS] " + peers.size() + " peer(s) in " + SERVERS_FILE);
            System.out.println();
            if (peers.isEmpty()) {
                System.out.println("  (empty -- add seed peers manually, one host:port per line)");
            } else {
                System.out.printf("  %-32s  %s%n", "ADDRESS", "NODE-ID (truncated)");
                System.out.println("  " + dashes(60));
                for (String peer : peers) {
                    String nid = computeNodeId(peer);
                    System.out.printf("  %-32s  %s%n",
                            peer, nid.substring(0, Math.min(16, nid.length())) + "...");
                }
            }
            System.out.println();
        }

        // ---- shared formatting ----
        void printFileTable(Collection<String> entries) {
            System.out.printf("  %-32s  %-26s  %s%n", "FILENAME", "SOURCE", "NODE-ID");
            System.out.println("  " + dashes(80));
            for (String e : entries) {
                String[] p = e.split("\\|", -1);
                String fname  = p.length > 0 ? p[0] : e;
                String source = p.length > 1 ? p[1] : "?";
                String nid    = p.length > 2 ? p[2].substring(0, Math.min(12, p[2].length())) + "..." : "?";
                System.out.printf("  %-32s  %-26s  %s%n", fname, source, nid);
            }
        }

        String dashes(int n) {
            char[] c = new char[n]; Arrays.fill(c, '-'); return new String(c);
        }
    }
}