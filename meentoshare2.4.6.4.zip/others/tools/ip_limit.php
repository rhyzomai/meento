﻿<?php
// ── config ────────────────────────────────────────────────────────────────────
const LIMIT_FILE  = __DIR__ . '/file_upload_limit.txt';
const IP_HASH_DIR = __DIR__ . '/tmp_ip/';
const SALT        = 'rK#8wP@5mX!jN2qY';   // ← change to your own secret salt

const INTERVALS = [
    'none'  => ['label' => 'No restriction', 'seconds' => 0],
    '1min'  => ['label' => '1 Minute',        'seconds' => 60],
    '10min' => ['label' => '10 Minutes',       'seconds' => 600],
    '1hour' => ['label' => '1 Hour',           'seconds' => 3600],
    '1day'  => ['label' => '1 Day',            'seconds' => 86400],
    '1week' => ['label' => '1 Week',           'seconds' => 604800],
];

// ── helpers ───────────────────────────────────────────────────────────────────
function getUserIP(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return trim(explode(',', $_SERVER[$k])[0]);
    }
    return '0.0.0.0';
}

function ipHashKey(string $ip): string {
    return hash('sha256', SALT . $ip);
}

function ipHashFile(string $ip): string {
    return IP_HASH_DIR . ipHashKey($ip) . '.txt';
}

/**
 * File format (plain text, pipe-delimited):
 *   timestamp|count
 * timestamp = unix time of the first access in the current window
 * count      = number of accesses in the current window
 */
function readUserRecord(string $ip): ?array {
    $f = ipHashFile($ip);
    if (!file_exists($f)) return null;
    $raw = trim(file_get_contents($f));
    if ($raw === '') return null;
    $parts = explode('|', $raw);
    if (count($parts) < 2) return null;
    return ['timestamp' => (int)$parts[0], 'count' => (int)$parts[1]];
}

function writeUserRecord(string $ip, int $timestamp, int $count): void {
    if (!is_dir(IP_HASH_DIR)) mkdir(IP_HASH_DIR, 0750, true);
    file_put_contents(ipHashFile($ip), $timestamp . '|' . $count);
}

/** Returns config from file_upload_limit.txt or null if empty/missing. */
function readLimitConfig(): ?array {
    if (!file_exists(LIMIT_FILE)) return null;
    $raw = trim(file_get_contents(LIMIT_FILE));
    if ($raw === '') return null;
    $d = json_decode($raw, true);
    return is_array($d) ? $d : null;
}

/** True when file_upload_limit.txt has ANY non-empty content. */
function isHardLocked(): bool {
    if (!file_exists(LIMIT_FILE)) return false;
    return trim(file_get_contents(LIMIT_FILE)) !== '';
}

function formatDuration(int $secs): string {
    if ($secs <= 0)    return '0 seconds';
    if ($secs < 60)    return $secs . ' second' . ($secs !== 1 ? 's' : '');
    if ($secs < 3600)  { $m = (int)($secs / 60);  return $m . ' minute' . ($m !== 1 ? 's' : ''); }
    if ($secs < 86400) { $h = (int)($secs / 3600); return $h . ' hour'   . ($h !== 1 ? 's' : ''); }
    $d = (int)($secs / 86400); return $d . ' day' . ($d !== 1 ? 's' : '');
}

// ── hard lock check (file_upload_limit.txt has content) ──────────────────────
$hardLocked = isHardLocked();

if ($hardLocked) {
    // Output nothing but the message and exit immediately
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Limits reached!</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;display:flex;align-items:center;justify-content:center;
          background:#fff;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
.msg{text-align:center;padding:2rem}
.msg h1{font-size:1.4rem;font-weight:700;color:#c00;letter-spacing:-0.02em}
.msg p{font-size:0.85rem;color:#888;margin-top:0.5rem}
</style>
</head>
<body>
<div class="msg">
  <h1>Limits reached!</h1>
  <p>Access to this resource has been permanently disabled.</p>
</div>
</body>
</html>
<?php
    exit;
}

// ── read limit config ─────────────────────────────────────────────────────────
$limitData   = readLimitConfig();
$isConfigSet = $limitData !== null;
$intervalKey = $limitData['interval']   ?? 'none';
$intervalSec = INTERVALS[$intervalKey]['seconds'] ?? 0;
$maxAccess   = isset($limitData['max_access']) ? (int)$limitData['max_access'] : 0; // 0 = unlimited

// ── evaluate user access ──────────────────────────────────────────────────────
$ip          = getUserIP();
$record      = readUserRecord($ip);
$showContent = false;
$accessBlocked  = false;
$limitExceeded  = false;
$secsLeft    = 0;
$userCount   = 0;

if ($isConfigSet) {
    $now = time();

    if ($record === null) {
        // First visit ever in this config
        writeUserRecord($ip, $now, 1);
        $record   = ['timestamp' => $now, 'count' => 1];
        $userCount = 1;
        $showContent = true;
    } else {
        $windowStart = $record['timestamp'];
        $elapsed     = $now - $windowStart;

        // Check if the interval window has reset
        $windowExpired = ($intervalSec > 0 && $elapsed >= $intervalSec);

        if ($windowExpired) {
            // New window — reset count
            writeUserRecord($ip, $now, 1);
            $record    = ['timestamp' => $now, 'count' => 1];
            $userCount = 1;
            $showContent = true;
        } else {
            $userCount = $record['count'];

            // Check max access limit within window
            if ($maxAccess > 0 && $userCount >= $maxAccess) {
                $limitExceeded = true;
                $accessBlocked = true;
                $showContent   = false;
                // Compute time until window resets (only relevant if interval > 0)
                $secsLeft = ($intervalSec > 0) ? max(0, $intervalSec - $elapsed) : 0;
            } else {
                // Still within allowed count — record this visit
                $newCount = $userCount + 1;
                writeUserRecord($ip, $windowStart, $newCount);
                $userCount   = $newCount;
                $showContent = true;
            }
        }
    }
}

// ── handle POST (save config) ─────────────────────────────────────────────────
$message = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isConfigSet) {
    $chosen    = trim($_POST['interval']   ?? '');
    $maxIn     = trim($_POST['max_access'] ?? '');
    $maxAccNew = max(0, (int)$maxIn);

    if (!array_key_exists($chosen, INTERVALS)) {
        $message = 'Invalid interval selected.';
        $msgType = 'fail';
    } else {
        $payload = [
            'interval'   => $chosen,
            'label'      => INTERVALS[$chosen]['label'],
            'seconds'    => INTERVALS[$chosen]['seconds'],
            'max_access' => $maxAccNew,
            'created_at' => date('Y-m-d H:i:s'),
        ];
        $fh = fopen(LIMIT_FILE, 'w');
        if ($fh === false) {
            $message = 'Could not write file_upload_limit.txt. Check permissions.';
            $msgType = 'fail';
        } else {
            fwrite($fh, json_encode($payload, JSON_PRETTY_PRINT));
            fclose($fh);
            // Reload state
            $limitData   = readLimitConfig();
            $isConfigSet = true;
            $intervalKey = $chosen;
            $intervalSec = INTERVALS[$chosen]['seconds'];
            $maxAccess   = $maxAccNew;
            $message     = 'Config saved — interval: ' . INTERVALS[$chosen]['label']
                         . ($maxAccNew > 0 ? ', max accesses: ' . $maxAccNew : ', max accesses: unlimited');
            $msgType     = 'ok';
            // Record this visit
            $now = time();
            writeUserRecord($ip, $now, 1);
            $userCount   = 1;
            $showContent = true;
        }
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node — Access Control</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:#fff;color:#111;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;flex-direction:column;align-items:center;padding:2rem 1.5rem}
.page{max-width:36rem;width:100%}

/* header */
header{margin-bottom:2rem;display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:0.8rem}
h1{font-size:1.4rem;font-weight:700;letter-spacing:-0.02em}
h1 em{font-weight:400;color:#555;font-style:normal}
.sub{font-size:0.8rem;color:#777;margin-top:0.2rem}

/* node bar */
#node-bar{display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.75rem;font-size:0.8rem;color:#555}
.nb-pill{display:flex;align-items:center;gap:0.35rem;padding:0.25rem 0.6rem;background:#f5f5f5;border-radius:4px;border:1px solid #e0e0e0}
.nb-dot{width:7px;height:7px;border-radius:50%;background:#aaa}
.nb-dot.ok{background:#1a8e3f}
.nb-dot.blue{background:#0044cc}
.nb-dot.warn{background:#c87000}
.nb-dot.red{background:#d00}
.nb-val{font-weight:500}

/* status messages */
.status-msg{margin-bottom:1.25rem;padding:0.8rem 1rem;border-radius:4px;font-size:0.9rem;line-height:1.5;animation:fadeUp 0.25s ease;display:flex;align-items:flex-start;gap:0.55rem}
.status-msg.ok  {background:#f0fff0;border:1px solid #c0e0c0;color:#1a8e3f}
.status-msg.fail{background:#fff0f0;border:1px solid #e0c0c0;color:#d00}
.status-msg.warn{background:#fff8f0;border:1px solid #f0c080;color:#c87000}
.status-msg.info{background:#f0f4ff;border:1px solid #c0d0ff;color:#0044cc}
.status-msg svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0;margin-top:0.15rem}
.status-msg div{flex:1}
.status-msg strong{display:block;margin-bottom:0.2rem}

/* card */
.card{border:1px solid #ddd;border-radius:6px;overflow:hidden;margin-bottom:1.25rem}
.card-head{display:flex;align-items:center;gap:0.75rem;padding:0.8rem 1rem;border-bottom:1px solid #eee;background:#fafafa}
.card-icon{width:2rem;height:2rem;border-radius:4px;display:grid;place-items:center;flex-shrink:0;color:#0044cc;background:#f0f4ff}
.card-icon.locked-icon{background:#fff8f0;color:#c87000}
.card-icon.ok-icon{background:#f0fff0;color:#1a8e3f}
.card-title{font-size:0.9rem;font-weight:600;flex:1}

.lock-badge{display:inline-flex;align-items:center;gap:0.3rem;font-size:0.72rem;padding:0.15rem 0.55rem;border-radius:4px;border:1px solid #f0c080;background:#fff8f0;color:#c87000;font-weight:600}
.open-badge{display:inline-flex;align-items:center;gap:0.3rem;font-size:0.72rem;padding:0.15rem 0.55rem;border-radius:4px;border:1px solid #c0e0c0;background:#f0fff0;color:#1a8e3f;font-weight:600}
.badge svg{width:0.75rem;height:0.75rem;fill:none;stroke:currentColor;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}

/* interval selector */
.card-body{padding:1rem}
label.fl{display:block;font-size:0.75rem;color:#777;margin-bottom:0.75rem}

.interval-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:0.5rem;margin-bottom:1rem}
.iv-option{position:relative}
.iv-option input[type=radio]{position:absolute;opacity:0;width:0;height:0}
.iv-label{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0.2rem;padding:0.65rem 0.5rem;border:1.5px solid #ddd;border-radius:5px;cursor:pointer;text-align:center;transition:border-color 0.15s,background 0.15s,color 0.15s;user-select:none}
.iv-label:hover{border-color:#aaa;background:#fafafa}
.iv-option input:checked + .iv-label{border-color:#0044cc;background:#f0f4ff;color:#0044cc}
.iv-icon{font-size:1.1rem;margin-bottom:0.1rem}
.iv-text{font-size:0.78rem;font-weight:600}
.iv-sub{font-size:0.68rem;color:#999}
.iv-option input:checked + .iv-label .iv-sub{color:#6688cc}

/* max access input */
.field-row{display:flex;flex-direction:column;gap:0.3rem;margin-bottom:0.75rem}
.field-row label{font-size:0.75rem;color:#777}
.field-row input[type=number]{width:100%;padding:0.5rem 0.7rem;border:1.5px solid #ddd;border-radius:5px;font-size:0.85rem;color:#111;outline:none;transition:border-color 0.15s}
.field-row input[type=number]:focus{border-color:#0044cc}
.field-row .hint{font-size:0.7rem;color:#aaa}

/* locked display */
.locked-display{display:flex;align-items:center;gap:0.75rem;padding:0.75rem;background:#fafafa;border:1px solid #eee;border-radius:5px;margin-bottom:0.75rem}
.ld-icon{width:2.5rem;height:2.5rem;background:#f0f4ff;border-radius:4px;display:grid;place-items:center;flex-shrink:0;font-size:1.3rem}
.ld-label{font-size:0.85rem;font-weight:600;color:#111}
.ld-meta{font-size:0.75rem;color:#888;margin-top:0.15rem}

.hint{font-size:0.73rem;color:#999;margin-top:0.5rem;line-height:1.5}

/* form footer */
.form-footer{padding:0.8rem 1rem;border-top:1px solid #eee;display:flex;align-items:center;justify-content:space-between;gap:0.8rem;background:#fafafa}
.form-note{font-size:0.8rem;color:#777}
.form-note b{color:#555;font-weight:600}
.btn-save{padding:0.5rem 1.2rem;background:#0044cc;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:0.85rem;cursor:pointer;transition:opacity 0.2s;display:flex;align-items:center;gap:0.4rem}
.btn-save:hover{opacity:0.88}
.btn-save svg{width:1rem;height:1rem;stroke:#fff;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

/* protected content */
.content-zone{border:1px solid #ddd;border-radius:6px;overflow:hidden;margin-bottom:1.25rem}
.content-head{display:flex;align-items:center;gap:0.75rem;padding:0.8rem 1rem;border-bottom:1px solid #eee;background:#fafafa}
.content-body{padding:1.25rem 1rem}
.content-body p{font-size:0.9rem;line-height:1.7;color:#333;margin-bottom:0.75rem}
.content-body p:last-child{margin-bottom:0}
.content-body code{font-family:"SF Mono","Fira Code","Fira Mono","Roboto Mono",monospace;font-size:0.8rem;background:#f5f5f5;padding:0.15rem 0.4rem;border-radius:3px;border:1px solid #e8e8e8;color:#b04000}

/* countdown */
.countdown-box{text-align:center;padding:1.5rem 1rem}
.cd-timer{font-size:2.2rem;font-weight:700;letter-spacing:-0.03em;color:#c87000;font-family:"SF Mono","Fira Code",monospace;margin:0.5rem 0}
.cd-label{font-size:0.78rem;color:#999}

/* access counter badge */
.access-counter{display:inline-flex;align-items:center;gap:0.4rem;font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:4px;background:#f0f4ff;border:1px solid #c0d0ff;color:#0044cc;margin-left:auto}

/* ip note */
.ip-note{margin-top:0.5rem;padding:0.65rem 1rem;border-radius:4px;background:#f5f5f5;border:1px solid #e8e8e8;font-size:0.75rem;color:#888;display:flex;align-items:center;gap:0.5rem}
.ip-note svg{width:0.85rem;height:0.85rem;stroke:#bbb;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}

/* json preview */
.info-box{border:1px solid #ddd;border-radius:4px;overflow:hidden;margin-bottom:1.25rem}
.info-box-head{padding:0.5rem 1rem;border-bottom:1px solid #eee;font-size:0.75rem;color:#777;background:#fafafa;display:flex;align-items:center;gap:0.4rem}
.info-box-head svg{width:0.9rem;height:0.9rem;stroke:#777;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
pre.json-pre{padding:1rem;font-family:"SF Mono","Fira Code","Fira Mono","Roboto Mono",monospace;font-size:0.8rem;line-height:1.6;color:#333;overflow-x:auto;margin:0}
.jk{color:#0044cc}.js{color:#1a8e3f}.jn{color:#b04000}.jb{color:#d00}

footer{border-top:1px solid #eee;padding-top:1.2rem;margin-top:2rem;display:flex;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;font-size:0.75rem;color:#aaa}

@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="page">

  <header>
    <div>
      <h1>Mesh Node <em>/ access control</em></h1>
      <p class="sub">Interval-based content gate with per-IP access counting</p>
    </div>
  </header>

  <!-- status bar -->
  <div id="node-bar">
    <div class="nb-pill">
      <span class="nb-dot blue"></span>
      <span>access-control</span>
    </div>
    <div class="nb-pill">
      <span class="nb-dot <?= $isConfigSet ? 'ok' : 'warn' ?>"></span>
      <span>config <span class="nb-val"><?= $isConfigSet ? 'set' : 'empty' ?></span></span>
    </div>
    <div class="nb-pill">
      <span class="nb-dot <?= $accessBlocked ? 'red' : ($showContent ? 'ok' : 'warn') ?>"></span>
      <span>your access <span class="nb-val"><?= $accessBlocked ? 'blocked' : ($showContent ? 'granted' : 'pending') ?></span></span>
    </div>
    <?php if ($isConfigSet): ?>
    <div class="nb-pill">
      <span class="nb-dot blue"></span>
      <span>interval <span class="nb-val"><?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></span></span>
    </div>
    <?php if ($maxAccess > 0): ?>
    <div class="nb-pill">
      <span class="nb-dot blue"></span>
      <span>max <span class="nb-val"><?= $maxAccess ?> access<?= $maxAccess !== 1 ? 'es' : '' ?></span></span>
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  <!-- feedback -->
  <?php if ($message): ?>
  <div class="status-msg <?= htmlspecialchars($msgType) ?>">
    <?php if ($msgType === 'ok'): ?>
      <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
    <?php else: ?>
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
    <?php endif; ?>
    <div><?= htmlspecialchars($message) ?></div>
  </div>
  <?php endif; ?>

  <!-- access blocked message -->
  <?php if ($accessBlocked): ?>
  <div class="status-msg warn">
    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <div>
      <strong>Access limit reached</strong>
      You have used all <b><?= $maxAccess ?></b> allowed access<?= $maxAccess !== 1 ? 'es' : '' ?>
      within the <b><?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></b> window.
      <?php if ($secsLeft > 0): ?>
        Please wait <b><?= formatDuration($secsLeft) ?></b> for the window to reset.
      <?php endif; ?>
    </div>
  </div>
  <?php elseif ($isConfigSet && $showContent && !$message): ?>
  <div class="status-msg info">
    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <div>
      <strong>Access granted</strong>
      This is access <b>#<?= $userCount ?></b><?= $maxAccess > 0 ? ' of <b>' . $maxAccess . '</b>' : '' ?>
      within the current <b><?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></b> window.
    </div>
  </div>
  <?php endif; ?>

  <!-- ── interval + max access config card ── -->
  <form method="POST" action="">
    <div class="card">
      <div class="card-head">
        <div class="card-icon <?= $isConfigSet ? 'locked-icon' : 'ok-icon' ?>">
          <?php if ($isConfigSet): ?>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <?php else: ?>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <?php endif; ?>
        </div>
        <span class="card-title">Access Configuration</span>
        <?php if ($isConfigSet): ?>
          <span class="lock-badge badge">
            <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            locked
          </span>
        <?php else: ?>
          <span class="open-badge badge">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            writable
          </span>
        <?php endif; ?>
      </div>

      <div class="card-body">
        <?php if ($isConfigSet): ?>
          <!-- locked: show current settings -->
          <label class="fl">Current settings (locked) — stored in <code>file_upload_limit.txt</code></label>
          <?php $icons = ['none'=>'♾️','1min'=>'⏱️','10min'=>'🕐','1hour'=>'🕒','1day'=>'📅','1week'=>'🗓️']; ?>
          <div class="locked-display">
            <div class="ld-icon"><?= $icons[$intervalKey] ?? '⏱️' ?></div>
            <div>
              <div class="ld-label">Interval: <?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></div>
              <div class="ld-meta">
                Max accesses: <?= $maxAccess > 0 ? $maxAccess . ' per window' : 'Unlimited' ?>
                &nbsp;·&nbsp;
                Set on <?= htmlspecialchars($limitData['created_at'] ?? '—') ?>
              </div>
            </div>
          </div>
          <p class="hint">Config is permanently locked. Delete <code>file_upload_limit.txt</code> to reset.</p>

        <?php else: ?>
          <!-- writable: show selector + max access input -->
          <label class="fl">Select the time interval for the access window</label>
          <div class="interval-grid">
            <?php
              $icons = ['none'=>'♾️','1min'=>'⏱️','10min'=>'🕐','1hour'=>'🕒','1day'=>'📅','1week'=>'🗓️'];
              $subs  = ['none'=>'always','1min'=>'60s','10min'=>'600s','1hour'=>'3 600s','1day'=>'86 400s','1week'=>'604 800s'];
              foreach (INTERVALS as $key => $iv):
            ?>
            <div class="iv-option">
              <input type="radio" name="interval" id="iv_<?= $key ?>" value="<?= $key ?>"
                <?= ($key === 'none') ? 'checked' : '' ?>>
              <label class="iv-label" for="iv_<?= $key ?>">
                <span class="iv-icon"><?= $icons[$key] ?></span>
                <span class="iv-text"><?= htmlspecialchars($iv['label']) ?></span>
                <span class="iv-sub"><?= $subs[$key] ?></span>
              </label>
            </div>
            <?php endforeach; ?>
          </div>

          <div class="field-row">
            <label for="max_access">Max accesses per window</label>
            <input type="number" id="max_access" name="max_access" min="0" step="1" value="0"
                   placeholder="0 = unlimited">
            <span class="hint">Set to <b>0</b> for unlimited accesses within the interval. Set to <b>1</b> for a one-time access per window, etc.</span>
          </div>

          <p class="hint">Once saved to <code>file_upload_limit.txt</code> this config cannot be changed without deleting that file.</p>
        <?php endif; ?>
      </div>

      <?php if (!$isConfigSet): ?>
      <div class="form-footer">
        <p class="form-note">Writes to <b>file_upload_limit.txt</b></p>
        <button type="submit" class="btn-save">
          <svg viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
          Save config
        </button>
      </div>
      <?php endif; ?>
    </div>
  </form>

  <!-- ════════════════════════════════════════════════════════════════════════
       ── PROTECTED CONTENT ZONE ──
       Replace everything inside .content-body with your actual content.
       ════════════════════════════════════════════════════════════════════════ -->
  <div class="content-zone">
    <div class="content-head">
      <div class="card-icon <?= (!$isConfigSet || $accessBlocked) ? 'locked-icon' : 'ok-icon' ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      </div>
      <span class="card-title">Protected Content</span>
      <?php if ($accessBlocked): ?>
        <span class="lock-badge badge">
          <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          limit reached
        </span>
      <?php elseif ($showContent): ?>
        <span class="open-badge badge">
          <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
          access granted
        </span>
        <?php if ($isConfigSet): ?>
        <span class="access-counter">
          visit <?= $userCount ?><?= $maxAccess > 0 ? ' / ' . $maxAccess : '' ?>
        </span>
        <?php endif; ?>
      <?php else: ?>
        <span class="lock-badge badge">
          <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          config required
        </span>
      <?php endif; ?>
    </div>

    <?php if ($showContent && !$accessBlocked): ?>
    <!-- ✅ CONTENT VISIBLE — replace this block with your real content -->
    <div class="content-body">
      <p>
        ✅ Access granted. This is the <strong>protected content zone</strong>. Replace this block
        with any HTML, download links, scripts, API keys, or other resources you want
        to gate behind the access interval.
      </p>
      <p>
        Your visit has been counted. Current window access: <code>#<?= $userCount ?></code>
        <?php if ($maxAccess > 0): ?>
          of <code><?= $maxAccess ?></code> allowed.
        <?php else: ?>
          (unlimited accesses in this window).
        <?php endif; ?>
        Interval: <code><?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></code>.
      </p>
    </div>

    <?php elseif ($accessBlocked): ?>
    <!-- ⛔ ACCESS LIMIT REACHED -->
    <div class="countdown-box">
      <div class="cd-label">Access limit reached for this window</div>
      <?php if ($secsLeft > 0): ?>
        <div class="cd-timer" id="cd-timer"><?= formatDuration($secsLeft) ?></div>
        <div class="cd-label">until the window resets · interval: <?= htmlspecialchars(INTERVALS[$intervalKey]['label']) ?></div>
      <?php else: ?>
        <div class="cd-timer" style="font-size:1.2rem;color:#c87000">Limit reached</div>
        <div class="cd-label">No timed window configured — access permanently blocked until reset.</div>
      <?php endif; ?>
    </div>

    <?php else: ?>
    <!-- ⚙️ NOT YET CONFIGURED -->
    <div class="countdown-box">
      <div class="cd-label" style="font-size:0.85rem;color:#bbb">
        Set and save an access config above to unlock this content zone.
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- config file preview -->
  <div class="info-box">
    <div class="info-box-head">
      <svg viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
      file_upload_limit.txt — current config
    </div>
    <pre class="json-pre"><?php
      if ($limitData) {
          echo '<span class="jk">{</span>' . "\n";
          foreach ($limitData as $k => $v) {
              $vOut = is_int($v) ? '<span class="jn">' . $v . '</span>'
                                 : '<span class="js">"' . htmlspecialchars($v) . '"</span>';
              echo '  <span class="jk">"' . htmlspecialchars($k) . '"</span>: ' . $vOut . ",\n";
          }
          echo '<span class="jk">}</span>';
      } else {
          echo '<span style="color:#bbb">— file is empty or does not exist —</span>';
      }
    ?></pre>
  </div>

  <!-- ip note -->
  <div class="ip-note">
    <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
    Access is tracked via <code>sha256(SALT + IP)</code>. Raw IPs are never written to disk.
    Records stored as plain text in <code>tmp_ip/&lt;hash&gt;.txt</code> (format: <code>timestamp|count</code>).
  </div>

  <footer>
    <span>mesh-node · access control</span>
    <span>interval gate · ip-hash tracking · access counting</span>
  </footer>
</div>

<?php if ($accessBlocked && $secsLeft > 0): ?>
<script>
var secs = <?= (int)$secsLeft ?>;
var el   = document.getElementById('cd-timer');
function fmt(s) {
  if (s <= 0)    return '0 seconds';
  if (s < 60)    return s + (s === 1 ? ' second' : ' seconds');
  if (s < 3600)  { var m = Math.floor(s/60); var rs = s%60; return m + (m===1?' minute':' minutes') + (rs ? ' ' + rs + 's' : ''); }
  if (s < 86400) { var h = Math.floor(s/3600); var rm = Math.floor((s%3600)/60); return h + (h===1?' hour':' hours') + (rm ? ' ' + rm + 'm' : ''); }
  var d = Math.floor(s/86400); var rh = Math.floor((s%86400)/3600); return d + (d===1?' day':' days') + (rh ? ' ' + rh + 'h' : '');
}
var t = setInterval(function() {
  secs--;
  if (secs <= 0) { el.textContent = '0 seconds'; clearInterval(t); location.reload(); return; }
  el.textContent = fmt(secs);
}, 1000);
</script>
<?php endif; ?>
</body>
</html>