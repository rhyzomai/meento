﻿<?php

// ─── Helpers ────────────────────────────────────────────────────────────────

function isValidMd5(string $value): bool {
    return (bool) preg_match('/^[a-f0-9]{32}$/i', $value);
}

function respond(int $code, string $status, string $message): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

// ─── Read & validate GET parameters ─────────────────────────────────────────

$file        = $_GET['file']        ?? null;
$chunk       = $_GET['chunk']       ?? null;
$chunk_hash  = $_GET['chunck_hash'] ?? null;  // note: kept the typo from spec
$contents    = $_GET['contents']    ?? null;

// Presence check
if ($file === null || $chunk === null || $chunk_hash === null || $contents === null) {
    respond(400, 'error', 'Missing required parameter(s): file, chunk, chunck_hash, contents.');
}

// "file" must be a valid MD5 hash
if (!isValidMd5($file)) {
    respond(400, 'error', '"file" must be a valid MD5 hash (32 hex characters).');
}

// "chunk" must be a positive integer
if (!ctype_digit($chunk) || (int) $chunk < 1) {
    respond(400, 'error', '"chunk" must be a positive integer.');
}
$chunkNumber = (int) $chunk;

// "chunck_hash" must be a valid MD5 hash
if (!isValidMd5($chunk_hash)) {
    respond(400, 'error', '"chunck_hash" must be a valid MD5 hash (32 hex characters).');
}

// ─── Verify content integrity ────────────────────────────────────────────────

$computedHash = md5($contents);

if (!hash_equals(strtolower($chunk_hash), strtolower($computedHash))) {
    respond(409, 'error', 'Integrity check failed: md5(contents) does not match chunck_hash.');
}

// ─── Prepare output folder ───────────────────────────────────────────────────

$outputDir = __DIR__ . '/base64';

if (!is_dir($outputDir)) {
    if (!mkdir($outputDir, 0755, true)) {
        respond(500, 'error', 'Could not create output directory "base64".');
    }
}

// ─── Build filename & write ───────────────────────────────────────────────────

// Format: <file_md5>.<chunk_number>.<chunk_md5>
$filename = strtolower($file) . '.' . $chunkNumber . '.' . strtolower($chunk_hash);
$filepath = $outputDir . '/' . $filename;

// Skip if already written (idempotent)
if (file_exists($filepath)) {
    respond(200, 'skipped', 'Chunk already exists, skipping write: ' . $filename);
}

$handle = fopen($filepath, 'x');   // 'x' = create only, fail if exists (race-condition safe)

if ($handle === false) {
    // Could have been created between the file_exists check and fopen
    if (file_exists($filepath)) {
        respond(200, 'skipped', 'Chunk already exists, skipping write: ' . $filename);
    }
    respond(500, 'error', 'Could not open file for writing: ' . $filename);
}

$written = fwrite($handle, $contents);
fclose($handle);

if ($written === false) {
    respond(500, 'error', 'Failed to write contents to file: ' . $filename);
}

respond(201, 'ok', 'Chunk saved successfully: ' . $filename);