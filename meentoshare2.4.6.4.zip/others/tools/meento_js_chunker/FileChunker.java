import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class FileChunker {

    private static final int CHUNK_SIZE = 500;
    private static final String SOURCE_DIR = "base64_files";
    private static final String OUTPUT_DIR = "base64_chuncks";

    public static void main(String[] args) {
        // Create directories if they don't exist
        createDirectoryIfNotExists(SOURCE_DIR);
        createDirectoryIfNotExists(OUTPUT_DIR);

        File sourceDir = new File(SOURCE_DIR);
        File[] files = sourceDir.listFiles();

        if (files == null || files.length == 0) {
            System.out.println("No files found in '" + SOURCE_DIR + "' directory.");
            return;
        }

        System.out.println("Found " + files.length + " file(s) in '" + SOURCE_DIR + "'.\n");

        for (File file : files) {
            if (file.isFile()) {
                System.out.println("Processing: " + file.getName());
                try {
                    processFile(file);
                } catch (Exception e) {
                    System.err.println("  ERROR processing " + file.getName() + ": " + e.getMessage());
                }
                System.out.println();
            }
        }

        System.out.println("Done.");
    }

    private static void processFile(File file) throws IOException, NoSuchAlgorithmException {
        byte[] fileBytes = Files.readAllBytes(file.toPath());

        String fileMd5 = md5Hex(fileBytes);
        System.out.println("  File MD5  : " + fileMd5);
        System.out.println("  File size : " + fileBytes.length + " bytes");

        int totalChunks = (int) Math.ceil((double) fileBytes.length / CHUNK_SIZE);
        System.out.println("  Chunks    : " + totalChunks);

        for (int i = 0; i < totalChunks; i++) {
            int chunkNumber = i + 1;
            int start = i * CHUNK_SIZE;
            int end = Math.min(start + CHUNK_SIZE, fileBytes.length);
            byte[] chunkBytes = Arrays.copyOfRange(fileBytes, start, end);

            String chunkMd5 = md5Hex(chunkBytes);
            String chunkFileName = fileMd5 + "." + chunkNumber + "." + chunkMd5;
            File chunkFile = new File(OUTPUT_DIR, chunkFileName);

            Files.write(chunkFile.toPath(), chunkBytes);
            System.out.println("  Saved chunk " + chunkNumber + "/" + totalChunks + " -> " + chunkFileName);
        }
    }

    private static String md5Hex(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static void createDirectoryIfNotExists(String dirName) {
        File dir = new File(dirName);
        if (!dir.exists()) {
            if (dir.mkdirs()) {
                System.out.println("Created directory: " + dirName);
            } else {
                System.err.println("Failed to create directory: " + dirName);
            }
        }
    }
}