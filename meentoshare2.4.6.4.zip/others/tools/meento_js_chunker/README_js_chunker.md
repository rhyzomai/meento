# File Chunk Distributor

A set of tools to split files into small chunks, distribute them across multiple servers, and safely reassemble them. Built with Java (chunking) and PHP (sending and receiving).

---

## Overview

```
[ Java ]                  [ PHP ]                    [ PHP ]
FileChunker.java  →  distribute_chunks.php  →  upload_chunk.php
                                                  (on each server)

base64_files/         base64_chuncks/                base64/
  original files   →    chunked pieces    →       stored chunks
```

---

## Programs

### 1. `FileChunker.java`

Reads every file inside the `base64_files` folder, splits each one into binary chunks of **500 bytes**, and saves each chunk as a named file inside `base64_chuncks`.

#### Chunk filename format

```
<file_md5>.<chunk_number>.<chunk_md5>
```

| Part | Description |
|------|-------------|
| `file_md5` | MD5 hash of the entire original file |
| `chunk_number` | Sequential number starting at 1 |
| `chunk_md5` | MD5 hash of this chunk's bytes only |

**Example:** `a1b2c3d4e5f6...32chars.1.9f8e7d6c...32chars`

#### How to use

```bash
# 1. Place your files inside base64_files/
# 2. Compile
javac FileChunker.java

# 3. Run
java FileChunker
```

Both `base64_files/` and `base64_chuncks/` are created automatically if they do not exist.

#### Requirements

- Java 8 or higher
- No external libraries

---

### 2. `distribute_chunks.php`

Reads every chunk file from `base64_chuncks/`, verifies its local integrity, and sends its contents to one or more remote servers listed in `servers.txt`.

#### `servers.txt` format

One server URL per line. Empty lines and invalid URLs are ignored.

```
https://server1.example.com
https://server2.example.com
http://192.168.1.50
```

#### How it works

1. Loads and validates all URLs from `servers.txt`.
2. Scans `base64_chuncks/` and parses each filename using the pattern `<md5>.<number>.<md5>`. Files that do not match are skipped with a warning.
3. Sorts chunks by file hash then by chunk number for orderly processing.
4. For each chunk, reads the file and **verifies** that `md5(contents)` matches the hash embedded in the filename. Corrupted local files are skipped.
5. Sends the chunk to **every server** via HTTP GET to `upload_chunk.php` with four parameters:

| GET parameter | Value sent |
|---------------|-----------|
| `file` | First MD5 (original file hash) |
| `chunk` | Chunk number |
| `chunck_hash` | Second MD5 (chunk hash) |
| `contents` | Raw chunk bytes |

6. Reads the JSON response from each server and reports the result.
7. Prints a full summary at the end. Exits with code `1` if any operation failed (useful for cron jobs or shell scripts).

#### Console output example

```
=======================================================
 Chunk Distributor
=======================================================
 Servers : 2
 Chunks  : 3
=======================================================

[1/3] a1b2...ef.1.9f8e...12
  + Server 1 [201] Chunk saved successfully: a1b2...ef.1.9f8e...12
  ~ Server 2 [200] Chunk already exists, skipping write: a1b2...ef.1.9f8e...12

=======================================================
 Summary
=======================================================
 Total operations : 6  (3 chunks × 2 servers)
 Written (201)    : 4
 Skipped (200)    : 1
 Failed           : 0
=======================================================
```

| Icon | Meaning |
|------|---------|
| `+` | Chunk written successfully on the server (HTTP 201) |
| `~` | Chunk already existed on the server, skipped (HTTP 200) |
| `x` | Error — chunk was not saved |

#### How to use

```bash
php distribute_chunks.php
```

#### Requirements

- PHP 7.0 or higher
- `allow_url_fopen = On` in `php.ini`
- `base64_chuncks/` folder populated by `FileChunker.java`
- `servers.txt` in the same directory

---

### 3. `upload_chunk.php`

Receives a single chunk from `distribute_chunks.php` via HTTP GET, validates all inputs, verifies data integrity, and saves the chunk to disk. This script runs on each remote server.

#### GET parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `file` | Yes | MD5 hash of the original file (32 hex chars) |
| `chunk` | Yes | Chunk number (positive integer) |
| `chunck_hash` | Yes | MD5 hash of this chunk's contents (32 hex chars) |
| `contents` | Yes | Raw chunk bytes |

#### Validation rules

- `file` must be a valid 32-character MD5 hex string.
- `chunk` must be a positive integer (≥ 1).
- `chunck_hash` must be a valid 32-character MD5 hex string.
- `md5(contents)` must equal `chunck_hash` — if not, the request is rejected with HTTP 409.

#### Saved filename format

```
<file>.<chunk>.<chunck_hash>
```

This is identical to the format produced by `FileChunker.java`, ensuring full consistency across the pipeline.

#### Idempotency

If the chunk file already exists on disk, it is **not overwritten**. The script returns HTTP 200 with status `skipped`. This makes it safe to re-run `distribute_chunks.php` multiple times without duplicating data.

File creation uses `fopen(..., 'x')` which atomically fails if the file exists, protecting against race conditions from concurrent requests.

#### JSON responses

| HTTP code | `status` | Meaning |
|-----------|----------|---------|
| 201 | `ok` | Chunk saved successfully |
| 200 | `skipped` | Chunk already exists, not overwritten |
| 400 | `error` | Missing or invalid parameter |
| 409 | `error` | Integrity check failed (hash mismatch) |
| 500 | `error` | Server-side file system error |

#### How to deploy

Place `upload_chunk.php` in the web root (or any accessible path) of each server listed in `servers.txt`. The script creates the `base64/` folder automatically next to itself if it does not exist.

#### Requirements

- PHP 7.0 or higher
- Web server with PHP support (Apache, Nginx, etc.)
- Write permission on the directory where the script is placed

---

## Full pipeline walkthrough

```
1.  Add original files to  base64_files/

2.  Run:  javac FileChunker.java && java FileChunker
          → chunks appear in  base64_chuncks/

3.  Edit  servers.txt  with target server URLs

4.  Run:  php distribute_chunks.php
          → each chunk is sent to every server
          → each server saves chunks in its  base64/  folder

5.  Re-running step 4 is safe — already-received chunks are skipped
```

---

## Directory structure

```
project/
├── FileChunker.java          # Java chunker
├── distribute_chunks.php     # PHP sender
├── upload_chunk.php          # PHP receiver (deploy to each server)
├── servers.txt               # List of target server URLs
├── base64_files/             # Input: original files
└── base64_chuncks/           # Output: chunk files produced by Java
```

On each remote server:
```
webroot/
├── upload_chunk.php
└── base64/                   # Chunks received from distribute_chunks.php
```
