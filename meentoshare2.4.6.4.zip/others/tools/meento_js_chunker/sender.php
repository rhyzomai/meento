﻿<?php

// ─── Configuration ────────────────────────────────────────────────────────────

define('CHUNKS_DIR',   __DIR__ . '/base64_chuncks');
define('SERVERS_FILE', __DIR__ . '/servers.txt');
define('TIMEOUT',      30);   // seconds per HTTP request

// ─── Helpers ─────────────────────────────────────────────────────────────────

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) {
        die("[ERROR] servers.txt not found at: " . SERVERS_FILE . "\n");
    }

    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $servers = [];

    foreach ($lines as $line) {
        $url = trim($line);
        if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
            $servers[] = rtrim($url, '/');
        }
    }

    if (empty($servers)) {
        die("[ERROR] No valid URLs found in servers.txt.\n");
    }

    return $servers;
}

function listChunks(): array {
    if (!is_dir(CHUNKS_DIR)) {
        die("[ERROR] Directory not found: " . CHUNKS_DIR . "\n");
    }

    $chunks = [];
    $files  = scandir(CHUNKS_DIR);

    foreach ($files as $filename) {
        if ($filename === '.' || $filename === '..') {
            continue;
        }

        // Expected pattern: <md5>.<number>.<md5>
        if (!preg_match('/^([a-f0-9]{32})\.(\d+)\.([a-f0-9]{32})$/i', $filename, $m)) {
            echo "[SKIP] Filename does not match expected pattern: $filename\n";
            continue;
        }

        $chunks[] = [
            'filename'   => $filename,
            'filepath'   => CHUNKS_DIR . '/' . $filename,
            'file_hash'  => strtolower($m[1]),
            'chunk_num'  => (int) $m[2],
            'chunk_hash' => strtolower($m[3]),
        ];
    }

    // Sort by file hash then chunk number for orderly processing
    usort($chunks, function($a, $b) {
        if ($a['file_hash'] !== $b['file_hash']) {
            return strcmp($a['file_hash'], $b['file_hash']);
        }
        return $a['chunk_num'] - $b['chunk_num'];
    });

    return $chunks;
}

function sendChunk(string $serverUrl, array $chunk, string $contents): array {
    $params = http_build_query([
        'file'        => $chunk['file_hash'],
        'chunk'       => $chunk['chunk_num'],
        'chunck_hash' => $chunk['chunk_hash'],   // typo kept to match receiver
        'contents'    => $contents,
    ]);

    $url = $serverUrl . '/upload_chunk.php?' . $params;

    $ctx = stream_context_create([
        'http' => [
            'method'          => 'GET',
            'timeout'         => TIMEOUT,
            'ignore_errors'   => true,            // get body even on 4xx/5xx
        ],
    ]);

    $body = @file_get_contents($url, false, $ctx);

    // Parse HTTP status from response headers
    $httpCode = 0;
    if (!empty($http_response_header)) {
        if (preg_match('#HTTP/\S+\s+(\d+)#', $http_response_header[0], $hm)) {
            $httpCode = (int) $hm[1];
        }
    }

    $decoded = $body !== false ? @json_decode($body, true) : null;
    $status  = $decoded['status']  ?? 'unknown';
    $message = $decoded['message'] ?? ($body ?: 'No response body');

    return [
        'http_code' => $httpCode,
        'status'    => $status,
        'message'   => $message,
        'success'   => in_array($httpCode, [200, 201], true),
    ];
}

// ─── Main ─────────────────────────────────────────────────────────────────────

$servers = loadServers();
$chunks  = listChunks();

$totalChunks  = count($chunks);
$totalServers = count($servers);

echo "=======================================================\n";
echo " Chunk Distributor\n";
echo "=======================================================\n";
echo " Servers : $totalServers\n";
echo " Chunks  : $totalChunks\n";
echo "=======================================================\n\n";

if ($totalChunks === 0) {
    echo "[INFO] No valid chunks found in " . CHUNKS_DIR . ". Nothing to send.\n";
    exit(0);
}

$globalSuccess = 0;
$globalSkipped = 0;
$globalFailed  = 0;

foreach ($chunks as $idx => $chunk) {
    $pos      = $idx + 1;
    $label    = "{$chunk['file_hash']}.{$chunk['chunk_num']}.{$chunk['chunk_hash']}";

    echo "[$pos/$totalChunks] $label\n";

    // Read file contents once per chunk
    $contents = file_get_contents($chunk['filepath']);
    if ($contents === false) {
        echo "  [ERROR] Could not read file, skipping.\n\n";
        $globalFailed++;
        continue;
    }

    // Verify local integrity before sending
    $localHash = md5($contents);
    if ($localHash !== $chunk['chunk_hash']) {
        echo "  [ERROR] Local MD5 mismatch (expected {$chunk['chunk_hash']}, got $localHash), skipping.\n\n";
        $globalFailed++;
        continue;
    }

    // Send to every server
    foreach ($servers as $sIdx => $serverUrl) {
        $sNum   = $sIdx + 1;
        $result = sendChunk($serverUrl, $chunk, $contents);

        if ($result['status'] === 'ok') {
            $icon = '+';
        } elseif ($result['status'] === 'skipped') {
            $icon = '~';
        } else {
            $icon = 'x';
        }

        echo "  $icon Server $sNum [{$result['http_code']}] {$result['message']}\n";

        if ($result['success']) {
            if ($result['status'] === 'skipped') {
                $globalSkipped++;
            } else {
                $globalSuccess++;
            }
        } else {
            $globalFailed++;
        }
    }

    echo "\n";
}

// ─── Summary ──────────────────────────────────────────────────────────────────

$totalOps = $totalChunks * $totalServers;

echo "=======================================================\n";
echo " Summary\n";
echo "=======================================================\n";
echo " Total operations : $totalOps  ($totalChunks chunks × $totalServers servers)\n";
echo " Written (201)    : $globalSuccess\n";
echo " Skipped (200)    : $globalSkipped\n";
echo " Failed           : $globalFailed\n";
echo "=======================================================\n";

exit($globalFailed > 0 ? 1 : 0);