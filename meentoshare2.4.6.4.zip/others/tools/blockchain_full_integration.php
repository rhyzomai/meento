﻿if (isset($_GET['bc_action'])) {
    require_once __DIR__ . '/blockchain.php';
    SeastarBlockchainApi::handle();
    exit;
}