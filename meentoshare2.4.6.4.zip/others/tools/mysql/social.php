﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  SOCIAL NODE — Single-file PHP/MySQL Messaging & Groups System
// ═══════════════════════════════════════════════════════════════════════════════

// --- 1. CONFIGURATION ---
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'social_node');
define('DB_USER', 'root');
define('DB_PASS', '');

define('UPLOAD_DIR', __DIR__ . '/uploads');
define('LIKE_SALT', 'ChangeThisToARandomString_99!'); // Salt for SHA256 likes
define('COMMENT_RATE_LIMIT', 3); // Max comments per minute per user
define('MESSAGES_PER_PAGE', 10);

// --- 2. BOOTSTRAP & DB CONNECTION ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    
    // Create DB if not exists and select it
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "`");
    $pdo->exec("USE `" . DB_NAME . "`");

    // Initialize Schema
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NULL, -- NULL if anonymous
        target_type ENUM('group', 'user') NOT NULL,
        target_name VARCHAR(100) NOT NULL,
        content TEXT,
        image_path VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE SET NULL
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        parent_id INT NULL,
        user_id INT NOT NULL,
        content TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
        FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS likes (
        message_id INT NOT NULL,
        user_hash VARCHAR(64) NOT NULL,
        PRIMARY KEY (message_id, user_hash),
        FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
    )");

} catch (PDOException $e) {
    die("Database Connection Failed: " . htmlspecialchars($e->getMessage()));
}

// --- 3. HELPER FUNCTIONS ---
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function esc($string): string {
    return htmlspecialchars((string)$string, ENT_QUOTES, 'UTF-8');
}

function handleImageUpload(): ?string {
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) return null;
    
    $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
    finfo_close($fileInfo);

    $allowedMimes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
    if (!array_key_exists($mimeType, $allowedMimes)) return null;

    $ext = $allowedMimes[$mimeType];
    $filename = hash_file('sha256', $_FILES['image']['tmp_name']) . '.' . $ext;
    $destination = UPLOAD_DIR . '/' . $filename;

    if (!file_exists($destination)) {
        move_uploaded_file($_FILES['image']['tmp_name'], $destination);
    }
    return 'uploads/' . $filename;
}

// --- 4. ACTION HANDLERS ---
$errorMsg = '';
$successMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        if ($user && $pass) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$user]);
            if ($stmt->fetch()) {
                $errorMsg = "Username already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
                $stmt->execute([$user, password_hash($pass, PASSWORD_DEFAULT)]);
                $successMsg = "Registration successful. You can now login.";
            }
        }
    } 
    elseif ($action === 'login') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$user]);
        $row = $stmt->fetch();
        if ($row && password_verify($pass, $row['password_hash'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            redirect('?');
        } else {
            $errorMsg = "Invalid credentials.";
        }
    } 
    elseif ($action === 'logout') {
        session_destroy();
        redirect('?');
    }
    elseif ($action === 'post_message') {
        $targetType = $_POST['target_type'] ?? 'group';
        $targetName = trim($_POST['target_name'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $isAnon = isset($_POST['anonymous']);
        
        if ($targetName === '') $errorMsg = "Target name cannot be empty.";
        else {
            $imagePath = handleImageUpload();
            if ($content === '' && !$imagePath) $errorMsg = "Message or image is required.";
            else {
                $senderId = ($isAnon || !isLoggedIn()) ? null : $_SESSION['user_id'];
                $stmt = $pdo->prepare("INSERT INTO messages (sender_id, target_type, target_name, content, image_path) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$senderId, $targetType, $targetName, $content, $imagePath]);
                redirect("?view=$targetType&name=" . urlencode($targetName));
            }
        }
    }
    elseif ($action === 'post_comment' && isLoggedIn()) {
        $msgId = (int)($_POST['message_id'] ?? 0);
        $parentId = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
        $content = trim($_POST['content'] ?? '');

        if ($content !== '') {
            // Rate Limit Check
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM comments WHERE user_id = ? AND created_at > (NOW() - INTERVAL 1 MINUTE)");
            $stmt->execute([$_SESSION['user_id']]);
            if ($stmt->fetchColumn() >= COMMENT_RATE_LIMIT) {
                $errorMsg = "You are commenting too fast. Wait a minute.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO comments (message_id, parent_id, user_id, content) VALUES (?, ?, ?, ?)");
                $stmt->execute([$msgId, $parentId, $_SESSION['user_id'], $content]);
                redirect($_SERVER['HTTP_REFERER'] ?? '?');
            }
        }
    }
    elseif ($action === 'like' && isLoggedIn()) {
        $msgId = (int)($_POST['message_id'] ?? 0);
        $userHash = hash('sha256', $_SESSION['user_id'] . LIKE_SALT);
        
        $stmt = $pdo->prepare("INSERT IGNORE INTO likes (message_id, user_hash) VALUES (?, ?)");
        $stmt->execute([$msgId, $userHash]);
        redirect($_SERVER['HTTP_REFERER'] ?? '?');
    }
}

// --- 5. DATA FETCHING ---
$viewType = $_GET['view'] ?? 'group';
$viewName = $_GET['name'] ?? 'Global';
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
$offset = ($page - 1) * MESSAGES_PER_PAGE;

// Fetch Messages
$stmt = $pdo->prepare("
    SELECT m.*, u.username AS sender_name,
           (SELECT COUNT(*) FROM likes WHERE message_id = m.id) as like_count
    FROM messages m
    LEFT JOIN users u ON m.sender_id = u.id
    WHERE m.target_type = ? AND m.target_name = ?
    ORDER BY m.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->bindValue(1, $viewType);
$stmt->bindValue(2, $viewName);
$stmt->bindValue(3, MESSAGES_PER_PAGE, PDO::PARAM_INT);
$stmt->bindValue(4, $offset, PDO::PARAM_INT);
$stmt->execute();
$messages = $stmt->fetchAll();

// Fetch Comments recursively
function fetchComments($pdo, $messageId) {
    $stmt = $pdo->prepare("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.message_id = ? ORDER BY c.created_at ASC");
    $stmt->execute([$messageId]);
    $allComments = $stmt->fetchAll();
    
    $tree = [];
    $lookup = [];
    foreach ($allComments as $c) {
        $c['children'] = [];
        $lookup[$c['id']] = $c;
    }
    foreach ($lookup as $id => &$c) {
        if ($c['parent_id'] === null) {
            $tree[$id] = &$c;
        } else {
            if (isset($lookup[$c['parent_id']])) {
                $lookup[$c['parent_id']]['children'][] = &$c;
            }
        }
    }
    return $tree;
}

function renderComments($comments) {
    if (empty($comments)) return;
    echo '<div class="comments-list">';
    foreach ($comments as $c) {
        echo '<div class="comment-item">';
        echo '<div class="c-meta"><b>' . esc($c['username']) . '</b> &middot; ' . esc($c['created_at']) . '</div>';
        echo '<div class="c-body">' . nl2br(esc($c['content'])) . '</div>';
        if (isLoggedIn()) {
            echo '<button class="reply-btn" onclick="document.getElementById(\'reply-'.$c['id'].'\').style.display=\'block\'">Reply</button>';
            echo '<form method="POST" id="reply-'.$c['id'].'" class="reply-form" style="display:none; margin-top:0.5rem;">';
            echo '<input type="hidden" name="action" value="post_comment">';
            echo '<input type="hidden" name="message_id" value="'.$c['message_id'].'">';
            echo '<input type="hidden" name="parent_id" value="'.$c['id'].'">';
            echo '<input type="text" name="content" placeholder="Write a reply..." required>';
            echo '<button type="submit" class="btn-small">Send</button>';
            echo '</form>';
        }
        renderComments($c['children']);
        echo '</div>';
    }
    echo '</div>';
}

// --- 6. HTML VIEW ---
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Social Node</title>
<style>
/* Base styling adapted for minimalism */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#f8f9fa;color:#111;font-family:system-ui,-apple-system,sans-serif;display:flex;flex-direction:column;align-items:center;padding:2rem 1rem;}
.container{max-width:42rem;width:100%;background:#fff;padding:2rem;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.05);}
header{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #eee;padding-bottom:1rem;margin-bottom:1.5rem;}
h1{font-size:1.5rem;color:#0044cc;}
a{color:#0044cc;text-decoration:none;} a:hover{text-decoration:underline;}
.btn{background:#0044cc;color:#fff;border:none;padding:0.5rem 1rem;border-radius:4px;cursor:pointer;font-size:0.9rem;}
.btn:hover{background:#0033aa;}
.btn-small{padding:0.3rem 0.6rem;font-size:0.8rem;background:#444;color:#fff;border:none;border-radius:3px;}
.alert{padding:0.8rem;margin-bottom:1rem;border-radius:4px;font-size:0.9rem;}
.alert.error{background:#fff0f0;color:#d00;border:1px solid #e0c0c0;}
.alert.success{background:#f0fff0;color:#1a8e3f;border:1px solid #c0e0c0;}
.auth-box{background:#fafafa;padding:1rem;border-radius:6px;margin-bottom:1.5rem;border:1px solid #ddd;}
.auth-box input{padding:0.5rem;margin-right:0.5rem;border:1px solid #ccc;border-radius:4px;}
.composer{background:#f0f4ff;padding:1rem;border-radius:6px;margin-bottom:2rem;border:1px solid #dce4f5;}
.composer input[type="text"], .composer textarea{width:100%;padding:0.5rem;margin-bottom:0.5rem;border:1px solid #ccc;border-radius:4px;font-family:inherit;}
.composer select{padding:0.5rem;margin-bottom:0.5rem;}
.composer .controls{display:flex;justify-content:space-between;align-items:center;}
.msg-card{border:1px solid #eee;border-radius:6px;padding:1rem;margin-bottom:1rem;}
.msg-meta{font-size:0.8rem;color:#777;margin-bottom:0.5rem;}
.msg-meta b{color:#111;}
.msg-body{font-size:1rem;line-height:1.5;margin-bottom:0.8rem;word-wrap:break-word;}
.msg-img{max-width:100%;border-radius:4px;margin-top:0.5rem;}
.msg-actions{display:flex;gap:1rem;font-size:0.85rem;border-top:1px solid #eee;padding-top:0.5rem;margin-top:0.5rem;}
.msg-actions form{display:inline;}
.like-btn{background:none;border:none;color:#d00;cursor:pointer;font-weight:bold;}
.comments-section{margin-top:1rem;background:#fafafa;padding:1rem;border-radius:4px;}
.comment-item{margin-left:1rem;border-left:2px solid #eee;padding-left:0.8rem;margin-top:0.8rem;}
.c-meta{font-size:0.75rem;color:#777;}
.c-body{font-size:0.85rem;margin:0.2rem 0;}
.reply-btn{background:none;border:none;color:#0044cc;cursor:pointer;font-size:0.75rem;padding:0;}
.pagination{display:flex;justify-content:space-between;margin-top:2rem;}
</style>
</head>
<body>
<div class="container">
    <header>
        <div>
            <h1>Social Node</h1>
            <span style="font-size:0.8rem;color:#777;">Viewing: <?= esc(ucfirst($viewType)) ?> > <?= esc($viewName) ?></span>
        </div>
        <nav>
            <?php if(isLoggedIn()): ?>
                <span style="font-size:0.9rem;margin-right:1rem;">Hello, <b><?= esc($_SESSION['username']) ?></b></span>
                <form method="POST" style="display:inline;"><input type="hidden" name="action" value="logout"><button class="btn-small">Logout</button></form>
            <?php else: ?>
                <span style="font-size:0.9rem;">Not logged in</span>
            <?php endif; ?>
        </nav>
    </header>

    <?php if($errorMsg): ?><div class="alert error"><?= esc($errorMsg) ?></div><?php endif; ?>
    <?php if($successMsg): ?><div class="alert success"><?= esc($successMsg) ?></div><?php endif; ?>

    <?php if(!isLoggedIn()): ?>
    <div class="auth-box">
        <form method="POST" style="display:inline-block; margin-right:1rem;">
            <input type="hidden" name="action" value="login">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button class="btn">Login</button>
        </form>
        <form method="POST" style="display:inline-block; border-left:1px solid #ccc; padding-left:1rem;">
            <input type="hidden" name="action" value="register">
            <input type="text" name="username" placeholder="New Username" required>
            <input type="password" name="password" placeholder="New Password" required>
            <button class="btn" style="background:#1a8e3f;">Register</button>
        </form>
    </div>
    <?php endif; ?>

    <div class="composer">
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="post_message">
            <div style="display:flex; gap:0.5rem;">
                <select name="target_type">
                    <option value="group" <?= $viewType === 'group' ? 'selected' : '' ?>>Group</option>
                    <option value="user" <?= $viewType === 'user' ? 'selected' : '' ?>>User</option>
                </select>
                <input type="text" name="target_name" value="<?= esc($viewName) ?>" placeholder="Target Name (e.g. 'Global' or username)" required>
            </div>
            <textarea name="content" rows="3" placeholder="Write something..."></textarea>
            <div class="controls">
                <div>
                    <input type="file" name="image" accept="image/jpeg, image/png, image/gif, image/webp" style="font-size:0.8rem;">
                    <label style="font-size:0.85rem; margin-left:1rem;"><input type="checkbox" name="anonymous" value="1"> Send Anonymously</label>
                </div>
                <button type="submit" class="btn">Post Message</button>
            </div>
        </form>
    </div>

    <div class="feed">
        <?php if(empty($messages)): ?>
            <p style="text-align:center;color:#999;padding:2rem 0;">No messages found in this space.</p>
        <?php endif; ?>

        <?php foreach($messages as $msg): ?>
            <div class="msg-card">
                <div class="msg-meta">
                    <b><?= $msg['sender_id'] ? esc($msg['sender_name']) : 'Anonymous' ?></b> 
                    sent to <?= esc($msg['target_type']) ?> <i><?= esc($msg['target_name']) ?></i> &middot; <?= esc($msg['created_at']) ?>
                </div>
                
                <?php if($msg['content']): ?>
                    <div class="msg-body"><?= nl2br(esc($msg['content'])) ?></div>
                <?php endif; ?>
                
                <?php if($msg['image_path']): ?>
                    <img src="<?= esc($msg['image_path']) ?>" class="msg-img" alt="Attached Image">
                <?php endif; ?>
                
                <div class="msg-actions">
                    <span>❤️ <?= $msg['like_count'] ?></span>
                    <?php if(isLoggedIn()): ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="like">
                            <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
                            <button type="submit" class="like-btn">Like</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="comments-section">
                    <?php if(isLoggedIn()): ?>
                        <form method="POST" style="margin-bottom:1rem; display:flex; gap:0.5rem;">
                            <input type="hidden" name="action" value="post_comment">
                            <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
                            <input type="text" name="content" placeholder="Add a comment..." style="flex:1; padding:0.4rem; border:1px solid #ccc; border-radius:3px;" required>
                            <button type="submit" class="btn-small">Comment</button>
                        </form>
                    <?php endif; ?>
                    <?php
                        $commentsTree = fetchComments($pdo, $msg['id']);
                        renderComments($commentsTree);
                    ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="pagination">
        <?php if($page > 1): ?>
            <a href="?view=<?= urlencode($viewType) ?>&name=<?= urlencode($viewName) ?>&p=<?= $page - 1 ?>" class="btn-small">&larr; Newer</a>
        <?php else: ?>
            <span></span>
        <?php endif; ?>
        
        <?php if(count($messages) === MESSAGES_PER_PAGE): ?>
            <a href="?view=<?= urlencode($viewType) ?>&name=<?= urlencode($viewName) ?>&p=<?= $page + 1 ?>" class="btn-small">Older &rarr;</a>
        <?php else: ?>
            <span></span>
        <?php endif; ?>
    </div>
</div>
</body>
</html>