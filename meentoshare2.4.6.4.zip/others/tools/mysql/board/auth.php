﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  auth.php — User registration, login, logout
//  Requires: config.php
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}

// ── Domain functions ──────────────────────────────────────────────────────────

/**
 * Register a new user.
 * Returns ['ok'=>true, 'user'=>[...]] or ['ok'=>false, 'error'=>'...'].
 */
function authRegister(string $username, string $password): array {
    $username = trim($username);
    if ($username === '' || strlen($username) < 3) {
        return ['ok' => false, 'error' => 'Username must be at least 3 characters.'];
    }
    if (strlen($username) > 60) {
        return ['ok' => false, 'error' => 'Username too long (max 60 chars).'];
    }
    if (!preg_match('/^[a-zA-Z0-9_\-\.]+$/', $username)) {
        return ['ok' => false, 'error' => 'Username may only contain letters, digits, _ - .'];
    }
    if (strlen($password) < 6) {
        return ['ok' => false, 'error' => 'Password must be at least 6 characters.'];
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);

    try {
        $st = db()->prepare('INSERT INTO users (username, pass_hash) VALUES (?, ?)');
        $st->execute([$username, $hash]);
        $id = (int) db()->lastInsertId();
        return ['ok' => true, 'user' => ['id' => $id, 'username' => $username]];
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            return ['ok' => false, 'error' => 'Username already taken.'];
        }
        return ['ok' => false, 'error' => 'DB error: ' . $e->getMessage()];
    }
}

/**
 * Log in an existing user.
 * On success, writes to $_SESSION['user'] and returns ['ok'=>true].
 */
function authLogin(string $username, string $password): array {
    $username = trim($username);
    $st = db()->prepare('SELECT id, username, pass_hash FROM users WHERE username = ? LIMIT 1');
    $st->execute([$username]);
    $row = $st->fetch();

    if (!$row || !password_verify($password, $row['pass_hash'])) {
        return ['ok' => false, 'error' => 'Invalid username or password.'];
    }

    // Regenerate session ID on privilege escalation
    session_regenerate_id(true);
    $_SESSION['user'] = ['id' => $row['id'], 'username' => $row['username']];
    return ['ok' => true];
}

/** Log out the current user. */
function authLogout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// ── Request handlers (invoked from board.php) ─────────────────────────────────

function handleAuthPost(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

    $action = $_POST['auth_action'] ?? '';

    if ($action === 'register') {
        $r = authRegister($_POST['username'] ?? '', $_POST['password'] ?? '');
        if ($r['ok']) {
            // Auto-login after register
            authLogin($_POST['username'], $_POST['password']);
            flashSet('ok', 'Welcome, ' . h($r['user']['username']) . '!');
        } else {
            flashSet('error', $r['error']);
        }
        redirect(selfUrl(['view' => $_GET['view'] ?? 'board']));
    }

    if ($action === 'login') {
        $r = authLogin($_POST['username'] ?? '', $_POST['password'] ?? '');
        if ($r['ok']) {
            flashSet('ok', 'Logged in successfully.');
        } else {
            flashSet('error', $r['error']);
        }
        redirect(selfUrl(['view' => $_GET['view'] ?? 'board']));
    }

    if ($action === 'logout') {
        authLogout();
        flashSet('ok', 'Logged out.');
        redirect(selfUrl(['view' => 'board']));
    }
}