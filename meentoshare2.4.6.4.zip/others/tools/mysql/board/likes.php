﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  likes.php — SHA-256-hashed like system (one like per user per message)
//  Requires: config.php
//  Only logged-in users may like.
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}

// ── Like token ────────────────────────────────────────────────────────────────

/**
 * Build the SHA-256 token for a (user, message) pair.
 * LIKE_SALT is mixed in so the hash can't be brute-forced back to a user id.
 */
function likeToken(int $userId, int $messageId): string {
    return hash('sha256', LIKE_SALT . '|' . $userId . '|' . $messageId);
}

// ── Like CRUD ─────────────────────────────────────────────────────────────────

/**
 * Toggle a like for the current user on a message.
 * Returns ['ok'=>true, 'liked'=>bool, 'count'=>int]
 *      or ['ok'=>false, 'error'=>'...'].
 */
function likeToggle(int $userId, int $messageId): array {
    $token = likeToken($userId, $messageId);
    $pdo   = db();

    // Check if already liked
    $st = $pdo->prepare('SELECT id FROM likes WHERE message_id = ? AND like_hash = ? LIMIT 1');
    $st->execute([$messageId, $token]);
    $existing = $st->fetch();

    if ($existing) {
        // Unlike
        $pdo->prepare('DELETE FROM likes WHERE message_id = ? AND like_hash = ?')
            ->execute([$messageId, $token]);
        $liked = false;
    } else {
        // Like
        try {
            $pdo->prepare('INSERT INTO likes (message_id, like_hash) VALUES (?, ?)')
                ->execute([$messageId, $token]);
        } catch (PDOException $e) {
            // Duplicate key (race condition) — treat as already liked
        }
        $liked = true;
    }

    $st = $pdo->prepare('SELECT COUNT(*) FROM likes WHERE message_id = ?');
    $st->execute([$messageId]);
    $count = (int) $st->fetchColumn();

    return ['ok' => true, 'liked' => $liked, 'count' => $count];
}

/**
 * Check whether a user has already liked a message.
 */
function likeStatus(int $userId, int $messageId): bool {
    $token = likeToken($userId, $messageId);
    $st    = db()->prepare('SELECT 1 FROM likes WHERE message_id = ? AND like_hash = ? LIMIT 1');
    $st->execute([$messageId, $token]);
    return (bool) $st->fetch();
}

/**
 * Bulk-check like status for multiple message ids in one query.
 * Returns an assoc [message_id => bool].
 */
function likeBulkStatus(int $userId, array $messageIds): array {
    if (empty($messageIds)) return [];

    $tokens   = [];
    $tokenMap = [];   // token => message_id
    foreach ($messageIds as $mid) {
        $t           = likeToken($userId, (int) $mid);
        $tokens[]    = $t;
        $tokenMap[$t] = (int) $mid;
    }

    $placeholders = implode(',', array_fill(0, count($tokens), '?'));
    $st = db()->prepare("SELECT like_hash FROM likes WHERE like_hash IN ({$placeholders})");
    $st->execute($tokens);
    $found = $st->fetchAll(PDO::FETCH_COLUMN);

    $result = array_fill_keys($messageIds, false);
    foreach ($found as $t) {
        if (isset($tokenMap[$t])) {
            $result[$tokenMap[$t]] = true;
        }
    }
    return $result;
}

// ── Request handler (AJAX-friendly JSON response) ─────────────────────────────

function handleLikePost(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['like_action'])) return;

    $user = currentUser();
    if (!$user) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Login required to like.']);
        exit;
    }

    $messageId = (int) ($_POST['message_id'] ?? 0);
    if ($messageId < 1) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Invalid message.']);
        exit;
    }

    $r = likeToggle($user['id'], $messageId);
    header('Content-Type: application/json');
    echo json_encode($r);
    exit;
}