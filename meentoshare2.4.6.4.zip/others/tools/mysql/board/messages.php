﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  messages.php — Post messages (with optional file), groups, pagination
//  Requires: config.php
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}

// ── Group helpers ─────────────────────────────────────────────────────────────

/** Find or create a group by name. Returns group id. */
function groupResolve(string $name): int {
    $name = trim($name);
    if ($name === '') $name = 'general';

    $st = db()->prepare('SELECT id FROM `groups` WHERE name = ? LIMIT 1');
    $st->execute([$name]);
    $row = $st->fetch();
    if ($row) return (int) $row['id'];

    $st = db()->prepare('INSERT INTO `groups` (name) VALUES (?)');
    $st->execute([$name]);
    return (int) db()->lastInsertId();
}

/** List all groups ordered by latest message. */
function groupList(): array {
    return db()->query("
        SELECT g.id, g.name,
               COUNT(m.id) AS msg_count,
               MAX(m.created_at) AS last_active
        FROM `groups` g
        LEFT JOIN messages m ON m.group_id = g.id
        GROUP BY g.id
        ORDER BY last_active DESC, g.name ASC
    ")->fetchAll();
}

// ── File handling ─────────────────────────────────────────────────────────────

/**
 * Save an uploaded file to UPLOAD_DIR.
 * Returns ['ok'=>true, 'path'=>'...', 'name'=>'...', 'mime'=>'...']
 *      or ['ok'=>false, 'error'=>'...'].
 */
function handleUpload(array $file): array {
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'path' => null, 'name' => null, 'mime' => null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Upload error code ' . $file['error']];
    }
    if ($file['size'] > MAX_FILE_BYTES) {
        return ['ok' => false, 'error' => 'File exceeds ' . (MAX_FILE_BYTES / 1024 / 1024) . ' MB limit.'];
    }

    $origName = basename($file['name']);
    $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $ext      = preg_replace('/[^a-z0-9]/', '', $ext);

    if (in_array($ext, BLOCKED_EXT, true)) {
        return ['ok' => false, 'error' => 'File type .' . $ext . ' is not allowed.'];
    }

    $mime    = mime_content_type($file['tmp_name']) ?: 'application/octet-stream';
    $hash    = hash_file('sha256', $file['tmp_name']);
    $stored  = $ext !== '' ? "{$hash}.{$ext}" : $hash;
    $dest    = UPLOAD_DIR . '/' . $stored;

    if (!file_exists($dest)) {
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            return ['ok' => false, 'error' => 'Could not save file to disk.'];
        }
    }

    return ['ok' => true, 'path' => $stored, 'name' => $origName, 'mime' => $mime];
}

// ── Message CRUD ──────────────────────────────────────────────────────────────

/**
 * Post a new message.
 * $opts = [
 *   'user_id'      => int|null,
 *   'group'        => string,
 *   'body'         => string,
 *   'file'         => $_FILES['...'] entry or null,
 *   'is_anonymous' => bool,
 * ]
 */
function messagePost(array $opts): array {
    $body      = trim($opts['body'] ?? '');
    $anonymous = !empty($opts['is_anonymous']);
    $userId    = $opts['user_id'] ?? null;

    // Anonymous messages need no login; logged users can also post anonymously
    if (!$anonymous && $userId === null) {
        return ['ok' => false, 'error' => 'You must be logged in to post as yourself.'];
    }

    $fileData = ['ok' => true, 'path' => null, 'name' => null, 'mime' => null];
    if (!empty($opts['file']) && $opts['file']['error'] !== UPLOAD_ERR_NO_FILE) {
        $fileData = handleUpload($opts['file']);
        if (!$fileData['ok']) return $fileData;
    }

    if ($body === '' && $fileData['path'] === null) {
        return ['ok' => false, 'error' => 'Message cannot be empty.'];
    }

    $groupId = groupResolve($opts['group'] ?? 'general');

    $st = db()->prepare("
        INSERT INTO messages (user_id, group_id, body, file_path, file_name, file_mime, is_anonymous)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $st->execute([
        $anonymous ? null : $userId,
        $groupId,
        $body,
        $fileData['path'],
        $fileData['name'],
        $fileData['mime'],
        $anonymous ? 1 : 0,
    ]);

    return ['ok' => true, 'id' => (int) db()->lastInsertId(), 'group_id' => $groupId];
}

/**
 * Paginated message list for a group, newest first.
 * Returns ['messages'=>[...], 'total'=>int, 'pages'=>int, 'page'=>int].
 */
function messageList(int $groupId, int $page = 1): array {
    $perPage = MESSAGES_PER_PAGE;
    $offset  = ($page - 1) * $perPage;
    if ($offset < 0) $offset = 0;

    $stCount = db()->prepare('SELECT COUNT(*) FROM messages WHERE group_id = ?');
    $stCount->execute([$groupId]);
    $total = (int) $stCount->fetchColumn();
    $pages = max(1, (int) ceil($total / $perPage));

    $st = db()->prepare("
        SELECT m.id, m.body, m.file_path, m.file_name, m.file_mime, m.is_anonymous,
               m.created_at,
               u.username,
               (SELECT COUNT(*) FROM likes  l WHERE l.message_id = m.id) AS like_count,
               (SELECT COUNT(*) FROM comments c WHERE c.message_id = m.id) AS comment_count
        FROM messages m
        LEFT JOIN users u ON u.id = m.user_id
        WHERE m.group_id = ?
        ORDER BY m.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $st->execute([$groupId, $perPage, $offset]);
    $rows = $st->fetchAll();

    return ['messages' => $rows, 'total' => $total, 'pages' => $pages, 'page' => $page];
}

/** Single message fetch. */
function messageFetch(int $id): ?array {
    $st = db()->prepare("
        SELECT m.*, u.username,
               (SELECT COUNT(*) FROM likes l WHERE l.message_id = m.id) AS like_count
        FROM messages m
        LEFT JOIN users u ON u.id = m.user_id
        WHERE m.id = ?
    ");
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

// ── Request handler ───────────────────────────────────────────────────────────

function handleMessagePost(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['msg_action'])) return;

    $user = currentUser();

    if ($_POST['msg_action'] === 'post') {
        $r = messagePost([
            'user_id'      => $user ? $user['id'] : null,
            'group'        => $_POST['group_name'] ?? 'general',
            'body'         => $_POST['body'] ?? '',
            'file'         => $_FILES['attachment'] ?? null,
            'is_anonymous' => !empty($_POST['is_anonymous']),
        ]);

        if ($r['ok']) {
            flashSet('ok', 'Message posted.');
            redirect(selfUrl(['view' => 'group', 'gid' => $r['group_id']]));
        } else {
            flashSet('error', $r['error']);
            redirect(selfUrl());
        }
    }
}