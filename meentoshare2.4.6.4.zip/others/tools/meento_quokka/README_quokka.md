# 🐨 Quokka Meento

A lightweight, single-file PHP tool for building a distributed URL and server mesh. Each node can share its known URLs with every other node in the network using plain HTTP GET requests — no database, no framework, no dependencies beyond a standard PHP installation with cURL.

---

## Requirements

- PHP 7.4 or later
- cURL extension enabled (`php-curl`)
- A web server (Apache, Nginx, Caddy, etc.) or PHP's built-in server for testing
- Write permission to the directory where `quokka_meento.php` lives

---

## Installation

1. Copy `quokka_meento.php` into any web-accessible directory.
2. Make sure the web server user has **read and write** permission to that directory.
3. Done. All supporting files and folders are created automatically on the first request.

```
/your-web-root/
└── quokka_meento.php   ← the only file you need to deploy
```

After the first request the directory will look like this:

```
/your-web-root/
├── quokka_meento.php
├── files.txt           ← known URLs (one per line, base URL only)
├── servers.txt         ← peer server endpoints (one per line)
├── public_key.txt      ← optional credential sent on sync
├── user.txt            ← optional credential sent on sync
├── btc.txt             ← optional credential sent on sync
├── server_ip/          ← IP deduplication sentinel files
├── url_hash/           ← JSON side-cars keyed by URL hash
└── server_ip_hash/     ← JSON side-cars keyed by IP hash
```

---

## Quick Start (local testing)

```bash
# Start the built-in PHP server
php -S localhost:8080

# Add a URL
curl "http://localhost:8080/quokka_meento.php?action=add_url&url=https://example.com"

# Add a peer server
curl "http://localhost:8080/quokka_meento.php?action=add_server&server=https://peer.example.com/quokka_meento.php"

# Push all URLs to all known servers
curl "http://localhost:8080/quokka_meento.php?action=sync"
```

---

## API Reference

All requests are plain HTTP GET. Every parameter is limited to **2000 bytes**; longer values are rejected with HTTP 400.

Every response is a JSON object.

### `?action=get_files`

Returns the list of all known URLs stored in `files.txt`.

**Example response**
```json
{
  "status": "ok",
  "files": [
    "https://example.com",
    "https://another.org/page"
  ]
}
```

---

### `?action=get_servers`

Returns the list of all known peer servers stored in `servers.txt`.

**Example response**
```json
{
  "status": "ok",
  "servers": [
    "https://peer1.example.com/quokka_meento.php",
    "https://peer2.example.com/quokka_meento.php"
  ]
}
```

---

### `?action=add_url&url=<url>`

Adds a URL to `files.txt`. Only the base URL (without query string) is stored. If the URL is already present the request is ignored.

When `VERIFY_URL_ONLINE` is enabled (see Configuration), the URL must be reachable and its IP must not have been seen before.

| Parameter | Required | Description |
|-----------|----------|-------------|
| `url` | Yes | The URL to add (max 2000 bytes) |

**Example**
```
?action=add_url&url=https://example.com/page
```

**Possible status values in response**

| `status` | Meaning |
|----------|---------|
| `added` | URL was new and has been stored |
| `exists` | URL was already in `files.txt` |
| `skipped` | IP already known — URL not added (only when `VERIFY_URL_ONLINE = true`) |
| `error` | URL empty, unreachable, or IP could not be resolved |

---

### `?action=add_server&server=<server>`

Adds a peer server endpoint to `servers.txt`. Duplicates are silently ignored.

| Parameter | Required | Description |
|-----------|----------|-------------|
| `server` | Yes | Full URL to the peer's `quokka_meento.php` (max 2000 bytes) |

**Example**
```
?action=add_server&server=https://peer.example.com/quokka_meento.php
```

---

### `?action=sync`

Pushes every URL in `files.txt` to every server in `servers.txt`. Each peer receives the URL via its `receive` action. Optional credentials from `user.txt`, `public_key.txt`, and `btc.txt` are appended automatically.

**Outgoing request format per pair:**
```
<server>?action=receive&url=<url>[&user=..][&public_key=..][&btc=..]
```

**Example response**
```json
{
  "status": "sync_complete",
  "results": [
    {
      "server": "https://peer.example.com/quokka_meento.php",
      "url": "https://example.com",
      "http": 200,
      "error": null,
      "response": "{\"status\":\"added\", ...}"
    }
  ]
}
```

---

### `?action=receive&url=<url>`

Intended to be called by other Quokka Meento nodes during sync. Behaves identically to `add_url` but also accepts optional credential parameters sent by the peer.

| Parameter | Required | Description |
|-----------|----------|-------------|
| `url` | Yes | URL being pushed by the peer |
| `user` | No | Credential value from the peer's `user.txt` |
| `public_key` | No | Credential value from the peer's `public_key.txt` |
| `btc` | No | Credential value from the peer's `btc.txt` |

---

### `?action=receive_server&server=<server>`

Receives a server endpoint pushed by another node and adds it to `servers.txt`.

---

### `?action=` *(any unknown value or omitted)*

Returns a usage info object with all available actions and current configuration values.

---

## Configuration

Open `quokka_meento.php` and edit the three constants near the top of the file.

### `VERIFY_URL_ONLINE` — default `false`

When set to `true`, the following extra steps run before a URL is added:

1. **Reachability check** — an HTTP HEAD request is made to the URL. If it does not respond with 2xx or 3xx the URL is rejected.
2. **IP resolution** — the hostname is resolved to an IP address.
3. **IP deduplication** — a sentinel file is created at `server_ip/<sha256(ip+salt)>.txt` using `fopen` with the exclusive-create flag (`O_CREAT|O_EXCL`). If the file already exists, the IP was seen before and the URL is skipped.
4. **Side-car storage** — any query-string parameters from the original URL are saved to two JSON files (see [Storage Layout](#storage-layout)).

```php
define('VERIFY_URL_ONLINE', true);   // change to true to enable
```

### `IP_SALT` — default `'quokka_meento_salt_2024'`

A secret string mixed into the hash used to name the IP sentinel files. Change this to make your node's deduplication namespace unique.

```php
define('IP_SALT', 'my_secret_salt');
```

### `MAX_INPUT_LENGTH` — default `2000`

Maximum byte length allowed for any single GET parameter. Requests exceeding this are rejected immediately with HTTP 400.

```php
define('MAX_INPUT_LENGTH', 2000);
```

---

## Credentials

Three plain-text files act as optional credentials that are appended to every outgoing sync request. Leave them empty to disable.

| File | GET parameter | Description |
|------|---------------|-------------|
| `user.txt` | `&user=` | Username or node identity |
| `public_key.txt` | `&public_key=` | Public key or API token |
| `btc.txt` | `&btc=` | Bitcoin address or any payment identifier |

Write a single value into each file (no newlines needed):

```bash
echo -n "my-node-id" > user.txt
echo -n "bc1qxyz..."  > btc.txt
```

---

## Storage Layout

```
files.txt
  One base URL per line (query strings are stripped before storage).

servers.txt
  One peer server URL per line.

server_ip/<sha256(ip + IP_SALT)>.txt
  Contains the raw IP address. Used as a deduplication sentinel.
  Created with O_CREAT|O_EXCL (atomic). Existence = IP already known.

url_hash/<sha256(base_url)>.json
  JSON object merging all query-string parameters ever seen for that URL.
  Only written when VERIFY_URL_ONLINE = true and the URL had a query string.

server_ip_hash/<sha256(ip)>.json
  Same as above but keyed by the resolved IP address of the URL's host.
```

---

## Concurrency & Race Conditions

Every file operation uses `fopen()` with `flock()`. No `file_get_contents()`, `file_put_contents()`, or `file()` calls are used anywhere in the script. This ensures safe behaviour under concurrent HTTP requests.

| Operation | Strategy |
|-----------|----------|
| Reading any file | `fopen('r')` + `LOCK_SH` — blocks if a writer is active |
| Overwriting a file | `fopen('c')` + `LOCK_EX`, truncate **after** lock granted — prevents readers seeing an empty file mid-write |
| Appending a unique line | `fopen('c')` + `LOCK_EX` held across the full read → duplicate-check → write sequence — two concurrent requests for the same line cannot both succeed |
| Creating a sentinel file | `fopen('x')` = `O_CREAT\|O_EXCL` — atomic at the OS level; exactly one process wins when many race simultaneously |
| Updating a JSON side-car | `fopen('c')` + `LOCK_EX` held across the full read → transform → write cycle |

---

## Security Notes

- This script performs no authentication by default. Deploy behind HTTP basic auth, a firewall rule, or a reverse proxy if the endpoint should not be publicly writable.
- `VERIFY_URL_ONLINE` triggers outbound HTTP requests from your server. Only enable it if you trust the sources of URLs being submitted.
- `IP_SALT` should be treated as a secret if IP-based deduplication privacy matters to your setup.
- All GET input is length-checked and URL-encoded before being used in outgoing requests. No input is ever executed or passed to a shell.

---

## License

MIT — do whatever you like with it.
