import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/**
 * WebCrawler - A simple Java web crawler that collects URLs with valid file extensions.
 *
 * Usage: java WebCrawler
 * You will be prompted for:
 *   - Start URL  (e.g. https://example.com)
 *   - Depth      (how many link-levels to follow)
 *
 * Any URL whose path ends with a filename (e.g. /images/photo.jpg, /docs/file.pdf)
 * will be written to "servers.txt", one URL per line, no duplicates.
 *
 * Relative URLs found on a page are resolved against the page's base URL so that
 * a link like "test/2.jpg" found on "https://my.com" becomes "https://my.com/test/2.jpg".
 *
 * No external libraries required � only the Java standard library.
 */
public class WebCrawler {

    // -----------------------------------------------------------------------
    // Configuration
    // -----------------------------------------------------------------------

    /** Output file where collected file URLs are stored. */
    private static final String OUTPUT_FILE = "servers.txt";

    /**
     * Regex that matches a URL path ending with a filename (has an extension).
     * Examples that match : /images/photo.jpg  /file.pdf  /a/b/c.tar.gz
     * Examples that don't  : /page  /category/  /search?q=foo
     */
    private static final Pattern FILE_URL_PATTERN =
            Pattern.compile(".*\\/[^/?#]+\\.[^/?#.]+$");

    /**
     * Pattern to extract href / src attributes from raw HTML.
     * Handles both single and double quotes.
     */
    private static final Pattern LINK_PATTERN =
            Pattern.compile("(?:href|src)=[\"']([^\"'#>]+)[\"']",
                    Pattern.CASE_INSENSITIVE);

    /** Connection / read timeout in milliseconds. */
    private static final int TIMEOUT_MS = 8_000;

    /** User-Agent sent with every HTTP request. */
    private static final String USER_AGENT =
            "Mozilla/5.0 (compatible; JavaWebCrawler/1.0)";

    // -----------------------------------------------------------------------
    // State shared across the crawl
    // -----------------------------------------------------------------------

    /** Every URL we have already fetched (or queued), to avoid re-visiting. */
    private final Set<String> visited = new LinkedHashSet<>();

    /** File URLs collected so far (loaded from disk + found during crawl). */
    private final Set<String> collected = new LinkedHashSet<>();

    // -----------------------------------------------------------------------
    // Entry point
    // -----------------------------------------------------------------------

    public static void main(String[] args) {
        new WebCrawler().run();
    }

    private void run() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("==============================================");
        System.out.println("          Java Web Crawler");
        System.out.println("==============================================");

        // --- read start URL ---
        String startUrl;
        while (true) {
            System.out.print("Enter start URL (e.g. https://example.com): ");
            startUrl = scanner.nextLine().trim();
            if (startUrl.isEmpty()) {
                System.out.println("  [!] URL cannot be empty. Please try again.");
                continue;
            }
            if (!startUrl.startsWith("http://") && !startUrl.startsWith("https://")) {
                System.out.println("  [!] URL must start with http:// or https://. Please try again.");
                continue;
            }
            break;
        }

        // --- read depth ---
        int depth = 0;
        while (true) {
            System.out.print("Enter crawl depth (0 = start page only, recommended 1-3): ");
            String depthInput = scanner.nextLine().trim();
            try {
                depth = Integer.parseInt(depthInput);
                if (depth < 0) {
                    System.out.println("  [!] Depth must be 0 or greater.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("  [!] Please enter a valid integer.");
            }
        }

        System.out.println();
        System.out.println("Starting crawl: " + startUrl);
        System.out.println("Max depth     : " + depth);
        System.out.println("Output file   : " + OUTPUT_FILE);
        System.out.println("----------------------------------------------");

        // Load any URLs already stored in servers.txt so we don't re-add them.
        loadExisting();

        // Kick off the recursive crawl.
        crawl(startUrl, depth);

        // Persist results.
        saveResults();

        System.out.println("----------------------------------------------");
        System.out.println("Crawl complete. Total file URLs saved: " + collected.size());
        System.out.println("Results written to: " + new File(OUTPUT_FILE).getAbsolutePath());
    }

    // -----------------------------------------------------------------------
    // Crawl logic
    // -----------------------------------------------------------------------

    /**
     * Recursively crawl {@code url} up to {@code remainingDepth} levels deep.
     */
    private void crawl(String url, int remainingDepth) {
        // Normalise the URL (strip trailing slash for comparison purposes).
        String normalisedUrl = normalise(url);
        if (normalisedUrl == null || visited.contains(normalisedUrl)) {
            return;
        }
        visited.add(normalisedUrl);

        System.out.println("[depth " + remainingDepth + "] Fetching: " + url);

        String html = fetchPage(url);
        if (html == null) {
            return; // fetch failed � already printed the error
        }

        // Extract every link / src found on this page.
        Set<String> links = extractLinks(html, url);

        for (String link : links) {
            // If the path has a filename extension, save it.
            if (hasFileExtension(link)) {
                if (collected.add(link)) {
                    System.out.println("  [+] Found file URL: " + link);
                }
            }

            // Follow non-file links deeper (if depth allows).
            if (remainingDepth > 0 && !hasFileExtension(link)) {
                crawl(link, remainingDepth - 1);
            }
        }
    }

    // -----------------------------------------------------------------------
    // HTTP fetch
    // -----------------------------------------------------------------------

    /**
     * Fetch the content of {@code url} and return it as a String, or {@code null}
     * if the request failed or the content type is not text/html.
     */
    private String fetchPage(String url) {
        try {
            URL u = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setRequestProperty("Accept",
                    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

            int status = conn.getResponseCode();
            if (status < 200 || status >= 400) {
                System.out.println("  [!] HTTP " + status + " for: " + url);
                conn.disconnect();
                return null;
            }

            // Only parse HTML / XHTML pages.
            String contentType = conn.getContentType();
            if (contentType != null
                    && !contentType.contains("text/html")
                    && !contentType.contains("application/xhtml")) {
                conn.disconnect();
                return null;
            }

            // Determine charset from Content-Type header (default UTF-8).
            String charset = extractCharset(contentType);

            try (InputStream is = conn.getInputStream();
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(is, charset))) {

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                return sb.toString();
            } finally {
                conn.disconnect();
            }

        } catch (MalformedURLException e) {
            System.out.println("  [!] Malformed URL: " + url);
        } catch (SocketTimeoutException e) {
            System.out.println("  [!] Timeout fetching: " + url);
        } catch (IOException e) {
            System.out.println("  [!] IO error fetching " + url + " � " + e.getMessage());
        }
        return null;
    }

    // -----------------------------------------------------------------------
    // Link extraction
    // -----------------------------------------------------------------------

    /**
     * Extract all href / src values from {@code html} and resolve them against
     * {@code baseUrl}.  Returns only http / https URLs.
     */
    private Set<String> extractLinks(String html, String baseUrl) {
        Set<String> links = new LinkedHashSet<>();
        Matcher m = LINK_PATTERN.matcher(html);

        while (m.find()) {
            String raw = m.group(1).trim();
            if (raw.isEmpty()) continue;

            String resolved = resolveUrl(baseUrl, raw);
            if (resolved != null) {
                links.add(resolved);
            }
        }
        return links;
    }

    /**
     * Resolve {@code raw} against {@code base}.
     * Handles absolute URLs, protocol-relative URLs, absolute paths, and relative paths.
     * Returns {@code null} for non-http(s) schemes (mailto:, javascript:, data:, �).
     */
    private String resolveUrl(String base, String raw) {
        try {
            // Skip non-http schemes early.
            String lower = raw.toLowerCase(Locale.ROOT);
            if (lower.startsWith("mailto:") || lower.startsWith("javascript:")
                    || lower.startsWith("data:") || lower.startsWith("tel:")) {
                return null;
            }

            URL baseUrl = new URL(base);
            URL resolved = new URL(baseUrl, raw);

            String scheme = resolved.getProtocol();
            if (!"http".equals(scheme) && !"https".equals(scheme)) {
                return null;
            }

            // Remove the fragment portion, keep query strings.
            String result = resolved.toExternalForm();
            int hashIdx = result.indexOf('#');
            if (hashIdx >= 0) {
                result = result.substring(0, hashIdx);
            }
            return result;

        } catch (MalformedURLException e) {
            return null;
        }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /** Return {@code true} if the URL path ends with a file extension. */
    private boolean hasFileExtension(String url) {
        try {
            String path = new URL(url).getPath();
            return FILE_URL_PATTERN.matcher(path).matches();
        } catch (MalformedURLException e) {
            return false;
        }
    }

    /**
     * Normalise a URL for de-duplication: strip a trailing slash from the path
     * and lower-case the scheme + host.
     */
    private String normalise(String url) {
        if (url == null || url.isEmpty()) return null;
        try {
            URL u = new URL(url);
            String path = u.getPath();
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            String query = u.getQuery() == null ? "" : "?" + u.getQuery();
            return u.getProtocol().toLowerCase(Locale.ROOT)
                    + "://"
                    + u.getHost().toLowerCase(Locale.ROOT)
                    + (u.getPort() == -1 ? "" : ":" + u.getPort())
                    + path
                    + query;
        } catch (MalformedURLException e) {
            return null;
        }
    }

    /** Extract the charset from a Content-Type header value, defaulting to UTF-8. */
    private String extractCharset(String contentType) {
        if (contentType != null) {
            Pattern p = Pattern.compile("charset=([^;\\s]+)", Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(contentType);
            if (m.find()) {
                return m.group(1).replace("\"", "").trim();
            }
        }
        return StandardCharsets.UTF_8.name();
    }

    // -----------------------------------------------------------------------
    // Persistence
    // -----------------------------------------------------------------------

    /** Load any URLs already present in {@value #OUTPUT_FILE}. */
    private void loadExisting() {
        File f = new File(OUTPUT_FILE);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    collected.add(line);
                }
            }
            System.out.println("Loaded " + collected.size()
                    + " existing URL(s) from " + OUTPUT_FILE);
        } catch (IOException e) {
            System.out.println("[!] Could not read existing " + OUTPUT_FILE
                    + ": " + e.getMessage());
        }
    }

    /** Write all collected file URLs to {@value #OUTPUT_FILE}, one per line. */
    private void saveResults() {
        try (PrintWriter pw = new PrintWriter(
                new BufferedWriter(new FileWriter(OUTPUT_FILE, false)))) {
            for (String url : collected) {
                pw.println(url);
            }
        } catch (IOException e) {
            System.out.println("[!] Failed to write " + OUTPUT_FILE
                    + ": " + e.getMessage());
        }
    }
}