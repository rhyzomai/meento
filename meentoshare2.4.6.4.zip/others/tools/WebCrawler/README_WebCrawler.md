# WebCrawler

A simple, self-contained Java web crawler that collects file URLs (images, PDFs, documents, etc.) from websites and saves them to a text file. No external libraries required — only the Java standard library.

---

## Features

- Interactive CLI: prompts for a start URL and crawl depth
- Detects and saves URLs that point to files (e.g. `.jpg`, `.png`, `.pdf`, `.txt`, `.zip`)
- Resolves relative URLs against the page's base URL (e.g. `test/2.jpg` on `https://my.com` → `https://my.com/test/2.jpg`)
- Deduplication: never writes the same URL twice, across multiple runs
- Loop-safe: each page is visited at most once per run
- Configurable depth: depth `0` scans only the start page; depth `N` follows links N levels deep
- Results saved to `servers.txt`, one URL per line

---

## Requirements

- Java 11 or higher (tested on Java 21)
- No third-party libraries

---

## Installation

Clone or download the repository, then compile the single source file:

```bash
javac WebCrawler.java
```

---

## Usage

```bash
java WebCrawler
```

You will be prompted for two inputs:

```
Enter start URL (e.g. https://example.com): https://example.com
Enter crawl depth (0 = start page only, recommended 1-3): 2
```

The crawler will then run and print its progress to the terminal:

```
==============================================
          Java Web Crawler
==============================================
Enter start URL (e.g. https://example.com): https://example.com
Enter crawl depth (0 = start page only, recommended 1-3): 2

Starting crawl: https://example.com
Max depth     : 2
Output file   : servers.txt
----------------------------------------------
[depth 2] Fetching: https://example.com
[depth 1] Fetching: https://example.com/about
  [+] Found file URL: https://example.com/images/logo.png
  [+] Found file URL: https://example.com/docs/brochure.pdf
----------------------------------------------
Crawl complete. Total file URLs saved: 2
Results written to: /path/to/servers.txt
```

---

## Output

Results are written to `servers.txt` in the working directory, one URL per line:

```
https://example.com/images/logo.png
https://example.com/docs/brochure.pdf
https://example.com/assets/banner.jpg
```

On subsequent runs, existing entries are loaded first and the file is never written with duplicates.

---

## How It Works

1. The crawler fetches the start URL using `HttpURLConnection`.
2. All `href` and `src` attribute values are extracted from the HTML with a regular expression.
3. Each extracted value is resolved into a full absolute URL against the current page's base URL.
4. If the resolved URL's path ends with a filename extension (e.g. `/photo.jpg`), it is recorded as a file URL.
5. If the remaining depth is greater than zero and the link is not a file URL, the crawler visits that page recursively.
6. At the end, all collected file URLs are written to `servers.txt`.

---

## Configuration

The following constants at the top of `WebCrawler.java` can be adjusted:

| Constant | Default | Description |
|---|---|---|
| `OUTPUT_FILE` | `"servers.txt"` | Path to the output file |
| `TIMEOUT_MS` | `8000` | HTTP connect/read timeout in milliseconds |
| `USER_AGENT` | `Mozilla/5.0 ...` | User-Agent header sent with requests |

---

## Limitations

- Only HTML pages are parsed for links. Binary files, JSON feeds, and sitemaps are not followed.
- JavaScript-rendered content is not executed; only the raw HTML is scanned.
- Crawling is single-threaded; large sites with high depth will be slow.
- No robots.txt compliance — use responsibly and only on sites you have permission to crawl.

---

## License

This project is released into the public domain. Use it freely.
