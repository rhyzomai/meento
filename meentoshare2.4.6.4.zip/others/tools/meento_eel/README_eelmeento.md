# Eel Meento

A peer-to-peer file sharing program written in C++. Every instance acts as **both a server and a client simultaneously** — run it on multiple machines and they can discover and download files from each other with a single command.

---

## Features

- Automatic server on startup — no separate daemon needed
- Download all new files from a list of peers in one command
- Skip files you already have (no duplicate downloads)
- Rank peers by file count and total size, exported to JSON
- Change the port at runtime without restarting
- Single self-contained binary, no dependencies

---

## Getting Started

### 1. Run the program

```bash
./executable
```

The server starts automatically on port **52525** and you are dropped into an interactive prompt.

### 2. Add files to share

Place any files you want to share in the `download/` folder (created automatically on first run).

```
download/
  movie.mp4
  document.pdf
  archive.zip
```

### 3. List your peers

Create a `servers.txt` file with one IP address or hostname per line:

```
192.168.1.10
192.168.1.25
myfriend.example.com
```

Lines starting with `#` are treated as comments and ignored.

### 4. Download from peers

```
> download
```

Eel Meento connects to every server in `servers.txt`, asks what files they have, and downloads anything you do not already have. Files that already exist locally are always skipped.

---

## Commands

| Command    | Description |
|------------|-------------|
| `list`     | Show all files in your local `download/` folder |
| `download` | Fetch all new files from every server in `servers.txt` |
| `rank`     | Query all servers, rank them by file count and total size, save results to `servers.json` |
| `port`     | Change the port used for both serving and connecting (default: `52525`) |
| `help`     | Display available commands |
| `quit`     | Exit the program |

---

## The `rank` Command

Running `rank` queries every peer in `servers.txt` and prints a leaderboard sorted by number of files (descending), with total size as a tiebreaker.

**Example output:**

```
=== Server Ranking ===
1. 192.168.1.10  | files: 42 | total size: 1073741824 bytes
2. 192.168.1.25  | files: 17 | total size: 209715200 bytes
3. myfriend.example.com | files: 3 | total size: 5242880 bytes [UNREACHABLE]
```

Results are automatically saved to `servers.json`:

```json
[
  {
    "rank": 1,
    "host": "192.168.1.10",
    "file_count": 42,
    "total_size_bytes": 1073741824,
    "reachable": true
  },
  ...
]
```

---

## Changing the Port

```
> port
Current port: 52525
Enter new port (1-65535): 9000
[*] Port changed to 9000. Server will rebind on next cycle.
```

All peers must use the same port to communicate.

---

## Building from Source

Requires a C++17-compatible compiler and Linux (POSIX sockets).

```bash
g++ -std=c++17 -O2 -pthread -o executable p2p.cpp
```

---

## File Structure

```
.
├── executable       # The compiled binary
├── p2p.cpp          # Full source code (single file)
├── servers.txt      # List of peer IPs/hostnames (one per line)
├── servers.json     # Output of the rank command
└── download/        # Files you share and receive
```

---

## How It Works

When you start Eel Meento, a background thread binds to the configured port and listens for incoming connections. Other peers can connect and issue two commands over a simple text protocol:

- `LIST` — returns a list of files available in the `download/` folder
- `GET <filename>` — streams the raw bytes of a file

When you run `download`, Eel Meento acts as a client: it connects to each server in `servers.txt`, requests the file list, compares it against what you already have, and fetches only the missing files. Downloads are streamed directly to disk.

---

## Security Notes

- Path traversal is blocked — filenames containing `/` or `..` are rejected by the server.
- There is no authentication. Only run this on trusted networks.
- Files are transferred unencrypted.

---

## License

This software is provided as-is for personal and educational use.
