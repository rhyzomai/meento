/*
 * P2P File Sharing Program
 * Works as both client and server on the same port.
 * Commands: port, download, rank, list, help, quit
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <filesystem>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <cstring>
#include <csignal>

// POSIX / Linux networking
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

namespace fs = std::filesystem;

// --- Globals ----------------------------------------------------------------
static std::atomic<int>  g_port{52525};
static std::atomic<bool> g_running{true};
static std::mutex        g_cout_mtx;

const std::string DOWNLOAD_DIR = "download";
const std::string SERVERS_FILE = "servers.txt";
const std::string SERVERS_JSON = "servers.json";
const int         BACKLOG      = 10;
const int         BUF_SIZE     = 8192;

// --- Helpers ----------------------------------------------------------------
void log(const std::string& msg) {
    std::lock_guard<std::mutex> lk(g_cout_mtx);
    std::cout << msg << "\n";
}

std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// Escape a string for JSON
std::string json_escape(const std::string& s) {
    std::string out;
    for (char c : s) {
        if      (c == '"')  out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else                out += c;
    }
    return out;
}

// Ensure the download directory exists
void ensure_download_dir() {
    if (!fs::exists(DOWNLOAD_DIR))
        fs::create_directories(DOWNLOAD_DIR);
}

// --- File listing helpers ----------------------------------------------------
struct FileInfo {
    std::string name;
    uintmax_t   size;
};

std::vector<FileInfo> list_download_files() {
    std::vector<FileInfo> files;
    if (!fs::exists(DOWNLOAD_DIR)) return files;
    for (auto& entry : fs::directory_iterator(DOWNLOAD_DIR)) {
        if (entry.is_regular_file()) {
            files.push_back({entry.path().filename().string(),
                             entry.file_size()});
        }
    }
    return files;
}

// --- Low-level send / recv ---------------------------------------------------
bool send_all(int fd, const char* buf, size_t len) {
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = send(fd, buf + sent, len - sent, MSG_NOSIGNAL);
        if (n <= 0) return false;
        sent += n;
    }
    return true;
}

bool recv_all(int fd, char* buf, size_t len) {
    size_t got = 0;
    while (got < len) {
        ssize_t n = recv(fd, buf + got, len - got, 0);
        if (n <= 0) return false;
        got += n;
    }
    return true;
}

// Read a line (terminated by '\n') from a socket
bool recv_line(int fd, std::string& line, int timeout_sec = 10) {
    line.clear();
    // Set receive timeout
    struct timeval tv{timeout_sec, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    char c;
    while (true) {
        ssize_t n = recv(fd, &c, 1, 0);
        if (n <= 0) return false;
        if (c == '\n') return true;
        if (c != '\r') line += c;
    }
}

bool send_line(int fd, const std::string& line) {
    std::string msg = line + "\r\n";
    return send_all(fd, msg.c_str(), msg.size());
}

// --- Protocol (text-based) ---------------------------------------------------
/*
  Client ? Server commands:
    LIST\r\n                 ? server replies with file list then "END\r\n"
    GET <filename>\r\n       ? server replies "SIZE <bytes>\r\n" then raw bytes
                               or "ERROR <msg>\r\n"
*/

// --- Server side -------------------------------------------------------------
void handle_client(int client_fd) {
    std::string cmd;
    while (recv_line(client_fd, cmd)) {
        cmd = trim(cmd);
        if (cmd == "LIST") {
            auto files = list_download_files();
            for (auto& f : files) {
                send_line(client_fd, f.name + " " + std::to_string(f.size));
            }
            send_line(client_fd, "END");
        } else if (cmd.rfind("GET ", 0) == 0) {
            std::string filename = trim(cmd.substr(4));
            // Security: no path traversal
            if (filename.find('/') != std::string::npos ||
                filename.find("..") != std::string::npos) {
                send_line(client_fd, "ERROR Invalid filename");
                continue;
            }
            std::string path = DOWNLOAD_DIR + "/" + filename;
            std::ifstream ifs(path, std::ios::binary);
            if (!ifs) {
                send_line(client_fd, "ERROR File not found");
                continue;
            }
            ifs.seekg(0, std::ios::end);
            uintmax_t fsz = ifs.tellg();
            ifs.seekg(0, std::ios::beg);
            send_line(client_fd, "SIZE " + std::to_string(fsz));

            // Stream the file
            char buf[BUF_SIZE];
            while (ifs) {
                ifs.read(buf, BUF_SIZE);
                std::streamsize rd = ifs.gcount();
                if (rd <= 0) break;
                if (!send_all(client_fd, buf, rd)) break;
            }
        } else if (cmd == "QUIT" || cmd.empty()) {
            break;
        } else {
            send_line(client_fd, "ERROR Unknown command");
        }
    }
    close(client_fd);
}

void server_thread_func() {
    int server_fd = -1;
    int current_port = -1;

    while (g_running) {
        int new_port = g_port.load();

        // If port changed (or first start), re-bind
        if (new_port != current_port) {
            if (server_fd >= 0) close(server_fd);

            server_fd = socket(AF_INET, SOCK_STREAM, 0);
            if (server_fd < 0) {
                log("[Server] socket() failed: " + std::string(strerror(errno)));
                std::this_thread::sleep_for(std::chrono::seconds(2));
                continue;
            }

            int opt = 1;
            setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

            // Non-blocking so we can check g_running
            fcntl(server_fd, F_SETFL, O_NONBLOCK);

            sockaddr_in addr{};
            addr.sin_family      = AF_INET;
            addr.sin_addr.s_addr = INADDR_ANY;
            addr.sin_port        = htons(new_port);

            if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
                log("[Server] bind() on port " + std::to_string(new_port) +
                    " failed: " + strerror(errno));
                close(server_fd);
                server_fd = -1;
                std::this_thread::sleep_for(std::chrono::seconds(2));
                continue;
            }
            listen(server_fd, BACKLOG);
            current_port = new_port;
            log("[Server] Listening on port " + std::to_string(current_port));
        }

        // Accept loop
        sockaddr_in cli{};
        socklen_t clen = sizeof(cli);
        int cfd = accept(server_fd, (sockaddr*)&cli, &clen);
        if (cfd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                // No connection yet, check if port changed
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                continue;
            }
            continue;
        }

        // Make client socket blocking
        int flags = fcntl(cfd, F_GETFL, 0);
        fcntl(cfd, F_SETFL, flags & ~O_NONBLOCK);

        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &cli.sin_addr, ip, sizeof(ip));
        log("[Server] Connection from " + std::string(ip));

        std::thread(handle_client, cfd).detach();
    }

    if (server_fd >= 0) close(server_fd);
}

// --- Client side -------------------------------------------------------------
int connect_to(const std::string& host, int port, int timeout_sec = 5) {
    struct addrinfo hints{}, *res = nullptr;
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    std::string port_str = std::to_string(port);
    if (getaddrinfo(host.c_str(), port_str.c_str(), &hints, &res) != 0 || !res)
        return -1;

    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { freeaddrinfo(res); return -1; }

    // Connect with timeout
    fcntl(fd, F_SETFL, O_NONBLOCK);
    connect(fd, res->ai_addr, res->ai_addrlen);
    freeaddrinfo(res);

    fd_set wset;
    FD_ZERO(&wset);
    FD_SET(fd, &wset);
    struct timeval tv{timeout_sec, 0};
    int sel = select(fd + 1, nullptr, &wset, nullptr, &tv);
    if (sel <= 0) { close(fd); return -1; }

    int err = 0; socklen_t elen = sizeof(err);
    getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &elen);
    if (err) { close(fd); return -1; }

    // Back to blocking
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
    return fd;
}

// Returns list of (filename, size) from a remote server
bool remote_list(const std::string& host, int port,
                 std::vector<FileInfo>& out_files) {
    int fd = connect_to(host, port);
    if (fd < 0) return false;

    send_line(fd, "LIST");
    std::string line;
    while (recv_line(fd, line, 15)) {
        line = trim(line);
        if (line == "END") break;
        // "filename size"
        size_t sp = line.rfind(' ');
        if (sp == std::string::npos) continue;
        FileInfo fi;
        fi.name = line.substr(0, sp);
        try { fi.size = std::stoull(line.substr(sp + 1)); }
        catch (...) { fi.size = 0; }
        out_files.push_back(fi);
    }
    send_line(fd, "QUIT");
    close(fd);
    return true;
}

bool remote_get(const std::string& host, int port,
                const std::string& filename, uintmax_t expected_size) {
    int fd = connect_to(host, port);
    if (fd < 0) {
        log("  [!] Cannot connect to " + host + ":" + std::to_string(port));
        return false;
    }

    send_line(fd, "GET " + filename);
    std::string resp;
    if (!recv_line(fd, resp, 15)) { close(fd); return false; }
    resp = trim(resp);

    if (resp.rfind("ERROR", 0) == 0) {
        log("  [!] Server error: " + resp);
        close(fd); return false;
    }
    if (resp.rfind("SIZE ", 0) != 0) { close(fd); return false; }

    uintmax_t sz = 0;
    try { sz = std::stoull(resp.substr(5)); } catch (...) {}

    ensure_download_dir();
    std::string path = DOWNLOAD_DIR + "/" + filename;
    std::ofstream ofs(path, std::ios::binary);
    if (!ofs) {
        log("  [!] Cannot open file for writing: " + path);
        close(fd); return false;
    }

    uintmax_t received = 0;
    char buf[BUF_SIZE];
    while (received < sz) {
        size_t to_read = std::min((uintmax_t)BUF_SIZE, sz - received);
        ssize_t n = recv(fd, buf, to_read, 0);
        if (n <= 0) break;
        ofs.write(buf, n);
        received += n;
    }
    ofs.close();
    close(fd);

    if (received == sz) {
        log("  [+] Downloaded: " + filename + " (" + std::to_string(sz) + " bytes)");
        return true;
    } else {
        log("  [!] Incomplete download: " + filename);
        fs::remove(path);
        return false;
    }
}

// --- Command: download -------------------------------------------------------
void cmd_download() {
    // Read servers.txt
    std::ifstream sf(SERVERS_FILE);
    if (!sf) {
        log("[!] Cannot open " + SERVERS_FILE);
        return;
    }

    ensure_download_dir();

    // Build set of already-existing files
    std::map<std::string, uintmax_t> local_files;
    for (auto& fi : list_download_files())
        local_files[fi.name] = fi.size;

    std::vector<std::string> servers;
    std::string line;
    while (std::getline(sf, line)) {
        line = trim(line);
        if (!line.empty() && line[0] != '#')
            servers.push_back(line);
    }

    if (servers.empty()) {
        log("[!] No servers in " + SERVERS_FILE);
        return;
    }

    int port = g_port.load();
    for (auto& srv : servers) {
        log("[*] Querying " + srv + ":" + std::to_string(port));
        std::vector<FileInfo> remote;
        if (!remote_list(srv, port, remote)) {
            log("  [!] Could not reach " + srv);
            continue;
        }
        log("  Found " + std::to_string(remote.size()) + " file(s)");
        for (auto& fi : remote) {
            if (local_files.count(fi.name)) {
                log("  [=] Already exists: " + fi.name + ", skipping.");
                continue;
            }
            remote_get(srv, port, fi.name, fi.size);
            local_files[fi.name] = fi.size; // mark as fetched
        }
    }
    log("[*] Download complete.");
}

// --- Command: rank -----------------------------------------------------------
void cmd_rank() {
    std::ifstream sf(SERVERS_FILE);
    if (!sf) {
        log("[!] Cannot open " + SERVERS_FILE);
        return;
    }

    std::vector<std::string> servers;
    std::string line;
    while (std::getline(sf, line)) {
        line = trim(line);
        if (!line.empty() && line[0] != '#')
            servers.push_back(line);
    }

    if (servers.empty()) {
        log("[!] No servers found in " + SERVERS_FILE);
        return;
    }

    struct ServerStat {
        std::string host;
        int         file_count;
        uintmax_t   total_size;
        bool        reachable;
    };

    int port = g_port.load();
    std::vector<ServerStat> stats;

    for (auto& srv : servers) {
        log("[*] Querying " + srv + "...");
        std::vector<FileInfo> files;
        bool ok = remote_list(srv, port, files);
        ServerStat st;
        st.host       = srv;
        st.reachable  = ok;
        st.file_count = (int)files.size();
        st.total_size = 0;
        for (auto& f : files) st.total_size += f.size;
        stats.push_back(st);
    }

    // Sort descending by file_count, then total_size
    std::sort(stats.begin(), stats.end(), [](const ServerStat& a, const ServerStat& b){
        if (a.file_count != b.file_count) return a.file_count > b.file_count;
        return a.total_size > b.total_size;
    });

    // Display
    log("\n=== Server Ranking ===");
    int rank = 1;
    for (auto& st : stats) {
        std::ostringstream oss;
        oss << rank++ << ". " << st.host
            << " | files: " << st.file_count
            << " | total size: " << st.total_size << " bytes"
            << (st.reachable ? "" : " [UNREACHABLE]");
        log(oss.str());
    }

    // Save JSON
    std::ofstream jf(SERVERS_JSON);
    if (!jf) {
        log("[!] Cannot write " + SERVERS_JSON);
        return;
    }
    jf << "[\n";
    for (size_t i = 0; i < stats.size(); ++i) {
        auto& st = stats[i];
        jf << "  {\n"
           << "    \"rank\": " << (i + 1) << ",\n"
           << "    \"host\": \"" << json_escape(st.host) << "\",\n"
           << "    \"file_count\": " << st.file_count << ",\n"
           << "    \"total_size_bytes\": " << st.total_size << ",\n"
           << "    \"reachable\": " << (st.reachable ? "true" : "false") << "\n"
           << "  }" << (i + 1 < stats.size() ? "," : "") << "\n";
    }
    jf << "]\n";
    log("[*] Ranking saved to " + SERVERS_JSON);
}

// --- Command: list -----------------------------------------------------------
void cmd_list() {
    auto files = list_download_files();
    if (files.empty()) {
        log("[*] No files in " + DOWNLOAD_DIR + "/");
        return;
    }
    log("[*] Local files in " + DOWNLOAD_DIR + "/:");
    uintmax_t total = 0;
    for (auto& f : files) {
        log("  " + f.name + "  (" + std::to_string(f.size) + " bytes)");
        total += f.size;
    }
    log("  Total: " + std::to_string(files.size()) + " file(s), " +
        std::to_string(total) + " bytes");
}

// --- Command: port -----------------------------------------------------------
void cmd_port() {
    log("Current port: " + std::to_string(g_port.load()));
    log("Enter new port (1-65535): ");
    std::string input;
    std::getline(std::cin, input);
    input = trim(input);
    try {
        int p = std::stoi(input);
        if (p < 1 || p > 65535) throw std::out_of_range("bad port");
        g_port.store(p);
        log("[*] Port changed to " + std::to_string(p) +
            ". Server will rebind on next cycle.");
    } catch (...) {
        log("[!] Invalid port number.");
    }
}

// --- Help --------------------------------------------------------------------
void print_help() {
    log(
        "\n=== P2P File Sharing ===\n"
        "Commands:\n"
        "  list       - List local files in the download/ folder\n"
        "  download   - Download all files from servers listed in servers.txt\n"
        "  rank       - Rank servers by file count & size, save to servers.json\n"
        "  port       - Change the listening/connecting port (default: 52525)\n"
        "  help       - Show this message\n"
        "  quit       - Exit the program\n"
        "\nThe built-in server runs automatically on the configured port.\n"
        "Other peers can connect and list/download your files from download/.\n"
        "servers.txt format: one IP/hostname per line.\n"
    );
}

// --- Main --------------------------------------------------------------------
int main() {
    signal(SIGPIPE, SIG_IGN); // Ignore broken pipe

    ensure_download_dir();

    log("=== P2P File Sharing ===");
    log("Type 'help' for available commands.");
    log("[*] Starting server thread on port " + std::to_string(g_port.load()) + "...");

    std::thread srv(server_thread_func);
    srv.detach();

    // Give server a moment to bind
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    while (g_running) {
        {
            std::lock_guard<std::mutex> lk(g_cout_mtx);
            std::cout << "\n> " << std::flush;
        }

        std::string cmd;
        if (!std::getline(std::cin, cmd)) break;
        cmd = trim(cmd);

        if (cmd == "quit" || cmd == "exit" || cmd == "q") {
            g_running = false;
            log("Bye!");
            break;
        } else if (cmd == "download") {
            cmd_download();
        } else if (cmd == "rank") {
            cmd_rank();
        } else if (cmd == "list") {
            cmd_list();
        } else if (cmd == "port") {
            cmd_port();
        } else if (cmd == "help" || cmd == "?") {
            print_help();
        } else if (cmd.empty()) {
            // Do nothing
        } else {
            log("[!] Unknown command: '" + cmd + "'. Type 'help' for usage.");
        }
    }

    return 0;
}