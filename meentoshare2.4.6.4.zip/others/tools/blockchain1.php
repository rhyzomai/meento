﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH NODE — Optional Blockchain Ledger
// ═══════════════════════════════════════════════════════════════════════════════

define('BLOCK_DIR', __DIR__ . '/json_blocks');
define('LATEST_BLOCK_FILE', BLOCK_DIR . '/latest.txt');
define('IP_SALT', 'ChangeThisToSomeRandomString'); // Salt used for hashing IPs

if (!is_dir(BLOCK_DIR)) {
    mkdir(BLOCK_DIR, 0755, true);
}

// ── RECEIVE BLOCK ENDPOINT (From Peers) ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mesh_block_push'])) {
    $blockJson = $_POST['block_data'] ?? '';
    
    if (!$blockJson) {
        http_response_code(400);
        exit(json_encode(['ok' => false, 'error' => 'No block data provided.']));
    }

    $block = json_decode($blockJson, true);
    if (!is_array($block) || !isset($block['hash'])) {
        http_response_code(400);
        exit(json_encode(['ok' => false, 'error' => 'Invalid block JSON structure.']));
    }

    $blockHash = $block['hash'];
    $blockPath = BLOCK_DIR . '/' . $blockHash . '.json';

    // Verify and store if we don't have it already
    if (!file_exists($blockPath)) {
        // Validate the hash matches the content
        $contentToHash = $block;
        unset($contentToHash['hash']);
        $expectedHash = hash('sha256', json_encode($contentToHash));

        if (hash_equals($expectedHash, $blockHash)) {
            file_put_contents($blockPath, json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            // Update the latest block pointer
            file_put_contents(LATEST_BLOCK_FILE, $blockHash);
        }
    }

    http_response_code(200);
    exit(json_encode(['ok' => true]));
}

// ── CREATE & PROPAGATE BLOCK ──────────────────────────────────────────────────
/**
 * Creates a new block in the chain and pushes it to all known peers.
 */
function recordToBlockchain(string $filename, int $size, string $senderPk, string $receiverPk = '') {
    // Hash the user's IP securely
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $ipHash = hash('sha256', IP_SALT . $ip);

    // Get the previous block's hash to form the "chain"
    $prevHash = file_exists(LATEST_BLOCK_FILE) 
        ? trim((string) file_get_contents(LATEST_BLOCK_FILE)) 
        : '0000000000000000000000000000000000000000000000000000000000000000'; // Genesis hash

    $blockData = [
        'timestamp'   => time(),
        'filename'    => $filename,
        'size'        => $size,
        'sender_pk'   => $senderPk,
        'receiver_pk' => $receiverPk,
        'ip_hash'     => $ipHash,
        'prev_hash'   => $prevHash
    ];

    // Calculate current block hash
    $blockHash = hash('sha256', json_encode($blockData));
    $blockData['hash'] = $blockHash;

    $blockPath = BLOCK_DIR . '/' . $blockHash . '.json';
    
    // Save locally
    if (!file_exists($blockPath)) {
        file_put_contents($blockPath, json_encode($blockData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        file_put_contents(LATEST_BLOCK_FILE, $blockHash);
    }

    // Propagate block to peers
    if (function_exists('loadServers')) {
        $servers = loadServers();
        foreach ($servers as $server) {
            pushBlockToServer($server, $blockData);
        }
    }
}

function pushBlockToServer(string $server, array $blockData) {
    $url = $server . '/' . basename($_SERVER['SCRIPT_FILENAME']);
    $body = http_build_query([
        'mesh_block_push' => '1',
        'block_data'      => json_encode($blockData)
    ]);

    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/x-www-form-urlencoded\r\n" .
                               "Content-Length: " . strlen($body),
            'content'       => $body,
            'timeout'       => 5,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer'      => false,
            'verify_peer_name' => false,
        ]
    ]);

    @file_get_contents($url, false, $ctx);
}