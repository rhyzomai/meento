﻿<?php
// ================================================================
//  Seastar Blockchain  —  blockchain.php
//  Optional module. Use anywhere via:
//      require_once __DIR__ . '/blockchain.php';
//
//  OVERVIEW
//  ----------------------------------------------------------------
//  Each block is a JSON file in  json_blockchain/<height>.json
//  plus a reverse-lookup index   json_blockchain/index/<txid>.json
//
//  A block contains one or more TRANSFERS. Each transfer records:
//    • sender_public_key   — base64-encoded RSA/EC public key (PEM)
//    • receiver_public_key — same format
//    • amount              — arbitrary numeric string (no float math)
//    • asset               — asset ticker / identifier string
//    • memo                — optional plain-text note (max 256 chars)
//    • timestamp           — unix timestamp (int)
//    • nonce               — random 16-byte hex string
//    • signature           — base64( RSA-SHA256 sign of canonical payload )
//    • txid                — sha256 of the canonical payload
//
//  A block contains:
//    • height              — 0-based sequential block number
//    • previous_hash       — sha256 of the previous block JSON (genesis = "0"*64)
//    • merkle_root         — sha256 of all txids concatenated in order
//    • timestamp           — unix timestamp when block was sealed
//    • nonce               — proof-of-work nonce (simple leading-zero hash)
//    • difficulty          — number of leading zero hex digits required
//    • hash                — sha256 of the canonical block header
//    • transfers           — array of transfer objects
//
//  CONSENSUS
//  ----------------------------------------------------------------
//  Consensus works by querying every server in servers.txt for its
//  chain tip (height + hash). The majority tip wins. If the local
//  chain is shorter or has a different hash, the local node fetches
//  and validates missing blocks from the winning peer, then applies
//  them locally.  All network calls use file_get_contents + stream
//  context (same pattern as index.php).
//
//  API ENDPOINTS  (handled when this file is the entry point OR
//                  when index.php includes it and routes actions)
//  ----------------------------------------------------------------
//  ?bc_action=tip
//      → {"height":N,"hash":"…"}
//
//  ?bc_action=block&height=N
//      → full block JSON
//
//  ?bc_action=submit_transfer
//  POST body: transfer JSON (see buildTransfer)
//      → {"ok":true,"txid":"…"}  or  {"ok":false,"error":"…"}
//
//  ?bc_action=sync
//      → triggers a consensus sync and returns a log
//
//  USAGE EXAMPLES
//  ----------------------------------------------------------------
//  // 1. Build & sign a transfer (sender side)
//  $tx = SeastarBlockchain::buildTransfer(
//      senderPublicKeyPem:   $myPubKey,
//      receiverPublicKeyPem: $theirPubKey,
//      amount:               '10.5',
//      asset:                'SST',
//      memo:                 'payment for services',
//      privateKeyPem:        $myPrivKey   // used to sign, never stored
//  );
//  SeastarBlockchain::submitTransferToServers($tx);
//
//  // 2. Mine a new block from the pending pool
//  $block = SeastarBlockchain::mineBlock(difficulty: 3);
//
//  // 3. Validate the full local chain
//  $ok = SeastarBlockchain::validateChain();
//
//  // 4. Run consensus against peers
//  $log = SeastarBlockchain::runConsensus();
// ================================================================

// ----------------------------------------------------------------
//  Guard: define constants only if not already defined (allows
//  requiring this file alongside index.php without conflicts).
// ----------------------------------------------------------------
if (!defined('BC_DIR'))         define('BC_DIR',         __DIR__ . '/json_blockchain');
if (!defined('BC_INDEX_DIR'))   define('BC_INDEX_DIR',   BC_DIR  . '/index');
if (!defined('BC_PENDING_DIR')) define('BC_PENDING_DIR', BC_DIR  . '/pending');
if (!defined('BC_SERVERS_FILE'))define('BC_SERVERS_FILE',__DIR__ . '/servers.txt');
if (!defined('BC_MAX_TX_BLOCK'))define('BC_MAX_TX_BLOCK', 100);    // max transfers per block
if (!defined('BC_MEMO_MAX'))    define('BC_MEMO_MAX',     256);
if (!defined('BC_ASSET_MAX'))   define('BC_ASSET_MAX',    32);
if (!defined('BC_DEFAULT_DIFF'))define('BC_DEFAULT_DIFF', 3);      // PoW leading zeros

foreach ([BC_DIR, BC_INDEX_DIR, BC_PENDING_DIR] as $_bcDir) {
    if (!is_dir($_bcDir)) mkdir($_bcDir, 0755, true);
}

// ================================================================
//  SeastarBlockchain
// ================================================================

class SeastarBlockchain
{
    // ============================================================
    //  Canonical representations
    //  (deterministic: same data → same string for hashing/signing)
    // ============================================================

    /**
     * Canonical string of a transfer used for txid + signature.
     * Fields are sorted alphabetically, values cast to string.
     */
    public static function transferCanonical(array $tx): string
    {
        return implode('|', [
            'amount:'   . $tx['amount'],
            'asset:'    . $tx['asset'],
            'memo:'     . ($tx['memo'] ?? ''),
            'nonce:'    . $tx['nonce'],
            'receiver:' . $tx['receiver_public_key'],
            'sender:'   . $tx['sender_public_key'],
            'timestamp:'. (string)$tx['timestamp'],
        ]);
    }

    /**
     * Canonical string of a block header used for block hash.
     */
    public static function blockHeaderCanonical(array $block): string
    {
        return implode('|', [
            'difficulty:'   . (string)$block['difficulty'],
            'height:'       . (string)$block['height'],
            'merkle_root:'  . $block['merkle_root'],
            'nonce:'        . (string)$block['nonce'],
            'previous_hash:'. $block['previous_hash'],
            'timestamp:'    . (string)$block['timestamp'],
        ]);
    }

    // ============================================================
    //  Transfer construction
    // ============================================================

    /**
     * Build a signed transfer array ready for submission.
     *
     * @param string $senderPublicKeyPem    PEM public key of sender
     * @param string $receiverPublicKeyPem  PEM public key of receiver
     * @param string $amount                Numeric string (e.g. "10.5")
     * @param string $asset                 Asset identifier (e.g. "SST")
     * @param string $memo                  Optional note
     * @param string $privateKeyPem         PEM private key — used to sign, never stored
     * @return array
     * @throws RuntimeException on invalid keys or signing failure
     */
    public static function buildTransfer(
        string $senderPublicKeyPem,
        string $receiverPublicKeyPem,
        string $amount,
        string $asset,
        string $memo,
        string $privateKeyPem
    ): array {
        // Basic validation
        if (!is_numeric($amount))
            throw new RuntimeException('amount must be numeric');
        if (strlen($asset) > BC_ASSET_MAX)
            throw new RuntimeException('asset too long (max ' . BC_ASSET_MAX . ')');
        if (strlen($memo) > BC_MEMO_MAX)
            throw new RuntimeException('memo too long (max ' . BC_MEMO_MAX . ')');

        // Normalise public keys to single-line base64 (strip PEM headers)
        $senderKey   = self::normalisePem($senderPublicKeyPem);
        $receiverKey = self::normalisePem($receiverPublicKeyPem);

        $tx = [
            'sender_public_key'   => $senderKey,
            'receiver_public_key' => $receiverKey,
            'amount'              => $amount,
            'asset'               => $asset,
            'memo'                => substr($memo, 0, BC_MEMO_MAX),
            'timestamp'           => time(),
            'nonce'               => bin2hex(random_bytes(16)),
        ];

        $canonical = self::transferCanonical($tx);
        $tx['txid'] = hash('sha256', $canonical);

        // Sign with sender's private key
        $privKey = openssl_pkey_get_private($privateKeyPem);
        if ($privKey === false)
            throw new RuntimeException('Invalid private key: ' . openssl_error_string());

        $rawSig = '';
        if (!openssl_sign($canonical, $rawSig, $privKey, OPENSSL_ALGO_SHA256))
            throw new RuntimeException('Signing failed: ' . openssl_error_string());

        $tx['signature'] = base64_encode($rawSig);

        return $tx;
    }

    /**
     * Verify a transfer's signature against the sender's public key.
     */
    public static function verifyTransfer(array $tx): bool
    {
        $required = ['sender_public_key','receiver_public_key','amount','asset',
                     'memo','timestamp','nonce','txid','signature'];
        foreach ($required as $k) {
            if (!array_key_exists($k, $tx)) return false;
        }

        // Check txid
        $canonical = self::transferCanonical($tx);
        if (hash('sha256', $canonical) !== $tx['txid']) return false;

        // Rebuild PEM from stored base64 key
        $pemPub = self::base64ToPem($tx['sender_public_key'], 'PUBLIC KEY');
        $pubKey = openssl_pkey_get_public($pemPub);
        if ($pubKey === false) return false;

        $result = openssl_verify(
            $canonical,
            base64_decode($tx['signature'], true),
            $pubKey,
            OPENSSL_ALGO_SHA256
        );

        return $result === 1;
    }

    // ============================================================
    //  Pending pool
    // ============================================================

    /**
     * Add a transfer to the local pending pool.
     * Returns true if accepted, false if duplicate or invalid.
     */
    public static function addToPending(array $tx): bool
    {
        if (!self::verifyTransfer($tx)) return false;

        $path = BC_PENDING_DIR . '/' . $tx['txid'] . '.json';
        if (file_exists($path)) return false; // duplicate

        // Reject if already confirmed in chain
        if (file_exists(BC_INDEX_DIR . '/' . $tx['txid'] . '.json')) return false;

        file_put_contents($path, json_encode($tx, JSON_PRETTY_PRINT));
        return true;
    }

    /**
     * List all pending (unconfirmed) transfers, sorted by timestamp.
     */
    public static function getPending(): array
    {
        $files = glob(BC_PENDING_DIR . '/*.json') ?: [];
        $out   = [];
        foreach ($files as $f) {
            $d = self::readJson($f);
            if ($d) $out[] = $d;
        }
        usort($out, fn($a, $b) => $a['timestamp'] <=> $b['timestamp']);
        return $out;
    }

    /**
     * Remove a transfer from pending (called after it is confirmed).
     */
    public static function removePending(string $txid): void
    {
        $path = BC_PENDING_DIR . '/' . $txid . '.json';
        if (file_exists($path)) unlink($path);
    }

    // ============================================================
    //  Mining  (Proof of Work)
    // ============================================================

    /**
     * Mine a new block from the pending pool.
     *
     * @param int $difficulty  Number of leading zero hex chars required in block hash
     * @return array|null  The mined block, or null if pending pool is empty
     */
    public static function mineBlock(int $difficulty = BC_DEFAULT_DIFF): ?array
    {
        $pending = self::getPending();
        if (empty($pending)) return null;

        // Take up to BC_MAX_TX_BLOCK transfers
        $transfers = array_slice($pending, 0, BC_MAX_TX_BLOCK);

        $height       = self::getChainHeight() + 1;
        $previousHash = self::getBlockHash($height - 1) ?? str_repeat('0', 64);
        $merkleRoot   = self::computeMerkleRoot(array_column($transfers, 'txid'));
        $timestamp    = time();
        $prefix       = str_repeat('0', $difficulty);

        $nonce = 0;
        do {
            $candidate = [
                'height'        => $height,
                'previous_hash' => $previousHash,
                'merkle_root'   => $merkleRoot,
                'timestamp'     => $timestamp,
                'difficulty'    => $difficulty,
                'nonce'         => $nonce,
            ];
            $hash = hash('sha256', self::blockHeaderCanonical($candidate));
            $nonce++;
        } while (strncmp($hash, $prefix, $difficulty) !== 0);

        $candidate['hash']      = $hash;
        $candidate['transfers'] = $transfers;

        return self::sealBlock($candidate);
    }

    // ============================================================
    //  Block storage
    // ============================================================

    /**
     * Write a validated block to disk and update the index.
     * Returns the sealed block on success, throws on failure.
     */
    public static function sealBlock(array $block): array
    {
        // Recompute and verify hash before writing
        $expected = hash('sha256', self::blockHeaderCanonical($block));
        if ($expected !== $block['hash'])
            throw new RuntimeException("Block hash mismatch at height {$block['height']}");

        $path = BC_DIR . '/' . (int)$block['height'] . '.json';
        if (file_exists($path))
            throw new RuntimeException("Block {$block['height']} already exists");

        // Verify every transfer
        foreach ($block['transfers'] as $tx) {
            if (!self::verifyTransfer($tx))
                throw new RuntimeException("Invalid transfer {$tx['txid']} in block {$block['height']}");
        }

        // Verify merkle root
        $expectedMerkle = self::computeMerkleRoot(array_column($block['transfers'], 'txid'));
        if ($expectedMerkle !== $block['merkle_root'])
            throw new RuntimeException("Merkle root mismatch in block {$block['height']}");

        // Write block file
        file_put_contents($path, json_encode($block, JSON_PRETTY_PRINT));

        // Write index entries (txid → height)
        foreach ($block['transfers'] as $tx) {
            $idxPath = BC_INDEX_DIR . '/' . $tx['txid'] . '.json';
            file_put_contents($idxPath, json_encode([
                'txid'   => $tx['txid'],
                'height' => $block['height'],
                'block_hash' => $block['hash'],
            ], JSON_PRETTY_PRINT));
            self::removePending($tx['txid']);
        }

        return $block;
    }

    /**
     * Load a block by height. Returns null if not found.
     */
    public static function getBlock(int $height): ?array
    {
        return self::readJson(BC_DIR . '/' . $height . '.json');
    }

    /**
     * Return the hash of the block at the given height.
     * For height -1 (genesis parent) returns the zero string.
     */
    public static function getBlockHash(int $height): ?string
    {
        if ($height < 0) return str_repeat('0', 64);
        $block = self::getBlock($height);
        return $block ? $block['hash'] : null;
    }

    /**
     * Current highest confirmed block height (-1 if no blocks).
     */
    public static function getChainHeight(): int
    {
        // Walk backwards from a large number to find the highest written block
        // (efficient because files are sequential integers)
        $files = glob(BC_DIR . '/[0-9]*.json') ?: [];
        if (empty($files)) return -1;
        $heights = array_map(fn($f) => (int)basename($f, '.json'), $files);
        return max($heights);
    }

    /**
     * Return tip info: ['height' => N, 'hash' => '…']
     */
    public static function getTip(): array
    {
        $h = self::getChainHeight();
        return [
            'height' => $h,
            'hash'   => $h >= 0 ? (self::getBlockHash($h) ?? str_repeat('0', 64)) : str_repeat('0', 64),
        ];
    }

    // ============================================================
    //  Chain validation
    // ============================================================

    /**
     * Validate the entire local chain from genesis to tip.
     *
     * @return array ['valid' => bool, 'errors' => string[], 'blocks_checked' => int]
     */
    public static function validateChain(): array
    {
        $height = self::getChainHeight();
        $errors = [];

        if ($height < 0) {
            return ['valid' => true, 'errors' => [], 'blocks_checked' => 0];
        }

        $prevHash = str_repeat('0', 64);

        for ($i = 0; $i <= $height; $i++) {
            $block = self::getBlock($i);
            if (!$block) {
                $errors[] = "Block {$i} missing from disk";
                continue;
            }

            // Height integrity
            if ((int)$block['height'] !== $i)
                $errors[] = "Block {$i}: height field mismatch ({$block['height']})";

            // Previous hash linkage
            if ($block['previous_hash'] !== $prevHash)
                $errors[] = "Block {$i}: previous_hash mismatch";

            // Recompute hash
            $recomputed = hash('sha256', self::blockHeaderCanonical($block));
            if ($recomputed !== $block['hash'])
                $errors[] = "Block {$i}: hash invalid";

            // PoW check
            $prefix = str_repeat('0', (int)($block['difficulty'] ?? 0));
            if ($prefix !== '' && strncmp($block['hash'], $prefix, strlen($prefix)) !== 0)
                $errors[] = "Block {$i}: does not meet difficulty {$block['difficulty']}";

            // Merkle root
            $merkle = self::computeMerkleRoot(array_column($block['transfers'] ?? [], 'txid'));
            if ($merkle !== $block['merkle_root'])
                $errors[] = "Block {$i}: merkle_root invalid";

            // Every transfer
            foreach ($block['transfers'] ?? [] as $tx) {
                if (!self::verifyTransfer($tx))
                    $errors[] = "Block {$i}: transfer {$tx['txid']} has invalid signature";
            }

            $prevHash = $block['hash'];
        }

        return [
            'valid'          => empty($errors),
            'errors'         => $errors,
            'blocks_checked' => $height + 1,
        ];
    }

    // ============================================================
    //  Consensus
    // ============================================================

    /**
     * Query all peers and achieve consensus.
     *
     * Strategy:
     *   1. Ask every peer for its tip (height + hash).
     *   2. Group peers by tip. The group with the most peers wins.
     *      Tie-break: highest height wins.
     *   3. If our local tip matches the winner, we are in sync.
     *   4. Otherwise fetch missing blocks from the winning peer
     *      and validate + apply each one.
     *
     * @return array  Log entries  [['type'=>'info|ok|skip|error', 'msg'=>'…'], …]
     */
    public static function runConsensus(): array
    {
        $servers = self::loadServers();
        $log     = [];

        if (empty($servers)) {
            $log[] = ['type' => 'error', 'msg' => 'No servers in servers.txt'];
            return $log;
        }

        // ── Step 1: collect tips ─────────────────────────────────
        $tips  = [];  // server => ['height'=>N, 'hash'=>'…']
        foreach ($servers as $server) {
            $resp = self::fetchJson(rtrim($server, '/') . '/blockchain.php?bc_action=tip');
            if ($resp && isset($resp['height'], $resp['hash'])) {
                $tips[$server] = $resp;
                $log[] = ['type' => 'info',
                          'msg'  => "Peer {$server} tip height={$resp['height']} hash=" . substr($resp['hash'],0,12) . '…'];
            } else {
                $log[] = ['type' => 'error', 'msg' => "Peer {$server} did not respond to tip request"];
            }
        }

        if (empty($tips)) {
            $log[] = ['type' => 'error', 'msg' => 'No peers responded'];
            return $log;
        }

        // ── Step 2: find winning tip ─────────────────────────────
        // Group by "height|hash"
        $groups = [];
        foreach ($tips as $server => $tip) {
            $key = $tip['height'] . '|' . $tip['hash'];
            $groups[$key]['count']  = ($groups[$key]['count']  ?? 0) + 1;
            $groups[$key]['height'] = $tip['height'];
            $groups[$key]['hash']   = $tip['hash'];
            $groups[$key]['servers'][] = $server;
        }

        // Sort by count desc, then height desc
        uasort($groups, function($a, $b) {
            if ($b['count'] !== $a['count']) return $b['count'] - $a['count'];
            return $b['height'] - $a['height'];
        });

        $winner     = reset($groups);
        $winHeight  = $winner['height'];
        $winHash    = $winner['hash'];
        $winServers = $winner['servers'];

        $log[] = ['type' => 'ok',
                  'msg'  => "Consensus: height={$winHeight} hash=" . substr($winHash,0,12)
                            . "… ({$winner['count']}/" . count($tips) . " peers agree)"];

        // ── Step 3: compare to local tip ─────────────────────────
        $local = self::getTip();
        if ($local['height'] === $winHeight && $local['hash'] === $winHash) {
            $log[] = ['type' => 'ok', 'msg' => 'Local chain is already in sync'];
            return $log;
        }

        $log[] = ['type' => 'info',
                  'msg'  => "Local tip height={$local['height']} hash=" . substr($local['hash'],0,12)
                            . '… — syncing from peer'];

        // ── Step 4: fetch and apply missing blocks ───────────────
        $source     = $winServers[0]; // use first agreeing peer
        $startFrom  = $local['height'] + 1;

        // If local chain is ahead but hash doesn't match, we need to detect
        // a fork. Simple strategy: rewind to the fork point.
        if ($local['height'] > $winHeight) {
            $log[] = ['type' => 'error',
                      'msg'  => "Local chain is longer than consensus — possible fork. Manual review needed."];
            return $log;
        }

        for ($h = $startFrom; $h <= $winHeight; $h++) {
            $block = self::fetchJson(
                rtrim($source, '/') . '/blockchain.php?bc_action=block&height=' . $h
            );
            if (!$block) {
                $log[] = ['type' => 'error', 'msg' => "Failed to fetch block {$h} from {$source}"];
                break;
            }

            // Validate and seal
            try {
                self::sealBlock($block);
                $log[] = ['type' => 'ok', 'msg' => "Applied block {$h} hash=" . substr($block['hash'],0,12) . '…'];
            } catch (RuntimeException $e) {
                $log[] = ['type' => 'error', 'msg' => "Block {$h} rejected: " . $e->getMessage()];
                break;
            }
        }

        return $log;
    }

    // ============================================================
    //  Remote transfer submission
    // ============================================================

    /**
     * Submit a signed transfer to all servers in servers.txt.
     * Each server adds it to its pending pool.
     *
     * @return array  Log entries
     */
    public static function submitTransferToServers(array $tx): array
    {
        $servers = self::loadServers();
        $log     = [];

        if (empty($servers)) {
            $log[] = ['type' => 'error', 'msg' => 'No servers configured'];
            return $log;
        }

        $payload = json_encode($tx);

        foreach ($servers as $server) {
            $url = rtrim($server, '/') . '/blockchain.php?bc_action=submit_transfer';
            $ctx = stream_context_create(['http' => [
                'method'        => 'POST',
                'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\n",
                'content'       => $payload,
                'timeout'       => 15,
                'ignore_errors' => true,
            ]]);
            $resp    = @file_get_contents($url, false, $ctx);
            $decoded = $resp !== false ? @json_decode($resp, true) : null;

            if ($resp === false) {
                $log[] = ['type' => 'error', 'msg' => "→ {$server} no response"];
            } elseif (!empty($decoded['ok'])) {
                $log[] = ['type' => 'ok', 'msg' => "→ {$server} accepted txid={$tx['txid']}"];
            } else {
                $err = is_array($decoded) ? ($decoded['error'] ?? $resp) : $resp;
                $log[] = ['type' => 'error', 'msg' => "→ {$server} rejected: {$err}"];
            }
        }

        return $log;
    }

    // ============================================================
    //  Lookup helpers
    // ============================================================

    /**
     * Find a confirmed transfer by txid.
     * Returns ['block' => array, 'transfer' => array] or null.
     */
    public static function findTransfer(string $txid): ?array
    {
        $idxPath = BC_INDEX_DIR . '/' . $txid . '.json';
        $idx     = self::readJson($idxPath);
        if (!$idx) return null;

        $block = self::getBlock((int)$idx['height']);
        if (!$block) return null;

        foreach ($block['transfers'] as $tx) {
            if ($tx['txid'] === $txid)
                return ['block' => $block, 'transfer' => $tx];
        }
        return null;
    }

    /**
     * Return all confirmed transfers involving a given public key
     * (as sender or receiver). Scans the full chain.
     *
     * @param string $publicKeyBase64  Base64-encoded public key (no PEM headers)
     * @return array  List of ['block_height'=>N,'txid'=>'…','role'=>'sender|receiver', …]
     */
    public static function getTransfersByKey(string $publicKeyBase64): array
    {
        $height = self::getChainHeight();
        $out    = [];
        for ($i = 0; $i <= $height; $i++) {
            $block = self::getBlock($i);
            if (!$block) continue;
            foreach ($block['transfers'] as $tx) {
                $role = null;
                if ($tx['sender_public_key']   === $publicKeyBase64) $role = 'sender';
                if ($tx['receiver_public_key']  === $publicKeyBase64) $role = ($role ? 'both' : 'receiver');
                if ($role) {
                    $out[] = array_merge($tx, [
                        'block_height' => $i,
                        'block_hash'   => $block['hash'],
                        'role'         => $role,
                    ]);
                }
            }
        }
        return $out;
    }

    // ============================================================
    //  Merkle root
    //  Simple binary Merkle tree — pairs of sha256 hashes.
    //  If odd number of leaves, duplicate the last one.
    // ============================================================

    public static function computeMerkleRoot(array $txids): string
    {
        if (empty($txids)) return str_repeat('0', 64);

        $layer = $txids;
        while (count($layer) > 1) {
            if (count($layer) % 2 !== 0) $layer[] = end($layer); // duplicate last
            $next = [];
            for ($i = 0; $i < count($layer); $i += 2) {
                $next[] = hash('sha256', $layer[$i] . $layer[$i + 1]);
            }
            $layer = $next;
        }
        return $layer[0];
    }

    // ============================================================
    //  PEM / key helpers
    // ============================================================

    /**
     * Strip PEM headers and whitespace, return raw base64 string.
     */
    public static function normalisePem(string $pem): string
    {
        $lines = explode("\n", $pem);
        $b64   = '';
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '-----')) continue;
            $b64 .= $line;
        }
        return $b64;
    }

    /**
     * Re-wrap a raw base64 key string into a PEM block.
     */
    public static function base64ToPem(string $b64, string $type = 'PUBLIC KEY'): string
    {
        return "-----BEGIN {$type}-----\n"
             . chunk_split($b64, 64, "\n")
             . "-----END {$type}-----\n";
    }

    // ============================================================
    //  I/O helpers
    // ============================================================

    /** Read and JSON-decode a file. Returns null on failure. */
    private static function readJson(string $path): ?array
    {
        if (!file_exists($path)) return null;
        $fh = fopen($path, 'r');
        if (!$fh) return null;
        $raw = '';
        while (!feof($fh)) $raw .= fread($fh, 8192);
        fclose($fh);
        $d = json_decode($raw, true);
        return is_array($d) ? $d : null;
    }

    /**
     * HTTP GET a URL and JSON-decode the response.
     * Returns null on network or parse error.
     */
    private static function fetchJson(string $url): ?array
    {
        $ctx = stream_context_create(['http' => [
            'method'        => 'GET',
            'timeout'       => 10,
            'ignore_errors' => true,
            'header'        => "Accept: application/json\r\n",
        ]]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) return null;
        $d = @json_decode($raw, true);
        return is_array($d) ? $d : null;
    }

    /** Load server list from the shared servers.txt. */
    private static function loadServers(): array
    {
        if (!file_exists(BC_SERVERS_FILE)) return [];
        $lines = file(BC_SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return array_values(array_unique(array_map('trim', $lines ?: [])));
    }
}

// ================================================================
//  API endpoint handler
//  Called when blockchain.php is accessed directly OR when
//  index.php routes a bc_action parameter here.
//
//  To integrate with index.php, add this near the top of
//  index.php's routing section:
//
//      if (isset($_GET['bc_action'])) {
//          require_once __DIR__ . '/blockchain.php';
//          SeastarBlockchainApi::handle();
//          exit;
//      }
// ================================================================

class SeastarBlockchainApi
{
    public static function handle(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $action = trim($_GET['bc_action'] ?? '');

        switch ($action) {

            // ── GET  ?bc_action=tip ──────────────────────────────
            case 'tip':
                echo json_encode(SeastarBlockchain::getTip());
                break;

            // ── GET  ?bc_action=block&height=N ──────────────────
            case 'block':
                $height = isset($_GET['height']) ? (int)$_GET['height'] : -1;
                $block  = SeastarBlockchain::getBlock($height);
                if ($block) {
                    echo json_encode($block);
                } else {
                    http_response_code(404);
                    echo json_encode(['ok' => false, 'error' => "Block {$height} not found"]);
                }
                break;

            // ── GET  ?bc_action=blocks&from=N&to=M ──────────────
            case 'blocks':
                $from   = max(0, (int)($_GET['from'] ?? 0));
                $to     = (int)($_GET['to'] ?? SeastarBlockchain::getChainHeight());
                $to     = min($to, $from + 99); // max 100 blocks per request
                $blocks = [];
                for ($i = $from; $i <= $to; $i++) {
                    $b = SeastarBlockchain::getBlock($i);
                    if ($b) $blocks[] = $b;
                }
                echo json_encode(['blocks' => $blocks, 'count' => count($blocks)]);
                break;

            // ── GET  ?bc_action=tx&txid=TXID ────────────────────
            case 'tx':
                $txid = trim($_GET['txid'] ?? '');
                if (!preg_match('/^[a-f0-9]{64}$/', $txid)) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'error' => 'Invalid txid']);
                    break;
                }
                $found = SeastarBlockchain::findTransfer($txid);
                if ($found) {
                    echo json_encode(['ok' => true] + $found);
                } else {
                    // check pending
                    $pendingPath = BC_PENDING_DIR . '/' . $txid . '.json';
                    if (file_exists($pendingPath)) {
                        $raw = @file_get_contents($pendingPath);
                        $tx  = $raw ? json_decode($raw, true) : null;
                        echo json_encode(['ok' => true, 'status' => 'pending', 'transfer' => $tx]);
                    } else {
                        http_response_code(404);
                        echo json_encode(['ok' => false, 'error' => 'Transaction not found']);
                    }
                }
                break;

            // ── GET  ?bc_action=pending ──────────────────────────
            case 'pending':
                $pending = SeastarBlockchain::getPending();
                echo json_encode(['ok' => true, 'count' => count($pending), 'transfers' => $pending]);
                break;

            // ── GET  ?bc_action=validate ─────────────────────────
            case 'validate':
                $result = SeastarBlockchain::validateChain();
                echo json_encode(array_merge(['ok' => $result['valid']], $result));
                break;

            // ── GET  ?bc_action=sync ─────────────────────────────
            case 'sync':
                $log = SeastarBlockchain::runConsensus();
                echo json_encode(['ok' => true, 'log' => $log]);
                break;

            // ── GET  ?bc_action=history&key=BASE64 ──────────────
            case 'history':
                $key = trim($_GET['key'] ?? '');
                if ($key === '') {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'error' => 'key parameter required']);
                    break;
                }
                $txs = SeastarBlockchain::getTransfersByKey($key);
                echo json_encode(['ok' => true, 'count' => count($txs), 'transfers' => $txs]);
                break;

            // ── POST ?bc_action=submit_transfer ─────────────────
            case 'submit_transfer':
                $raw = file_get_contents('php://input');
                if (!$raw) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'error' => 'Empty body']);
                    break;
                }
                $tx = @json_decode($raw, true);
                if (!is_array($tx)) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
                    break;
                }
                $accepted = SeastarBlockchain::addToPending($tx);
                if ($accepted) {
                    echo json_encode(['ok' => true, 'txid' => $tx['txid']]);
                } else {
                    http_response_code(409);
                    echo json_encode(['ok' => false, 'error' => 'Transfer rejected (duplicate, invalid signature, or already confirmed)']);
                }
                break;

            // ── POST ?bc_action=mine ─────────────────────────────
            // Trigger mining from the pending pool.
            // In production you should protect this endpoint.
            case 'mine':
                $difficulty = max(1, min(6, (int)($_GET['difficulty'] ?? BC_DEFAULT_DIFF)));
                try {
                    $block = SeastarBlockchain::mineBlock($difficulty);
                    if ($block) {
                        echo json_encode(['ok' => true, 'block' => $block]);
                    } else {
                        echo json_encode(['ok' => false, 'error' => 'No pending transfers to mine']);
                    }
                } catch (RuntimeException $e) {
                    http_response_code(500);
                    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
                }
                break;

            default:
                http_response_code(400);
                echo json_encode(['ok' => false, 'error' => "Unknown bc_action: {$action}"]);
        }
    }
}

// ================================================================
//  Auto-handle: only execute if this file is the entry point,
//  not when required/included from another script.
// ================================================================
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    if (isset($_GET['bc_action'])) {
        SeastarBlockchainApi::handle();
        exit;
    }
    // No action: return a simple status JSON
    header('Content-Type: application/json; charset=utf-8');
    $tip = SeastarBlockchain::getTip();
    echo json_encode([
        'node'    => 'Seastar Blockchain',
        'height'  => $tip['height'],
        'hash'    => $tip['hash'],
        'pending' => count(SeastarBlockchain::getPending()),
    ]);
    exit;
}