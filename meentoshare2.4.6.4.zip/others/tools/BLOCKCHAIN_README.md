# Mesh Blockchain — Integration Guide

## Files

| File | Purpose |
|------|---------|
| `blockchain.php` | The library — include or require anywhere |
| `json_blocks/` | Auto-created folder; every block stored as `block_NNNNNNNNNN.json` |
| `json_blocks/chain_index.json` | Ordered list of block filenames (internal index) |

---

## Quick Start — 3 lines

```php
require_once 'blockchain.php';
$chain = new MeshBlockchain();          // creates json_blocks/ + genesis block

// Call after every successful Mesh Node upload:
$bcResult = $chain->handleSuccessfulUpload(
    $local,          // array from storeLocally()
    $peerResults,    // array from pushToServer() calls
    $upload['name'],
    $description,
    $publicKey,
    $nodeInfo,
    $servers         // from loadServers()
);
```

Paste those lines in **index.php** just before the final `jsonOut(...)` call in the
upload handler (the block that starts `jsonOut(['ok' => true, 'hash' => ...`).

---

## Full index.php Diff

Find this section in `index.php`:

```php
    jsonOut([
        'ok'          => true,
        'hash'        => $local['hash'],
        'filename'    => $local['filename'],
        'existed'     => $local['existed'],
        'public_key'  => $publicKey !== '' ? '✓ included' : '— not found',
        'node_info'   => $nodeInfo  !== '' ? '✓ included' : '— not found',
        'peers_total' => count($servers),
        'peers'       => $peerResults,
    ]);
```

Replace with:

```php
    // ── Blockchain recording ──────────────────────────────────────────────────
    require_once __DIR__ . '/blockchain.php';
    $chain    = new MeshBlockchain();
    $bcResult = $chain->handleSuccessfulUpload(
        $local, $peerResults,
        $upload['name'], $description, $publicKey, $nodeInfo,
        $servers
    );
    // ─────────────────────────────────────────────────────────────────────────

    jsonOut([
        'ok'          => true,
        'hash'        => $local['hash'],
        'filename'    => $local['filename'],
        'existed'     => $local['existed'],
        'public_key'  => $publicKey !== '' ? '✓ included' : '— not found',
        'node_info'   => $nodeInfo  !== '' ? '✓ included' : '— not found',
        'peers_total' => count($servers),
        'peers'       => $peerResults,
        'blockchain'  => $bcResult,   // optional — include in response
    ]);
```

Also add this near the **top** of `index.php` (after the `define(...)` block),
so peer-pushed blocks are accepted:

```php
require_once __DIR__ . '/blockchain.php';
(new MeshBlockchain())->handlePeerPushRequest();   // exits if it's a BC push
```

---

## Block JSON Structure

Every block in `json_blocks/block_NNNNNNNNNN.json` looks like this:

```json
{
  "index": 5,
  "prev_hash": "e3b0c44298fc1c149afb...previous block hash...",
  "timestamp": 1715695200.8341,
  "datetime": "2025-05-14T12:00:00Z",
  "version": "1.0.0",

  "transfer": {
    "filename": "photo.jpg",
    "stored_as": "abc123def456.jpg",
    "hash": "abc123def456...",
    "size": 204800,
    "description": "Optional user comment",
    "public_key": "...PEM contents or empty string...",
    "node_info": "node-42",
    "peers_reached": [
      "https://node1.example.com",
      "https://node2.example.com"
    ],
    "peers_failed": [],
    "sender_ip": "192.168.1.10",
    "existed": false,
    "extra": null
  },

  "block_hash": "7f83b1657ff1fc53b92dc181...SHA-256 of this block...",
  "next_hash": "9a4bfd5e7c2d...SHA-256 of next block, or null if tip..."
}
```

### Genesis block (index 0)

```json
{
  "index": 0,
  "prev_hash": "0000000000000000000000000000000000000000000000000000000000000000",
  "timestamp": 1715695100.0,
  "datetime": "2025-05-14T11:58:20Z",
  "version": "1.0.0",
  "transfer": null,
  "genesis": true,
  "message": "Mesh Blockchain — genesis block",
  "block_hash": "...",
  "next_hash": "..."
}
```

---

## API Reference

```php
$chain = new MeshBlockchain();           // default: ./json_blocks
$chain = new MeshBlockchain('/var/data/blocks');  // custom path

// Record a transfer
$chain->recordTransfer(array $transfer): array

// Broadcast a block to peers
$chain->broadcastBlock(int $blockIndex, array $servers): array

// Accept an inbound peer block
$chain->receivePeerBlock(string $rawJson): array

// Validate the whole chain
$chain->validateChain(): array   // ['valid', 'broken_at', 'length', 'errors']

// List all blocks
$chain->listBlocks(bool $includeGenesis = true): array

// Get one block
$chain->getBlock(int $index): ?array
$chain->getBlock(string $blockHash): ?array

// Chain length
$chain->chainLength(): int

// Status summary (for ?node_status endpoint)
$chain->status(): array

// Integration helpers
$chain->handleSuccessfulUpload(...): array
$chain->handlePeerPushRequest(): bool    // returns true if it handled the request
```

---

## Verify the chain (CLI)

```bash
php -r "
  require 'blockchain.php';
  \$r = (new MeshBlockchain())->validateChain();
  echo \$r['valid'] ? 'Chain OK — '.\$r['length'].' blocks' : 'BROKEN at block '.\$r['broken_at'];
  echo PHP_EOL;
"
```

---

## How hashing works

The `block_hash` for each block is computed as:

```
SHA-256( JSON_encode(block without block_hash and next_hash fields) )
```

This means:
- **block_hash** is a fingerprint of everything: index, prev_hash, timestamp, and the full transfer payload.
- **next_hash** is filled in retroactively when the *next* block is saved, creating a doubly-linked chain.
- Neither field participates in the hash, so back-filling `next_hash` never invalidates existing hashes.

---

## Requirements

- PHP 7.4+ (uses `int|string` union type — PHP 8.0+ recommended)
- No external libraries, no cURL — uses only built-in PHP stream functions
- Write access to the `json_blocks/` directory

For PHP 7.4 compatibility, change the `getBlock` signature from:
```php
public function getBlock(int|string $indexOrHash): ?array
```
to:
```php
/** @param int|string $indexOrHash */
public function getBlock($indexOrHash): ?array
```
