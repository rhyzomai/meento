﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH NODE — file replication over HTTP/HTTPS
//  Single-file PHP 7+ application
// ═══════════════════════════════════════════════════════════════════════════════

define('FILES_DIR',     __DIR__ . '/files');
define('INFO_DIR',      __DIR__ . '/info');
define('FILES_INDEX',   __DIR__ . '/files.txt');
define('SERVERS_FILE',  __DIR__ . '/servers.txt');
define('PUB_KEY_FILE',  __DIR__ . '/public_key.txt');
define('NODE_INFO_FILE',__DIR__ . '/node_info.txt');
define('MAX_COMMENT',   1 * 1024);   // 1 KB
define('BLOCKED_EXT',   ['php','php3','php4','php5','php7','phtml','phar']);

// ── bootstrap ─────────────────────────────────────────────────────────────────
foreach ([FILES_DIR, INFO_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}
if (!file_exists(FILES_INDEX)) file_put_contents(FILES_INDEX, '');

// ── helpers ───────────────────────────────────────────────────────────────────

function blockedExt(string $ext): bool {
    return in_array(strtolower($ext), BLOCKED_EXT, true);
}

function safeExt(string $filename): string {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return preg_replace('/[^a-z0-9]/', '', $ext);
}

function jsonOut(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function appendIndex(string $entry): void {
    $lines = file_exists(FILES_INDEX)
        ? array_map('trim', file(FILES_INDEX, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
        : [];
    if (!in_array($entry, $lines, true)) {
        file_put_contents(FILES_INDEX, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $out = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        if (!preg_match('#^https?://#i', $line)) $line = 'http://' . $line;
        $out[] = rtrim($line, '/');
    }
    return array_unique($out);
}

/** Read a local text file; return trimmed content or empty string if absent. */
function readOptionalFile(string $path): string {
    return file_exists($path) ? trim((string) file_get_contents($path)) : '';
}

/**
 * Store a file locally and write its structured info JSON.
 *
 * The info JSON always contains exactly these fields:
 *   original_filename, size, extension, public_key, node_info, description
 *
 * - $publicKey / $nodeInfo  : from own txt files (on upload) or forwarded by peer
 * - $description            : optional user comment; stored as empty string when absent
 *
 * Never overwrites an existing file or info record.
 *
 * Returns ['ok'=>true,  'hash'=>..., 'filename'=>..., 'existed'=>bool]
 *      or ['ok'=>false, 'error'=>...].
 */
function storeLocally(
    string $tmpPath,
    string $originalName,
    string $description,
    string $publicKey,
    string $nodeInfo
): array {
    $ext      = safeExt($originalName);
    if (blockedExt($ext)) return ['ok' => false, 'error' => 'PHP files are not accepted.'];

    $hash     = hash_file('sha256', $tmpPath);
    $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
    $destFile = FILES_DIR . '/' . $baseName;
    $destInfo = INFO_DIR  . '/' . $hash . '.json';

    $existed = file_exists($destFile);

    // ── save file only if new ──
    if (!$existed) {
        if (!copy($tmpPath, $destFile)) {
            return ['ok' => false, 'error' => 'Could not write file to disk.'];
        }
        appendIndex($baseName);
    }

    // ── save info JSON only if new — never overwrite ──
    if (!file_exists($destInfo)) {
        $info = [
            'original_filename' => $originalName,
            'size'              => (int) filesize($destFile),
            'extension'         => $ext,
            'public_key'        => $publicKey,
            'node_info'         => $nodeInfo,
            'description'       => $description,  // empty string if not supplied
        ];
        file_put_contents(
            $destInfo,
            json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    return ['ok' => true, 'hash' => $hash, 'filename' => $baseName, 'existed' => $existed];
}

/**
 * Push a file + metadata fields to one remote peer via multipart/form-data POST.
 * Uses only built-in PHP stream functions — no cURL, no external libraries.
 */
function pushToServer(
    string $server,
    string $filePath,
    string $filename,
    string $description,
    string $publicKey,
    string $nodeInfo
): array {
    $boundary = '----MeshBoundary' . bin2hex(random_bytes(12));
    $body = '';

    // ── file field ──
    $mime  = @mime_content_type($filePath) ?: 'application/octet-stream';
    $body .= "--{$boundary}\r\n";
    $body .= 'Content-Disposition: form-data; name="file"; filename="' . addslashes($filename) . "\"\r\n";
    $body .= "Content-Type: {$mime}\r\n\r\n";
    $body .= file_get_contents($filePath) . "\r\n";

    // ── text fields ──
    $fields = [
        'description' => $description,
        'public_key'  => $publicKey,
        'node_info'   => $nodeInfo,
        'peer_push'   => '1',
    ];
    foreach ($fields as $name => $value) {
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"{$name}\"\r\n\r\n";
        $body .= $value . "\r\n";
    }
    $body .= "--{$boundary}--\r\n";

    $url = $server . '/' . basename(__FILE__);

    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => implode("\r\n", [
                "Content-Type: multipart/form-data; boundary={$boundary}",
                "Content-Length: " . strlen($body),
                "X-Mesh-Node: 1",
            ]),
            'content'       => $body,
            'timeout'       => 20,
            'ignore_errors' => true,
        ],
        'ssl'  => [
            'verify_peer'      => false,
            'verify_peer_name' => false,
        ],
    ]);

    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) {
        return ['ok' => false, 'server' => $server, 'error' => 'Connection failed.'];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return ['ok' => false, 'server' => $server, 'error' => 'Bad response: ' . substr($raw, 0, 120)];
    }

    return array_merge($decoded, ['server' => $server]);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  RECEIVE ENDPOINT  —  POST from a peer node  (peer_push = 1)
// ═══════════════════════════════════════════════════════════════════════════════
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_FILES['file'], $_POST['peer_push']) &&
    $_POST['peer_push'] === '1'
) {
    $upload = $_FILES['file'];

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        jsonOut(['ok' => false, 'error' => 'Upload error ' . $upload['error']], 400);
    }

    if (blockedExt(safeExt($upload['name']))) {
        jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);
    }

    $description = isset($_POST['description']) ? substr(trim($_POST['description']), 0, MAX_COMMENT) : '';
    $publicKey   = isset($_POST['public_key'])   ? trim($_POST['public_key'])  : '';
    $nodeInfo    = isset($_POST['node_info'])     ? trim($_POST['node_info'])   : '';

    $result = storeLocally($upload['tmp_name'], $upload['name'], $description, $publicKey, $nodeInfo);
    jsonOut($result, $result['ok'] ? 200 : 500);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  UPLOAD ENDPOINT  —  POST from the browser  (stores locally + propagates)
// ═══════════════════════════════════════════════════════════════════════════════
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_FILES['file']) &&
    !isset($_POST['peer_push'])
) {
    $upload = $_FILES['file'];

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        jsonOut(['ok' => false, 'error' => 'Upload error ' . $upload['error']], 400);
    }

    if (blockedExt(safeExt($upload['name']))) {
        jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);
    }

    $description = isset($_POST['comment']) ? substr(trim($_POST['comment']), 0, MAX_COMMENT) : '';

    // Read own public_key.txt / node_info.txt
    $publicKey = readOptionalFile(PUB_KEY_FILE);
    $nodeInfo  = readOptionalFile(NODE_INFO_FILE);

    // 1. Store locally
    $local = storeLocally($upload['tmp_name'], $upload['name'], $description, $publicKey, $nodeInfo);

if ($local['ok']) {
    require_once __DIR__ . '/data_json.php';
    DataLog::append($local['hash']);
}
    if (!$local['ok']) jsonOut($local, 500);

    // 2. Push to every peer
    $servers     = loadServers();
    $peerResults = [];
    $storedPath  = FILES_DIR . '/' . $local['filename'];

    foreach ($servers as $server) {
        $peerResults[] = pushToServer(
            $server, $storedPath, $upload['name'],
            $description, $publicKey, $nodeInfo
        );
    }

    jsonOut([
        'ok'          => true,
        'hash'        => $local['hash'],
        'filename'    => $local['filename'],
        'existed'     => $local['existed'],
        'public_key'  => $publicKey !== '' ? '✓ included' : '— not found',
        'node_info'   => $nodeInfo  !== '' ? '✓ included' : '— not found',
        'peers_total' => count($servers),
        'peers'       => $peerResults,
    ]);
}

// ── lightweight JSON endpoints for the UI ─────────────────────────────────────
if (isset($_GET['node_status'])) {
    jsonOut([
        'public_key' => file_exists(PUB_KEY_FILE),
        'node_info'  => file_exists(NODE_INFO_FILE),
        'peers'      => count(loadServers()),
    ]);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  HTML FRONT-END
// ═══════════════════════════════════════════════════════════════════════════════
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;900&family=Fira+Code:wght@300;400;500&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

:root{
  --ink:     #f0ede6;
  --paper:   #111010;
  --card:    #1a1918;
  --line:    #2e2b28;
  --amber:   #f5a623;
  --amber2:  #f5d423;
  --red:     #e8453c;
  --green:   #3ce87a;
  --blue:    #3cb4e8;
  --muted:   #6b6560;
  --r:       10px;
  --mono:    'Fira Code', monospace;
  --display: 'Unbounded', sans-serif;
}

html,body{min-height:100%;background:var(--paper);color:var(--ink);font-family:var(--mono)}

body::after{
  content:'';position:fixed;inset:0;pointer-events:none;z-index:999;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23g)' opacity='0.035'/%3E%3C/svg%3E");
  opacity:.7;
}

.page{max-width:880px;margin:0 auto;padding:0 28px 80px}

/* header */
header{padding:60px 0 44px;border-bottom:1px solid var(--line);margin-bottom:44px}
.hstack{display:flex;align-items:center;gap:18px}
.hex-badge{
  width:48px;height:48px;background:var(--amber);
  clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);
  display:grid;place-items:center;flex-shrink:0;
}
.hex-badge svg{width:22px;height:22px;stroke:#111;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.brand h1{font-family:var(--display);font-size:1.35rem;font-weight:900;letter-spacing:-.04em;line-height:1}
.brand h1 em{color:var(--amber);font-style:normal}
.brand p{font-size:.65rem;color:var(--muted);letter-spacing:.12em;margin-top:5px;text-transform:uppercase}

/* node status bar */
#node-bar{
  display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px;
  padding:12px 16px;background:var(--card);border:1px solid var(--line);border-radius:var(--r);
  font-size:.68rem;
}
.nb-pill{display:flex;align-items:center;gap:6px;padding:4px 10px;border-radius:99px;background:rgba(255,255,255,.04);border:1px solid var(--line)}
.nb-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;background:var(--muted)}
.nb-dot.ok{background:var(--green)}
.nb-dot.blue{background:var(--blue)}
.nb-label{color:var(--muted)}
.nb-val{color:var(--ink)}

/* drop zone */
#drop-zone{
  border:2px dashed var(--line);border-radius:var(--r);
  padding:58px 32px;text-align:center;cursor:pointer;
  background:var(--card);transition:border-color .2s,background .2s,transform .15s;
  position:relative;overflow:hidden;
}
#drop-zone::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse at 50% -10%,rgba(245,166,35,.07) 0%,transparent 60%);
  pointer-events:none;
}
#drop-zone.over{border-color:var(--amber);background:rgba(245,166,35,.04);transform:scale(1.008)}
#drop-zone.over .dz-icon{transform:scale(1.2) translateY(-5px)}
.dz-icon{
  width:60px;height:60px;margin:0 auto 22px;
  background:rgba(245,166,35,.1);border-radius:14px;
  display:grid;place-items:center;
  transition:transform .3s cubic-bezier(.34,1.56,.64,1);
}
.dz-icon svg{width:28px;height:28px;stroke:var(--amber);stroke-width:1.7;fill:none;stroke-linecap:round;stroke-linejoin:round}
.dz-title{font-family:var(--display);font-size:.95rem;font-weight:600;margin-bottom:8px;letter-spacing:-.02em}
.dz-sub{font-size:.68rem;color:var(--muted);line-height:1.7}
.dz-sub b{color:var(--amber)}
#file-input{display:none}

/* panel */
#panel{display:none;margin-top:20px;background:var(--card);border:1px solid var(--line);border-radius:var(--r);overflow:hidden}

.panel-top{padding:14px 18px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--line)}
.f-icon{width:34px;height:34px;background:rgba(245,212,35,.1);border-radius:8px;display:grid;place-items:center;flex-shrink:0}
.f-icon svg{width:16px;height:16px;stroke:var(--amber2);stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round}
#f-name{font-size:.78rem;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#f-size{font-size:.7rem;color:var(--muted);flex-shrink:0}
.x-btn{background:none;border:none;color:var(--muted);cursor:pointer;padding:4px;border-radius:6px;line-height:0;transition:color .15s,background .15s}
.x-btn:hover{color:var(--red);background:rgba(232,69,60,.1)}
.x-btn svg{width:16px;height:16px;stroke:currentColor;stroke-width:2;fill:none;stroke-linecap:round}

/* metadata preview pills */
.meta-pills{
  padding:10px 18px;display:flex;gap:8px;flex-wrap:wrap;
  border-bottom:1px solid var(--line);background:rgba(0,0,0,.18);
}
.mpill{
  font-size:.64rem;padding:3px 10px;border-radius:99px;
  display:flex;align-items:center;gap:5px;
  border:1px solid var(--line);color:var(--muted);background:rgba(255,255,255,.03);
  transition:all .2s;
}
.mpill.has{background:rgba(60,232,122,.08);border-color:rgba(60,232,122,.25);color:var(--green)}
.mpill svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}

/* description field */
.panel-mid{padding:20px}
.fl{display:block;font-size:.64rem;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
textarea#comment-box{
  width:100%;min-height:96px;background:var(--paper);
  border:1px solid var(--line);border-radius:8px;
  color:var(--ink);font-family:var(--mono);font-size:.78rem;
  line-height:1.65;padding:11px 14px;resize:vertical;outline:none;
  transition:border-color .2s;
}
textarea#comment-box:focus{border-color:var(--amber)}
textarea#comment-box::placeholder{color:var(--muted)}
.cmeta{display:flex;justify-content:space-between;margin-top:6px}
.chint,.ccount{font-size:.64rem;color:var(--muted)}
.ccount.over{color:var(--red)}

/* panel footer */
.panel-bot{
  padding:14px 18px;border-top:1px solid var(--line);
  display:flex;align-items:center;justify-content:space-between;gap:12px;
}
.peer-info{font-size:.68rem;color:var(--muted)}
.peer-info b{color:var(--amber)}
.btn-send{
  background:var(--amber);color:#111;border:none;border-radius:8px;
  padding:10px 26px;font-family:var(--display);font-size:.75rem;font-weight:600;
  cursor:pointer;letter-spacing:.02em;display:flex;align-items:center;gap:8px;
  transition:opacity .15s,transform .15s;white-space:nowrap;
}
.btn-send:hover{opacity:.88;transform:translateY(-1px)}
.btn-send:active{transform:translateY(0)}
.btn-send svg{width:15px;height:15px;stroke:#111;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.btn-send.busy{opacity:.55;pointer-events:none}

/* progress */
#prog-wrap{height:2px;background:var(--line);border-radius:99px;overflow:hidden;display:none;margin-top:14px}
#prog-bar{height:100%;width:0%;background:linear-gradient(90deg,var(--amber),var(--amber2));transition:width .1s linear}

/* status */
#status{display:none;margin-top:18px;border-radius:var(--r);padding:16px 18px;font-size:.75rem;line-height:1.75;animation:fadeUp .3s ease}
#status.ok{background:rgba(60,232,122,.07);border:1px solid rgba(60,232,122,.2);color:var(--green)}
#status.fail{background:rgba(232,69,60,.07);border:1px solid rgba(232,69,60,.2);color:var(--red)}
.hash-line{word-break:break-all;opacity:.75;font-size:.7rem;margin-top:2px}
.meta-sent{font-size:.68rem;opacity:.75;margin-top:5px;color:var(--blue)}

#peer-log{margin-top:8px}
.peer-row{display:flex;align-items:center;gap:8px;font-size:.68rem;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.peer-row:last-child{border:none}
.dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.dot.ok{background:var(--green)} .dot.fail{background:var(--red)}
.peer-url{color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.peer-msg{color:var(--muted);font-size:.64rem;flex-shrink:0}

/* info box showing json structure */
.json-preview{
  margin-top:28px;background:var(--card);border:1px solid var(--line);
  border-radius:var(--r);overflow:hidden;
}
.json-preview-head{
  padding:10px 16px;border-bottom:1px solid var(--line);
  font-size:.64rem;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);
  display:flex;align-items:center;gap:8px;
}
.json-preview-head svg{width:13px;height:13px;stroke:var(--muted);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
pre#json-schema{
  padding:16px;margin:0;font-family:var(--mono);font-size:.72rem;
  line-height:1.7;color:var(--muted);overflow-x:auto;
}
.jk{color:#f5a623} .js{color:#c8f04a} .jn{color:#3cb4e8} .jb{color:#f04a6a}

@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}

footer{border-top:1px solid var(--line);padding:22px 0;display:flex;justify-content:space-between}
footer p{font-size:.62rem;color:var(--muted)}
</style>
</head>
<body>
<div class="page">

<header>
  <div class="hstack">
    <div class="hex-badge">
      <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
    </div>
    <div class="brand">
      <h1>Mesh <em>Node</em></h1>
      <p>Peer replication · SHA-256 storage</p>
      <p><a href="view.php" style="color: #ffffff;">Search</a></p>
    </div>
  </div>
</header>

<!-- Node status bar -->
<div id="node-bar">
  <div class="nb-pill">
    <span class="nb-dot blue"></span>
    <span class="nb-label">peers&nbsp;</span>
    <span class="nb-val" id="nb-peers">…</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-pk-dot"></span>
    <span class="nb-label">public_key.txt&nbsp;</span>
    <span class="nb-val" id="nb-pk">…</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-ni-dot"></span>
    <span class="nb-label">node_info.txt&nbsp;</span>
    <span class="nb-val" id="nb-ni">…</span>
  </div>
</div>

<!-- Drop zone -->
<div id="drop-zone" tabindex="0" role="button" aria-label="Select or drop a file">
  <div class="dz-icon">
    <svg viewBox="0 0 24 24"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/></svg>
  </div>
  <p class="dz-title">Drop a file or click to select</p>
  <p class="dz-sub">Stored as <b>sha256.ext</b> · pushed to all peers · <b>public_key</b> &amp; <b>node_info</b> attached · <b>.php</b> blocked</p>
</div>
<input type="file" id="file-input">

<!-- Upload panel (shown after file selection) -->
<div id="panel">
  <div class="panel-top">
    <div class="f-icon">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    </div>
    <span id="f-name">—</span>
    <span id="f-size"></span>
    <button class="x-btn" id="x-btn" aria-label="Remove file">
      <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>
  </div>

  <!-- live metadata pills -->
  <div class="meta-pills">
    <div class="mpill" id="mpill-pk">
      <svg viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
      public_key
    </div>
    <div class="mpill" id="mpill-ni">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      node_info
    </div>
    <div class="mpill has">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      original_filename · size · extension
    </div>
  </div>

  <div class="panel-mid">
    <label class="fl" for="comment-box">Description <span style="opacity:.5">(optional · max 500 KB · stored as "description" field)</span></label>
    <textarea id="comment-box" placeholder="Add an optional description for this file…"></textarea>
    <div class="cmeta">
      <span class="chint">Empty = stored as "" in info/&lt;hash&gt;.json</span>
      <span class="ccount" id="ccount">0 / 1 000</span>
    </div>
  </div>

  <div class="panel-bot">
    <span class="peer-info">Sending to <b id="peer-count">…</b> peer(s)</span>
    <button class="btn-send" id="send-btn">
      <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      Send to network
    </button>
  </div>
</div>

<div id="prog-wrap"><div id="prog-bar"></div></div>
<div id="status"></div>

<!-- JSON schema preview -->
<div class="json-preview">
  <div class="json-preview-head">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    info/&lt;hash&gt;.json — stored structure
  </div>
  <pre id="json-schema">{
  <span class="jk">"original_filename"</span>: <span class="js">"photo.jpg"</span>,
  <span class="jk">"size"</span>:              <span class="jn">204800</span>,
  <span class="jk">"extension"</span>:        <span class="js">"jpg"</span>,
  <span class="jk">"public_key"</span>:       <span class="js">"&lt;contents of public_key.txt or empty string&gt;"</span>,
  <span class="jk">"node_info"</span>:        <span class="js">"&lt;contents of node_info.txt or empty string&gt;"</span>,
  <span class="jk">"description"</span>:      <span class="js">"&lt;user comment or empty string&gt;"</span>
}</pre>
</div>

</div><!-- .page -->

<footer class="page" style="padding-top:0;padding-bottom:24px">
  <p>Mesh Node · files stored as sha256.ext · info JSON has 6 fixed fields</p>
  <p>PHP <?php echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION; ?></p>
</footer>

<script>
(function(){
'use strict';

const dz       = document.getElementById('drop-zone');
const fi       = document.getElementById('file-input');
const panel    = document.getElementById('panel');
const fName    = document.getElementById('f-name');
const fSize    = document.getElementById('f-size');
const xBtn     = document.getElementById('x-btn');
const commentB = document.getElementById('comment-box');
const ccount   = document.getElementById('ccount');
const sendBtn  = document.getElementById('send-btn');
const peerCnt  = document.getElementById('peer-count');
const status   = document.getElementById('status');
const progWrap = document.getElementById('prog-wrap');
const progBar  = document.getElementById('prog-bar');
const mpillPk  = document.getElementById('mpill-pk');
const mpillNi  = document.getElementById('mpill-ni');

const MAX     = 1000;
const BLOCKED = ['php','php3','php4','php5','php7','phtml','phar'];
let file = null;
let ns   = { public_key: false, node_info: false, peers: 0 };

// ── fetch node status ──────────────────────────────────────────────────────────
fetch(window.location.href + '?node_status=1')
  .then(r => r.json())
  .then(d => {
    ns = d;
    document.getElementById('nb-peers').textContent = d.peers;
    peerCnt.textContent = d.peers;

    const dot = (id, ok) => {
      const el = document.getElementById(id);
      if(el) el.className = 'nb-dot ' + (ok ? 'ok' : '');
    };
    dot('nb-pk-dot', d.public_key);
    dot('nb-ni-dot', d.node_info);
    document.getElementById('nb-pk').textContent = d.public_key ? '✓ found' : '— missing';
    document.getElementById('nb-ni').textContent = d.node_info  ? '✓ found' : '— missing';
    updatePills();
  })
  .catch(() => {
    ['nb-peers','nb-pk','nb-ni'].forEach(id => {
      const el = document.getElementById(id); if(el) el.textContent='?';
    });
    peerCnt.textContent = '?';
  });

function updatePills(){
  mpillPk.className = 'mpill ' + (ns.public_key ? 'has' : '');
  mpillNi.className = 'mpill ' + (ns.node_info  ? 'has' : '');
}

function fmt(b){
  if(b<1024) return b+' B';
  if(b<1048576) return (b/1024).toFixed(1)+' KB';
  return (b/1048576).toFixed(2)+' MB';
}

function extOf(n){ return n.split('.').pop().toLowerCase(); }

function setFile(f){
  if(!f) return;
  if(BLOCKED.includes(extOf(f.name))){ show('fail','PHP files are not accepted.'); return; }
  file = f;
  fName.textContent = f.name;
  fSize.textContent = fmt(f.size);
  panel.style.display = 'block';
  commentB.value = '';
  updateCount();
  updatePills();
  hide();
}

function clear(){
  file = null; fi.value = '';
  panel.style.display = 'none';
  commentB.value = '';
  hide();
}

dz.addEventListener('click', () => fi.click());
dz.addEventListener('keydown', e => { if(e.key==='Enter'||e.key===' ') fi.click(); });
fi.addEventListener('change', () => { if(fi.files[0]) setFile(fi.files[0]); });
xBtn.addEventListener('click', clear);

['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', e => { if(e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

function updateCount(){
  const len = new TextEncoder().encode(commentB.value).length;
  ccount.textContent = len.toLocaleString()+' / '+MAX.toLocaleString();
  ccount.classList.toggle('over', len > MAX);
}
commentB.addEventListener('input', updateCount);

function show(type, html){ status.className=type; status.innerHTML=html; status.style.display='block'; }
function hide(){ status.style.display='none'; }

sendBtn.addEventListener('click', () => {
  if(!file) return;
  if(new TextEncoder().encode(commentB.value).length > MAX){
    show('fail','Description exceeds the 500 KB limit.'); return;
  }

  const fd = new FormData();
  fd.append('file', file);
  fd.append('comment', commentB.value);

  const xhr = new XMLHttpRequest();
  sendBtn.classList.add('busy');
  sendBtn.lastChild.textContent = ' Transmitting…';
  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  hide();

  xhr.upload.addEventListener('progress', e => {
    if(e.lengthComputable) progBar.style.width = Math.round(e.loaded/e.total*100)+'%';
  });

  xhr.addEventListener('load', () => {
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    progBar.style.width = '100%';
    setTimeout(() => { progWrap.style.display='none'; progBar.style.width='0%'; }, 700);

    let res;
    try { res = JSON.parse(xhr.responseText); } catch(e){ show('fail','Unexpected server response.'); return; }
    if(!res.ok){ show('fail','✗ '+(res.error||'Unknown error')); return; }

    const existed = res.existed ? ' <span style="opacity:.5">(content already stored)</span>' : '';
    let html = '✓ File stored' + existed +
      '<div class="hash-line">sha256 · ' + res.hash + '</div>' +
      '<div class="hash-line">filename · ' + res.filename + '</div>';

    const meta = [res.public_key, res.node_info].filter(v => v && v.startsWith('✓'));
    if(meta.length) html += '<div class="meta-sent">' + meta.join(' &nbsp;·&nbsp; ') + '</div>';

    if(Array.isArray(res.peers) && res.peers.length){
      html += '<div id="peer-log">';
      res.peers.forEach(p => {
        const ok  = p.ok === true;
        const msg = ok ? (p.existed ? 'already had it' : 'stored') : (p.error||'failed');
        html += `<div class="peer-row">
          <span class="dot ${ok?'ok':'fail'}"></span>
          <span class="peer-url">${esc(p.server)}</span>
          <span class="peer-msg">${esc(msg)}</span>
        </div>`;
      });
      html += '</div>';
    } else {
      html += '<div class="hash-line" style="margin-top:6px;opacity:.45">No peers configured.</div>';
    }

    show('ok', html);
    clear();
  });

  xhr.addEventListener('error', () => {
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    show('fail','✗ Network error.'); progWrap.style.display='none';
  });

  xhr.open('POST', window.location.href);
  xhr.send(fd);
});

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

})();
</script>
</body>
</html>