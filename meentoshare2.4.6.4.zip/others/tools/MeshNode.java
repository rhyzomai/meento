import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/**
 * MeshNode.java � Java 8 Swing GUI
 * Equivalent of the PHP Mesh Node file-replication application.
 *
 * Features:
 *  - Drag-and-drop or click-to-browse file selection
 *  - SHA-256 content-addressed local storage (files/ and info/)
 *  - Optional description (max 1 KB)
 *  - Peer propagation via multipart/form-data POST
 *  - Node status bar (peers, public_key.txt, node_info.txt)
 *  - All in a single file, Java 8, no external libraries
 *
 * Usage:
 *   javac MeshNode.java
 *   java  MeshNode
 *
 * Directory layout (created automatically next to the .class):
 *   files/          stored files
 *   info/           <hash>.json metadata records
 *   files.txt       index of stored basenames
 *   servers.txt     one peer URL per line
 *   public_key.txt  optional public key
 *   node_info.txt   optional node description
 */
public class MeshNode extends JFrame {

    // -- constants --------------------------------------------------------------
    private static final String[] BLOCKED_EXT =
            {"php","php3","php4","php5","php7","phtml","phar"};
    private static final int MAX_COMMENT = 1024; // bytes
    private static final Color BLUE      = new Color(0, 68, 204);
    private static final Color GREEN     = new Color(26, 142, 63);
    private static final Color RED       = new Color(204, 0, 0);
    private static final Color BG        = Color.WHITE;
    private static final Color BG_LIGHT  = new Color(250, 250, 250);
    private static final Color BORDER    = new Color(221, 221, 221);
    private static final Font  MONO      = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    // -- working directory ------------------------------------------------------
    private static final File BASE_DIR    = new File(System.getProperty("user.dir"));
    private static final File FILES_DIR   = new File(BASE_DIR, "files");
    private static final File INFO_DIR    = new File(BASE_DIR, "info");
    private static final File FILES_INDEX = new File(BASE_DIR, "files.txt");
    private static final File SERVERS_F   = new File(BASE_DIR, "servers.txt");
    private static final File PUB_KEY_F   = new File(BASE_DIR, "public_key.txt");
    private static final File NODE_INFO_F = new File(BASE_DIR, "node_info.txt");

    // -- UI state ---------------------------------------------------------------
    private File selectedFile = null;

    // -- UI components ----------------------------------------------------------
    private JLabel  nbPeers, nbPk, nbNi;
    private JPanel  nbPkDot, nbNiDot, nbPeerDot;
    private JPanel  dropZone;
    private JLabel  dropLabel;
    private JPanel  panel;
    private JLabel  fName, fSize;
    private JLabel  mpillPk, mpillNi;
    private JTextArea commentBox;
    private JLabel  ccount;
    private JLabel  peerCount;
    private JButton sendBtn;
    private JProgressBar progressBar;
    private JPanel  statusPanel;
    private JLabel  statusLabel;
    private JButton openFileLink;

    // -- constructor ------------------------------------------------------------
    public MeshNode() {
        super("Mesh Node");
        bootstrap();
        buildUI();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setMinimumSize(new Dimension(560, 500));
        setLocationRelativeTo(null);
        setVisible(true);
        loadNodeStatus();
    }

    // -- bootstrap: create directories -----------------------------------------
    private void bootstrap() {
        FILES_DIR.mkdirs();
        INFO_DIR.mkdirs();
        try {
            if (!FILES_INDEX.exists()) FILES_INDEX.createNewFile();
        } catch (IOException ignored) {}
    }

    // ---------------------------------------------------------------------------
    //  UI CONSTRUCTION
    // ---------------------------------------------------------------------------

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));

        root.add(buildHeader(),    BorderLayout.NORTH);
        root.add(buildCenter(),    BorderLayout.CENTER);
        root.add(buildFooter(),    BorderLayout.SOUTH);

        setContentPane(root);
    }

    // -- header -----------------------------------------------------------------
    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout(12, 0));
        h.setBackground(BG);
        h.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));

        JPanel left = new JPanel(new GridLayout(2, 1, 0, 2));
        left.setBackground(BG);
        JLabel title = new JLabel("<html><b>Mesh</b> <span style='color:#555;font-weight:400'>Node</span></html>");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        JLabel sub = new JLabel("Peer replication � SHA-256 storage");
        sub.setFont(sub.getFont().deriveFont(10f));
        sub.setForeground(new Color(119, 119, 119));
        left.add(title);
        left.add(sub);

        JButton searchBtn = makeLink("Search ?");
        searchBtn.addActionListener(e -> showFileListDialog());

        h.add(left,     BorderLayout.WEST);
        h.add(searchBtn, BorderLayout.EAST);
        return h;
    }

    // -- center scroll area -----------------------------------------------------
    private JScrollPane buildCenter() {
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(BG);

        center.add(buildNodeBar());
        center.add(Box.createVerticalStrut(16));
        center.add(buildDropZone());
        center.add(Box.createVerticalStrut(12));
        center.add(buildUploadPanel());
        center.add(Box.createVerticalStrut(8));
        center.add(buildProgressRow());
        center.add(Box.createVerticalStrut(4));
        center.add(buildStatusRow());
        center.add(Box.createVerticalStrut(16));
        center.add(buildJsonPreview());

        JScrollPane sp = new JScrollPane(center,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
        sp.getViewport().setBackground(BG);
        return sp;
    }

    // -- node status bar --------------------------------------------------------
    private JPanel buildNodeBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setBackground(BG);
        bar.setAlignmentX(0f);

        nbPeerDot = makeDot(BLUE);
        nbPeers   = new JLabel("�");
        nbPeers.setFont(nbPeers.getFont().deriveFont(Font.BOLD, 11f));
        bar.add(makePill(nbPeerDot, new JLabel("peers"), nbPeers));

        nbPkDot = makeDot(new Color(170,170,170));
        nbPk    = new JLabel("�");
        nbPk.setFont(nbPk.getFont().deriveFont(Font.BOLD, 11f));
        bar.add(makePill(nbPkDot, new JLabel("public_key.txt"), nbPk));

        JPanel niDotWrapper = new JPanel(new FlowLayout(0,0,0));
        niDotWrapper.setBackground(BG);
        nbNiDot = makeDot(new Color(170,170,170));
        nbNi    = new JLabel("�");
        nbNi.setFont(nbNi.getFont().deriveFont(Font.BOLD, 11f));
        bar.add(makePill(nbNiDot, new JLabel("node_info.txt"), nbNi));

        return bar;
    }

    private JPanel makeDot(Color c) {
        JPanel dot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(getBackground());
                g.fillOval(0, 0, 8, 8);
            }
        };
        dot.setPreferredSize(new Dimension(8, 8));
        dot.setBackground(c);
        dot.setOpaque(false);
        return dot;
    }

    private JPanel makePill(JPanel dot, JLabel lbl, JLabel val) {
        JPanel pill = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        pill.setBackground(BG_LIGHT);
        pill.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(3, 8, 3, 8)));
        lbl.setFont(lbl.getFont().deriveFont(10f));
        lbl.setForeground(new Color(85, 85, 85));
        pill.add(dot); pill.add(lbl); pill.add(val);
        return pill;
    }

    // -- drop zone --------------------------------------------------------------
    private JPanel buildDropZone() {
        dropZone = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(204, 204, 204));
                float[] dash = {6f, 4f};
                g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND,
                        BasicStroke.JOIN_ROUND, 1f, dash, 0f));
                g2.drawRoundRect(1, 1, getWidth()-3, getHeight()-3, 8, 8);
            }
        };
        dropZone.setBackground(BG);
        dropZone.setPreferredSize(new Dimension(500, 120));
        dropZone.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        dropZone.setAlignmentX(0f);
        dropZone.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel icon = new JLabel("?");
        icon.setFont(icon.getFont().deriveFont(30f));
        icon.setForeground(new Color(119,119,119));

        JLabel title = new JLabel("Drop a file here or click to select");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 13f));

        JLabel sub = new JLabel("<html><center>Stored as <b>sha256.ext</b> � pushed to all peers � <b style='color:#0044cc'>.php</b> blocked</center></html>");
        sub.setFont(sub.getFont().deriveFont(10f));
        sub.setForeground(new Color(102,102,102));

        gbc.insets = new Insets(0,0,4,0);
        dropZone.add(icon, gbc);
        gbc.insets = new Insets(0,0,4,0);
        dropZone.add(title, gbc);
        gbc.insets = new Insets(0,0,0,0);
        dropZone.add(sub, gbc);

        dropZone.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { browseFile(); }
            @Override public void mouseEntered(MouseEvent e) { dropZone.setBackground(new Color(250,250,250)); dropZone.repaint(); }
            @Override public void mouseExited(MouseEvent e)  { dropZone.setBackground(BG); dropZone.repaint(); }
        });

        new DropTarget(dropZone, new DropTargetAdapter() {
            @Override public void dragEnter(DropTargetDragEvent e) {
                dropZone.setBackground(new Color(240,244,255)); dropZone.repaint();
            }
            @Override public void dragExit(DropTargetEvent e) {
                dropZone.setBackground(BG); dropZone.repaint();
            }
            @Override public void drop(DropTargetDropEvent e) {
                dropZone.setBackground(BG); dropZone.repaint();
                try {
                    e.acceptDrop(DnDConstants.ACTION_COPY);
                    @SuppressWarnings("unchecked")
                    List<File> files = (List<File>) e.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);
                    if (!files.isEmpty()) handleFileSelected(files.get(0));
                } catch (Exception ex) { /* ignore */ }
            }
        });

        return dropZone;
    }

    // -- upload panel -----------------------------------------------------------
    private JPanel buildUploadPanel() {
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createLineBorder(BORDER));
        panel.setAlignmentX(0f);
        panel.setVisible(false);

        // top row: filename + size + remove
        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setBackground(BG);
        top.setBorder(new CompoundBorder(
                new MatteBorder(0,0,1,0,BORDER),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));

        JLabel fileIcon = new JLabel("??");
        fileIcon.setFont(fileIcon.getFont().deriveFont(18f));

        fName = new JLabel("�");
        fName.setFont(fName.getFont().deriveFont(13f));
        fSize = new JLabel("");
        fSize.setFont(fSize.getFont().deriveFont(11f));
        fSize.setForeground(new Color(119,119,119));

        JPanel nameRow = new JPanel(new BorderLayout(6, 0));
        nameRow.setBackground(BG);
        nameRow.add(fileIcon, BorderLayout.WEST);
        nameRow.add(fName,    BorderLayout.CENTER);
        nameRow.add(fSize,    BorderLayout.EAST);

        JButton xBtn = new JButton("?");
        xBtn.setFont(xBtn.getFont().deriveFont(14f));
        xBtn.setForeground(new Color(153,153,153));
        xBtn.setBorderPainted(false);
        xBtn.setContentAreaFilled(false);
        xBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        xBtn.addActionListener(e -> clearFile());
        xBtn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { xBtn.setForeground(RED); }
            @Override public void mouseExited (MouseEvent e) { xBtn.setForeground(new Color(153,153,153)); }
        });

        top.add(nameRow, BorderLayout.CENTER);
        top.add(xBtn,    BorderLayout.EAST);

        // meta pills row
        JPanel pills = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pills.setBackground(BG_LIGHT);
        pills.setBorder(new CompoundBorder(
                new MatteBorder(0,0,1,0,BORDER),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)));

        mpillPk = makeMetaPill("?? public_key", false);
        mpillNi = makeMetaPill("? node_info", false);
        JLabel mpillFile = makeMetaPill("?? filename � size � extension", true);

        pills.add(mpillPk);
        pills.add(mpillNi);
        pills.add(mpillFile);

        // description / comment area
        JPanel mid = new JPanel(new BorderLayout(0, 4));
        mid.setBackground(BG);
        mid.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));

        JLabel lbl = new JLabel("Description  (optional � max 1 KB)");
        lbl.setFont(lbl.getFont().deriveFont(10f));
        lbl.setForeground(new Color(119,119,119));

        commentBox = new JTextArea(3, 30);
        commentBox.setLineWrap(true);
        commentBox.setWrapStyleWord(true);
        commentBox.setFont(commentBox.getFont().deriveFont(12f));
        commentBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204,204,204)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        JScrollPane csp = new JScrollPane(commentBox);
        csp.setBorder(BorderFactory.createLineBorder(new Color(204,204,204)));

        ccount = new JLabel("0 / 1 000");
        ccount.setFont(ccount.getFont().deriveFont(10f));
        ccount.setForeground(new Color(153,153,153));
        ccount.setHorizontalAlignment(SwingConstants.RIGHT);

        commentBox.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { updateCount(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { updateCount(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateCount(); }
        });

        mid.add(lbl,    BorderLayout.NORTH);
        mid.add(csp,    BorderLayout.CENTER);
        mid.add(ccount, BorderLayout.SOUTH);

        // bottom: peer count + send button
        JPanel bot = new JPanel(new BorderLayout(8, 0));
        bot.setBackground(BG);
        bot.setBorder(new CompoundBorder(
                new MatteBorder(1,0,0,0,BORDER),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));

        peerCount = new JLabel("�");
        peerCount.setFont(peerCount.getFont().deriveFont(Font.BOLD, 11f));
        JLabel peerLbl = new JLabel("<html>Sending to <b id='pc'>�</b> peer(s)</html>");
        peerLbl.setFont(peerLbl.getFont().deriveFont(11f));
        peerLbl.setForeground(new Color(85,85,85));

        sendBtn = new JButton("?  Send to network");
        sendBtn.setFont(sendBtn.getFont().deriveFont(Font.BOLD, 12f));
        sendBtn.setBackground(BLUE);
        sendBtn.setForeground(Color.WHITE);
        sendBtn.setBorderPainted(false);
        sendBtn.setFocusPainted(false);
        sendBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sendBtn.addActionListener(e -> doSend());

        bot.add(peerLbl,  BorderLayout.WEST);
        bot.add(sendBtn,  BorderLayout.EAST);

        panel.add(top);
        panel.add(pills);
        panel.add(mid);
        panel.add(bot);

        return panel;
    }

    private JLabel makeMetaPill(String text, boolean active) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(lbl.getFont().deriveFont(10f));
        lbl.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(active ? GREEN : BORDER),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        lbl.setForeground(active ? GREEN : new Color(85,85,85));
        lbl.setBackground(active ? new Color(240,255,240) : BG);
        lbl.setOpaque(true);
        return lbl;
    }

    // -- progress + status rows -------------------------------------------------
    private JPanel buildProgressRow() {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(BG);
        row.setAlignmentX(0f);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(false);
        progressBar.setForeground(BLUE);
        progressBar.setBackground(new Color(238,238,238));
        progressBar.setBorderPainted(false);
        progressBar.setPreferredSize(new Dimension(0, 4));
        progressBar.setVisible(false);

        row.add(progressBar, BorderLayout.CENTER);
        return row;
    }

    private JPanel buildStatusRow() {
        statusPanel = new JPanel(new BorderLayout(8, 0));
        statusPanel.setBackground(BG);
        statusPanel.setAlignmentX(0f);
        statusPanel.setVisible(false);

        statusLabel = new JLabel("");
        statusLabel.setFont(statusLabel.getFont().deriveFont(12f));

        openFileLink = new JButton("Open file");
        openFileLink.setFont(openFileLink.getFont().deriveFont(11f));
        openFileLink.setForeground(BLUE);
        openFileLink.setBackground(BG);
        openFileLink.setBorderPainted(true);
        openFileLink.setBorder(BorderFactory.createLineBorder(BLUE));
        openFileLink.setFocusPainted(false);
        openFileLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        openFileLink.setVisible(false);

        statusPanel.add(statusLabel, BorderLayout.CENTER);
        statusPanel.add(openFileLink, BorderLayout.EAST);
        return statusPanel;
    }

    // -- JSON schema preview ----------------------------------------------------
    private JPanel buildJsonPreview() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(BG);
        wrap.setBorder(BorderFactory.createLineBorder(BORDER));
        wrap.setAlignmentX(0f);

        JPanel head = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        head.setBackground(BG_LIGHT);
        head.setBorder(new MatteBorder(0,0,1,0,BORDER));
        JLabel hl = new JLabel("??  info/<hash>.json � stored structure");
        hl.setFont(hl.getFont().deriveFont(10f));
        hl.setForeground(new Color(119,119,119));
        head.add(hl);

        JTextArea schema = new JTextArea(
                "{\n" +
                "  \"original_filename\" : \"photo.jpg\",\n" +
                "  \"size\"              : 204800,\n" +
                "  \"extension\"         : \"jpg\",\n" +
                "  \"public_key\"        : \"<contents of public_key.txt or empty>\",\n" +
                "  \"node_info\"         : \"<contents of node_info.txt or empty>\",\n" +
                "  \"description\"       : \"<user comment or empty>\"\n" +
                "}"
        );
        schema.setFont(MONO);
        schema.setEditable(false);
        schema.setForeground(new Color(51,51,51));
        schema.setBackground(BG);
        schema.setBorder(BorderFactory.createEmptyBorder(10,14,10,14));

        wrap.add(head,   BorderLayout.NORTH);
        wrap.add(schema, BorderLayout.CENTER);
        return wrap;
    }

    // -- footer -----------------------------------------------------------------
    private JPanel buildFooter() {
        JPanel f = new JPanel(new BorderLayout());
        f.setBackground(BG);
        f.setBorder(new CompoundBorder(
                new MatteBorder(1,0,0,0, new Color(238,238,238)),
                BorderFactory.createEmptyBorder(10, 0, 0, 0)));

        JLabel l = new JLabel("Mesh Node � files stored as sha256.ext � info JSON has 6 fixed fields");
        l.setFont(l.getFont().deriveFont(10f));
        l.setForeground(new Color(170,170,170));

        JLabel r = new JLabel("Java " + System.getProperty("java.version"));
        r.setFont(r.getFont().deriveFont(10f));
        r.setForeground(new Color(170,170,170));

        f.add(l, BorderLayout.WEST);
        f.add(r, BorderLayout.EAST);
        return f;
    }

    // -- small helpers ----------------------------------------------------------
    private JButton makeLink(String text) {
        JButton b = new JButton(text);
        b.setFont(b.getFont().deriveFont(11f));
        b.setForeground(BLUE);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ---------------------------------------------------------------------------
    //  BEHAVIOUR
    // ---------------------------------------------------------------------------

    private void loadNodeStatus() {
        SwingWorker<int[], Void> worker = new SwingWorker<int[], Void>() {
            @Override protected int[] doInBackground() {
                int peers = loadServers().size();
                int hasPk = PUB_KEY_F.exists() && PUB_KEY_F.length() > 0 ? 1 : 0;
                int hasNi = NODE_INFO_F.exists() && NODE_INFO_F.length() > 0 ? 1 : 0;
                return new int[]{peers, hasPk, hasNi};
            }
            @Override protected void done() {
                try {
                    int[] r = get();
                    nbPeers.setText(String.valueOf(r[0]));
                    nbPeerDot.setBackground(BLUE);

                    nbPk.setText(r[1] == 1 ? "? found" : "� missing");
                    nbPkDot.setBackground(r[1] == 1 ? GREEN : new Color(170,170,170));

                    nbNi.setText(r[2] == 1 ? "? found" : "� missing");
                    nbNiDot.setBackground(r[2] == 1 ? GREEN : new Color(170,170,170));

                    peerCount.setText(String.valueOf(r[0]));
                    updateMetaPills(r[1] == 1, r[2] == 1);
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    private void updateMetaPills(boolean hasPk, boolean hasNi) {
        updatePill(mpillPk, "?? public_key", hasPk);
        updatePill(mpillNi, "? node_info",   hasNi);
    }

    private void updatePill(JLabel pill, String text, boolean active) {
        pill.setText(text);
        pill.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(active ? GREEN : BORDER),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        pill.setForeground(active ? GREEN : new Color(85,85,85));
        pill.setBackground(active ? new Color(240,255,240) : BG);
    }

    private void browseFile() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select a file");
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            handleFileSelected(fc.getSelectedFile());
        }
    }

    private void handleFileSelected(File f) {
        String ext = getExt(f.getName());
        if (isBlockedExt(ext)) {
            showStatus(false, "? PHP files are not accepted.", null);
            return;
        }
        selectedFile = f;
        fName.setText(f.getName());
        fSize.setText(formatSize(f.length()));
        panel.setVisible(true);
        commentBox.setText("");
        updateCount();
        hideStatus();
        revalidate(); repaint();
    }

    private void clearFile() {
        selectedFile = null;
        panel.setVisible(false);
        commentBox.setText("");
        hideStatus();
        revalidate(); repaint();
    }

    private void updateCount() {
        int len = commentBox.getText().getBytes(StandardCharsets.UTF_8).length;
        String txt = String.format("%,d / %,d", len, MAX_COMMENT);
        ccount.setText(txt);
        ccount.setForeground(len > MAX_COMMENT ? RED : new Color(153,153,153));
    }

    // -- send -------------------------------------------------------------------
    private void doSend() {
        if (selectedFile == null) return;
        int commentLen = commentBox.getText().getBytes(StandardCharsets.UTF_8).length;
        if (commentLen > MAX_COMMENT) {
            showStatus(false, "? Description exceeds the 1 KB limit.", null);
            return;
        }

        final File file    = selectedFile;
        final String desc  = commentBox.getText();
        final String pubKey= readOptionalFile(PUB_KEY_F);
        final String niStr = readOptionalFile(NODE_INFO_F);

        sendBtn.setEnabled(false);
        sendBtn.setText("?  Transmitting�");
        progressBar.setValue(0);
        progressBar.setVisible(true);
        hideStatus();

        SwingWorker<StoreResult, Integer> worker = new SwingWorker<StoreResult, Integer>() {
            @Override
            protected StoreResult doInBackground() throws Exception {
                publish(10);
                StoreResult local = storeLocally(file, file.getName(), desc, pubKey, niStr);
                publish(50);
                if (!local.ok) return local;

                List<String> servers = loadServers();
                publish(60);

                if (!local.existed) {
                    appendFilesAndDataJson(local.hash, file.getName());
                }

                int step = servers.isEmpty() ? 0 : 35 / servers.size();
                int prog = 60;
                for (String server : servers) {
                    pushToServer(server, new File(FILES_DIR, local.filename),
                            file.getName(), desc, pubKey, niStr);
                    prog += step;
                    publish(Math.min(prog, 95));
                }
                publish(100);
                return local;
            }

            @Override protected void process(List<Integer> chunks) {
                if (!chunks.isEmpty()) progressBar.setValue(chunks.get(chunks.size() - 1));
            }

            @Override protected void done() {
                sendBtn.setEnabled(true);
                sendBtn.setText("?  Send to network");
                javax.swing.Timer hideBar = new javax.swing.Timer(700, ev -> progressBar.setVisible(false));
                hideBar.setRepeats(false); hideBar.start();

                try {
                    StoreResult r = get();
                    if (!r.ok) {
                        showStatus(false, "? " + r.error, null);
                        return;
                    }
                    File stored = new File(FILES_DIR, r.filename);
                    showStatus(true,
                            "? File stored" + (r.existed ? " (already stored)" : ""),
                            stored);
                    clearFile();
                } catch (Exception ex) {
                    showStatus(false, "? " + ex.getMessage(), null);
                }
            }
        };
        worker.execute();
    }

    // -- status display ---------------------------------------------------------
    private void showStatus(boolean ok, String msg, File fileToOpen) {
        statusLabel.setText(msg);
        statusLabel.setForeground(ok ? GREEN : RED);
        statusPanel.setBackground(ok ? new Color(240,255,240) : new Color(255,240,240));
        statusPanel.setBorder(BorderFactory.createLineBorder(
                ok ? new Color(192,224,192) : new Color(224,192,192)));
        statusPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ok ? new Color(192,224,192) : new Color(224,192,192)),
                BorderFactory.createEmptyBorder(8,12,8,12)));
        statusPanel.setVisible(true);

        if (fileToOpen != null) {
            openFileLink.setVisible(true);
            for (ActionListener al : openFileLink.getActionListeners())
                openFileLink.removeActionListener(al);
            openFileLink.addActionListener(e -> {
                try { Desktop.getDesktop().open(fileToOpen); }
                catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                            "Cannot open: " + fileToOpen.getAbsolutePath(),
                            "Open File", JOptionPane.INFORMATION_MESSAGE);
                }
            });
        } else {
            openFileLink.setVisible(false);
        }
        revalidate(); repaint();
    }

    private void hideStatus() {
        statusPanel.setVisible(false);
        openFileLink.setVisible(false);
    }

    // -- file list dialog (Search) ----------------------------------------------
    private void showFileListDialog() {
        JDialog dlg = new JDialog(this, "Stored Files", true);
        dlg.setSize(580, 420);
        dlg.setLocationRelativeTo(this);

        JPanel content = new JPanel(new BorderLayout(0, 8));
        content.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        content.setBackground(BG);

        JTextField search = new JTextField();
        search.setFont(search.getFont().deriveFont(12f));
        search.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(5,8,5,8)));
        search.putClientProperty("JTextField.placeholderText", "Filter files�");

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setFont(MONO);
        list.setFixedCellHeight(22);
        list.setBackground(BG);
        list.setBorder(null);

        List<String> allFiles = readLines(FILES_INDEX);
        for (String line : allFiles) model.addElement(line);

        search.addActionListener(ev -> {
            String q = search.getText().toLowerCase();
            model.clear();
            for (String f : allFiles)
                if (f.toLowerCase().contains(q)) model.addElement(f);
        });
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { filterList(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { filterList(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterList(); }
            private void filterList() {
                String q = search.getText().toLowerCase();
                model.clear();
                for (String f : allFiles)
                    if (f.toLowerCase().contains(q)) model.addElement(f);
            }
        });

        list.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String sel = list.getSelectedValue();
                    if (sel != null) {
                        File f = new File(FILES_DIR, sel);
                        if (f.exists()) {
                            try { Desktop.getDesktop().open(f); }
                            catch (Exception ex) {
                                JOptionPane.showMessageDialog(dlg,
                                        f.getAbsolutePath(), "File path",
                                        JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    }
                }
            }
        });

        JScrollPane sp = new JScrollPane(list);
        sp.setBorder(BorderFactory.createLineBorder(BORDER));

        JLabel hint = new JLabel(allFiles.size() + " file(s) stored � double-click to open");
        hint.setFont(hint.getFont().deriveFont(10f));
        hint.setForeground(new Color(153,153,153));

        content.add(search, BorderLayout.NORTH);
        content.add(sp,     BorderLayout.CENTER);
        content.add(hint,   BorderLayout.SOUTH);

        dlg.setContentPane(content);
        dlg.setVisible(true);
    }

    // ---------------------------------------------------------------------------
    //  CORE LOGIC  (mirrors the PHP functions)
    // ---------------------------------------------------------------------------

    /** Mirror of PHP storeLocally() */
    private StoreResult storeLocally(File tmpFile, String originalName,
            String description, String publicKey, String nodeInfo) {
        String ext      = safeExt(originalName);
        if (isBlockedExt(ext)) return StoreResult.fail("PHP files are not accepted.");

        String hash;
        try { hash = sha256File(tmpFile); }
        catch (Exception e) { return StoreResult.fail("Cannot hash file: " + e.getMessage()); }

        String baseName = ext.isEmpty() ? hash : hash + "." + ext;
        File   destFile = new File(FILES_DIR, baseName);
        File   destInfo = new File(INFO_DIR,  hash + ".json");

        boolean existed = destFile.exists();

        if (!existed) {
            try {
                Files.copy(tmpFile.toPath(), destFile.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
                appendIndex(baseName);
            } catch (IOException e) {
                return StoreResult.fail("Could not write file to disk: " + e.getMessage());
            }
        }

        if (!destInfo.exists()) {
            String json = buildInfoJson(originalName, destFile.length(),
                    ext, publicKey, nodeInfo, description);
            try { writeFile(destInfo, json); }
            catch (IOException ignored) {}
        }

        return StoreResult.ok(hash, baseName, existed);
    }

    /** Mirror of PHP appendFilesAndDataJson() */
    private void appendFilesAndDataJson(String hash, String originalName) {
        File infoPath = new File(INFO_DIR, hash + ".json");
        if (!infoPath.exists()) return;

        String raw = readOptionalFile(infoPath);
        if (raw.isEmpty()) return;

        // parse extension from JSON minimally
        String ext      = extractJsonString(raw, "extension");
        String baseName = ext.isEmpty() ? hash : hash + "." + ext;
        appendIndex(baseName);

        File dataJson = new File(BASE_DIR, "data.json");
        appendToDataJson(dataJson, hash, raw);
    }

    private synchronized void appendToDataJson(File dataJson, String hash, String infoRaw) {
        try {
            if (!dataJson.exists()) writeFile(dataJson, "[\n]");

            String content     = new String(Files.readAllBytes(dataJson.toPath()), StandardCharsets.UTF_8).trim();
            int    closingPos  = content.lastIndexOf(']');
            String entry       = "    {\n      \"hash\": \"" + hash + "\",\n"
                    + indent(infoRaw.trim()) + "\n    }";

            String newContent;
            if (closingPos < 0) {
                newContent = "[\n" + entry + "\n]";
            } else {
                String inner = content.substring(1, closingPos).trim();
                if (inner.isEmpty()) {
                    newContent = "[\n" + entry + "\n]";
                } else {
                    newContent = content.substring(0, closingPos).replaceAll("\\s+$", "")
                            + ",\n" + entry + "\n]";
                }
            }
            writeFile(dataJson, newContent);
        } catch (IOException ignored) {}
    }

    private String indent(String json) {
        StringBuilder sb = new StringBuilder();
        for (String line : json.split("\n")) sb.append("      ").append(line).append("\n");
        if (sb.length() > 0) sb.setLength(sb.length() - 1);
        return sb.toString();
    }

    /** Mirror of PHP pushToServer() */
    private void pushToServer(String server, File filePath, String filename,
            String description, String publicKey, String nodeInfo) {
        try {
            String boundary = "----MeshBoundary" + randomHex(12);
            byte[] body = buildMultipartBody(boundary, filePath, filename,
                    description, publicKey, nodeInfo);

            String url = server.endsWith("/") ? server + "index.php" : server + "/index.php";
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(20_000);
            conn.setReadTimeout(20_000);
            conn.setRequestProperty("Content-Type",
                    "multipart/form-data; boundary=" + boundary);
            conn.setRequestProperty("Content-Length", String.valueOf(body.length));
            conn.setRequestProperty("X-Mesh-Node", "1");

            try (OutputStream out = conn.getOutputStream()) { out.write(body); }

            conn.getResponseCode(); // consume response
            conn.disconnect();
        } catch (Exception ignored) {}
    }

    private byte[] buildMultipartBody(String boundary, File filePath, String filename,
            String description, String publicKey, String nodeInfo) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // file part
        String filePart = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"" + filename + "\"\r\n"
                + "Content-Type: application/octet-stream\r\n\r\n";
        baos.write(filePart.getBytes(StandardCharsets.UTF_8));
        baos.write(Files.readAllBytes(filePath.toPath()));
        baos.write("\r\n".getBytes(StandardCharsets.UTF_8));
        // text fields
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("description", description);
        fields.put("public_key",  publicKey);
        fields.put("node_info",   nodeInfo);
        fields.put("peer_push",   "1");
        for (Map.Entry<String, String> e : fields.entrySet()) {
            String part = "--" + boundary + "\r\n"
                    + "Content-Disposition: form-data; name=\"" + e.getKey() + "\"\r\n\r\n"
                    + e.getValue() + "\r\n";
            baos.write(part.getBytes(StandardCharsets.UTF_8));
        }
        baos.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        return baos.toByteArray();
    }

    // ---------------------------------------------------------------------------
    //  FILE / STRING HELPERS
    // ---------------------------------------------------------------------------

    private List<String> loadServers() {
        List<String> out = new ArrayList<>();
        if (!SERVERS_F.exists()) return out;
        for (String line : readLines(SERVERS_F)) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (!line.matches("(?i)https?://.*")) line = "http://" + line;
            line = line.replaceAll("/+$", "");
            if (!out.contains(line)) out.add(line);
        }
        return out;
    }

    private List<String> readLines(File f) {
        if (!f.exists()) return Collections.emptyList();
        try {
            return Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
        } catch (IOException e) { return Collections.emptyList(); }
    }

    private synchronized void appendIndex(String entry) {
        List<String> existing = readLines(FILES_INDEX);
        if (existing.contains(entry)) return;
        try (FileWriter fw = new FileWriter(FILES_INDEX, true)) {
            fw.write(entry + System.lineSeparator());
        } catch (IOException ignored) {}
    }

    private String readOptionalFile(File f) {
        if (!f.exists()) return "";
        try { return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim(); }
        catch (IOException e) { return ""; }
    }

    private void writeFile(File f, String content) throws IOException {
        Files.write(f.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    private String sha256File(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream is = new BufferedInputStream(new FileInputStream(f))) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = is.read(buf)) != -1) md.update(buf, 0, n);
        }
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder(64);
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private String safeExt(String filename) {
        int dot = filename.lastIndexOf('.');
        if (dot < 0) return "";
        String ext = filename.substring(dot + 1).toLowerCase();
        return ext.replaceAll("[^a-z0-9]", "");
    }

    private boolean isBlockedExt(String ext) {
        for (String b : BLOCKED_EXT)
            if (b.equalsIgnoreCase(ext)) return true;
        return false;
    }

    private String getExt(String filename) {
        int dot = filename.lastIndexOf('.');
        if (dot < 0) return "";
        return filename.substring(dot + 1).toLowerCase();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024)    return bytes + " B";
        if (bytes < 1048576) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.2f MB", bytes / 1048576.0);
    }

    private String buildInfoJson(String originalName, long size, String ext,
            String publicKey, String nodeInfo, String description) {
        return "{\n"
                + "  \"original_filename\": " + jsonStr(originalName) + ",\n"
                + "  \"size\": " + size + ",\n"
                + "  \"extension\": " + jsonStr(ext) + ",\n"
                + "  \"public_key\": " + jsonStr(publicKey) + ",\n"
                + "  \"node_info\": " + jsonStr(nodeInfo) + ",\n"
                + "  \"description\": " + jsonStr(description) + "\n"
                + "}";
    }

    private String jsonStr(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }

    /** Minimal JSON string extractor � no external library needed */
    private String extractJsonString(String json, String key) {
        String search = "\"" + key + "\"";
        int ki = json.indexOf(search);
        if (ki < 0) return "";
        int colon = json.indexOf(':', ki + search.length());
        if (colon < 0) return "";
        int q1 = json.indexOf('"', colon + 1);
        if (q1 < 0) return "";
        int q2 = json.indexOf('"', q1 + 1);
        if (q2 < 0) return "";
        return json.substring(q1 + 1, q2);
    }

    private String randomHex(int bytes) {
        byte[] b = new byte[bytes];
        new java.security.SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte bb : b) sb.append(String.format("%02x", bb));
        return sb.toString();
    }

    // -- result value object ----------------------------------------------------
    private static class StoreResult {
        boolean ok; String hash, filename, error; boolean existed;

        static StoreResult ok(String hash, String filename, boolean existed) {
            StoreResult r = new StoreResult();
            r.ok = true; r.hash = hash; r.filename = filename; r.existed = existed;
            return r;
        }
        static StoreResult fail(String error) {
            StoreResult r = new StoreResult();
            r.ok = false; r.error = error;
            return r;
        }
    }

    // ---------------------------------------------------------------------------
    //  ENTRY POINT
    // ---------------------------------------------------------------------------

    public static void main(String[] args) {
        // Use system look and feel for a native appearance
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}

        SwingUtilities.invokeLater(MeshNode::new);
    }
}