import java.io.*;
import java.net.*;
import java.net.URI;
import java.net.URI;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

/**
 * Seal Meento - Distributed file tracker and downloader.
 * Reads servers.txt, discovers files, ranks them by server distribution,
 * optionally downloads them, and stores block metadata in http_blocks/.
 *
 * No external libraries. Pure Java standard library only.
 */
public class SealMeento {

    // -- constants ------------------------------------------------------------
    static final int    MAX_LINE_LEN    = 2000;
    static final int    CONNECT_TIMEOUT = 8_000;   // ms
    static final int    READ_TIMEOUT    = 30_000;  // ms
    static final String DOWNLOAD_FOLDER = "download";
    static final String BLOCK_FOLDER    = "get_block";
    static final String LOCAL_BLOCKS    = "http_blocks";
    static final String RANK_FILE       = "http_blocks/rank.json";

    // -- user choices (filled interactively) ---------------------------------
    static boolean doDownload      = false;
    static boolean useHashFilename = false;
    static boolean overwriteFiles  = false;

    // -- data structures ------------------------------------------------------

    /** Canonical info about one discovered file. */
    static class FileRecord {
        String filename;          // e.g. cat.jpg
        String sha256;            // known hash (from get_block) or null
        long   size;              // bytes, -1 if unknown
        /** Set of server base-URLs that have this file (one entry per unique IP). */
        Set<String> serversSeen = new LinkedHashSet<>();
        /** Full download URL per server: serverBase -> url */
        Map<String, String> downloadUrls = new LinkedHashMap<>();
        int rank;                 // filled later

        FileRecord(String filename) {
            this.filename = filename;
            this.size = -1;
        }
    }

    // serverBase -> list of raw lines/urls returned by that server
    static Map<String, List<String>> serverLines  = new LinkedHashMap<>();
    // filename (lower-cased for dedup) -> FileRecord
    static Map<String, FileRecord>   fileRegistry = new LinkedHashMap<>();
    // serverBase -> resolved IP (to detect same-IP duplicates)
    static Map<String, String>       serverIPs    = new LinkedHashMap<>();

    // -- entry point ----------------------------------------------------------
    public static void main(String[] args) throws Exception {
        printBanner();
        Scanner sc = new Scanner(System.in);

        // -- 1. Load servers --------------------------------------------------
        List<String> servers = loadServers("servers.txt");
        if (servers.isEmpty()) {
            System.out.println("[ERROR] No valid servers found in servers.txt. Exiting.");
            return;
        }
        System.out.println("[INFO] Loaded " + servers.size() + " server(s).");

        // -- 2. Ask user preferences ------------------------------------------
        doDownload      = askYesNo(sc, "Download files to disk?");
        if (doDownload) {
            useHashFilename = askYesNo(sc, "Store files using SHA-256 hash + extension (instead of original filename)?");
            overwriteFiles  = askYesNo(sc, "Overwrite files that already exist?");
        }

        // -- 3. Resolve server IPs --------------------------------------------
        System.out.println("\n[INFO] Resolving server IPs...");
        for (String srv : servers) {
            String ip = resolveIP(srv);
            serverIPs.put(srv, ip);
            System.out.printf("  %-50s  ->  %s%n", srv, ip == null ? "unresolvable" : ip);
        }

        // -- 4. Fetch file lists from every server ----------------------------
        System.out.println("\n[INFO] Fetching file lists...");
        for (String srv : servers) {
            List<String> lines = fetchFileList(srv);
            serverLines.put(srv, lines);
            System.out.printf("  %-50s  %d line(s)%n", srv, lines.size());
        }

        // -- 5. Parse lines -> FileRecord entries -----------------------------
        System.out.println("\n[INFO] Parsing file entries...");
        for (Map.Entry<String, List<String>> e : serverLines.entrySet()) {
            String       srv   = e.getKey();
            List<String> lines = e.getValue();
            for (String rawLine : lines) {
                processLine(srv, rawLine);
            }
        }
        System.out.println("[INFO] Unique files discovered: " + fileRegistry.size());

        // -- 6. Fetch block metadata (get_block/<sha256>) ---------------------
        System.out.println("\n[INFO] Fetching block metadata from servers...");
        fetchAllBlockMetadata(servers);

        // -- 7. Compute ranks (exclude same-IP duplicates) --------------------
        computeRanks();

        // -- 8. Save rank file -------------------------------------------------
        Files.createDirectories(Paths.get(LOCAL_BLOCKS));
        saveRankJson();
        System.out.println("[INFO] Rank saved -> " + RANK_FILE);

        // -- 9. Save individual block JSON files ------------------------------
        saveBlockJsonFiles();

        // -- 10. Broadcast file info to all servers (GET only) -----------------
        System.out.println("\n[INFO] Broadcasting file info to all servers...");
        broadcastFileInfo(servers);

        // -- 11. Download files (optional) ------------------------------------
        if (doDownload) {
            System.out.println("\n[INFO] Downloading files...");
            downloadFiles();
        }

        System.out.println("\n[DONE] Seal Meento finished.");
    }

    // ------------------------------------------------------------------------
    //  STEP helpers
    // ------------------------------------------------------------------------

    /** Load and validate servers.txt */
    static List<String> loadServers(String path) throws IOException {
        List<String> result = new ArrayList<>();
        File f = new File(path);
        if (!f.exists()) {
            System.out.println("[WARN] servers.txt not found. Creating empty template.");
            new FileWriter(f).close();
            return result;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (!line.startsWith("http://") && !line.startsWith("https://")) {
                    System.out.println("[SKIP] Not http/https: " + line);
                    continue;
                }
                // Normalise: strip trailing slash
                while (line.endsWith("/")) line = line.substring(0, line.length() - 1);
                result.add(line);
            }
        }
        return result;
    }

    /** Fetch the plain-text file list from a server root URL */
    static List<String> fetchFileList(String serverBase) {
        List<String> lines = new ArrayList<>();
        try {
            URL url = toURL(serverBase);
            HttpURLConnection con = openConnection(url);
            int code = con.getResponseCode();
            if (code != 200) return lines;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    if (line.length() > MAX_LINE_LEN) {
                        System.out.printf("  [SKIP] Line too long (%d chars) from %s%n", line.length(), serverBase);
                        continue;
                    }
                    lines.add(line);
                }
            }
        } catch (Exception ex) {
            System.out.println("  [WARN] Cannot fetch list from " + serverBase + ": " + ex.getMessage());
        }
        return lines;
    }

    /**
     * Given a raw line from a server's file list, determine the canonical
     * filename and the full download URL, then register in fileRegistry.
     */
    static void processLine(String serverBase, String rawLine) {
        String downloadUrl;
        String filename;

        if (rawLine.startsWith("http://") || rawLine.startsWith("https://")) {
            // Absolute URL
            downloadUrl = rawLine;
            filename    = extractFilename(rawLine);
        } else if (rawLine.contains("/")) {
            // Relative path, e.g. "download/cat.jpg"
            downloadUrl = serverBase + "/" + rawLine;
            filename    = extractFilename(rawLine);
        } else {
            // Plain filename, e.g. "cat.jpg"
            downloadUrl = serverBase + "/" + DOWNLOAD_FOLDER + "/" + rawLine;
            filename    = rawLine;
        }

        if (filename == null || filename.isEmpty()) return;

        String key = filename.toLowerCase(Locale.ROOT);
        FileRecord rec = fileRegistry.computeIfAbsent(key, k -> new FileRecord(filename));

        // Only count unique IPs
        String ip = serverIPs.getOrDefault(serverBase, serverBase);
        boolean newIP = true;
        for (String seen : rec.serversSeen) {
            if (Objects.equals(serverIPs.get(seen), ip)) { newIP = false; break; }
        }
        rec.serversSeen.add(serverBase);
        rec.downloadUrls.put(serverBase, downloadUrl);
    }

    /** Extract filename from a URL or path string */
    static String extractFilename(String s) {
        int q = s.indexOf('?');
        if (q >= 0) s = s.substring(0, q);
        int slash = s.lastIndexOf('/');
        if (slash >= 0) s = s.substring(slash + 1);
        return s.isEmpty() ? null : s;
    }

    /** Fetch block metadata (JSON) for each known file from each server */
    static void fetchAllBlockMetadata(List<String> servers) {
        for (FileRecord rec : fileRegistry.values()) {
            // Try get_block/<sha256> if we have a hash, else skip block fetch
            if (rec.sha256 == null) continue;
            for (String srv : servers) {
                String blockUrl = srv + "/" + BLOCK_FOLDER + "/" + rec.sha256;
                try {
                    String json = fetchText(blockUrl);
                    if (json != null && !json.isEmpty()) {
                        mergeBlockJson(rec, json);
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    /** Very minimal JSON key-value extractor (no external libs). */
    static String jsonGet(String json, String key) {
        String search = "\"" + key + "\"";
        int idx = json.indexOf(search);
        if (idx < 0) return null;
        idx += search.length();
        // skip whitespace and colon
        while (idx < json.length() && (json.charAt(idx) == ' ' || json.charAt(idx) == ':')) idx++;
        if (idx >= json.length()) return null;
        char first = json.charAt(idx);
        if (first == '"') {
            idx++;
            StringBuilder sb = new StringBuilder();
            while (idx < json.length() && json.charAt(idx) != '"') sb.append(json.charAt(idx++));
            return sb.toString();
        } else {
            StringBuilder sb = new StringBuilder();
            while (idx < json.length() && ",}\n".indexOf(json.charAt(idx)) < 0) sb.append(json.charAt(idx++));
            return sb.toString().trim();
        }
    }

    static void mergeBlockJson(FileRecord rec, String json) {
        String hash = jsonGet(json, "sha256");
        if (hash != null && !hash.isEmpty()) rec.sha256 = hash;
        String sizeStr = jsonGet(json, "size");
        if (sizeStr != null) {
            try { rec.size = Long.parseLong(sizeStr); } catch (NumberFormatException ignored) {}
        }
    }

    /** Compute rank for each file = number of unique IPs that have it */
    static void computeRanks() {
        List<FileRecord> list = new ArrayList<>(fileRegistry.values());
        for (FileRecord rec : list) {
            Set<String> uniqueIPs = new HashSet<>();
            for (String srv : rec.serversSeen) {
                String ip = serverIPs.getOrDefault(srv, srv);
                if (ip != null) uniqueIPs.add(ip);
            }
            rec.rank = uniqueIPs.size();
        }
        list.sort((a, b) -> Integer.compare(b.rank, a.rank));
    }

    /** Save http_blocks/rank.json */
    static void saveRankJson() throws IOException {
        List<FileRecord> sorted = fileRegistry.values().stream()
            .sorted((a, b) -> Integer.compare(b.rank, a.rank))
            .collect(Collectors.toList());

        StringBuilder sb = new StringBuilder();
        sb.append("[\n");
        for (int i = 0; i < sorted.size(); i++) {
            FileRecord r = sorted.get(i);
            sb.append("  {\n");
            sb.append("    \"filename\": ").append(jsonString(r.filename)).append(",\n");
            sb.append("    \"sha256\": ").append(jsonString(r.sha256 != null ? r.sha256 : "")).append(",\n");
            sb.append("    \"size\": ").append(r.size).append(",\n");
            sb.append("    \"rank\": ").append(r.rank).append(",\n");
            sb.append("    \"servers\": [\n");
            List<String> srvList = new ArrayList<>(r.serversSeen);
            for (int j = 0; j < srvList.size(); j++) {
                sb.append("      ").append(jsonString(srvList.get(j)));
                if (j < srvList.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("    ]\n");
            sb.append("  }");
            if (i < sorted.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("]\n");

        writeFile(RANK_FILE, sb.toString());
    }

    /** Save individual http_blocks/<filename>.json for each file */
    static void saveBlockJsonFiles() throws IOException {
        for (FileRecord rec : fileRegistry.values()) {
            String safeName = rec.filename.replaceAll("[^a-zA-Z0-9._-]", "_");
            String blockPath = LOCAL_BLOCKS + "/" + safeName + ".json";

            StringBuilder sb = new StringBuilder();
            sb.append("{\n");
            sb.append("  \"filename\": ").append(jsonString(rec.filename)).append(",\n");
            sb.append("  \"sha256\": ").append(jsonString(rec.sha256 != null ? rec.sha256 : "")).append(",\n");
            sb.append("  \"size\": ").append(rec.size).append(",\n");
            sb.append("  \"rank\": ").append(rec.rank).append(",\n");
            sb.append("  \"download_urls\": {\n");
            List<Map.Entry<String, String>> urls = new ArrayList<>(rec.downloadUrls.entrySet());
            for (int i = 0; i < urls.size(); i++) {
                sb.append("    ").append(jsonString(urls.get(i).getKey()))
                  .append(": ").append(jsonString(urls.get(i).getValue()));
                if (i < urls.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  },\n");
            sb.append("  \"servers\": [\n");
            List<String> srvList = new ArrayList<>(rec.serversSeen);
            for (int i = 0; i < srvList.size(); i++) {
                sb.append("    ").append(jsonString(srvList.get(i)));
                if (i < srvList.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  ]\n");
            sb.append("}\n");

            writeFile(blockPath, sb.toString());
        }
        System.out.println("[INFO] Block JSON files saved in " + LOCAL_BLOCKS + "/");
    }

    /**
     * Broadcast file info to each server as a GET request.
     * We only SEND; we never start a server to receive.
     * Endpoint convention: serverBase/?action=block_info&filename=<f>&sha256=<h>&rank=<r>
     */
    static void broadcastFileInfo(List<String> servers) {
        for (FileRecord rec : fileRegistry.values()) {
            for (String srv : servers) {
                try {
                    String query = "action=block_info"
                        + "&filename=" + urlEncode(rec.filename)
                        + "&sha256="   + urlEncode(rec.sha256 != null ? rec.sha256 : "")
                        + "&size="     + rec.size
                        + "&rank="     + rec.rank;
                    String target = srv + "/?" + query;
                    // Fire-and-forget GET; we don't care about the response body
                    fetchText(target);
                } catch (Exception ignored) {}
            }
        }
        System.out.println("[INFO] Broadcast complete.");
    }

    /** Download all files (highest-rank first) */
    static void downloadFiles() throws Exception {
        Files.createDirectories(Paths.get(DOWNLOAD_FOLDER));
        List<FileRecord> sorted = fileRegistry.values().stream()
            .sorted((a, b) -> Integer.compare(b.rank, a.rank))
            .collect(Collectors.toList());

        int ok = 0, skipped = 0, failed = 0;
        for (FileRecord rec : sorted) {
            String destName = resolveDestName(rec);
            Path destPath   = Paths.get(DOWNLOAD_FOLDER, destName);

            if (Files.exists(destPath) && !overwriteFiles) {
                System.out.println("  [SKIP] Exists: " + destPath);
                skipped++;
                continue;
            }

            // Try servers in rank order (already stored insertion-order; best-effort)
            boolean downloaded = false;
            for (String url : rec.downloadUrls.values()) {
                try {
                    byte[] data = fetchBytes(url);
                    if (data == null || data.length == 0) continue;

                    // If we don't yet have a sha256, compute it
                    if (rec.sha256 == null) {
                        rec.sha256 = sha256Hex(data);
                        // Re-save its block file with the now-known hash
                        saveBlockJsonFiles(); // re-save all (simple approach)
                    }

                    // Re-resolve dest name if we just learned the hash
                    destName = resolveDestName(rec);
                    destPath = Paths.get(DOWNLOAD_FOLDER, destName);

                    if (Files.exists(destPath) && !overwriteFiles) {
                        System.out.println("  [SKIP] Exists (hash name): " + destPath);
                        skipped++;
                        downloaded = true;
                        break;
                    }

                    Files.write(destPath, data);
                    System.out.println("  [OK]   " + destPath + "  (" + data.length + " bytes)");
                    ok++;
                    downloaded = true;
                    break;
                } catch (Exception ex) {
                    System.out.println("  [WARN] Failed " + url + ": " + ex.getMessage());
                }
            }
            if (!downloaded) {
                System.out.println("  [FAIL] " + rec.filename);
                failed++;
            }
        }
        System.out.printf("%n[INFO] Download summary: %d OK, %d skipped, %d failed%n", ok, skipped, failed);
    }

    /** Decide the destination filename based on user preference */
    static String resolveDestName(FileRecord rec) {
        if (useHashFilename && rec.sha256 != null) {
            String ext = "";
            int dot = rec.filename.lastIndexOf('.');
            if (dot >= 0) ext = rec.filename.substring(dot);   // includes the dot
            return rec.sha256 + ext;
        }
        return rec.filename;
    }

    // ------------------------------------------------------------------------
    //  Network helpers
    // ------------------------------------------------------------------------

    /** Convert String to URL using URI to avoid deprecated URL(String) constructor. */
    static URL toURL(String s) throws IOException {
        try { return URI.create(s).toURL(); }
        catch (IllegalArgumentException e) { throw new IOException("Bad URL: " + s, e); }
    }

    static HttpURLConnection openConnection(URL url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setConnectTimeout(CONNECT_TIMEOUT);
        con.setReadTimeout(READ_TIMEOUT);
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "SealMeento/1.0");
        return con;
    }

    static String fetchText(String urlStr) {
        try {
            URL url = toURL(urlStr);
            HttpURLConnection con = openConnection(url);
            int code = con.getResponseCode();
            if (code != 200) return null;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
                return sb.toString();
            }
        } catch (Exception e) {
            return null;
        }
    }

    static byte[] fetchBytes(String urlStr) throws IOException {
        URL url = toURL(urlStr);
        HttpURLConnection con = openConnection(url);
        int code = con.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        try (InputStream is = con.getInputStream();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) >= 0) baos.write(buf, 0, n);
            return baos.toByteArray();
        }
    }

    static String resolveIP(String serverBase) {
        try {
            URL url = toURL(serverBase);
            String ip = InetAddress.getByName(url.getHost()).getHostAddress();
            return ip;
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------------
    //  Crypto / encoding helpers
    // ------------------------------------------------------------------------

    static String sha256Hex(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(data);
        StringBuilder sb = new StringBuilder(64);
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    static String urlEncode(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (UnsupportedEncodingException e) { return s; }
    }

    // ------------------------------------------------------------------------
    //  File / JSON helpers
    // ------------------------------------------------------------------------

    static void writeFile(String path, String content) throws IOException {
        Path p = Paths.get(path);
        Files.createDirectories(p.getParent());
        try (Writer w = new FileWriter(p.toFile())) {
            w.write(content);
        }
    }

    /** Produce a JSON-safe quoted string. */
    static String jsonString(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\")
                       .replace("\"", "\\\"")
                       .replace("\n", "\\n")
                       .replace("\r", "\\r")
                       .replace("\t", "\\t") + "\"";
    }

    // ------------------------------------------------------------------------
    //  UI helpers
    // ------------------------------------------------------------------------

    static boolean askYesNo(Scanner sc, String question) {
        while (true) {
            System.out.print("[?] " + question + " (y/n): ");
            String ans = sc.nextLine().trim().toLowerCase(Locale.ROOT);
            if (ans.equals("y") || ans.equals("yes")) return true;
            if (ans.equals("n") || ans.equals("no"))  return false;
            System.out.println("    Please enter y or n.");
        }
    }

    static void printBanner() {
        System.out.println("+----------------------------------------------+");
        System.out.println("�          S E A L   M E E N T O  v1.0        �");
        System.out.println("�   Distributed File Tracker & Downloader      �");
        System.out.println("+----------------------------------------------+");
        System.out.println();
    }
}