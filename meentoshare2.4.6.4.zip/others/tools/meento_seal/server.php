﻿<?php
/**
 * Seal Meento — Server Node
 *
 * Endpoints
 * ─────────
 *  GET /                              → plain-text list of filenames in downloads/
 *  GET /?list=links                   → plain-text list of full URLs to every file
 *  GET /?action=block_info&…          → receive broadcast from a Seal Meento client
 *  GET /download/<filename>           → serve a file from downloads/
 *  GET /get_block/<hash>              → serve a block JSON from blocks/
 *
 * Config (edit the section below)
 * ────────────────────────────────
 *  CHECK_REMOTE_BEFORE_WRITE          → when true, verify the file exists on every
 *                                       broadcasting server before saving block data.
 *                                       Default: false (trust what clients send).
 */

// ═══════════════════════════════════════════════════════════════════
//  CONFIGURATION
// ═══════════════════════════════════════════════════════════════════

define('DOWNLOADS_DIR',            __DIR__ . '/downloads');
define('BLOCKS_DIR',               __DIR__ . '/blocks');
define('BLOCK_LOG',                __DIR__ . '/blocks/block_log.json');
define('CHECK_REMOTE_BEFORE_WRITE', false);   // set true to enable remote verification
define('CONNECT_TIMEOUT',           8);        // seconds
define('MAX_LINE_LEN',              2000);

// ═══════════════════════════════════════════════════════════════════
//  BOOTSTRAP
// ═══════════════════════════════════════════════════════════════════

@mkdir(DOWNLOADS_DIR, 0755, true);
@mkdir(BLOCKS_DIR,    0755, true);

// ═══════════════════════════════════════════════════════════════════
//  ROUTER
// ═══════════════════════════════════════════════════════════════════

$requestUri  = $_SERVER['REQUEST_URI'] ?? '/';
$scriptName  = $_SERVER['SCRIPT_NAME'] ?? '';
// Strip script name so the router works whether accessed as index.php or via rewrite
$path = parse_url($requestUri, PHP_URL_PATH);
if ($scriptName !== '' && strpos($path, $scriptName) === 0) {
    $path = substr($path, strlen($scriptName));
}
$path = '/' . ltrim($path, '/');

// ── /download/<filename> ─────────────────────────────────────────
if (preg_match('#^/download/(.+)$#', $path, $m)) {
    serveDownload($m[1]);
    exit;
}

// ── /get_block/<hash> ────────────────────────────────────────────
if (preg_match('#^/get_block/([a-fA-F0-9]{64})$#', $path, $m)) {
    serveBlock($m[1]);
    exit;
}

// ── / (root) ─────────────────────────────────────────────────────
if ($path === '/' || $path === '') {

    // Broadcast receiver
    if (isset($_GET['action']) && $_GET['action'] === 'block_info') {
        handleBlockInfo();
        exit;
    }

    // Link listing
    if (isset($_GET['list']) && $_GET['list'] === 'links') {
        listLinks();
        exit;
    }

    // Default: plain-text filename listing (consumed by other Seal Meento clients)
    listFiles();
    exit;
}

// ── 404 ──────────────────────────────────────────────────────────
http_response_code(404);
header('Content-Type: text/plain');
echo "404 Not Found\n";
exit;


// ═══════════════════════════════════════════════════════════════════
//  ENDPOINT HANDLERS
// ═══════════════════════════════════════════════════════════════════

/**
 * GET /
 * Returns a plain-text list of filenames available in downloads/.
 * One filename per line — consumed by Seal Meento Java clients.
 */
function listFiles(): void
{
    header('Content-Type: text/plain; charset=utf-8');
    $files = scanDownloads();
    echo implode("\n", $files);
    if ($files) echo "\n";
}

/**
 * GET /?list=links
 * Returns a plain-text list of full download URLs, one per line.
 * Useful for browsers or human inspection.
 */
function listLinks(): void
{
    header('Content-Type: text/plain; charset=utf-8');
    $base  = baseUrl();
    $files = scanDownloads();
    foreach ($files as $f) {
        echo $base . '/download/' . rawurlencode($f) . "\n";
    }
}

/**
 * GET /?action=block_info&filename=…&sha256=…&size=…&rank=…
 * Receive broadcast from a Seal Meento client.
 * Validates, optionally verifies remote, then persists the block.
 */
function handleBlockInfo(): void
{
    header('Content-Type: text/plain; charset=utf-8');

    $filename = sanitiseFilename($_GET['filename'] ?? '');
    $sha256   = preg_match('/^[a-f0-9]{64}$/i', $_GET['sha256'] ?? '')
                ? strtolower($_GET['sha256'])
                : '';
    $size     = isset($_GET['size']) ? (int)$_GET['size'] : -1;
    $rank     = isset($_GET['rank']) ? (int)$_GET['rank'] : 0;

    if ($filename === '') {
        http_response_code(400);
        echo "ERROR: missing or invalid filename\n";
        return;
    }

    // ── Optional remote verification ─────────────────────────────────
    if (CHECK_REMOTE_BEFORE_WRITE) {
        $servers = knownServers();
        if (!remoteFileExists($filename, $sha256, $servers)) {
            http_response_code(404);
            echo "SKIP: file not confirmed on any known remote server\n";
            return;
        }
    }

    // ── Persist block ─────────────────────────────────────────────────
    $block = [
        'filename'   => $filename,
        'sha256'     => $sha256,
        'size'       => $size,
        'rank'       => $rank,
        'seen_at'    => date('c'),
        'sender_ip'  => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    ];

    saveBlock($sha256 !== '' ? $sha256 : $filename, $block);
    appendBlockLog($block);

    echo "OK\n";
}

/**
 * GET /download/<filename>
 * Stream a file from downloads/ to the client.
 */
function serveDownload(string $rawName): void
{
    $name = sanitiseFilename(rawurldecode($rawName));
    if ($name === '') { send404(); return; }

    $path = DOWNLOADS_DIR . '/' . $name;
    if (!is_file($path)) { send404(); return; }

    $mime = mime_content_type($path) ?: 'application/octet-stream';
    header('Content-Type: '    . $mime);
    header('Content-Length: '  . filesize($path));
    header('Content-Disposition: attachment; filename="' . addslashes($name) . '"');
    header('Cache-Control: public, max-age=31536000');
    readfile($path);
}

/**
 * GET /get_block/<sha256>
 * Return the JSON block for a given hash.
 */
function serveBlock(string $hash): void
{
    $hash = strtolower($hash);
    $path = BLOCKS_DIR . '/' . $hash . '.json';
    if (!is_file($path)) { send404(); return; }

    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: public, max-age=86400');
    readfile($path);
}


// ═══════════════════════════════════════════════════════════════════
//  BLOCK STORAGE
// ═══════════════════════════════════════════════════════════════════

/**
 * Save or merge a block JSON file.
 * Key is either the sha256 hash or (fallback) a safe version of the filename.
 */
function saveBlock(string $key, array $incoming): void
{
    $safeKey = preg_replace('/[^a-zA-Z0-9._-]/', '_', $key);
    $path    = BLOCKS_DIR . '/' . $safeKey . '.json';

    $existing = [];
    if (is_file($path)) {
        $existing = json_decode(file_get_contents($path), true) ?? [];
    }

    // Merge: keep highest rank, update seen_at, accumulate sender IPs
    $senders = $existing['senders'] ?? [];
    $ip      = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!in_array($ip, $senders, true)) {
        $senders[] = $ip;
    }

    $block = [
        'filename'  => $incoming['filename'],
        'sha256'    => $incoming['sha256'],
        'size'      => $incoming['size'] >= 0 ? $incoming['size'] : ($existing['size'] ?? -1),
        'rank'      => max((int)($existing['rank'] ?? 0), (int)$incoming['rank']),
        'first_seen'=> $existing['first_seen'] ?? $incoming['seen_at'],
        'last_seen' => $incoming['seen_at'],
        'senders'   => $senders,
    ];

    file_put_contents($path, json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);
}

/**
 * Append a line to blocks/block_log.json (newline-delimited JSON).
 */
function appendBlockLog(array $block): void
{
    $line = json_encode($block, JSON_UNESCAPED_SLASHES) . "\n";
    file_put_contents(BLOCK_LOG, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Return all known sender IPs collected from saved block files.
 * Used by CHECK_REMOTE_BEFORE_WRITE to know which servers to query.
 */
function knownServers(): array
{
    $servers = [];
    foreach (glob(BLOCKS_DIR . '/*.json') as $file) {
        if ($file === BLOCK_LOG) continue;
        $data = json_decode(file_get_contents($file), true) ?? [];
        foreach (($data['senders'] ?? []) as $ip) {
            if (!in_array($ip, $servers, true) && filter_var($ip, FILTER_VALIDATE_IP)) {
                $servers[] = $ip;
            }
        }
    }
    return $servers;
}

/**
 * When CHECK_REMOTE_BEFORE_WRITE is enabled:
 * Try to confirm the file exists on at least one known server before saving.
 * Checks /download/<filename> and (if hash known) /get_block/<sha256>.
 */
function remoteFileExists(string $filename, string $sha256, array $servers): bool
{
    if (empty($servers)) return false;          // no known servers yet → allow

    foreach ($servers as $ip) {
        // Build candidate URLs (try both http and https)
        $candidates = [
            'http://'  . $ip . '/download/' . rawurlencode($filename),
            'https://' . $ip . '/download/' . rawurlencode($filename),
        ];
        if ($sha256 !== '') {
            $candidates[] = 'http://'  . $ip . '/get_block/' . $sha256;
            $candidates[] = 'https://' . $ip . '/get_block/' . $sha256;
        }

        foreach ($candidates as $url) {
            if (httpHead($url) === 200) return true;
        }
    }
    return false;
}

/**
 * Perform an HTTP HEAD request; return the status code or 0 on failure.
 */
function httpHead(string $url): int
{
    $ctx = stream_context_create([
        'http' => [
            'method'          => 'HEAD',
            'timeout'         => CONNECT_TIMEOUT,
            'ignore_errors'   => true,
            'follow_location' => 1,
        ],
        'ssl' => [
            'verify_peer'      => false,
            'verify_peer_name' => false,
        ],
    ]);

    $headers = @get_headers($url, false, $ctx);
    if (!$headers) return 0;

    // First header line is "HTTP/x.x <code> <text>"
    if (preg_match('/HTTP\/\S+\s+(\d{3})/', $headers[0], $m)) {
        return (int)$m[1];
    }
    return 0;
}


// ═══════════════════════════════════════════════════════════════════
//  UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════

/** Return sorted list of filenames inside downloads/. */
function scanDownloads(): array
{
    $files = [];
    if (!is_dir(DOWNLOADS_DIR)) return $files;

    $items = scandir(DOWNLOADS_DIR);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $fullPath = DOWNLOADS_DIR . '/' . $item;
        if (!is_file($fullPath)) continue;
        // Skip hidden files
        if ($item[0] === '.') continue;
        $files[] = $item;
    }
    sort($files);
    return $files;
}

/**
 * Strip directory traversal and control characters from a filename.
 * Returns an empty string if the result is unsafe.
 */
function sanitiseFilename(string $name): string
{
    // Remove any directory component
    $name = basename($name);
    // Remove null bytes and control characters
    $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
    // Reject names that are still suspiciously empty or just dots
    if ($name === '' || $name === '.' || $name === '..') return '';
    // Enforce max length
    if (strlen($name) > MAX_LINE_LEN) return '';
    return $name;
}

/** Build the base URL of this server (scheme + host + optional port). */
function baseUrl(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    return $scheme . '://' . $host;
}

function send404(): void
{
    http_response_code(404);
    header('Content-Type: text/plain');
    echo "404 Not Found\n";
}