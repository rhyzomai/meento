﻿require_once __DIR__ . '/blockchain.php'; // <-- ADD THIS LINE

// 1. Store locally
    $local = storeLocally($upload['tmp_name'], $upload['name'], $description, $publicKey, $nodeInfo);

    if (!$local['ok']) jsonOut($local, 500);

    // --- ADD THIS BLOCKCHAIN HOOK ---
    // Only record a new block if the file is genuinely new to the network
    if (!$local['existed'] && function_exists('recordToBlockchain')) {
        recordToBlockchain(
            $local['filename'], 
            $upload['size'], 
            $publicKey, 
            'broadcast' // Receiver PK placeholder for a broadcast network
        );
    }
    // --------------------------------

    // If file already existed, return success with the link...