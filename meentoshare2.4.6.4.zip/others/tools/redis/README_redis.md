# Meento Share — Redis Module

A drop-in Redis sidecar for `index_full.php`. **Zero changes to your existing code.**

---

## Files

| File | Purpose |
|---|---|
| `redis_module.php` | Main module — include at the top of `index_full.php` |
| `redis_module_core.php` | `MeentoRedis` class only — used by CLI tools |
| `redis_worker.php` | Background re-verification worker |
| `redis_listener.php` | Real-time event log subscriber |

---

## Installation

### 1. Install Redis

```bash
# Debian/Ubuntu
apt install redis-server php-redis

# macOS
brew install redis
pecl install redis

# Start
redis-server --daemonize yes
```

### 2. Add one line to `index_full.php`

Open `index_full.php` and add **one line** immediately after `<?php`:

```php
<?php
require_once __DIR__ . '/redis_module.php';   // ← add this line
// ═══════════════════════════════════════════
//  MESH NODE — authenticated file replication
```

That is the only change. Everything else is automatic.

### 3. Optional configuration

Define constants **before** the `require_once` line to override defaults:

```php
<?php
define('REDIS_HOST',             '127.0.0.1');
define('REDIS_PORT',             6379);
define('REDIS_PASSWORD',         '');          // leave empty for no auth
define('REDIS_DB',               0);
define('REDIS_PREFIX',           'meento:');
define('REDIS_ACCOUNT_TTL',      300);         // account cache TTL (seconds)
define('REDIS_SESSION_TTL',      86400);       // session token TTL (24 h)
define('REDIS_LOCK_TTL',         5);           // distributed lock TTL
define('REDIS_RATE_WINDOW',      300);         // rate limit window (5 min)
define('REDIS_RATE_LIMIT',       10);          // max login attempts per window
define('REDIS_REVERIF_INTERVAL', 604800);      // re-verify every 7 days
define('REDIS_ENABLED',          true);        // set false to disable entirely

require_once __DIR__ . '/redis_module.php';
```

---

## What the module adds

### Account cache
Every `loadByKey()` call checks Redis before reading from disk. Writes update both the file and the cache atomically. TTL is 5 minutes by default — stale data is never served for longer than that even if Redis goes down.

### Distributed locks
All account writes (file records, server reports) are wrapped in a Redis `SET NX EX` lock. Concurrent upload requests for the same user no longer race each other.

### Session tokens
After login, the response now includes a `session_token` field alongside the legacy `session_nonce`. Pass the token instead of the nonce in upload requests:

```
POST index_full.php (multipart)
  session_token = <token from login response>
  public_key    = <your public key>
  file          = <binary>
```

The legacy nonce still works — old clients are not broken.

**Logout** is now a proper operation:

```json
POST index_full.php
Content-Type: application/json

{ "action": "logout", "session_token": "<token>" }
```

### Rate limiting
Login attempts are counted per public key and per IP address. After 10 failures in a 5-minute window the response is:

```json
{ "ok": false, "message": "Too many login attempts. Try again in 287s.", "rate_limited": true }
```

Counters reset automatically on a successful login.

### Event pub/sub
Every significant action publishes a message to the `meento:events` Redis channel. Start the listener to see events in real time:

```bash
php redis_listener.php
# or log to a file
php redis_listener.php --log /var/log/meento_events.log
# or JSON output (one object per line, for log aggregators)
php redis_listener.php --json
```

Example output:
```
[2025-06-01T12:00:01+00:00] [webserver1] login  key=alice ip=203.0.113.42
[2025-06-01T12:00:05+00:00] [webserver1] file_added  hash=c33c4f0d... file=photo.jpg
[2025-06-01T12:00:06+00:00] [webserver1] server_confirmed  server=http://peer2.example.com balance=3
```

### Re-verification queue
When a file is confirmed on a server, a task is added to a Redis sorted set scheduled to run in 7 days. The worker processes these tasks:

```bash
# Run once (process all due tasks and exit)
php redis_worker.php

# Run as daemon (sleep 60 s between batches)
php redis_worker.php --daemon

# Cron (every hour, exit after processing due tasks)
0 * * * * php /var/www/html/node/redis_worker.php >> /var/log/meento_worker.log 2>&1
```

If a re-verification fails, the task is rescheduled for 24 hours later (shorter retry interval). If it succeeds, `last_verified` is updated in the account JSON and the task is rescheduled for the full 7-day interval.

### IP hash DNS cache
`gethostbyname()` is called once per hostname per hour instead of on every upload. Results are stored with a 1-hour TTL.

### Node heartbeat
Every request sends a 2-minute TTL heartbeat to Redis. The `?redis_status` endpoint shows all nodes that have been active in the last 2 minutes:

```
GET index_full.php?redis_status
```

```json
{
  "redis": {
    "available": true,
    "redis_version": "7.2.3",
    "used_memory_human": "2.1M",
    "connected_clients": "3"
  },
  "live_nodes": [
    { "url": "http://node1.example.com/node", "ts": 1748779200, "host": "server1" }
  ],
  "event_log": [...]
}
```

---

## Graceful degradation

If Redis is unavailable (not installed, wrong password, server down), the module logs a warning to PHP's error log and **does nothing** — all operations fall back to the original filesystem behaviour. The node keeps working exactly as before. No errors are shown to users.

To verify Redis is connected:

```bash
php -r "
define('REDIS_ENABLED', true);
define('REDIS_HOST', '127.0.0.1');
define('REDIS_PORT', 6379);
define('REDIS_PASSWORD', '');
define('REDIS_DB', 0);
define('REDIS_PREFIX', 'meento:');
define('REDIS_ACCOUNT_TTL', 300);
define('REDIS_SESSION_TTL', 86400);
define('REDIS_LOCK_TTL', 5);
define('REDIS_RATE_WINDOW', 300);
define('REDIS_RATE_LIMIT', 10);
define('REDIS_REVERIF_INTERVAL', 604800);
require 'redis_module_core.php';
\$r = MeentoRedis::get();
echo \$r->available() ? 'Redis: OK' : 'Redis: unavailable';
echo PHP_EOL;
print_r(\$r->info());
"
```

---

## Environment variables (for Docker / CI)

All configuration can be passed as environment variables to `redis_worker.php` and `redis_listener.php`:

| Variable | Default | Description |
|---|---|---|
| `REDIS_HOST` | `127.0.0.1` | Redis server hostname |
| `REDIS_PORT` | `6379` | Redis server port |
| `REDIS_PASS` | _(empty)_ | Redis password |
| `REDIS_DB` | `0` | Redis database index |
| `REDIS_PREFIX` | `meento:` | Key prefix |
| `MEENTO_NODE_DIR` | _(script dir)_ | Path to node's working directory |
| `REVERIF_INTERVAL` | `604800` | Re-verification interval in seconds |
| `WORKER_BATCH` | `20` | Tasks per worker batch |

---

## Redis key reference

| Key pattern | Type | Contents |
|---|---|---|
| `meento:account:<pubkey>` | String | Cached account JSON |
| `meento:lock:account:<pubkey>` | String | Distributed lock token |
| `meento:session:<token_hash>` | String | Public key for session |
| `meento:rate:login_key:<pubkey>` | String | Login attempt counter |
| `meento:rate:login_ip:<ip>` | String | Login attempt counter by IP |
| `meento:iphash:<hostname>` | String | SHA-256 of resolved IP |
| `meento:reverif_queue` | Sorted set | Re-verification tasks (score = next run time) |
| `meento:events` | Pub/Sub channel | Real-time event stream |
| `meento:event_log` | List | Last 500 events (capped) |
| `meento:heartbeat:<node_hash>` | String | Node liveness (TTL 120 s) |
| `meento:known_nodes` | Set | All node URLs seen |
