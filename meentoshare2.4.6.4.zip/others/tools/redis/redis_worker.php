#!/usr/bin/env php
<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  redis_worker.php — Meento Share re-verification worker
//
//  Dequeues tasks from the Redis re-verification sorted set and checks that
//  each stored file is still accessible on its confirmed servers.
//  Updates last_verified in the account JSON and publishes results to the
//  event bus.
//
//  Run as a cron job:
//    * * * * * php /path/to/redis_worker.php >> /var/log/meento_worker.log 2>&1
//
//  Or as a daemon (runs continuously with a sleep between batches):
//    php redis_worker.php --daemon
//
//  The worker does NOT need to run on the same machine as the web node —
//  it only needs access to Redis and the accounts/ directory.
// ═══════════════════════════════════════════════════════════════════════════════

// ── Bootstrap ─────────────────────────────────────────────────────────────────
$workerDir = dirname(__FILE__);

// Load the redis module (which defines MeentoRedis) without bootstrapping
// the web-request logic — we set a flag to skip meentoRedisBootstrap().
define('MEENTO_WORKER_MODE', true);

// Load just enough of the node to use accountPath() and verifyOnServer()
// We inline the minimum required functions here so the worker is self-contained.

// ── Configuration — match your index_full.php settings ─────────────────────
define('REDIS_HOST',             getenv('REDIS_HOST')    ?: '127.0.0.1');
define('REDIS_PORT',     (int)  (getenv('REDIS_PORT')    ?: 6379));
define('REDIS_PASSWORD',         getenv('REDIS_PASS')    ?: '');
define('REDIS_DB',       (int)  (getenv('REDIS_DB')      ?: 0));
define('REDIS_PREFIX',           getenv('REDIS_PREFIX')  ?: 'meento:');
define('REDIS_ENABLED',          true);
define('REDIS_ACCOUNT_TTL',      300);
define('REDIS_SESSION_TTL',      86400);
define('REDIS_LOCK_TTL',         10);
define('REDIS_RATE_WINDOW',      300);
define('REDIS_RATE_LIMIT',       10);
define('REDIS_REVERIF_INTERVAL', (int)(getenv('REVERIF_INTERVAL') ?: 604800));

$nodeDir = getenv('MEENTO_NODE_DIR') ?: $workerDir;
define('ACCOUNTS_DIR',     $nodeDir . '/accounts');
define('TRANSACTIONS_DIR', $nodeDir . '/transactions');

// ── Minimal helpers ───────────────────────────────────────────────────────────
function pubkeyToFilename(string $pk): string {
    $safe = preg_replace('/[^A-Za-z0-9+\/=\-_]/', '_', trim($pk));
    $safe = preg_replace('/_+/', '_', $safe);
    return substr(trim($safe, '_'), 0, 200);
}
function accountPath(string $pk): string { return ACCOUNTS_DIR . '/' . pubkeyToFilename($pk) . '.json'; }
function nowIso(): string { return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format(DATE_ATOM); }

function verifyOnServer(string $server, string $hash, string $filename): array {
    $base    = rtrim($server, '/');
    $fileUrl = $base . '/files/' . rawurlencode($filename);
    $infoUrl = $base . '/info/'  . rawurlencode($hash . '.json');
    if (function_exists('curl_init')) {
        $ch = curl_init($fileUrl);
        curl_setopt_array($ch, [CURLOPT_NOBODY => true, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10, CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
        curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($status >= 200 && $status < 300) return ['ok' => true, 'status' => $status, 'method' => 'curl_head'];
        if ($status === 0)                   return ['ok' => false, 'status' => 0, 'method' => 'curl_head', 'error' => 'connection_failed'];
        $ch2 = curl_init($infoUrl);
        curl_setopt_array($ch2, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
        $body = curl_exec($ch2);
        $st2  = (int)curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        if ($st2 >= 200 && $st2 < 300 && is_array(json_decode((string)$body, true)))
            return ['ok' => true, 'status' => $st2, 'method' => 'curl_get_info'];
        return ['ok' => false, 'status' => $st2, 'method' => 'curl_get_info'];
    }
    $hdrs = @get_headers($fileUrl);
    if (is_array($hdrs) && isset($hdrs[0])) {
        $st = (int)substr($hdrs[0], 9, 3);
        if ($st >= 200 && $st < 300) return ['ok' => true, 'status' => $st, 'method' => 'get_headers'];
    }
    return ['ok' => false, 'status' => 0, 'method' => 'get_headers', 'error' => 'not_found'];
}

// ── Load MeentoRedis without triggering the web bootstrap ────────────────────
// We manually inline just the MeentoRedis class parts we need,
// or we can load it via a slim require with a guard.
require_once $workerDir . '/redis_module_core.php';  // see note below

// ── Worker loop ───────────────────────────────────────────────────────────────
$isDaemon = in_array('--daemon', $argv ?? [], true);
$batchSize = (int)(getenv('WORKER_BATCH') ?: 20);
$redis = MeentoRedis::get();

if (!$redis->available()) {
    echo "[" . date('c') . "] ERROR: Redis not available. Exiting.\n";
    exit(1);
}

echo "[" . date('c') . "] Worker started. Daemon=" . ($isDaemon ? 'yes' : 'no') . "\n";

do {
    $tasks = $redis->reverifDequeueDue($batchSize);

    if (empty($tasks)) {
        if ($isDaemon) {
            sleep(60);
            continue;
        }
        echo "[" . date('c') . "] No tasks due. Exiting.\n";
        break;
    }

    foreach ($tasks as $task) {
        if (!is_array($task)) continue;
        $pk       = $task['public_key']  ?? '';
        $server   = $task['server_url']  ?? '';
        $hash     = $task['file_hash']   ?? '';
        $filename = $task['filename']    ?? '';

        if ($pk === '' || $server === '' || $hash === '') continue;

        echo "[" . date('c') . "] Checking $hash @ $server ... ";

        $result = verifyOnServer($server, $hash, $filename);

        if ($result['ok']) {
            echo "OK [{$result['method']} {$result['status']}]\n";
            // Update last_verified in account JSON
            $path = accountPath($pk);
            if (file_exists($path)) {
                $lockToken = $redis->acquireLockWait('account:' . $pk, 3000);
                if ($lockToken !== null) {
                    try {
                        $raw  = file_get_contents($path);
                        $data = json_decode($raw, true);
                        if (is_array($data)) {
                            foreach ($data['files'] as &$f) {
                                if (is_array($f) && ($f['hash'] ?? '') === $hash) {
                                    $f['last_verified'] = nowIso();
                                    break;
                                }
                            }
                            unset($f);
                            $data['updated_at'] = nowIso();
                            $tmp  = $path . '.reverif.tmp';
                            $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                            file_put_contents($tmp, $json, LOCK_EX);
                            if (PHP_OS_FAMILY === 'Windows' && file_exists($path)) unlink($path);
                            rename($tmp, $path);
                            $redis->accountSet($pk, $data);
                        }
                    } finally {
                        $redis->releaseLock('account:' . $pk, $lockToken);
                    }
                }
            }
            // Re-schedule for next interval
            $redis->reverifReschedule($pk, $server, $hash, $filename);
            $redis->eventPublish('reverif_done', ['public_key' => $pk, 'server' => $server, 'hash' => $hash, 'ok' => true]);
        } else {
            echo "FAIL [{$result['method']} {$result['status']}] " . ($result['error'] ?? '') . "\n";
            // Re-schedule with a shorter retry interval (24 h) to catch transient failures
            $redis->reverifEnqueue($pk, $server, $hash, $filename);
            // Override the score to now+86400 (24 h retry)
            // Note: reverifEnqueue uses REDIS_REVERIF_INTERVAL; we adjust by calling raw Redis
            $r = $redis->raw();
            if ($r !== null) {
                $item = json_encode(['public_key' => $pk, 'server_url' => $server,
                    'file_hash' => $hash, 'filename' => $filename, 'enqueued_at' => time()]);
                // Remove the item just enqueued and re-add with a 24 h score
                $r->zRem(REDIS_PREFIX . 'reverif_queue', $item);
                $r->zAdd(REDIS_PREFIX . 'reverif_queue', time() + 86400, $item);
            }
            $redis->eventPublish('reverif_done', ['public_key' => $pk, 'server' => $server, 'hash' => $hash, 'ok' => false]);
        }
    }

    if ($isDaemon) sleep(5);

} while ($isDaemon);

echo "[" . date('c') . "] Worker finished.\n";
