﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  DATA LOGGER  —  optional module for index.php (Mesh Node)
//
//  Usage (add to index.php after the require/define block):
//      require __DIR__ . '/data_json_slice.php';
//
//  Then replace (or supplement) the appendFilesAndDataJson() call sites with:
//      appendFilesAndDataJson($hash);          // existing call — keep as-is
//      appendRotatingDataJson($hash);          // new call added below it
//
//  What it does:
//      After a JSON info record is successfully written, appends the same entry
//      to a rotating series of files:  data.json → data_2.json → data_3.json …
//      Each file is capped at 100 KB.  When the current file reaches the limit
//      the entry is written to the next numbered file instead.
//      Never erases existing content.  Entirely silent — no output, no exceptions.
// ═══════════════════════════════════════════════════════════════════════════════

define('DATA_LOG_MAX_BYTES', 100 * 1024);   // 100 KB per file

/**
 * Resolve the path of the current target data_N.json file.
 * Scans from data.json upward until it finds one that is under the size cap,
 * or returns the next new filename if all existing ones are full.
 */
function _dataLogTargetPath(): string
{
    $dir = __DIR__;

    // data.json is index 1; data_2.json is index 2, etc.
    $index = 1;
    while (true) {
        $path = $index === 1
            ? $dir . '/data.json'
            : $dir . '/data_' . $index . '.json';

        if (!file_exists($path)) {
            return $path;   // new file, definitely has room
        }

        if (@filesize($path) < DATA_LOG_MAX_BYTES) {
            return $path;   // existing file still has room
        }

        $index++;
    }
}

/**
 * Append the info record for $hash to the appropriate rotating data_N.json.
 * Mirrors the JSON-array format used by appendFilesAndDataJson() in index.php.
 * Entirely silent — never leaks output or exceptions.
 */
function appendRotatingDataJson(string $hash): void
{
    ob_start();
    $prev = error_reporting(0);
    try {
        $infoPath = INFO_DIR . '/' . $hash . '.json';
        $raw      = @file_get_contents($infoPath);
        if ($raw === false) return;

        $info = json_decode($raw, true);
        if (!is_array($info)) return;

        $entry   = array_merge(['hash' => $hash], $info);
        $encoded = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($encoded === false) return;

        $indented = implode("\n", array_map(
            static fn(string $l) => '    ' . $l,
            explode("\n", $encoded)
        ));

        // Resolve the target file (may advance to a new index if current is full)
        $targetPath = _dataLogTargetPath();

        // Initialise the file with an empty JSON array if it does not exist yet
        if (!file_exists($targetPath)) {
            file_put_contents($targetPath, "[\n]", LOCK_EX);
        }

        $fp = @fopen($targetPath, 'c+');
        if ($fp === false) return;

        if (!flock($fp, LOCK_EX)) { fclose($fp); return; }

        $content    = rtrim((string) stream_get_contents($fp));
        $closingPos = strrpos($content, ']');

        if ($closingPos === false) {
            $newContent = "[\n" . $indented . "\n]";
        } elseif (trim(substr($content, 1, $closingPos - 1)) === '') {
            // Array is empty  →  first entry
            $newContent = "[\n" . $indented . "\n]";
        } else {
            // Array already has entries  →  append with comma
            $newContent = rtrim(substr($content, 0, $closingPos)) . ",\n" . $indented . "\n]";
        }

        rewind($fp);
        ftruncate($fp, 0);
        fwrite($fp, $newContent);
        flock($fp, LOCK_UN);
        fclose($fp);

        // After writing, check whether this file now exceeds the cap.
        // If so the NEXT call will automatically pick the following index —
        // no action needed here; the cap is a "stop adding to this file" signal.

    } catch (\Throwable $e) {
        // silently discard
    } finally {
        error_reporting($prev);
        ob_end_clean();
    }
}