﻿<?php
// ============================================================
//  P2P Chunk Downloader  —  BitTorrent-like over HTTP GET
// ============================================================

define('DHT_FILE',       __DIR__ . '/dht.txt');
define('SERVERS_FILE',   __DIR__ . '/servers.txt');
define('CHUNKS_DIR',     __DIR__ . '/base64_chuncks');
define('BASE64_DIR',     __DIR__ . '/base64');
define('BLOCKS_DIR',     __DIR__ . '/json_blocks');
define('PUBKEY_FILE',    __DIR__ . '/pub.key.txt');
define('OUTPUT_DIR',     __DIR__ . '/downloaded');
define('TIMEOUT',        10);
define('MAX_RETRIES',    2);

foreach ([CHUNKS_DIR, BASE64_DIR, BLOCKS_DIR, OUTPUT_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Helpers
// ============================================================

function isValidMd5(string $v): bool {
    return (bool)preg_match('/^[a-f0-9]{32}$/i', $v);
}

function loadPublicKey(): string {
    if (file_exists(PUBKEY_FILE)) {
        return trim(file_get_contents(PUBKEY_FILE));
    }
    return '';
}

function loadPeers(): array {
    $peers = [];
    foreach ([DHT_FILE, SERVERS_FILE] as $f) {
        if (!file_exists($f)) continue;
        $lines = file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $url = trim($line);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
                $peers[] = rtrim($url, '/');
            }
        }
    }
    return array_values(array_unique($peers));
}

function savePeer(string $url): void {
    $url = rtrim(trim($url), '/');
    if (!filter_var($url, FILTER_VALIDATE_URL)) return;
    $existing = loadDhtPeers();
    if (in_array($url, $existing, true)) return;
    file_put_contents(DHT_FILE, $url . "\n", FILE_APPEND | LOCK_EX);
}

function loadDhtPeers(): array {
    if (!file_exists(DHT_FILE)) return [];
    $lines = file(DHT_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $peers = [];
    foreach ($lines as $line) {
        $url = trim($line);
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
            $peers[] = rtrim($url, '/');
        }
    }
    return array_values(array_unique($peers));
}

function httpGet(string $url): array {
    $ctx = stream_context_create([
        'http' => [
            'method'        => 'GET',
            'timeout'       => TIMEOUT,
            'ignore_errors' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (!empty($http_response_header)) {
        if (preg_match('#HTTP/\S+\s+(\d+)#', $http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
    }
    return ['code' => $code, 'body' => $body !== false ? $body : ''];
}

function saveBlock(array $data): string {
    if (!is_dir(BLOCKS_DIR)) mkdir(BLOCKS_DIR, 0755, true);
    $hash     = md5(json_encode($data) . microtime(true) . rand());
    $filepath = BLOCKS_DIR . '/' . $hash . '.json';
    file_put_contents($filepath, json_encode($data, JSON_PRETTY_PRINT));
    return $hash;
}

function notifyPeers(array $peers, array $blockData): array {
    $results = [];
    $payload = urlencode(json_encode($blockData));
    foreach ($peers as $peer) {
        $url    = $peer . '/p2p.php?action=notify&block=' . $payload;
        $result = httpGet($url);
        $results[$peer] = $result['code'];
    }
    return $results;
}

// ─── DHT: ask a peer for its peer list ───────────────────────
function discoverPeers(array $knownPeers): array {
    $found = [];
    foreach ($knownPeers as $peer) {
        $url    = $peer . '/p2p.php?action=peers';
        $result = httpGet($url);
        if ($result['code'] === 200 && $result['body']) {
            $list = @json_decode($result['body'], true);
            if (is_array($list)) {
                foreach ($list as $p) {
                    $p = rtrim(trim($p), '/');
                    if ($p && filter_var($p, FILTER_VALIDATE_URL)) {
                        $found[] = $p;
                    }
                }
            }
        }
    }
    return array_values(array_unique($found));
}

// ─── Ask a peer how many chunks a file has ───────────────────
function queryFileInfo(array $peers, string $fileHash): array {
    foreach ($peers as $peer) {
        $url    = $peer . '/p2p.php?action=file_info&file=' . $fileHash;
        $result = httpGet($url);
        if ($result['code'] === 200) {
            $data = @json_decode($result['body'], true);
            if (isset($data['total_chunks']) && $data['total_chunks'] > 0) {
                return ['peer' => $peer, 'total_chunks' => (int)$data['total_chunks']];
            }
        }
        // Fallback: infer total from the highest chunk number available
        $url2    = $peer . '/p2p.php?action=list_chunks&file=' . $fileHash;
        $result2 = httpGet($url2);
        if ($result2['code'] === 200) {
            $list = @json_decode($result2['body'], true);
            if (is_array($list) && count($list) > 0) {
                return ['peer' => $peer, 'total_chunks' => max($list)];
            }
        }
    }
    return [];
}

// ─── Download a single chunk from any peer that has it ───────
//
// Chunks are base64 text (ASCII), so they survive JSON round-trip safely.
// We verify integrity AFTER json_decode against the hash in the filename.
function downloadChunk(array $peers, string $fileHash, int $chunkNum): array {
    foreach ($peers as $peer) {
        for ($try = 0; $try < MAX_RETRIES; $try++) {
            $url    = $peer . '/p2p.php?action=get_chunk&file=' . $fileHash . '&chunk=' . $chunkNum;
            $result = httpGet($url);
            if ($result['code'] !== 200 || $result['body'] === '') {
                continue;
            }
            $data = @json_decode($result['body'], true);
            if (!isset($data['contents'], $data['chunk_hash'])) {
                continue;
            }
            // Integrity: md5 of the contents string must match the stored hash
            $computed = md5($data['contents']);
            if ($computed !== strtolower($data['chunk_hash'])) {
                continue; // corrupted — try next retry or next peer
            }
            return [
                'success'    => true,
                'peer'       => $peer,
                'contents'   => $data['contents'],
                'chunk_hash' => strtolower($data['chunk_hash']),
            ];
        }
    }
    return ['success' => false];
}

// ─── Detect file extension from magic bytes ──────────────────
//
// Reads the binary header (magic number) of the decoded file and
// returns the most appropriate extension. Falls back to 'bin'.
function detectExtension(string $binary): string {
    $len = strlen($binary);
    if ($len === 0) return 'bin';

    // Build a hex string of the first 16 bytes for signature matching
    $h = '';
    for ($i = 0; $i < min(16, $len); $i++) {
        $h .= sprintf('%02x', ord($binary[$i]));
    }

    // ── Images ────────────────────────────────────────────────
    if (substr($h, 0, 6)  === 'ffd8ff')                                         return 'jpg';
    if (substr($h, 0, 16) === '89504e470d0a1a0a')                               return 'png';
    if (substr($h, 0, 6)  === '474946')                                         return 'gif';  // GIF8x
    if (substr($h, 0, 8)  === '52494646' && substr($h, 16, 8) === '57454250')   return 'webp';
    if (substr($h, 0, 4)  === '424d')                                           return 'bmp';
    if (substr($h, 0, 8)  === '00000100')                                       return 'ico';
    if (substr($h, 0, 8)  === '49492a00' || substr($h, 0, 8) === '4d4d002a')   return 'tif';

    // ── Documents ─────────────────────────────────────────────
    if (substr($h, 0, 8)  === '25504446')                                       return 'pdf';  // %PDF
    if (substr($h, 0, 16) === 'd0cf11e0a1b11ae1')                               return 'doc';  // OLE2 compound

    if (substr($h, 0, 8)  === '504b0304') {
        // ZIP-based container — distinguish Office Open XML and others
        if (strpos($binary, '[Content_Types].xml') !== false) {
            if (strpos($binary, 'word/')  !== false) return 'docx';
            if (strpos($binary, 'xl/')   !== false) return 'xlsx';
            if (strpos($binary, 'ppt/')  !== false) return 'pptx';
        }
        if (strpos($binary, 'META-INF/') !== false)                             return 'jar';
        if (strpos($binary, 'AndroidManifest.xml') !== false)                  return 'apk';
        return 'zip';
    }

    // ── Archives ──────────────────────────────────────────────
    if (substr($h, 0, 14) === '377abcaf271c')                                   return '7z';
    if (substr($h, 0, 4)  === '1f8b')                                           return 'gz';
    if (substr($h, 0, 8)  === '425a6839')                                       return 'bz2';
    if (substr($h, 0, 12) === '526172211a07')                                   return 'rar';

    // ── Audio ─────────────────────────────────────────────────
    if (substr($h, 0, 6)  === '494433')                                         return 'mp3';  // ID3 tag
    if (substr($h, 0, 4)  === 'fffb' || substr($h, 0, 4) === 'fff3')           return 'mp3';  // raw MPEG frame
    if (substr($h, 0, 8)  === '4f676753')                                       return 'ogg';
    if (substr($h, 0, 8)  === '664c6143')                                       return 'flac';
    if (substr($h, 0, 8)  === '52494646' && substr($h, 16, 8) === '57415645')  return 'wav';

    // ── Video ─────────────────────────────────────────────────
    if (strlen($binary) >= 8 && substr($binary, 4, 4) === 'ftyp')              return 'mp4';
    if (substr($h, 0, 8)  === '1a45dfa3')                                       return 'mkv';
    if (substr($h, 0, 8)  === '000001b3' || substr($h, 0, 8) === '000001ba')   return 'mpg';
    if (substr($h, 0, 8)  === '52494646' && substr($h, 16, 8) === '41564920')  return 'avi';

    // ── Executables ───────────────────────────────────────────
    if (substr($h, 0, 4)  === '4d5a')                                           return 'exe';  // MZ header
    if (substr($h, 0, 8)  === '7f454c46')                                       return 'elf';
    if (substr($h, 0, 8)  === 'cafebabe')                                       return 'class';

    // ── Text heuristic ────────────────────────────────────────
    // If the first 512 bytes contain only printable / UTF-8 characters, treat as text
    $sample   = substr($binary, 0, 512);
    $nonPrint = preg_replace('/[\x09\x0a\x0d\x20-\x7e\x80-\xff]/', '', $sample);
    if (strlen($nonPrint) === 0) {
        $start = ltrim(substr($binary, 0, 256));
        if (strncasecmp($start, '<?xml',         5) === 0) return 'xml';
        if (strncasecmp($start, '<?php',         5) === 0) return 'php';
        if (strncasecmp($start, '<!DOCTYPE html',14) === 0) return 'html';
        if (strncasecmp($start, '<html',         5) === 0) return 'html';
        if ($start !== '' && ($start[0] === '{' || $start[0] === '[')) return 'json';
        return 'txt';
    }

    return 'bin';
}

// ─── Self URL detection (best-effort) ────────────────────────
function selfUrl(): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '/p2p.php';
    return $scheme . '://' . $host . dirname($script);
}

// ============================================================
//  API endpoint (called by other peers via GET ?action=...)
// ============================================================

$action = $_GET['action'] ?? '';

if ($action !== '') {
    header('Content-Type: application/json');

    // ── Return known peer list ────────────────────────────────
    if ($action === 'peers') {
        echo json_encode(loadPeers());
        exit;
    }

    // ── Receive transfer notification block ──────────────────
    if ($action === 'notify') {
        $raw = $_GET['block'] ?? '';
        if ($raw) {
            $data = @json_decode($raw, true);
            if (is_array($data)) {
                $data['received_at'] = date('c');
                $hash = saveBlock($data);
                echo json_encode(['status' => 'ok', 'block' => $hash]);
                exit;
            }
        }
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid block data']);
        exit;
    }

    // ── Return chunk info for a file ─────────────────────────
    if ($action === 'file_info') {
        $fileHash = strtolower($_GET['file'] ?? '');
        if (!isValidMd5($fileHash)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid file hash']);
            exit;
        }
        $chunks = glob(BASE64_DIR . '/' . $fileHash . '.*.*');
        $nums   = [];
        foreach ($chunks as $c) {
            $parts = explode('.', basename($c));
            if (count($parts) === 3 && is_numeric($parts[1])) {
                $nums[] = (int)$parts[1];
            }
        }
        if (empty($nums)) {
            http_response_code(404);
            echo json_encode(['status' => 'not_found']);
            exit;
        }
        echo json_encode(['status' => 'ok', 'total_chunks' => max($nums), 'available' => count($nums)]);
        exit;
    }

    // ── List available chunk numbers for a file ───────────────
    if ($action === 'list_chunks') {
        $fileHash = strtolower($_GET['file'] ?? '');
        if (!isValidMd5($fileHash)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid file hash']);
            exit;
        }
        $chunks = glob(BASE64_DIR . '/' . $fileHash . '.*.*');
        $nums   = [];
        foreach ($chunks as $c) {
            $parts = explode('.', basename($c));
            if (count($parts) === 3 && is_numeric($parts[1])) {
                $nums[] = (int)$parts[1];
            }
        }
        echo json_encode(array_values($nums));
        exit;
    }

    // ── Serve a specific chunk ────────────────────────────────
    if ($action === 'get_chunk') {
        $fileHash = strtolower($_GET['file'] ?? '');
        $chunkNum = (int)($_GET['chunk'] ?? 0);
        if (!isValidMd5($fileHash) || $chunkNum < 1) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
            exit;
        }
        $pattern = BASE64_DIR . '/' . $fileHash . '.' . $chunkNum . '.*';
        $matches = glob($pattern);
        if (empty($matches)) {
            http_response_code(404);
            echo json_encode(['status' => 'not_found']);
            exit;
        }
        $filepath  = $matches[0];
        $parts     = explode('.', basename($filepath));
        $chunkHash = isset($parts[2]) ? $parts[2] : '';
        $contents  = file_get_contents($filepath);
        if ($contents === false) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Could not read chunk file']);
            exit;
        }
        echo json_encode([
            'status'     => 'ok',
            'file'       => $fileHash,
            'chunk'      => $chunkNum,
            'chunk_hash' => $chunkHash,
            'contents'   => $contents,
        ]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
    exit;
}

// ============================================================
//  Web UI  —  handle POST actions
// ============================================================

$message   = '';
$msgType   = 'info';
$result    = null;
$tabActive = isset($_POST['tab']) ? $_POST['tab'] : (isset($_GET['tab']) ? $_GET['tab'] : 'download');

// ── Add peer ─────────────────────────────────────────────────
if (isset($_POST['add_peer'])) {
    $newPeer = trim($_POST['peer_url'] ?? '');
    if (filter_var($newPeer, FILTER_VALIDATE_URL)) {
        savePeer($newPeer);
        $message = 'Peer added: ' . htmlspecialchars($newPeer);
        $msgType = 'ok';
    } else {
        $message = 'Invalid URL.';
        $msgType = 'error';
    }
    $tabActive = 'dht';
}

// ── Discover peers ────────────────────────────────────────────
if (isset($_POST['discover_peers'])) {
    $known = loadPeers();
    $found = discoverPeers($known);
    $added = 0;
    foreach ($found as $p) {
        $before = count(loadDhtPeers());
        savePeer($p);
        if (count(loadDhtPeers()) > $before) $added++;
    }
    $message   = 'Discovery complete. Found ' . count($found) . ' peer(s), added ' . $added . ' new.';
    $msgType   = 'ok';
    $tabActive = 'dht';
}

// ── Download file ─────────────────────────────────────────────
if (isset($_POST['download_file'])) {
    $tabActive = 'download';
    $fileHash  = strtolower(trim($_POST['file_hash'] ?? ''));

    if (!isValidMd5($fileHash)) {
        $message = 'Invalid MD5 hash.';
        $msgType = 'error';
    } else {
        $peers = loadPeers();
        if (empty($peers)) {
            $message = 'No peers known. Add peers in the DHT tab first.';
            $msgType = 'error';
        } else {
            $log    = [];
            $pubKey = loadPublicKey();

            // 1. Discover additional peers before starting
            $discovered = discoverPeers($peers);
            foreach ($discovered as $p) savePeer($p);
            $peers = loadPeers();
            $log[] = 'Peers available: ' . count($peers);

            // 2. Find out how many chunks exist for this file
            $info = queryFileInfo($peers, $fileHash);
            if (empty($info)) {
                $message = 'File not found on any peer.';
                $msgType = 'error';
            } else {
                $totalChunks = $info['total_chunks'];
                $log[]       = 'Total chunks reported: ' . $totalChunks;

                // 3. Download each chunk, verifying integrity on arrival
                $chunkMap = [];
                $failed   = [];

                for ($i = 1; $i <= $totalChunks; $i++) {
                    $dl = downloadChunk($peers, $fileHash, $i);

                    if ($dl['success']) {
                        $chunkMap[$i] = $dl;
                        $log[] = 'Chunk ' . $i . '/' . $totalChunks . ' OK from ' . $dl['peer'];

                        // Cache chunk locally so this node can seed it immediately
                        $localPath = BASE64_DIR . '/' . $fileHash . '.' . $i . '.' . $dl['chunk_hash'];
                        if (!file_exists($localPath)) {
                            file_put_contents($localPath, $dl['contents']);
                        }

                        // Record a per-chunk transfer block
                        $blockData = [
                            'type'         => 'chunk_received',
                            'file_hash'    => $fileHash,
                            'chunk'        => $i,
                            'chunk_hash'   => $dl['chunk_hash'],
                            'from_peer'    => $dl['peer'],
                            'to_peer'      => selfUrl(),
                            'sender_key'   => '',
                            'receiver_key' => $pubKey,
                            'timestamp'    => date('c'),
                        ];
                        $blockHash = saveBlock($blockData);
                        $log[]     = 'Block saved: ' . $blockHash;
                        notifyPeers($peers, $blockData);

                    } else {
                        $failed[] = $i;
                        $log[]    = 'Chunk ' . $i . '/' . $totalChunks . ' FAILED — not found on any peer';
                    }
                }

                if (!empty($failed)) {
                    $message = 'Download incomplete. Missing chunks: ' . implode(', ', $failed);
                    $msgType = 'error';
                } else {
                    // 4. Assemble — strictly sorted by chunk number
                    ksort($chunkMap);
                    $assembled = '';
                    foreach ($chunkMap as $chunkNum => $chunk) {
                        $assembled .= $chunk['contents'];
                    }
                    $log[] = 'Assembled ' . strlen($assembled) . ' chars of base64 data.';

                    // 5. Strip whitespace that may sit at chunk boundaries, then decode.
                    //    strict=false: PHP's lenient mode handles minor padding variations.
                    $clean  = preg_replace('/\s+/', '', $assembled);
                    $binary = base64_decode($clean, false);

                    if ($binary === false || strlen($binary) === 0) {
                        // Content was stored raw (not base64) — keep as-is
                        $binary = $assembled;
                        $log[]  = 'Note: content is not base64-encoded; saving raw assembled bytes.';
                    } else {
                        $log[] = 'Base64 decoded: ' . number_format(strlen($binary)) . ' bytes.';
                    }

                    // 6. Infer the original file type from magic bytes / content
                    $ext   = detectExtension($binary);
                    $log[] = 'Detected file type: .' . $ext;

                    // 7. Write output file — idempotent
                    $outFile = OUTPUT_DIR . '/' . $fileHash . '.' . $ext;
                    if (!file_exists($outFile)) {
                        file_put_contents($outFile, $binary);
                        $log[] = 'Saved: ' . basename($outFile) . ' (' . number_format(strlen($binary)) . ' bytes)';
                    } else {
                        $log[] = 'Already exists: ' . basename($outFile) . ' — skipped write.';
                    }

                    // Final assembled-file block
                    $finalBlock = [
                        'type'         => 'file_assembled',
                        'file_hash'    => $fileHash,
                        'total_chunks' => $totalChunks,
                        'output_file'  => basename($outFile),
                        'detected_ext' => $ext,
                        'size_bytes'   => strlen($binary),
                        'receiver_key' => $pubKey,
                        'timestamp'    => date('c'),
                    ];
                    $finalHash = saveBlock($finalBlock);
                    notifyPeers($peers, $finalBlock);
                    $log[] = 'Final block: ' . $finalHash;

                    $message = 'File assembled: ' . basename($outFile)
                               . ' (' . number_format(strlen($binary)) . ' bytes)';
                    $msgType = 'ok';
                }

                $result = ['log' => $log, 'file_hash' => $fileHash];
            }
        }
    }
}

// ── Load display data ─────────────────────────────────────────
$peers        = loadPeers();
$pubKey       = loadPublicKey();
$blocks       = [];
$blockFiles   = glob(BLOCKS_DIR . '/*.json') ?: [];
usort($blockFiles, function($a, $b) { return filemtime($b) - filemtime($a); });
foreach (array_slice($blockFiles, 0, 20) as $bf) {
    $decoded = @json_decode(file_get_contents($bf), true);
    if ($decoded) {
        $decoded['_file'] = basename($bf);
        $blocks[] = $decoded;
    }
}

$localFiles   = glob(OUTPUT_DIR . '/*') ?: [];
$seededChunks = count(glob(BASE64_DIR . '/*.*.*') ?: []);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Chunk Network</title>
<style>
  :root {
    --bg:     #0d0d0d;
    --panel:  #161616;
    --border: #2a2a2a;
    --accent: #00e5a0;
    --dim:    #555;
    --text:   #ddd;
    --muted:  #888;
    --red:    #e05555;
    --yellow: #e0b840;
    --mono:   'Courier New', monospace;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--mono); font-size: 13px; min-height: 100vh; }
  a { color: var(--accent); text-decoration: none; }
  a:hover { text-decoration: underline; }

  header { border-bottom: 1px solid var(--border); padding: 16px 24px; display: flex; align-items: center; gap: 16px; }
  header h1 { font-size: 15px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
  .status-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); box-shadow: 0 0 6px var(--accent); }
  .header-meta { margin-left: auto; color: var(--muted); font-size: 11px; }

  nav { display: flex; border-bottom: 1px solid var(--border); }
  nav button {
    background: none; border: none; border-bottom: 2px solid transparent;
    color: var(--muted); cursor: pointer; font-family: var(--mono); font-size: 12px;
    letter-spacing: 1px; padding: 12px 20px; text-transform: uppercase; transition: all .15s;
  }
  nav button:hover { color: var(--text); }
  nav button.active { border-bottom-color: var(--accent); color: var(--accent); }

  .tab { display: none; padding: 24px; max-width: 900px; }
  .tab.active { display: block; }

  .msg { border-left: 3px solid var(--dim); margin-bottom: 20px; padding: 10px 14px; font-size: 12px; }
  .msg.ok    { border-color: var(--accent); color: var(--accent); }
  .msg.error { border-color: var(--red);    color: var(--red); }
  .msg.info  { border-color: var(--yellow); color: var(--yellow); }

  label { color: var(--muted); display: block; font-size: 11px; letter-spacing: 1px; margin-bottom: 6px; text-transform: uppercase; }
  input[type=text], input[type=url] {
    background: var(--panel); border: 1px solid var(--border); border-radius: 3px;
    color: var(--text); font-family: var(--mono); font-size: 13px;
    padding: 9px 12px; width: 100%; transition: border-color .15s;
  }
  input[type=text]:focus, input[type=url]:focus { border-color: var(--accent); outline: none; }
  .field { margin-bottom: 16px; }

  button[type=submit], .btn {
    background: none; border: 1px solid var(--accent); border-radius: 3px;
    color: var(--accent); cursor: pointer; font-family: var(--mono); font-size: 12px;
    letter-spacing: 1px; padding: 9px 18px; text-transform: uppercase; transition: all .15s;
  }
  button[type=submit]:hover, .btn:hover { background: var(--accent); color: var(--bg); }
  .btn-muted { border-color: var(--dim); color: var(--muted); }
  .btn-muted:hover { background: var(--dim); color: var(--text); }

  .card { background: var(--panel); border: 1px solid var(--border); border-radius: 4px; margin-bottom: 12px; padding: 14px 16px; }
  .card-title { color: var(--accent); font-size: 11px; letter-spacing: 1px; margin-bottom: 8px; text-transform: uppercase; }
  .card p { color: var(--muted); font-size: 12px; line-height: 1.6; }

  .peer-list { list-style: none; }
  .peer-list li { border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; padding: 8px 0; font-size: 12px; }
  .peer-list li:last-child { border-bottom: none; }
  .peer-dot { background: var(--accent); border-radius: 50%; flex-shrink: 0; height: 6px; width: 6px; }

  .log-box { background: #0a0a0a; border: 1px solid var(--border); border-radius: 3px; font-size: 11px; line-height: 1.8; max-height: 300px; overflow-y: auto; padding: 12px; }
  .log-box .ok   { color: var(--accent); }
  .log-box .err  { color: var(--red); }
  .log-box .info { color: var(--yellow); }
  .log-line::before { content: '> '; color: var(--dim); }

  .block-item { border-bottom: 1px solid var(--border); padding: 10px 0; font-size: 11px; }
  .block-item:last-child { border-bottom: none; }
  .block-type { color: var(--accent); }
  .block-meta { color: var(--muted); margin-top: 3px; line-height: 1.8; }

  .hash { color: var(--yellow); font-size: 11px; word-break: break-all; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .stat-val { color: var(--accent); font-size: 22px; margin-bottom: 4px; }
  .stat-label { color: var(--muted); font-size: 11px; letter-spacing: 1px; text-transform: uppercase; }
  .form-row { display: flex; gap: 10px; align-items: flex-end; }
  .form-row .field { flex: 1; margin-bottom: 0; }
  .key-box { background: #0a0a0a; border: 1px solid var(--border); border-radius: 3px; color: var(--muted); font-size: 10px; padding: 8px 10px; word-break: break-all; line-height: 1.5; }
  table { border-collapse: collapse; width: 100%; font-size: 11px; }
  th { color: var(--muted); font-weight: normal; letter-spacing: 1px; padding: 6px 10px; text-align: left; text-transform: uppercase; border-bottom: 1px solid var(--border); }
  td { padding: 8px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  .tag { background: var(--border); border-radius: 2px; color: var(--muted); display: inline-block; font-size: 10px; padding: 2px 6px; }
  .tag.green { background: #0d2b1e; color: var(--accent); }
  .tag.red   { background: #2b0d0d; color: var(--red); }
  .ext-badge { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 2px; color: #7eb8f7; display: inline-block; font-size: 10px; padding: 1px 6px; letter-spacing: 1px; text-transform: uppercase; }
</style>
</head>
<body>

<header>
  <div class="status-dot"></div>
  <h1>P2P Chunk Network</h1>
  <div class="header-meta">
    peers: <?= count($peers) ?> &nbsp;|&nbsp;
    seeding: <?= $seededChunks ?> chunks &nbsp;|&nbsp;
    blocks: <?= count($blockFiles) ?>
  </div>
</header>

<nav>
  <button class="<?= $tabActive==='download'?'active':'' ?>" onclick="switchTab('download',this)">Download</button>
  <button class="<?= $tabActive==='dht'     ?'active':'' ?>" onclick="switchTab('dht',this)">DHT / Peers</button>
  <button class="<?= $tabActive==='blocks'  ?'active':'' ?>" onclick="switchTab('blocks',this)">Blocks</button>
  <button class="<?= $tabActive==='seeding' ?'active':'' ?>" onclick="switchTab('seeding',this)">Seeding</button>
  <button class="<?= $tabActive==='node'    ?'active':'' ?>" onclick="switchTab('node',this)">Node Info</button>
</nav>

<?php if ($message): ?>
<div style="padding:20px 24px 0;">
  <div class="msg <?= $msgType ?>"><?= htmlspecialchars($message) ?></div>
</div>
<?php endif; ?>

<!-- ══ DOWNLOAD TAB ══════════════════════════════════════════ -->
<div id="tab-download" class="tab <?= $tabActive==='download'?'active':'' ?>">
  <div class="card">
    <div class="card-title">Download File by Hash</div>
    <form method="POST">
      <input type="hidden" name="tab" value="download">
      <div class="field">
        <label>File MD5 Hash</label>
        <input type="text" name="file_hash"
               placeholder="e.g. a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"
               value="<?= htmlspecialchars(isset($_POST['file_hash']) ? $_POST['file_hash'] : '') ?>"
               maxlength="32" autocomplete="off">
      </div>
      <button type="submit" name="download_file">Download</button>
    </form>
  </div>

  <?php if ($result): ?>
  <div class="card" style="margin-top:16px;">
    <div class="card-title">Transfer Log</div>
    <div class="log-box" id="logbox">
      <?php foreach ($result['log'] as $line):
        $cls = 'info';
        if (strpos($line, 'OK') !== false    || strpos($line, 'Saved') !== false  ||
            strpos($line, 'decoded') !== false || strpos($line, 'Block') !== false ||
            strpos($line, 'assembled') !== false || strpos($line, 'Final') !== false) $cls = 'ok';
        if (strpos($line, 'FAILED') !== false || strpos($line, 'error') !== false  ||
            strpos($line, 'Error') !== false) $cls = 'err';
      ?>
      <div class="log-line <?= $cls ?>"><?= htmlspecialchars($line) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!empty($localFiles)): ?>
  <div class="card" style="margin-top:16px;">
    <div class="card-title">Downloaded Files</div>
    <table>
      <tr><th>Filename</th><th>Type</th><th>Size</th><th>Modified</th></tr>
      <?php foreach ($localFiles as $lf): $ext = pathinfo($lf, PATHINFO_EXTENSION); ?>
      <tr>
        <td class="hash"><?= htmlspecialchars(basename($lf)) ?></td>
        <td><span class="ext-badge"><?= htmlspecialchars($ext ?: '?') ?></span></td>
        <td><?= number_format(filesize($lf)) ?> B</td>
        <td><?= date('Y-m-d H:i:s', filemtime($lf)) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <?php endif; ?>
</div>

<!-- ══ DHT / PEERS TAB ══════════════════════════════════════ -->
<div id="tab-dht" class="tab <?= $tabActive==='dht'?'active':'' ?>">
  <div class="grid2" style="margin-bottom:16px;">
    <div class="card">
      <div class="stat-val"><?= count($peers) ?></div>
      <div class="stat-label">Known Peers</div>
    </div>
    <div class="card">
      <div class="stat-val"><?= count(loadDhtPeers()) ?></div>
      <div class="stat-label">DHT Entries</div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">Add Peer</div>
    <form method="POST">
      <input type="hidden" name="tab" value="dht">
      <div class="form-row">
        <div class="field">
          <label>Peer URL</label>
          <input type="url" name="peer_url" placeholder="https://peer.example.com">
        </div>
        <button type="submit" name="add_peer">Add</button>
      </div>
    </form>
  </div>

  <div class="card" style="margin-top:16px;">
    <div class="card-title">Auto-Discovery</div>
    <p style="margin-bottom:12px;">Ask each known peer for their peer list and merge new entries into DHT.</p>
    <form method="POST">
      <input type="hidden" name="tab" value="dht">
      <button type="submit" name="discover_peers" class="btn btn-muted">Discover Peers</button>
    </form>
  </div>

  <?php if (!empty($peers)): ?>
  <div class="card" style="margin-top:16px;">
    <div class="card-title">Known Peers</div>
    <ul class="peer-list">
      <?php foreach ($peers as $p): ?>
      <li><span class="peer-dot"></span><?= htmlspecialchars($p) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
  <?php else: ?>
  <div class="card" style="margin-top:16px;">
    <p>No peers yet. Add a peer URL above or run peer discovery.</p>
  </div>
  <?php endif; ?>
</div>

<!-- ══ BLOCKS TAB ═══════════════════════════════════════════ -->
<div id="tab-blocks" class="tab <?= $tabActive==='blocks'?'active':'' ?>">
  <div class="card">
    <div class="card-title">Recent Transfer Blocks (last 20)</div>
    <?php if (empty($blocks)): ?>
      <p>No blocks recorded yet.</p>
    <?php else: ?>
      <?php foreach ($blocks as $block): ?>
      <div class="block-item">
        <div>
          <span class="block-type"><?= htmlspecialchars($block['type'] ?? 'unknown') ?></span>
          &nbsp;
          <span class="tag"><?= htmlspecialchars($block['_file']) ?></span>
          <?php if (!empty($block['detected_ext'])): ?>
          &nbsp;<span class="ext-badge"><?= htmlspecialchars($block['detected_ext']) ?></span>
          <?php endif; ?>
        </div>
        <div class="block-meta">
          <?php if (!empty($block['file_hash'])): ?>
          file: <span class="hash"><?= htmlspecialchars($block['file_hash']) ?></span><br>
          <?php endif; ?>
          <?php if (!empty($block['chunk'])): ?>
          chunk: <?= (int)$block['chunk'] ?> &nbsp;
          <?php endif; ?>
          <?php if (!empty($block['size_bytes'])): ?>
          size: <?= number_format($block['size_bytes']) ?> B &nbsp;
          <?php endif; ?>
          <?php if (!empty($block['from_peer'])): ?>
          from: <?= htmlspecialchars($block['from_peer']) ?><br>
          <?php endif; ?>
          <?php if (!empty($block['receiver_key'])): ?>
          key: <span class="hash" style="font-size:10px"><?= htmlspecialchars(substr($block['receiver_key'], 0, 48)) ?>...</span><br>
          <?php endif; ?>
          <?= htmlspecialchars(isset($block['timestamp']) ? $block['timestamp'] : (isset($block['received_at']) ? $block['received_at'] : '')) ?>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<!-- ══ SEEDING TAB ═══════════════════════════════════════════ -->
<div id="tab-seeding" class="tab <?= $tabActive==='seeding'?'active':'' ?>">
  <div class="card">
    <div class="stat-val"><?= $seededChunks ?></div>
    <div class="stat-label">Chunks Available to Seed</div>
  </div>

  <?php
  $chunkFiles = glob(BASE64_DIR . '/*.*.*') ?: [];
  $byFile = [];
  foreach ($chunkFiles as $cf) {
      $parts = explode('.', basename($cf));
      if (count($parts) === 3) {
          $byFile[$parts[0]][] = (int)$parts[1];
      }
  }
  ?>

  <?php if (!empty($byFile)): ?>
  <div class="card" style="margin-top:16px;">
    <div class="card-title">Files Being Seeded</div>
    <table>
      <tr><th>File Hash</th><th>Have</th><th>Max #</th><th>Status</th></tr>
      <?php foreach ($byFile as $fh => $cnums): sort($cnums); ?>
      <tr>
        <td class="hash"><?= htmlspecialchars($fh) ?></td>
        <td><?= count($cnums) ?></td>
        <td><?= max($cnums) ?></td>
        <td>
          <?php if (count($cnums) === max($cnums)): ?>
            <span class="tag green">complete</span>
          <?php else: ?>
            <span class="tag red">partial</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <?php else: ?>
  <div class="card" style="margin-top:16px;">
    <p>No chunks to seed. Download a file or place chunks in <code>base64/</code>.</p>
  </div>
  <?php endif; ?>
</div>

<!-- ══ NODE INFO TAB ════════════════════════════════════════ -->
<div id="tab-node" class="tab <?= $tabActive==='node'?'active':'' ?>">
  <div class="card">
    <div class="card-title">This Node</div>
    <table>
      <tr><th>Field</th><th>Value</th></tr>
      <tr><td>URL</td><td><?= htmlspecialchars(selfUrl()) ?></td></tr>
      <tr><td>PHP Version</td><td><?= phpversion() ?></td></tr>
      <tr><td>Chunk Store</td><td><?= htmlspecialchars(BASE64_DIR) ?></td></tr>
      <tr><td>Blocks Dir</td><td><?= htmlspecialchars(BLOCKS_DIR) ?></td></tr>
      <tr><td>Output Dir</td><td><?= htmlspecialchars(OUTPUT_DIR) ?></td></tr>
      <tr><td>DHT File</td><td><?= htmlspecialchars(DHT_FILE) ?></td></tr>
      <tr><td>Public Key</td><td><?= htmlspecialchars(PUBKEY_FILE) ?> &nbsp;<span class="tag <?= file_exists(PUBKEY_FILE)?'green':'red' ?>"><?= file_exists(PUBKEY_FILE)?'found':'not found' ?></span></td></tr>
    </table>
  </div>

  <?php if ($pubKey): ?>
  <div class="card" style="margin-top:16px;">
    <div class="card-title">Public Key (pub.key.txt)</div>
    <div class="key-box"><?= htmlspecialchars($pubKey) ?></div>
  </div>
  <?php else: ?>
  <div class="card" style="margin-top:16px;">
    <p style="color:var(--yellow);">Create <code>pub.key.txt</code> next to this file and paste your public key into it.</p>
  </div>
  <?php endif; ?>

  <div class="card" style="margin-top:16px;">
    <div class="card-title">API Endpoints</div>
    <table>
      <tr><th>action=</th><th>Extra params</th><th>Returns</th></tr>
      <tr><td>peers</td>       <td>—</td>                                              <td>JSON array of peer URLs</td></tr>
      <tr><td>file_info</td>   <td>file=&lt;md5&gt;</td>                               <td>total_chunks, available</td></tr>
      <tr><td>list_chunks</td> <td>file=&lt;md5&gt;</td>                               <td>Array of chunk numbers held</td></tr>
      <tr><td>get_chunk</td>   <td>file=&lt;md5&gt; &amp; chunk=&lt;n&gt;</td>         <td>contents + chunk_hash as JSON</td></tr>
      <tr><td>notify</td>      <td>block=&lt;json&gt;</td>                             <td>Stores transfer block, returns hash</td></tr>
    </table>
  </div>
</div>

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(function(t) { t.classList.remove('active'); });
  document.querySelectorAll('nav button').forEach(function(b) { b.classList.remove('active'); });
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}
// Auto-scroll log box to bottom
var lb = document.getElementById('logbox');
if (lb) lb.scrollTop = lb.scrollHeight;
</script>
</body>
</html>