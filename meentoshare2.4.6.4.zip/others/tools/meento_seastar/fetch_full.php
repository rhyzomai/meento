﻿<?php
// ============================================================
//  fetch.php — P2P Chunk Downloader
//  - Reads servers from servers.txt
//  - Reads chunk list from hash_chunks/<hash>.txt
//  - Downloads each chunk from servers at /chunks/<filename>
//  - Assembles, base64-decodes, infers file extension
//  - Falls back to direct download if no chunk list / single entry
// ============================================================

define('SERVERS_FILE',   __DIR__ . '/servers.txt');
define('HASH_CHUNK_DIR', __DIR__ . '/hash_chunks');
define('LOCAL_CHUNK_DIR',__DIR__ . '/chunks');
define('DOWNLOADED_DIR', __DIR__ . '/downloaded');
define('TIMEOUT',        12);
define('MAX_RETRIES',    2);

foreach ([LOCAL_CHUNK_DIR, HASH_CHUNK_DIR, DOWNLOADED_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Utilities
// ============================================================

function isValidMd5(string $v): bool {
    return (bool) preg_match('/^[a-f0-9]{32}$/i', $v);
}

function formatBytes(int $b): string {
    if ($b >= 1048576) return round($b / 1048576, 2) . ' MB';
    if ($b >= 1024)    return round($b / 1024, 2) . ' KB';
    return $b . ' B';
}

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $out = [];
    foreach (file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        $u = rtrim(trim($l), '/');
        if ($u && filter_var($u, FILTER_VALIDATE_URL)) $out[] = $u;
    }
    return array_values(array_unique($out));
}

function httpFetch(string $url): ?string {
    $ctx  = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => TIMEOUT,
        'ignore_errors' => true,
        'header'        => "User-Agent: P2P-Fetcher/1.0\r\n",
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false || empty($http_response_header)) return null;
    if (!preg_match('#HTTP/\S+\s+200#', $http_response_header[0])) return null;
    return $body;
}

// ── Infer file extension from binary magic bytes ──────────────
function inferExtension(string $bin): string {
    $h = substr($bin, 0, 16);

    if (str_starts_with($h, "\xFF\xD8\xFF"))                                   return 'jpg';
    if (str_starts_with($h, "\x89PNG\r\n\x1A\n"))                              return 'png';
    if (str_starts_with($h, 'GIF87a') || str_starts_with($h, 'GIF89a'))       return 'gif';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='WEBP')              return 'webp';
    if (str_starts_with($h, 'BM'))                                              return 'bmp';
    if (str_starts_with($h, "\x00\x00\x01\x00"))                               return 'ico';
    if (str_starts_with($h, "\x1A\x45\xDF\xA3"))                               return 'mkv';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='AVI ')              return 'avi';
    if (str_starts_with($h, 'FLV'))                                             return 'flv';
    if (str_starts_with($h, "\x00\x00\x00") && in_array(substr($h,4,4),['ftyp','moov','mdat'])) return 'mp4';
    if (str_starts_with($h, "\x00\x00\x00\x1C\x66\x74\x79\x70"))              return 'mp4';
    if (str_starts_with($h, 'ID3') || (strlen($h)>1 && ord($h[0])===0xFF && (ord($h[1])&0xE0)===0xE0)) return 'mp3';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='WAVE')              return 'wav';
    if (str_starts_with($h, 'fLaC'))                                            return 'flac';
    if (str_starts_with($h, 'OggS'))                                            return 'ogg';
    if (str_starts_with($h, '%PDF'))                                            return 'pdf';
    if (str_starts_with($h, 'PK'))                                              return 'zip';
    if (str_starts_with($h, "\xD0\xCF\x11\xE0"))                               return 'doc';
    if (str_starts_with($h, "\x1F\x8B"))                                        return 'gz';
    if (str_starts_with($h, 'BZh'))                                             return 'bz2';
    if (str_starts_with($h, "\xFD\x37\x7A\x58\x5A\x00"))                      return 'xz';
    if (str_starts_with($h, "7z\xBC\xAF'\x1C"))                                return '7z';
    if (str_starts_with($h, 'Rar!'))                                            return 'rar';
    if (str_starts_with($h, "\x7FELF"))                                         return 'elf';
    if (str_starts_with($h, 'MZ'))                                              return 'exe';
    if (str_starts_with($h, "SQLite"))                                          return 'sqlite';
    if (str_starts_with($h, "\xCA\xFE\xBA\xBE"))                               return 'class';

    // Text-based detection
    $sample = substr($bin, 0, 512);
    if (mb_detect_encoding($sample, 'UTF-8', true) !== false) {
        $t = ltrim($sample);
        if (str_starts_with($t, '<?php'))                return 'php';
        if (str_starts_with($t, '<?xml'))                return 'xml';
        if (str_starts_with($t, '<!DOCTYPE') || str_starts_with($t, '<html')) return 'html';
        if (str_starts_with($t, '{') || str_starts_with($t, '['))             return 'json';
        return 'txt';
    }
    return 'bin';
}

// ── Read chunk-hash index ─────────────────────────────────────
function readChunkIndex(string $hash): array {
    $path = HASH_CHUNK_DIR . '/' . $hash . '.txt';
    if (!file_exists($path)) return [];
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_filter(array_map('trim', $lines), 'isValidMd5'));
}

// ── Find whole file already on disk ───────────────────────────
function findLocalFile(string $hash): ?string {
    foreach ([DOWNLOADED_DIR, LOCAL_CHUNK_DIR] as $dir) {
        foreach (glob($dir . '/' . $hash . '*') ?: [] as $f) {
            if (is_file($f)) return $f;
        }
    }
    return null;
}

// ── Fetch one chunk: local cache first, then each server ──────
// Filename convention: <fileHash>.<lineNum>.<chunkHash>
function fetchChunk(string $fileHash, int $lineNum, string $chunkHash, array $servers): array {
    $filename  = $fileHash . '.' . $lineNum . '.' . $chunkHash;
    $localPath = LOCAL_CHUNK_DIR . '/' . $filename;

    if (file_exists($localPath)) {
        $d = file_get_contents($localPath);
        if ($d !== false && md5($d) === $chunkHash)
            return ['ok' => true, 'data' => $d, 'src' => 'local'];
    }

    foreach ($servers as $server) {
        for ($t = 0; $t < MAX_RETRIES; $t++) {
            $body = httpFetch(rtrim($server, '/') . '/chunks/' . $filename);
            if ($body !== null && md5($body) === $chunkHash) {
                file_put_contents($localPath, $body);
                return ['ok' => true, 'data' => $body, 'src' => $server];
            }
        }
    }
    return ['ok' => false, 'data' => '', 'src' => ''];
}

// ── Try direct whole-file download from servers ───────────────
function fetchDirect(string $hash, array $servers): ?string {
    foreach ($servers as $server) {
        for ($t = 0; $t < MAX_RETRIES; $t++) {
            $body = httpFetch(rtrim($server, '/') . '/chunks/' . $hash);
            if ($body !== null) return $body;
        }
    }
    return null;
}

// ============================================================
//  Serve downloaded file to browser
// ============================================================
if (isset($_GET['serve'])) {
    $h = preg_replace('/[^a-f0-9]/i', '', $_GET['serve'] ?? '');
    if (!isValidMd5($h)) { http_response_code(400); exit('Bad hash'); }
    foreach (glob(DOWNLOADED_DIR . '/' . $h . '*') ?: [] as $f) {
        if (is_file($f)) {
            $ext = pathinfo($f, PATHINFO_EXTENSION) ?: 'bin';
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $h . '.' . $ext . '"');
            header('Content-Length: ' . filesize($f));
            readfile($f);
            exit;
        }
    }
    http_response_code(404); exit('Not found');
}

// ============================================================
//  API: file info from info/<hash>.txt on each server
// ============================================================
if (isset($_GET['api']) && $_GET['api'] === 'info') {
    header('Content-Type: application/json');
    $h = preg_replace('/[^a-f0-9]/i', '', $_GET['hash'] ?? '');
    if (!isValidMd5($h)) { echo json_encode(['error'=>'bad hash']); exit; }

    $servers   = loadServers();
    $chunks    = readChunkIndex($h);
    $infoText  = null;
    $serverMap = []; // server => has_chunk_count

    // Count how many servers host each chunk (popularity)
    $chunkCoverage = [];
    foreach ($chunks as $idx => $chunkHash) {
        $n        = $idx + 1;
        $filename = $h . '.' . $n . '.' . $chunkHash;
        $cnt      = 0;
        foreach ($servers as $srv) {
            $ctx  = stream_context_create(['http'=>['method'=>'HEAD','timeout'=>4,'ignore_errors'=>true]]);
            $out  = @get_headers(rtrim($srv,'/')  .'/chunks/'.$filename, true);
            if ($out && strpos($out[0],'200') !== false) $cnt++;
        }
        $chunkCoverage[] = ['chunk'=>$n,'hash'=>$chunkHash,'servers'=>$cnt];
    }

    // Fetch info text from first server that has it
    foreach ($servers as $srv) {
        $url  = rtrim($srv,'/') . '/info/' . $h . '.txt';
        $body = httpFetch($url);
        if ($body !== null) { $infoText = $body; break; }
    }

    echo json_encode([
        'hash'          => $h,
        'total_chunks'  => count($chunks),
        'chunk_coverage'=> $chunkCoverage,
        'info'          => $infoText,
        'servers'       => count($servers),
    ]);
    exit;
}

// ============================================================
//  API: stream download progress via SSE
// ============================================================
if (isset($_GET['api']) && $_GET['api'] === 'stream_fetch') {
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');
    @ob_end_flush();

    $h = preg_replace('/[^a-f0-9]/i', '', $_GET['hash'] ?? '');
    if (!isValidMd5($h)) {
        echo "data: " . json_encode(['type'=>'error','msg'=>'Invalid hash']) . "\n\n";
        exit;
    }

    $flush = function(array $d) {
        echo "data: " . json_encode($d) . "\n\n";
        @ob_flush(); @flush();
    };

    $servers = loadServers();
    $flush(['type'=>'info','msg'=>count($servers).' server(s) loaded','servers'=>count($servers)]);

    // Local check
    $local = findLocalFile($h);
    if ($local !== null) {
        $flush(['type'=>'ok','msg'=>'Found locally: '.basename($local),'progress'=>100,'done'=>true,'file'=>$h,'path'=>$h]);
        exit;
    }

    $chunks = readChunkIndex($h);
    $total  = count($chunks);

    if ($total > 1) {
        $flush(['type'=>'info','msg'=>"Chunk index: {$total} piece(s)",'total'=>$total]);
        $assembled = '';
        $failed    = [];
        $startTime = microtime(true);
        $bytesGot  = 0;

        foreach ($chunks as $idx => $chunkHash) {
            $n        = $idx + 1;
            $t0       = microtime(true);
            $result   = fetchChunk($h, $n, $chunkHash, $servers);
            $elapsed  = microtime(true) - $t0;

            if ($result['ok']) {
                $bytes      = strlen($result['data']);
                $bytesGot  += $bytes;
                $assembled .= $result['data'];
                $speed      = $elapsed > 0 ? (int)($bytes / $elapsed) : 0;
                $src        = $result['src'] === 'local' ? 'local cache'
                              : (parse_url($result['src'], PHP_URL_HOST) ?: $result['src']);
                $flush([
                    'type'     => 'chunk',
                    'n'        => $n,
                    'total'    => $total,
                    'progress' => round($n/$total*100),
                    'speed'    => $speed,
                    'bytes'    => $bytesGot,
                    'src'      => $src,
                    'msg'      => "Chunk {$n}/{$total} [{$chunkHash}] OK ({$src})",
                ]);
            } else {
                $failed[] = $n;
                $flush(['type'=>'error','n'=>$n,'total'=>$total,'progress'=>round($n/$total*100),
                        'msg'=>"Chunk {$n}/{$total} MISSING"]);
            }
        }

        if (!empty($failed)) {
            $flush(['type'=>'error','msg'=>'Incomplete — missing: '.implode(', ',$failed),'done'=>true]);
        } else {
            $dec    = base64_decode($assembled, true);
            $binary = ($dec !== false) ? $dec : $assembled;
            $ext    = inferExtension($binary);
            $path   = DOWNLOADED_DIR . '/' . $h . '.' . $ext;
            file_put_contents($path, $binary);
            $flush(['type'=>'done','msg'=>"Saved: {$h}.{$ext} (".formatBytes(strlen($binary)).")",
                    'done'=>true,'file'=>$h.'.'.$ext,'hash'=>$h,'ext'=>$ext,
                    'size'=>strlen($binary),'progress'=>100]);
        }
    } else {
        $flush(['type'=>'info','msg'=>'No chunk index — direct download']);
        $t0  = microtime(true);
        $raw = fetchDirect($h, $servers);
        if ($raw !== null) {
            $el     = microtime(true) - $t0;
            $speed  = $el > 0 ? (int)(strlen($raw)/$el) : 0;
            $dec    = base64_decode($raw, true);
            $binary = ($dec !== false) ? $dec : $raw;
            $ext    = inferExtension($binary);
            $path   = DOWNLOADED_DIR . '/' . $h . '.' . $ext;
            file_put_contents($path, $binary);
            $flush(['type'=>'done','msg'=>"Saved: {$h}.{$ext}",
                    'done'=>true,'file'=>$h.'.'.$ext,'hash'=>$h,'ext'=>$ext,
                    'size'=>strlen($binary),'speed'=>$speed,'progress'=>100]);
        } else {
            $flush(['type'=>'error','msg'=>'Not found on any server','done'=>true]);
        }
    }
    exit;
}


$log     = [];
$error   = '';
$success = false;
$outPath = '';
$outExt  = '';
$outSize = 0;
$hash    = '';
$tab     = $_POST['tab'] ?? $_GET['tab'] ?? 'download';

$history = [];
foreach (glob(DOWNLOADED_DIR . '/*') ?: [] as $f) {
    if (is_file($f))
        $history[] = ['path'=>$f,'name'=>basename($f),'size'=>filesize($f),'mtime'=>filemtime($f)];
}
usort($history, fn($a,$b) => $b['mtime'] - $a['mtime']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_fetch'])) {
    $tab  = 'download';
    $hash = strtolower(trim($_POST['file_hash'] ?? ''));

    if (!isValidMd5($hash)) {
        $error = 'Invalid MD5 hash — must be exactly 32 hex characters.';
    } else {
        $servers = loadServers();
        $log[]   = empty($servers)
            ? ['info', 'No servers in servers.txt — local cache only']
            : ['info', count($servers) . ' server(s) loaded from servers.txt'];

        $binary = null;
        $method = '';

        // ── Step 1: already on disk ───────────────────────────
        $local = findLocalFile($hash);
        if ($local !== null) {
            $log[]  = ['ok', 'Found locally: ' . basename($local) . ' — no download needed'];
            $binary = file_get_contents($local);
            $method = 'local';
        }

        // ── Step 2: chunk index ───────────────────────────────
        if ($binary === null) {
            $chunks = readChunkIndex($hash);

            if (count($chunks) > 1) {
                $log[]     = ['info', 'Chunk index loaded — ' . count($chunks) . ' piece(s)'];
                $assembled = '';
                $failed    = [];

                foreach ($chunks as $idx => $chunkHash) {
                    $n      = $idx + 1;
                    $result = fetchChunk($hash, $n, $chunkHash, $servers);
                    if ($result['ok']) {
                        $assembled .= $result['data'];
                        $src = $result['src'] === 'local'
                            ? 'local cache'
                            : (parse_url($result['src'], PHP_URL_HOST) ?: $result['src']);
                        $log[] = ['ok', "Chunk {$n}/" . count($chunks) . " [{$chunkHash}] — OK ({$src})"];
                    } else {
                        $failed[] = $n;
                        $log[]    = ['error', "Chunk {$n}/" . count($chunks) . " [{$chunkHash}] — NOT FOUND"];
                    }
                }

                if (!empty($failed)) {
                    $error = 'Incomplete — missing chunk(s): ' . implode(', ', $failed);
                } else {
                    $dec    = base64_decode($assembled, true);
                    $binary = ($dec !== false) ? $dec : $assembled;
                    $method = 'chunked';
                    $log[]  = ['ok', 'All chunks assembled and decoded'];
                }

            } else {
                // ── Step 3: no index or single-entry → direct download ──
                $reason = count($chunks) === 1
                    ? 'Single entry in chunk index'
                    : 'No chunk index found';
                $log[] = ['info', $reason . ' — trying direct download'];

                $raw = fetchDirect($hash, $servers);
                if ($raw !== null) {
                    $dec    = base64_decode($raw, true);
                    $binary = ($dec !== false) ? $dec : $raw;
                    $method = 'direct';
                    $log[]  = ['ok', 'Downloaded directly from server'];
                } else {
                    $error = 'File not found on any server and no local data available.';
                }
            }
        }

        // ── Step 4: infer extension and save ─────────────────
        if ($binary !== null && $error === '') {
            $outExt  = inferExtension($binary);
            $outPath = DOWNLOADED_DIR . '/' . $hash . '.' . $outExt;
            file_put_contents($outPath, $binary);
            $outSize = strlen($binary);
            $log[]   = ['ok', "Saved: {$hash}.{$outExt} (" . formatBytes($outSize) . ") via {$method}"];
            $success = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Fetch</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0d0f14;
    --surface:  #13161e;
    --border:   #1e2330;
    --accent:   #00e5a0;
    --accent2:  #0077ff;
    --yellow:   #f5c400;
    --red:      #ff3f5b;
    --text:     #d4dae8;
    --muted:    #5a6380;
    --mono:     'IBM Plex Mono', monospace;
    --sans:     'Space Grotesk', sans-serif;
    --radius:   6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent2);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 20px; height: 20px; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .header-link  {
    margin-left: auto;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent2);
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 4px 10px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  .header-link:hover { background: rgba(0,119,255,.12); }

  .container { max-width: 860px; margin: 0 auto; padding: 32px 24px 0; }

  nav {
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0;
  }
  nav button {
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans);
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }

  .tab { display: none; }
  .tab.active { display: block; }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted);
    margin-bottom: 18px;
  }

  .field { margin-bottom: 16px; }
  label  { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text] {
    width: 100%;
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-family: var(--mono);
    font-size: 15px;
    padding: 11px 14px;
    outline: none;
    letter-spacing: .06em;
    transition: border-color .15s;
  }
  input[type=text]:focus { border-color: var(--accent2); }
  input[type=text]::placeholder { color: var(--muted); font-size: 13px; letter-spacing: .03em; }

  button[type=submit], .btn {
    background: var(--accent);
    color: #0d0f14;
    border: none;
    border-radius: var(--radius);
    font-family: var(--sans);
    font-weight: 600;
    font-size: 13px;
    padding: 9px 20px;
    cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }

  .banner {
    padding: 12px 18px;
    border-radius: var(--radius);
    margin-bottom: 20px;
    font-size: 13px;
    font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08); border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);  border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);  border-color: var(--accent2); color: var(--accent2); }

  .result-box {
    background: #080a10;
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    padding: 18px 20px;
    margin-top: 16px;
    display: flex;
    align-items: flex-start;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .result-box .rl { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .result-box .rv { font-family: var(--mono); font-size: 16px; color: var(--accent); word-break: break-all; }
  .result-box .rm { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 6px; }
  .result-box .dl-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--accent2);
    color: #fff;
    font-family: var(--mono);
    font-size: 12px;
    font-weight: 600;
    padding: 9px 18px;
    border-radius: var(--radius);
    text-decoration: none;
    white-space: nowrap;
    transition: opacity .15s;
    align-self: center;
  }
  .result-box .dl-btn:hover { opacity: .85; }

  .log-box {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    max-height: 280px;
    overflow-y: auto;
    font-family: var(--mono);
    font-size: 12px;
    line-height: 1.7;
  }
  .log-line        { padding: 1px 0; }
  .log-line.ok     { color: var(--accent); }
  .log-line.ok::before    { content: '✓  '; }
  .log-line.error  { color: var(--red); }
  .log-line.error::before { content: '✗  '; }
  .log-line.info   { color: var(--accent2); }
  .log-line.info::before  { content: '→  '; }

  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px;
    text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .08em; }

  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left; font-size: 11px; font-weight: 600; color: var(--muted);
    text-transform: uppercase; letter-spacing: .08em; padding: 0 12px 10px;
    border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }
  .mono { font-family: var(--mono); font-size: 12px; }

  .tag {
    display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 600;
    padding: 2px 7px; border-radius: 3px; text-transform: uppercase; letter-spacing: .06em;
  }
  .tag.green  { background: rgba(0,229,160,.15); color: var(--accent);  border: 1px solid rgba(0,229,160,.3); }
  .tag.blue   { background: rgba(0,119,255,.15); color: var(--accent2); border: 1px solid rgba(0,119,255,.3); }
  .tag.yellow { background: rgba(245,196,0,.12); color: var(--yellow);  border: 1px solid rgba(245,196,0,.3); }
  .tag.red    { background: rgba(255,63,91,.12); color: var(--red);     border: 1px solid rgba(255,63,91,.3); }

  a.dl-link {
    color: var(--accent2); font-family: var(--mono); font-size: 11px; text-decoration: none;
    border: 1px solid var(--accent2); padding: 3px 9px; border-radius: var(--radius);
    transition: background .15s;
  }
  a.dl-link:hover { background: rgba(0,119,255,.12); }

  .steps { display: flex; flex-direction: column; gap: 14px; }
  .step  { display: flex; gap: 14px; }
  .step-n {
    width: 24px; height: 24px; border-radius: 50%; background: var(--accent2); color: #fff;
    font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; margin-top: 2px;
  }
  .step-body { font-size: 13px; line-height: 1.75; }
  .step-body strong { color: var(--accent2); }
  code {
    background: #080a10; border: 1px solid var(--border); border-radius: 3px;
    padding: 1px 5px; font-family: var(--mono); font-size: 11px; color: var(--accent);
  }

  /* ── Download Monitor ── */
  .mon-stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 16px;
  }
  .mon-stat {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    text-align: center;
  }
  .mon-stat span {
    display: block;
    font-size: 22px;
    font-weight: 700;
    font-family: var(--mono);
    color: var(--accent);
  }
  .mon-stat small {
    font-size: 10px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .08em;
  }

  .dl-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 18px 20px;
    margin-bottom: 12px;
    position: relative;
    overflow: hidden;
    transition: border-color .2s;
  }
  .dl-card.active  { border-color: var(--accent2); }
  .dl-card.done    { border-color: var(--accent); }
  .dl-card.error   { border-color: var(--red); }

  .dl-card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
    flex-wrap: wrap;
  }
  .dl-card-hash {
    font-family: var(--mono);
    font-size: 13px;
    color: var(--text);
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .dl-card-status {
    font-family: var(--mono);
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .08em;
    padding: 2px 8px;
    border-radius: 3px;
  }
  .dl-card-status.active  { background: rgba(0,119,255,.15); color: var(--accent2); border: 1px solid rgba(0,119,255,.3); }
  .dl-card-status.done    { background: rgba(0,229,160,.15); color: var(--accent);  border: 1px solid rgba(0,229,160,.3); }
  .dl-card-status.error   { background: rgba(255,63,91,.12); color: var(--red);     border: 1px solid rgba(255,63,91,.3); }
  .dl-card-status.queued  { background: rgba(245,196,0,.12); color: var(--yellow);  border: 1px solid rgba(245,196,0,.3); }

  .dl-progress-track {
    height: 6px;
    background: #080a10;
    border-radius: 3px;
    overflow: hidden;
    margin-bottom: 10px;
  }
  .dl-progress-fill {
    height: 100%;
    border-radius: 3px;
    background: var(--accent2);
    width: 0%;
    transition: width .3s ease, background .3s;
    position: relative;
  }
  .dl-progress-fill.done { background: var(--accent); }
  .dl-progress-fill.error { background: var(--red); }
  .dl-progress-fill::after {
    content: '';
    position: absolute;
    right: 0; top: 0; bottom: 0;
    width: 30px;
    background: linear-gradient(to right, transparent, rgba(255,255,255,.25));
    border-radius: 3px;
  }

  .dl-meta-row {
    display: flex;
    gap: 20px;
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    flex-wrap: wrap;
    align-items: center;
  }
  .dl-meta-row .val { color: var(--text); }
  .dl-meta-row .spd { color: var(--yellow); }

  .dl-log {
    margin-top: 10px;
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    max-height: 80px;
    overflow-y: auto;
    border-top: 1px solid var(--border);
    padding-top: 8px;
    line-height: 1.7;
  }
  .dl-log .ok    { color: var(--accent); }
  .dl-log .error { color: var(--red); }
  .dl-log .info  { color: var(--accent2); }

  .dl-open-link {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(0,229,160,.1);
    color: var(--accent);
    font-family: var(--mono);
    font-size: 11px;
    font-weight: 600;
    padding: 5px 12px;
    border-radius: var(--radius);
    text-decoration: none;
    border: 1px solid rgba(0,229,160,.3);
    transition: background .15s;
    margin-top: 10px;
    cursor: pointer;
  }
  .dl-open-link:hover { background: rgba(0,229,160,.2); }

  /* Completed list */
  .comp-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border);
    cursor: pointer;
    transition: background .1s;
    flex-wrap: wrap;
  }
  .comp-item:last-child { border-bottom: none; }
  .comp-item:hover { background: rgba(255,255,255,.02); margin: 0 -24px; padding: 10px 24px; }
  .comp-item-name {
    flex: 1;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent);
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .comp-item-size { font-family: var(--mono); font-size: 11px; color: var(--muted); }
  .comp-item-open {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--accent2);
    border: 1px solid var(--accent2);
    padding: 2px 8px;
    border-radius: 3px;
    text-decoration: none;
    transition: background .15s;
  }
  .comp-item-open:hover { background: rgba(0,119,255,.15); }

  /* Graph */
  #mon-graph-canvas { display: block; }

  /* Meta grid */
  .meta-cell {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 12px 14px;
  }
  .meta-cell-label { font-size: 10px; color: var(--muted); font-family: var(--mono); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 4px; }
  .meta-cell-value { font-size: 15px; font-family: var(--mono); color: var(--accent); font-weight: 600; }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>
      <path d="M2 17l10 5 10-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
      <path d="M2 12l10 5 10-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
    </svg>
  </div>
  <div>
    <div class="header-title">P2P Fetch</div>
    <div class="header-sub">chunks · assemble · decode · infer</div>
  </div>
  <a href="seeder.php" class="header-link">← Seeder</a>
</div>

<div class="container">

  <?php if ($error): ?>
  <div class="banner error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <nav>
    <button onclick="switchTab('download',this)" class="<?= $tab==='download'?'active':'' ?>">Fetch File</button>
    <button onclick="switchTab('monitor', this)" id="nav-monitor">⬇ Downloads</button>
    <button onclick="switchTab('history', this)" class="<?= $tab==='history' ?'active':'' ?>">History (<?= count($history) ?>)</button>
    <button onclick="switchTab('howto',   this)" class="<?= $tab==='howto'   ?'active':'' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       FETCH TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-download" class="tab <?= $tab==='download'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Fetch File by MD5 Hash</div>
      <form method="POST">
        <input type="hidden" name="tab" value="download">
        <div class="field">
          <label for="file_hash">MD5 File Hash</label>
          <input
            type="text" id="file_hash" name="file_hash"
            maxlength="32" autocomplete="off" spellcheck="false"
            placeholder="dd1b96f27453cca646d161e9408d0877"
            value="<?= htmlspecialchars($hash) ?>"
          >
        </div>
        <button type="submit" name="do_fetch">⬇ Fetch</button>
      </form>

      <?php if ($success): ?>
      <div class="result-box">
        <div>
          <div class="rl">File ready</div>
          <div class="rv"><?= htmlspecialchars(basename($outPath)) ?></div>
          <div class="rm">
            <?= formatBytes($outSize) ?>
            &nbsp;·&nbsp; <span style="color:var(--accent)">.<?= htmlspecialchars($outExt) ?></span>
            &nbsp;·&nbsp; <?= htmlspecialchars(DOWNLOADED_DIR) ?>
          </div>
        </div>
        <a class="dl-btn" href="?serve=<?= urlencode($hash) ?>">⬇ Save File</a>
      </div>
      <?php endif; ?>
    </div>

    <?php if (!empty($log)): ?>
    <div class="card">
      <div class="card-title">Transfer Log</div>
      <div class="log-box" id="logBox">
        <?php foreach ($log as [$type, $msg]): ?>
        <div class="log-line <?= htmlspecialchars($type) ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HISTORY TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-history" class="tab <?= $tab==='history'?'active':'' ?>">
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-val"><?= count($history) ?></div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= formatBytes(array_sum(array_column($history,'size'))) ?></div>
        <div class="stat-label">Total Size</div>
      </div>
    </div>

    <?php if (empty($history)): ?>
    <div class="card">
      <p style="color:var(--muted);font-family:var(--mono);font-size:13px;">No files downloaded yet.</p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Downloaded Files</div>
      <table>
        <tr><th>Filename</th><th>Type</th><th>Size</th><th>Date</th><th></th></tr>
        <?php foreach ($history as $f):
          $ext    = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
          $imgExts   = ['jpg','jpeg','png','gif','webp','bmp','ico'];
          $vidExts   = ['mp4','mkv','avi','flv','mov','wmv'];
          $audioExts = ['mp3','wav','flac','ogg','aac','m4a'];
          $docExts   = ['pdf','doc','docx','xls','xlsx','ppt','pptx'];
          $tagCls = 'green';
          if (in_array($ext, $vidExts))   $tagCls = 'yellow';
          elseif (in_array($ext, $audioExts)) $tagCls = 'blue';
          elseif (in_array($ext, $docExts))   $tagCls = 'red';
          $baseHash = preg_replace('/\.[^.]+$/', '', $f['name']);
        ?>
        <tr>
          <td class="mono" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= htmlspecialchars($f['name']) ?></td>
          <td><?php if ($ext): ?><span class="tag <?= $tagCls ?>">.<?= htmlspecialchars($ext) ?></span><?php endif; ?></td>
          <td class="mono"><?= formatBytes($f['size']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= date('Y-m-d H:i', $f['mtime']) ?></td>
          <td><?php if (isValidMd5($baseHash)): ?>
            <a class="dl-link" href="?serve=<?= urlencode($baseHash) ?>">⬇ Download</a>
          <?php endif; ?></td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       DOWNLOADS MONITOR TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-monitor" class="tab">

    <!-- Add download row -->
    <div class="card" style="margin-bottom:16px">
      <div class="card-title">Queue Download</div>
      <div style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
        <div style="flex:1;min-width:240px">
          <label for="mon-hash">MD5 File Hash</label>
          <input type="text" id="mon-hash" maxlength="32" autocomplete="off" spellcheck="false"
            placeholder="dd1b96f27453cca646d161e9408d0877"
            style="margin-bottom:0">
        </div>
        <button class="btn" id="mon-add-btn" onclick="monitorAddDownload()">⬇ Start Download</button>
        <button class="btn" id="mon-info-btn" onclick="monitorFetchInfo()"
          style="background:var(--accent2);color:#fff">🔍 Fetch Info + Graph</button>
      </div>
    </div>

    <!-- Stats row -->
    <div class="mon-stats-row" id="mon-stats" style="display:none">
      <div class="mon-stat"><span id="ms-active">0</span><small>Active</small></div>
      <div class="mon-stat"><span id="ms-done">0</span><small>Completed</small></div>
      <div class="mon-stat"><span id="ms-speed">0 B/s</span><small>Speed</small></div>
      <div class="mon-stat"><span id="ms-bytes">0 B</span><small>Downloaded</small></div>
    </div>

    <!-- Active downloads -->
    <div id="mon-active-area"></div>

    <!-- File Info + Popularity Graph -->
    <div id="mon-info-panel" style="display:none" class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:8px">
        <div class="card-title" style="margin-bottom:0">File Info &amp; Popularity</div>
        <span id="mon-info-hash" class="tag green" style="font-size:11px"></span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px" id="mon-meta-grid"></div>
      <div id="mon-info-text-box" style="display:none">
        <div style="font-size:11px;color:var(--muted);font-family:var(--mono);margin-bottom:8px;text-transform:uppercase;letter-spacing:.08em">Info File</div>
        <pre id="mon-info-text" style="background:#080a10;border:1px solid var(--border);border-radius:6px;padding:14px 16px;font-family:var(--mono);font-size:12px;color:var(--text);overflow-x:auto;white-space:pre-wrap;line-height:1.7"></pre>
      </div>
      <div id="mon-graph-area" style="margin-top:16px">
        <div style="font-size:11px;color:var(--muted);font-family:var(--mono);margin-bottom:10px;text-transform:uppercase;letter-spacing:.08em">Chunk Popularity — Servers Hosting Each Piece</div>
        <div id="mon-graph-wrap" style="background:#080a10;border:1px solid var(--border);border-radius:6px;padding:16px;overflow-x:auto">
          <canvas id="mon-graph-canvas" height="140"></canvas>
        </div>
        <div id="mon-graph-legend" style="display:flex;gap:18px;margin-top:10px;font-family:var(--mono);font-size:11px;color:var(--muted);flex-wrap:wrap"></div>
      </div>
    </div>

    <!-- Completed files -->
    <div id="mon-completed-area" style="display:none" class="card">
      <div class="card-title">Completed Files <span id="mon-done-count" class="tag green" style="font-size:10px;margin-left:6px"></span></div>
      <div id="mon-completed-list"></div>
    </div>

    <div id="mon-empty" class="card" style="text-align:center;padding:40px 24px;color:var(--muted);font-family:var(--mono);font-size:13px">
      No active downloads. Enter a hash above and click Start Download.
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HOW IT WORKS TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-howto" class="tab <?= $tab==='howto'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Fetch Logic — Step by Step</div>
      <div class="steps">
        <div class="step"><div class="step-n">1</div><div class="step-body">
          <strong>Local check</strong> — Scans <code>downloaded/</code> and <code>chunks/</code>
          for any file starting with the hash. If found, serves it immediately — zero network calls.
        </div></div>
        <div class="step"><div class="step-n">2</div><div class="step-body">
          <strong>Chunk index</strong> — Opens <code>hash_chunks/&lt;hash&gt;.txt</code>.
          Each line is the MD5 hash of one chunk, in assembly order.
          If the file is missing or has only one entry, falls through to direct download.
        </div></div>
        <div class="step"><div class="step-n">3</div><div class="step-body">
          <strong>Chunk fetch</strong> — For each line, builds the chunk filename:
          <code>&lt;fileHash&gt;.&lt;lineNumber&gt;.&lt;chunkHash&gt;</code>
          and requests it from each server at <code>&lt;server&gt;/chunks/&lt;filename&gt;</code>.
          MD5 of the received data is verified against the chunk hash. Cached locally in <code>chunks/</code>.
        </div></div>
        <div class="step"><div class="step-n">4</div><div class="step-body">
          <strong>Direct download fallback</strong> — If no chunk index (or single entry),
          fetches <code>&lt;server&gt;/chunks/&lt;hash&gt;</code> directly from each server.
        </div></div>
        <div class="step"><div class="step-n">5</div><div class="step-body">
          <strong>Assemble &amp; decode</strong> — Concatenates all Base64 chunks in line order,
          then decodes the full string to binary. If base64_decode fails, raw content is saved.
        </div></div>
        <div class="step"><div class="step-n">6</div><div class="step-body">
          <strong>Extension inference</strong> — Inspects the first 16 bytes for magic signatures:
          JPEG <code>FF D8 FF</code>, PNG <code>89 50 4E 47</code>, ZIP/DOCX <code>50 4B</code>,
          PDF <code>25 50 44 46</code>, MP3 <code>49 44 33</code>, MKV <code>1A 45 DF A3</code>, etc.
          Falls back to UTF-8 text detection (<code>.json</code>, <code>.html</code>, <code>.php</code>, <code>.txt</code>)
          and finally <code>.bin</code> for unknown binary.
        </div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Expected Directory Layout</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">servers.txt                              ← one server base URL per line</div>
        <div class="log-line info">hash_chunks/                             ← chunk-hash index (written by seeder)</div>
        <div class="log-line info">  &lt;fileHash&gt;.txt                       ← one MD5 chunkHash per line</div>
        <div class="log-line ok">chunks/                                  ← local chunk cache</div>
        <div class="log-line ok">  &lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;         ← individual chunk (base64)</div>
        <div class="log-line" style="color:var(--accent)">downloaded/                              ← assembled output</div>
        <div class="log-line" style="color:var(--accent)">  &lt;fileHash&gt;.&lt;inferred_ext&gt;           ← complete binary file</div>
        <br>
        <div class="log-line" style="color:var(--muted)">Remote servers expose:</div>
        <div class="log-line" style="color:var(--muted)">  &lt;server&gt;/chunks/&lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;</div>
      </div>
    </div>
  </div>

</div>

<script>
// ── Tab switcher ──────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}
const lb = document.getElementById('logBox');
if (lb) lb.scrollTop = lb.scrollHeight;

// ── Monitor state ─────────────────────────────────────────────
const downloads = {};   // hash → { id, hash, status, progress, speed, bytes, log, file, ext, size }
const completed = [];   // [{hash,file,ext,size}]

function fmtBytes(b) {
  if (b >= 1048576) return (b/1048576).toFixed(2)+' MB';
  if (b >= 1024)    return (b/1024).toFixed(1)+' KB';
  return b+' B';
}
function fmtSpeed(bps) {
  if (bps >= 1048576) return (bps/1048576).toFixed(1)+' MB/s';
  if (bps >= 1024)    return (bps/1024).toFixed(0)+' KB/s';
  return bps+' B/s';
}

// ── Add a download ────────────────────────────────────────────
function monitorAddDownload() {
  const input = document.getElementById('mon-hash');
  const hash  = input.value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(hash)) { alert('Invalid MD5 hash'); return; }
  if (downloads[hash]) { alert('Already queued or downloading'); return; }

  downloads[hash] = { hash, status:'queued', progress:0, speed:0, bytes:0, log:[], file:null };
  renderDownloads();
  updateStats();
  switchTab('monitor', document.getElementById('nav-monitor'));
  startSSEDownload(hash);
}

// ── SSE download stream ───────────────────────────────────────
function startSSEDownload(hash) {
  const dl  = downloads[hash];
  dl.status = 'active';
  renderDownloads();

  const es = new EventSource(`?api=stream_fetch&hash=${encodeURIComponent(hash)}`);
  dl.es = es;

  es.onmessage = e => {
    const d = JSON.parse(e.data);
    dl.log.push(d);
    if (d.progress !== undefined) dl.progress = d.progress;
    if (d.speed    !== undefined) dl.speed    = d.speed;
    if (d.bytes    !== undefined) dl.bytes    = d.bytes;

    if (d.type === 'done') {
      dl.status   = 'done';
      dl.progress = 100;
      dl.file     = d.file;
      dl.hash     = d.hash;
      dl.ext      = d.ext;
      dl.size     = d.size;
      completed.unshift({ hash: d.hash, file: d.file, ext: d.ext, size: d.size });
      renderCompleted();
      es.close();
    } else if (d.type === 'error' && d.done) {
      dl.status = 'error';
      es.close();
    }

    renderDlCard(hash);
    updateStats();
  };

  es.onerror = () => {
    if (dl.status !== 'done') dl.status = 'error';
    renderDlCard(hash);
    updateStats();
    es.close();
  };
}

// ── Render all download cards ─────────────────────────────────
function renderDownloads() {
  const area  = document.getElementById('mon-active-area');
  const empty = document.getElementById('mon-empty');
  const count = Object.keys(downloads).length;
  const stats = document.getElementById('mon-stats');

  if (count === 0) {
    empty.style.display = '';
    stats.style.display = 'none';
    area.innerHTML = '';
    return;
  }
  empty.style.display = 'none';
  stats.style.display = '';

  for (const hash of Object.keys(downloads)) {
    if (!document.getElementById('dlcard-' + hash)) {
      const card = document.createElement('div');
      card.id = 'dlcard-' + hash;
      area.appendChild(card);
    }
    renderDlCard(hash);
  }
}

function renderDlCard(hash) {
  const dl   = downloads[hash];
  const card = document.getElementById('dlcard-' + hash);
  if (!card) return;
  card.className = 'dl-card ' + dl.status;

  const lastMsgs = dl.log.slice(-5).reverse();
  const logHtml  = lastMsgs.map(m => {
    const cls = m.type === 'ok' ? 'ok' : m.type === 'error' ? 'error' : 'info';
    const icon = cls === 'ok' ? '✓' : cls === 'error' ? '✗' : '→';
    return `<div class="${cls}">${icon}  ${m.msg||''}</div>`;
  }).join('');

  const statusLabel = { active:'Downloading', done:'Complete', error:'Failed', queued:'Queued' }[dl.status] || dl.status;

  let bottomHtml = '';
  if (dl.status === 'done' && dl.hash) {
    bottomHtml = `<a class="dl-open-link" href="?serve=${encodeURIComponent(dl.hash)}" target="_blank">
      ↗ Open ${dl.file||dl.hash}</a>`;
  }

  card.innerHTML = `
    <div class="dl-card-header">
      <div class="dl-card-hash">${hash}</div>
      <div class="dl-card-status ${dl.status}">${statusLabel}</div>
      ${dl.ext ? `<span class="tag ${dl.ext === 'bin' ? '' : 'blue'}">.${dl.ext}</span>` : ''}
    </div>
    <div class="dl-progress-track">
      <div class="dl-progress-fill ${dl.status}" style="width:${dl.progress}%"></div>
    </div>
    <div class="dl-meta-row">
      <span>${dl.progress}%</span>
      ${dl.speed ? `<span>Speed: <span class="spd">${fmtSpeed(dl.speed)}</span></span>` : ''}
      ${dl.bytes ? `<span>Recv: <span class="val">${fmtBytes(dl.bytes)}</span></span>` : ''}
      ${dl.size  ? `<span>Size: <span class="val">${fmtBytes(dl.size)}</span></span>` : ''}
    </div>
    ${logHtml ? `<div class="dl-log">${logHtml}</div>` : ''}
    ${bottomHtml}
  `;
}

// ── Update global stats bar ───────────────────────────────────
function updateStats() {
  const all    = Object.values(downloads);
  const active = all.filter(d => d.status === 'active').length;
  const done   = all.filter(d => d.status === 'done').length;
  const speed  = all.reduce((s,d) => s + (d.speed||0), 0);
  const bytes  = all.reduce((s,d) => s + (d.bytes||0), 0);

  document.getElementById('ms-active').textContent = active;
  document.getElementById('ms-done').textContent   = done;
  document.getElementById('ms-speed').textContent  = fmtSpeed(speed);
  document.getElementById('ms-bytes').textContent  = fmtBytes(bytes);
}

// ── Render completed files panel ──────────────────────────────
function renderCompleted() {
  const area  = document.getElementById('mon-completed-area');
  const list  = document.getElementById('mon-completed-list');
  const count = document.getElementById('mon-done-count');
  if (completed.length === 0) { area.style.display = 'none'; return; }
  area.style.display = '';
  count.textContent  = completed.length;

  list.innerHTML = completed.map(f => `
    <div class="comp-item" onclick="window.open('?serve=${encodeURIComponent(f.hash)}','_blank')">
      <div class="comp-item-name">${f.file || f.hash}</div>
      ${f.size ? `<span class="comp-item-size">${fmtBytes(f.size)}</span>` : ''}
      ${f.ext  ? `<span class="tag green">.${f.ext}</span>` : ''}
      <a class="comp-item-open" href="?serve=${encodeURIComponent(f.hash)}" target="_blank"
         onclick="event.stopPropagation()">↗ Open</a>
    </div>
  `).join('');
}

// ── Fetch Info + Graph ────────────────────────────────────────
async function monitorFetchInfo() {
  const hash = document.getElementById('mon-hash').value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(hash)) { alert('Enter a valid MD5 hash first'); return; }

  const btn = document.getElementById('mon-info-btn');
  btn.textContent = '⏳ Loading…';
  btn.disabled    = true;
  switchTab('monitor', document.getElementById('nav-monitor'));

  try {
    const resp = await fetch(`?api=info&hash=${encodeURIComponent(hash)}`);
    const data = await resp.json();

    if (data.error) { alert('Error: ' + data.error); return; }

    const panel = document.getElementById('mon-info-panel');
    panel.style.display = '';

    // Hash badge
    document.getElementById('mon-info-hash').textContent = hash;

    // Meta grid
    const grid = document.getElementById('mon-meta-grid');
    const meta = [
      ['Hash',        hash],
      ['Total Chunks', data.total_chunks || 'N/A'],
      ['Servers',      data.servers      || '0'],
      ['Has Info File', data.info ? 'Yes' : 'No'],
    ];
    grid.innerHTML = meta.map(([l,v]) =>
      `<div class="meta-cell"><div class="meta-cell-label">${l}</div><div class="meta-cell-value">${v}</div></div>`
    ).join('');

    // Info text
    const infoBox  = document.getElementById('mon-info-text-box');
    const infoPre  = document.getElementById('mon-info-text');
    if (data.info) {
      infoBox.style.display = '';
      infoPre.textContent   = data.info;
    } else {
      infoBox.style.display = 'none';
    }

    // Graph
    drawPopularityGraph(data.chunk_coverage || []);

    // Legend
    const legend = document.getElementById('mon-graph-legend');
    const maxSrv = data.servers || 0;
    legend.innerHTML = `
      <span>🟦 High coverage (=${maxSrv} servers)</span>
      <span>🟨 Partial</span>
      <span>🟥 Not found (0 servers)</span>
    `;

    panel.scrollIntoView({ behavior:'smooth', block:'start' });
  } catch(e) {
    alert('Request failed: ' + e.message);
  } finally {
    btn.textContent = '🔍 Fetch Info + Graph';
    btn.disabled    = false;
  }
}

// ── Popularity bar chart ──────────────────────────────────────
function drawPopularityGraph(coverage) {
  const wrap   = document.getElementById('mon-graph-wrap');
  const canvas = document.getElementById('mon-graph-canvas');
  if (!coverage.length) {
    canvas.style.display = 'none';
    wrap.innerHTML = '<div style="font-family:var(--mono);font-size:12px;color:var(--muted);padding:8px">No chunk data available</div>';
    return;
  }
  canvas.style.display = 'block';

  const maxServers = Math.max(...coverage.map(c => c.servers), 1);
  const N     = coverage.length;
  const BAR_W = Math.max(6, Math.min(30, Math.floor((wrap.clientWidth - 64) / N)));
  const GAP   = Math.max(2, Math.floor(BAR_W * 0.25));
  const H     = 140;
  const CHART_H = H - 30;
  const W     = N * (BAR_W + GAP) + 40;

  canvas.width  = Math.max(W, wrap.clientWidth - 32);
  canvas.height = H;
  const ctx = canvas.getContext('2d');

  // BG
  ctx.fillStyle = '#080a10';
  ctx.fillRect(0, 0, canvas.width, H);

  // Grid lines
  for (let i = 0; i <= maxServers; i++) {
    const y = CHART_H - (i / maxServers) * CHART_H + 8;
    ctx.strokeStyle = 'rgba(255,255,255,0.04)';
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.moveTo(32, y); ctx.lineTo(canvas.width - 4, y);
    ctx.stroke();
    if (i === 0 || i === maxServers) {
      ctx.fillStyle = 'rgba(90,99,128,0.8)';
      ctx.font      = '9px IBM Plex Mono, monospace';
      ctx.fillText(i, 4, y + 3);
    }
  }

  // Bars
  coverage.forEach((c, i) => {
    const ratio  = maxServers > 0 ? c.servers / maxServers : 0;
    const barH   = Math.max(2, Math.floor(ratio * CHART_H));
    const x      = 32 + i * (BAR_W + GAP);
    const y      = CHART_H - barH + 8;
    const color  = ratio >= 0.8 ? '#00e5a0' : ratio >= 0.4 ? '#f5c400' : ratio > 0 ? '#0077ff' : '#ff3f5b';

    // Glow
    ctx.shadowColor = color;
    ctx.shadowBlur  = 4;

    const grad = ctx.createLinearGradient(0, y, 0, y + barH);
    grad.addColorStop(0, color);
    grad.addColorStop(1, color + '55');
    ctx.fillStyle = grad;
    ctx.fillRect(x, y, BAR_W, barH);

    ctx.shadowBlur = 0;
  });

  // X-axis labels (every N/8 chunks or so)
  const step = Math.max(1, Math.floor(N / 8));
  ctx.fillStyle = 'rgba(90,99,128,0.7)';
  ctx.font      = '9px IBM Plex Mono, monospace';
  coverage.forEach((c, i) => {
    if (i % step === 0 || i === N - 1) {
      const x = 32 + i * (BAR_W + GAP) + BAR_W / 2;
      ctx.textAlign = 'center';
      ctx.fillText(c.chunk, x, H - 4);
    }
  });
}
</script>
</body>
</html>