﻿<?php
// ============================================================
//  Seeder — File Chunker & Seeder for p2p.php
//  Drop in the same directory as p2p.php
//  Does NOT modify p2p.php in any way.
// ============================================================

define('BASE64_DIR',      __DIR__ . '/base64');
define('SEEDER_TMPDIR',   __DIR__ . '/seeder_tmp');
define('HASH_CHUNK_DIR',  __DIR__ . '/hash_chunks');
define('DEFAULT_CHUNK_SIZE', 512 * 1024); // 512 KB per chunk (before base64)
define('MAX_UPLOAD_MB', 200);

foreach ([BASE64_DIR, SEEDER_TMPDIR, HASH_CHUNK_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Core Logic
// ============================================================

// -- Write chunk hash to hash_chunk/<fileHash>.txt ---------------
function writeChunkHash(string $fileHash, string $chunkHash): void {
    $filePath = HASH_CHUNK_DIR . '/' . $fileHash . '.txt';
    $fh = fopen($filePath, 'a');
    if ($fh) {
        fwrite($fh, $chunkHash . "\n");
        fclose($fh);
    }
}

function chunkAndSeed(string $tmpPath, string $originalName, int $chunkSize): array {
    $fileHash    = md5_file($tmpPath);
    $fileSize    = filesize($tmpPath);
    $totalChunks = (int)ceil($fileSize / $chunkSize);
    $log         = [];
    $existingChunks = 0;
    $newChunks   = 0;

    $log[] = ['type' => 'info',    'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info',    'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info',    'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info',    'msg' => "Chunk size: " . formatBytes($chunkSize)];
    $log[] = ['type' => 'info',    'msg' => "Total chunks: {$totalChunks}"];

    $fh = fopen($tmpPath, 'rb');
    if (!$fh) {
        $log[] = ['type' => 'error', 'msg' => 'Could not open uploaded file.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash, 'total_chunks' => 0];
    }

    for ($i = 1; $i <= $totalChunks; $i++) {
        $raw       = fread($fh, $chunkSize);
        $encoded   = base64_encode($raw);
        $chunkHash = md5($encoded);
        $destPath  = BASE64_DIR . '/' . $fileHash . '.' . $i . '.' . $chunkHash;

        if (file_exists($destPath)) {
            $existingChunks++;
            $log[] = ['type' => 'skip', 'msg' => "Chunk {$i}/{$totalChunks} already exists — skipped"];
        } else {
            $written = file_put_contents($destPath, $encoded);
            if ($written === false) {
                $log[] = ['type' => 'error', 'msg' => "Chunk {$i}/{$totalChunks} FAILED to write"];
            } else {
                $newChunks++;
                $log[] = ['type' => 'ok', 'msg' => "Chunk {$i}/{$totalChunks} seeded ({$chunkHash})"];
                writeChunkHash($fileHash, $chunkHash);
            }
        }
    }
    fclose($fh);

    $log[] = ['type' => 'ok', 'msg' => "Done. {$newChunks} new chunk(s), {$existingChunks} skipped."];

    return [
        'success'      => true,
        'log'          => $log,
        'file_hash'    => $fileHash,
        'total_chunks' => $totalChunks,
        'new_chunks'   => $newChunks,
        'skipped'      => $existingChunks,
        'original_name'=> $originalName,
        'file_size'    => $fileSize,
    ];
}

function listSeededFiles(): array {
    $files   = glob(BASE64_DIR . '/*.*.*') ?: [];
    $byFile  = [];
    foreach ($files as $f) {
        $parts = explode('.', basename($f));
        if (count($parts) !== 3) continue;
        [$hash, $chunkNum, $chunkMd5] = $parts;
        $byFile[$hash]['chunks'][]  = (int)$chunkNum;
        $byFile[$hash]['size']      = ($byFile[$hash]['size'] ?? 0) + filesize($f);
    }
    foreach ($byFile as $hash => &$data) {
        sort($data['chunks']);
        $max              = max($data['chunks']);
        $data['count']    = count($data['chunks']);
        $data['max']      = $max;
        $data['complete'] = count($data['chunks']) === $max;
    }
    unset($data);
    arsort($byFile);
    return $byFile;
}

function deleteFileChunks(string $fileHash): int {
    if (!preg_match('/^[a-f0-9]{32}$/i', $fileHash)) return 0;
    $pattern = BASE64_DIR . '/' . $fileHash . '.*.*';
    $files   = glob($pattern) ?: [];
    foreach ($files as $f) unlink($f);
    return count($files);
}

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

// ============================================================
//  Handle Actions
// ============================================================

$result    = null;
$message   = '';
$msgType   = '';
$tab       = $_POST['tab'] ?? $_GET['tab'] ?? 'seed';

// ── Upload & seed ─────────────────────────────────────────────
if (isset($_POST['do_seed']) && isset($_FILES['upload_file'])) {
    $tab  = 'seed';
    $file = $_FILES['upload_file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload error code: ' . $file['error'];
        $msgType = 'error';
    } elseif ($file['size'] > MAX_UPLOAD_MB * 1024 * 1024) {
        $message = 'File exceeds ' . MAX_UPLOAD_MB . ' MB limit.';
        $msgType = 'error';
    } else {
        $chunkKb   = max(64, min(4096, (int)($_POST['chunk_kb'] ?? 512)));
        $chunkSize = $chunkKb * 1024;
        $tmpDest   = SEEDER_TMPDIR . '/' . basename($file['tmp_name']);
        move_uploaded_file($file['tmp_name'], $tmpDest);

        $result  = chunkAndSeed($tmpDest, $file['name'], $chunkSize);
        unlink($tmpDest);

        if ($result['success']) {
            $message = "File seeded successfully! Share the hash below with peers.";
            $msgType = 'ok';
        } else {
            $message = 'Seeding failed — check the log below.';
            $msgType = 'error';
        }
    }
}

// ── Delete file chunks ────────────────────────────────────────
if (isset($_POST['do_delete'])) {
    $tab      = 'manage';
    $delHash  = strtolower(trim($_POST['del_hash'] ?? ''));
    if (preg_match('/^[a-f0-9]{32}$/i', $delHash)) {
        $count   = deleteFileChunks($delHash);
        $message = "Removed {$count} chunk(s) for {$delHash}.";
        $msgType = 'ok';
    } else {
        $message = 'Invalid hash.';
        $msgType = 'error';
    }
}

$seededFiles = listSeededFiles();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Seeder</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0d0f14;
    --surface:  #13161e;
    --border:   #1e2330;
    --accent:   #00e5a0;
    --accent2:  #0077ff;
    --yellow:   #f5c400;
    --red:      #ff3f5b;
    --text:     #d4dae8;
    --muted:    #5a6380;
    --mono:     'IBM Plex Mono', monospace;
    --sans:     'Space Grotesk', sans-serif;
    --radius:   6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  /* ── Header ── */
  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 20px; height: 20px; fill: #0d0f14; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .header-link  {
    margin-left: auto;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent2);
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 4px 10px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  .header-link:hover { background: rgba(0,119,255,.12); }

  /* ── Layout ── */
  .container { max-width: 860px; margin: 0 auto; padding: 32px 24px 0; }

  /* ── Tabs ── */
  nav {
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0;
  }
  nav button {
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans);
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }

  .tab { display: none; }
  .tab.active { display: block; }

  /* ── Cards ── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted);
    margin-bottom: 18px;
  }

  /* ── Upload zone ── */
  .drop-zone {
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 40px 24px;
    text-align: center;
    cursor: pointer;
    transition: border-color .2s, background .2s;
    margin-bottom: 20px;
    position: relative;
  }
  .drop-zone:hover, .drop-zone.dragover {
    border-color: var(--accent);
    background: rgba(0,229,160,.04);
  }
  .drop-zone input[type=file] {
    position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
  }
  .drop-icon { font-size: 32px; margin-bottom: 10px; }
  .drop-label { color: var(--text); font-size: 14px; font-weight: 500; }
  .drop-hint  { color: var(--muted); font-size: 12px; margin-top: 4px; font-family: var(--mono); }
  .drop-chosen { color: var(--accent); font-size: 13px; margin-top: 8px; font-family: var(--mono); display: none; }

  /* ── Form controls ── */
  .field { margin-bottom: 16px; }
  label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  .form-row {
    display: flex;
    gap: 12px;
    align-items: flex-end;
    flex-wrap: wrap;
  }
  .form-row .field { margin-bottom: 0; flex: 1; min-width: 140px; }

  input[type=range] {
    width: 100%;
    accent-color: var(--accent);
    height: 4px;
    cursor: pointer;
  }
  .range-row { display: flex; align-items: center; gap: 12px; }
  .range-val {
    font-family: var(--mono);
    font-size: 13px;
    color: var(--accent);
    min-width: 70px;
    text-align: right;
  }

  button[type=submit], .btn {
    background: var(--accent);
    color: #0d0f14;
    border: none;
    border-radius: var(--radius);
    font-family: var(--sans);
    font-weight: 600;
    font-size: 13px;
    padding: 9px 20px;
    cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }
  .btn-danger { background: var(--red); color: #fff; }
  .btn-muted  { background: var(--border); color: var(--text); }

  /* ── Message banner ── */
  .banner {
    padding: 12px 18px;
    border-radius: var(--radius);
    margin-bottom: 20px;
    font-size: 13px;
    font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08); border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);  border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);  border-color: var(--accent2); color: var(--accent2); }

  /* ── Result hash box ── */
  .hash-box {
    background: #080a10;
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    padding: 18px 20px;
    margin-top: 16px;
  }
  .hash-box .hash-label { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .hash-box .hash-val {
    font-family: var(--mono);
    font-size: 20px;
    color: var(--accent);
    letter-spacing: .04em;
    word-break: break-all;
  }
  .hash-box .hash-meta { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 8px; }

  .copy-btn {
    background: rgba(0,229,160,.12);
    color: var(--accent);
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    font-family: var(--mono);
    font-size: 11px;
    padding: 4px 10px;
    cursor: pointer;
    margin-top: 10px;
    transition: background .15s;
  }
  .copy-btn:hover { background: rgba(0,229,160,.22); }

  /* ── Log box ── */
  .log-box {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    max-height: 280px;
    overflow-y: auto;
    font-family: var(--mono);
    font-size: 12px;
    line-height: 1.7;
  }
  .log-line { padding: 1px 0; }
  .log-line.ok   { color: var(--accent); }
  .log-line.skip { color: var(--muted); }
  .log-line.error{ color: var(--red); }
  .log-line.info { color: var(--accent2); }

  /* ── Stats grid ── */
  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px;
    text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .08em; }

  /* ── Seeded files table ── */
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .08em;
    padding: 0 12px 10px;
    border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }

  .mono   { font-family: var(--mono); font-size: 12px; color: var(--text); }
  .tag    {
    display: inline-block;
    font-family: var(--mono);
    font-size: 10px;
    font-weight: 600;
    padding: 2px 7px;
    border-radius: 3px;
    text-transform: uppercase;
    letter-spacing: .06em;
  }
  .tag.green { background: rgba(0,229,160,.15); color: var(--accent); border: 1px solid rgba(0,229,160,.3); }
  .tag.red   { background: rgba(255,63,91,.12);  color: var(--red);    border: 1px solid rgba(255,63,91,.3); }

  .del-form { display: inline; }
  .del-btn {
    background: none;
    border: 1px solid var(--border);
    color: var(--muted);
    font-size: 11px;
    font-family: var(--mono);
    padding: 3px 8px;
    border-radius: var(--radius);
    cursor: pointer;
    transition: border-color .15s, color .15s;
  }
  .del-btn:hover { border-color: var(--red); color: var(--red); }

  /* ── Scrollbar ── */
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
  </div>
  <div>
    <div class="header-title">P2P Seeder</div>
    <div class="header-sub">chunk · encode · serve</div>
  </div>
  <a href="p2p.php" class="header-link">← p2p.php</a>
</div>

<div class="container">

  <?php if ($message): ?>
  <div class="banner <?= htmlspecialchars($msgType) ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <!-- ── TABS ── -->
  <nav>
    <button onclick="switchTab('seed',  this)" class="<?= $tab==='seed'   ? 'active' : '' ?>">Seed a File</button>
    <button onclick="switchTab('manage',this)" class="<?= $tab==='manage' ? 'active' : '' ?>">
      Manage (<?= count($seededFiles) ?>)
    </button>
    <button onclick="switchTab('help',  this)" class="<?= $tab==='help'   ? 'active' : '' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       SEED TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-seed" class="tab <?= $tab==='seed' ? 'active' : '' ?>">

    <div class="card">
      <div class="card-title">Upload &amp; Seed File</div>

      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="tab" value="seed">

        <div class="drop-zone" id="dropZone">
          <input type="file" name="upload_file" id="fileInput" required>
          <div class="drop-icon">📦</div>
          <div class="drop-label">Drop file here or click to browse</div>
          <div class="drop-hint">Max <?= MAX_UPLOAD_MB ?> MB · Any file type</div>
          <div class="drop-chosen" id="chosenName"></div>
        </div>

        <div class="field">
          <label>Chunk Size</label>
          <div class="range-row">
            <input type="range" name="chunk_kb" id="chunkRange"
                   min="64" max="4096" step="64"
                   value="<?= (int)($_POST['chunk_kb'] ?? 512) ?>">
            <span class="range-val" id="rangeLabel">512 KB</span>
          </div>
        </div>

        <button type="submit" name="do_seed">⚡ Chunk &amp; Seed</button>
      </form>
    </div>

    <?php if ($result && $result['success']): ?>
    <div class="card">
      <div class="card-title">Seeded Successfully</div>

      <div class="hash-box">
        <div class="hash-label">File Hash (MD5) — share this with peers</div>
        <div class="hash-val" id="resultHash"><?= htmlspecialchars($result['file_hash']) ?></div>
        <div class="hash-meta">
          <?= htmlspecialchars($result['original_name']) ?>
          &nbsp;·&nbsp; <?= formatBytes($result['file_size']) ?>
          &nbsp;·&nbsp; <?= $result['total_chunks'] ?> chunks
          &nbsp;·&nbsp; <?= $result['new_chunks'] ?> new, <?= $result['skipped'] ?> skipped
        </div>
        <button class="copy-btn" onclick="copyHash()">Copy Hash</button>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Chunk Log</div>
      <div class="log-box">
        <?php foreach ($result['log'] as $entry): ?>
        <div class="log-line <?= htmlspecialchars($entry['type']) ?>">
          <?= htmlspecialchars($entry['msg']) ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($result && !$result['success']): ?>
    <div class="card">
      <div class="card-title">Error Log</div>
      <div class="log-box">
        <?php foreach ($result['log'] as $entry): ?>
        <div class="log-line <?= htmlspecialchars($entry['type']) ?>"><?= htmlspecialchars($entry['msg']) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       MANAGE TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-manage" class="tab <?= $tab==='manage' ? 'active' : '' ?>">

    <?php
    $totalChunkCount = array_sum(array_column($seededFiles, 'count'));
    $totalSize       = array_sum(array_column($seededFiles, 'size'));
    $completeCount   = count(array_filter($seededFiles, fn($f) => $f['complete']));
    ?>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-val"><?= count($seededFiles) ?></div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= $totalChunkCount ?></div>
        <div class="stat-label">Total Chunks</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= $completeCount ?></div>
        <div class="stat-label">Complete</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= formatBytes($totalSize) ?></div>
        <div class="stat-label">Disk Used</div>
      </div>
    </div>

    <?php if (empty($seededFiles)): ?>
    <div class="card">
      <p style="color:var(--muted); font-family:var(--mono); font-size:13px;">
        No chunks seeded yet. Use the "Seed a File" tab to add files.
      </p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Seeded Files</div>
      <table>
        <tr>
          <th>File Hash</th>
          <th>Chunks</th>
          <th>Size (chunks)</th>
          <th>Status</th>
          <th></th>
        </tr>
        <?php foreach ($seededFiles as $hash => $data): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($hash) ?></td>
          <td><?= $data['count'] ?> / <?= $data['max'] ?></td>
          <td class="mono"><?= formatBytes($data['size']) ?></td>
          <td>
            <?php if ($data['complete']): ?>
              <span class="tag green">complete</span>
            <?php else: ?>
              <span class="tag red">partial</span>
            <?php endif; ?>
          </td>
          <td>
            <form method="POST" class="del-form"
                  onsubmit="return confirm('Remove all chunks for this file?')">
              <input type="hidden" name="tab"      value="manage">
              <input type="hidden" name="del_hash" value="<?= htmlspecialchars($hash) ?>">
              <button type="submit" name="do_delete" class="del-btn">✕ Remove</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HELP TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-help" class="tab <?= $tab==='help' ? 'active' : '' ?>">
    <div class="card">
      <div class="card-title">How Seeding Works</div>
      <div style="line-height:1.8; color:var(--text); font-size:13px;">
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">1. Upload</strong> — You pick any file (up to <?= MAX_UPLOAD_MB ?> MB).
          The seeder computes its <span class="mono" style="background:#080a10;padding:1px 5px;border-radius:3px;">MD5</span>
          which becomes the permanent file identifier used by all peers.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">2. Chunk</strong> — The file is split into fixed-size pieces.
          Each piece is Base64-encoded and its own MD5 is computed for integrity checking.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">3. Store</strong> — Chunks are saved into the <span class="mono" style="background:#080a10;padding:1px 5px;border-radius:3px;">base64/</span>
          directory using the naming convention <span class="mono" style="background:#080a10;padding:1px 5px;border-radius:3px;">&lt;file_md5&gt;.&lt;chunk#&gt;.&lt;chunk_md5&gt;</span>
          — exactly what <code>p2p.php</code> expects.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">4. Serve</strong> — As soon as chunks exist in <span class="mono" style="background:#080a10;padding:1px 5px;border-radius:3px;">base64/</span>,
          <code>p2p.php</code> will start answering <code>?action=get_chunk</code> requests from peers automatically.
          No restart needed.
        </p>
        <p>
          <strong style="color:var(--accent)">5. Share</strong> — Give the file's MD5 hash to anyone running
          <code>p2p.php</code>. They paste it in the Download tab and fetch all chunks from your node
          (and any other node that has them).
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Directory Layout</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">base64/                    ← chunks served by p2p.php</div>
        <div class="log-line info">  &lt;file_md5&gt;.1.&lt;chunk_md5&gt;  ← chunk 1</div>
        <div class="log-line info">  &lt;file_md5&gt;.2.&lt;chunk_md5&gt;  ← chunk 2</div>
        <div class="log-line info">  ...                        ← chunk N</div>
        <div class="log-line skip">seeder_tmp/                ← used during upload, auto-cleaned</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Chunk Size Guide</div>
      <table>
        <tr><th>Size</th><th>Best For</th></tr>
        <tr><td class="mono">64 – 128 KB</td><td>Small files, slow connections, many peers</td></tr>
        <tr><td class="mono">256 – 512 KB</td><td>General use (default)</td></tr>
        <tr><td class="mono">1 – 2 MB</td><td>Large files, fast connections, few peers</td></tr>
        <tr><td class="mono">4 MB</td><td>Very large files, LAN / local network only</td></tr>
      </table>
    </div>
  </div>

</div><!-- /container -->

<script>
// ── Tab switching ─────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// ── Chunk size label ──────────────────────────────────────────
const range = document.getElementById('chunkRange');
const label = document.getElementById('rangeLabel');
function updateLabel() {
  const kb = parseInt(range.value);
  label.textContent = kb >= 1024 ? (kb/1024) + ' MB' : kb + ' KB';
}
range.addEventListener('input', updateLabel);
updateLabel();

// ── File input label ──────────────────────────────────────────
const fileInput  = document.getElementById('fileInput');
const chosenName = document.getElementById('chosenName');
const dropZone   = document.getElementById('dropZone');

fileInput.addEventListener('change', () => {
  if (fileInput.files.length > 0) {
    chosenName.style.display = 'block';
    chosenName.textContent   = '✓ ' + fileInput.files[0].name;
  }
});

dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  if (e.dataTransfer.files.length > 0) {
    fileInput.files = e.dataTransfer.files;
    chosenName.style.display = 'block';
    chosenName.textContent   = '✓ ' + e.dataTransfer.files[0].name;
  }
});

// ── Copy hash ─────────────────────────────────────────────────
function copyHash() {
  const hash = document.getElementById('resultHash');
  if (!hash) return;
  navigator.clipboard.writeText(hash.textContent.trim()).then(() => {
    const btn = document.querySelector('.copy-btn');
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = 'Copy Hash', 1800);
  });
}
</script>
</body>
</html>