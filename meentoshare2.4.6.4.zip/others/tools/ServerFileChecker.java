import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;
import javax.net.ssl.*;
import java.security.cert.X509Certificate;

/**
 * ServerFileChecker
 *
 * For each server listed in servers.txt, fetches:
 *   - files.txt       : lines that may be filenames (hash.ext)
 *   - public_key.txt  : raw content kept as-is
 *   - node_info.txt   : raw content kept as-is
 *
 * A "filename line" is one whose stem looks like a hex digest:
 *   - 32 hex chars  ? MD5
 *   - 64 hex chars  ? SHA-256
 *
 * The file is downloaded from <server>/files/<filename>.
 * Its actual digest is compared to the stem; a match scores +1 point.
 *
 * Results are written to results.txt in descending order of matched files.
 * Each output line:  url-serverSha256-matchCount-publicKey-nodeInfo
 *
 * The user is also asked whether to save every matched file locally under ./files/.
 *
 * Compatible with Java 14+.  No external libraries.
 */
public class ServerFileChecker {

    // --- helpers ------------------------------------------------------------

    /** Disable SSL certificate validation so both http and self-signed https work. */
    private static void trustAllCerts() {
        try {
            TrustManager[] trustAll = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] c, String a) {}
                    public void checkServerTrusted(X509Certificate[] c, String a) {}
                }
            };
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAll, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((host, session) -> true);
        } catch (Exception e) {
            System.err.println("[WARN] Could not install trust-all SSL manager: " + e.getMessage());
        }
    }

    /** Fetch a URL as a UTF-8 string.  Returns null on any error. */
    private static String fetchText(String url) {
        try {
            URLConnection conn = new URL(url).openConnection();
            conn.setConnectTimeout(8_000);
            conn.setReadTimeout(15_000);
            conn.setRequestProperty("User-Agent", "ServerFileChecker/1.0");
            try (InputStream in = conn.getInputStream();
                 ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[4096];
                int n;
                while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                return buf.toString(StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** Fetch a URL as raw bytes.  Returns null on any error. */
    private static byte[] fetchBytes(String url) {
        try {
            URLConnection conn = new URL(url).openConnection();
            conn.setConnectTimeout(8_000);
            conn.setReadTimeout(30_000);
            conn.setRequestProperty("User-Agent", "ServerFileChecker/1.0");
            try (InputStream in = conn.getInputStream();
                 ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[4096];
                int n;
                while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                return buf.toByteArray();
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** Compute hex digest of bytes using the given algorithm ("MD5" or "SHA-256"). */
    private static String hexDigest(byte[] data, String algorithm) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            byte[] digest = md.digest(data);
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);          // MD5 & SHA-256 always available
        }
    }

    /** SHA-256 hex digest of a plain string (used for IP ? server ID). */
    private static String sha256hex(String text) {
        return hexDigest(text.getBytes(StandardCharsets.UTF_8), "SHA-256");
    }

    /**
     * Decide whether a line looks like a hash filename.
     * Returns the algorithm name if yes, null if no.
     *  - stem length 32  ? MD5
     *  - stem length 64  ? SHA-256
     */
    private static String detectAlgorithm(String line) {
        line = line.trim();
        int dot = line.lastIndexOf('.');
        if (dot < 0) return null;
        String stem = line.substring(0, dot);
        if (!stem.matches("[0-9a-fA-F]+")) return null;
        if (stem.length() == 32) return "MD5";
        if (stem.length() == 64) return "SHA-256";
        return null;
    }

    /** Normalise a server URL: strip trailing slash, ensure scheme present. */
    private static String normalise(String raw) {
        raw = raw.trim();
        if (raw.isEmpty()) return raw;
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) {
            raw = "http://" + raw;
        }
        return raw.endsWith("/") ? raw.substring(0, raw.length() - 1) : raw;
    }

    /** Extract the host/IP portion from a URL string. */
    private static String extractHost(String url) {
        try {
            return new URL(url).getHost();
        } catch (MalformedURLException e) {
            return url;
        }
    }

    // --- main ---------------------------------------------------------------

    public static void main(String[] args) throws Exception {

        trustAllCerts();

        Scanner console = new Scanner(System.in);

        // Ask whether to download matched files locally
        System.out.print("Download matched files into local ./files/ folder? (yes/no): ");
        String answer = console.nextLine().trim().toLowerCase();
        boolean downloadFiles = answer.equals("yes") || answer.equals("y");

        if (downloadFiles) {
            new File("files").mkdirs();
        }

        // Read server list
        List<String> servers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("servers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String s = normalise(line);
                if (!s.isEmpty()) servers.add(s);
            }
        }

        if (servers.isEmpty()) {
            System.out.println("No servers found in servers.txt. Exiting.");
            return;
        }

        System.out.printf("Found %d server(s) in servers.txt.%n%n", servers.size());

        List<ServerResult> results = new ArrayList<>();

        for (String serverUrl : servers) {

            System.out.println("---------------------------------------");
            System.out.println("Server : " + serverUrl);

            String host = extractHost(serverUrl);
            String serverId = sha256hex(host);
            System.out.println("ID     : " + serverId);

            // -- fetch the three required files ---------------------------

            String filesIndex  = fetchText(serverUrl + "/files.txt");
            String publicKey   = fetchText(serverUrl + "/public_key.txt");
            String nodeInfo    = fetchText(serverUrl + "/node_info.txt");

            if (filesIndex == null) {
                System.out.println("[SKIP] Could not fetch files.txt");
                results.add(new ServerResult(serverUrl, serverId, 0,
                        publicKey  == null ? "-" : publicKey.trim(),
                        nodeInfo   == null ? "-" : nodeInfo.trim()));
                continue;
            }

            String pubKeyClean  = (publicKey != null) ? publicKey.trim()  : "-";
            String nodeInfoClean = (nodeInfo != null) ? nodeInfo.trim()   : "-";

            // -- walk each line of files.txt -------------------------------

            int matches = 0;
            String[] lines = filesIndex.split("\\r?\\n");

            for (String rawLine : lines) {
                String filename = rawLine.trim();
                if (filename.isEmpty()) continue;

                String algorithm = detectAlgorithm(filename);
                if (algorithm == null) continue;   // not a hash filename

                String fileUrl = serverUrl + "/files/" + filename;
                byte[] content = fetchBytes(fileUrl);

                if (content == null) {
                    System.out.printf("  [MISS ] %-70s  (download failed)%n", filename);
                    continue;
                }

                // stem is everything before the last dot
                String stem = filename.substring(0, filename.lastIndexOf('.')).toLowerCase();
                String actual = hexDigest(content, algorithm).toLowerCase();
                boolean ok = stem.equals(actual);

                System.out.printf("  [%s] %s  (%s)%n",
                        ok ? "MATCH" : "FAIL ",
                        filename,
                        algorithm);

                if (ok) {
                    matches++;
                    if (downloadFiles) {
                        File dest = new File("files", filename);
                        try (FileOutputStream fos = new FileOutputStream(dest)) {
                            fos.write(content);
                        }
                        System.out.printf("       ? saved to files/%s%n", filename);
                    }
                }
            }

            System.out.printf("  Score: %d verified file(s)%n", matches);
            results.add(new ServerResult(serverUrl, serverId, matches, pubKeyClean, nodeInfoClean));
        }

        // -- sort descending by match count --------------------------------
        results.sort(Comparator.comparingInt(ServerResult::matchCount).reversed());

        // -- write results.txt ---------------------------------------------
        String outputPath = "results.txt";
        try (PrintWriter pw = new PrintWriter(new FileWriter(outputPath))) {
            for (ServerResult r : results) {
                // Flatten multi-line public key / node info to a single line
                String pk = r.publicKey().replace("\n", " ").replace("\r", "");
                String ni = r.nodeInfo().replace("\n", " ").replace("\r", "");
                pw.printf("%s-%s-%d-%s-%s%n",
                        r.url(), r.serverId(), r.matchCount(), pk, ni);
            }
        }

        System.out.println("\n---------------------------------------");
        System.out.println("Results saved to: " + outputPath);
        System.out.println("\nTop servers (descending by verified files):");
        for (ServerResult r : results) {
            System.out.printf("  %s  ->  %d match(es)%n", r.url(), r.matchCount());
        }
    }

    // -- replaces the Java 16 record � compatible with Java 8+ ---------------
    private static final class ServerResult {
        private final String url;
        private final String serverId;
        private final int    matchCount;
        private final String publicKey;
        private final String nodeInfo;

        ServerResult(String url, String serverId, int matchCount,
                     String publicKey, String nodeInfo) {
            this.url        = url;
            this.serverId   = serverId;
            this.matchCount = matchCount;
            this.publicKey  = publicKey;
            this.nodeInfo   = nodeInfo;
        }

        String url()        { return url; }
        String serverId()   { return serverId; }
        int    matchCount() { return matchCount; }
        String publicKey()  { return publicKey; }
        String nodeInfo()   { return nodeInfo; }
    }
}