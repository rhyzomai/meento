﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH BLOCKCHAIN  —  Transfer ledger for Mesh Node
//  Single-file PHP 7.4+ library — include or require from any project
//
//  Usage:
//    require_once 'blockchain.php';
//    $chain = new MeshBlockchain();                    // uses defaults
//    $chain = new MeshBlockchain('/custom/path');      // custom blocks dir
//
//  After a successful Mesh Node file transfer:
//    $result = $chain->recordTransfer([
//        'filename'        => 'photo.jpg',
//        'hash'            => 'abc123...',
//        'size'            => 204800,
//        'description'     => 'Optional comment',
//        'public_key'      => '...pem...',
//        'node_info'       => 'node-42',
//        'peers_reached'   => ['https://node1.example.com', 'https://node2.example.com'],
//        'peers_failed'    => [],
//        'sender_ip'       => $_SERVER['REMOTE_ADDR'] ?? '',
//    ]);
//    // $result = ['ok' => true, 'block_index' => 5, 'block_hash' => '...', 'filename' => 'block_5.json']
//
//  Broadcast the new block to peers automatically:
//    $chain->broadcastBlock($result['block_index'], $servers);
//
//  Validate the entire chain:
//    ['valid' => true/false, 'broken_at' => null|int, 'length' => int]
//    = $chain->validateChain();
//
//  List all blocks:
//    $blocks = $chain->listBlocks();          // array of decoded block arrays
//
//  Get a single block:
//    $block = $chain->getBlock(3);            // by index
//    $block = $chain->getBlock('abc123...');  // by block_hash
//
//  Receive a block pushed by a remote peer (call from your POST handler):
//    $chain->receivePeerBlock($_POST['block_json'] ?? '');
// ═══════════════════════════════════════════════════════════════════════════════

class MeshBlockchain
{
    // ── constants ──────────────────────────────────────────────────────────────
    public const VERSION        = '1.0.0';
    public const GENESIS_PREV   = '0000000000000000000000000000000000000000000000000000000000000000';
    public const ALGO           = 'sha256';
    public const PEER_PUSH_PARAM = 'bc_peer_push';
    public const PEER_ENDPOINT_PARAM = 'bc_receive';
    public const BLOCK_FILE_PREFIX = 'block_';

    // ── state ──────────────────────────────────────────────────────────────────
    private string $blocksDir;
    private string $indexFile;   // JSON index of all block filenames in order
    private int    $httpTimeout = 20;

    // ──────────────────────────────────────────────────────────────────────────
    public function __construct(string $blocksDir = '')
    {
        $this->blocksDir = $blocksDir !== ''
            ? rtrim($blocksDir, '/\\')
            : dirname(__FILE__) . '/json_blocks';

        $this->indexFile = $this->blocksDir . '/chain_index.json';

        if (!is_dir($this->blocksDir)) {
            mkdir($this->blocksDir, 0755, true);
        }

        // Create genesis block if chain is empty
        if ($this->chainLength() === 0) {
            $this->writeGenesisBlock();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Record a completed file transfer as a new block.
     *
     * @param  array $transfer  Associative array with transfer metadata.
     *                          All keys are optional but recommended:
     *                          filename, hash, size, extension, description,
     *                          public_key, node_info, peers_reached, peers_failed,
     *                          sender_ip, extra (free-form array).
     * @return array  ['ok'=>bool, 'block_index'=>int, 'block_hash'=>string,
     *                 'filename'=>string, 'error'=>string|null]
     */
    public function recordTransfer(array $transfer): array
    {
        $tip = $this->getTipBlock();
        if ($tip === null) {
            return ['ok' => false, 'error' => 'Chain is corrupt — no tip block found.'];
        }

        $index     = (int)$tip['index'] + 1;
        $prevHash  = $tip['block_hash'];
        $timestamp = microtime(true);

        $blockData = $this->buildBlockData($index, $prevHash, $timestamp, $transfer);
        $blockHash = $this->computeBlockHash($blockData);
        $blockData['block_hash'] = $blockHash;

        $result = $this->saveBlock($blockData);
        if (!$result['ok']) {
            return $result;
        }

        $this->appendToIndex($result['filename'], $index);

        return [
            'ok'          => true,
            'block_index' => $index,
            'block_hash'  => $blockHash,
            'filename'    => $result['filename'],
            'error'       => null,
        ];
    }

    /**
     * Broadcast a block (by index) to all mesh peer servers.
     *
     * @param  int    $blockIndex
     * @param  array  $servers  List of peer URLs (same format as servers.txt)
     * @return array  Per-peer results [['server'=>..., 'ok'=>bool, 'error'=>...], ...]
     */
    public function broadcastBlock(int $blockIndex, array $servers): array
    {
        $block = $this->getBlock($blockIndex);
        if ($block === null) {
            return [['ok' => false, 'error' => "Block {$blockIndex} not found."]];
        }

        $json    = json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $results = [];

        foreach ($servers as $server) {
            $server    = rtrim(trim($server), '/');
            if (!preg_match('#^https?://#i', $server)) {
                $server = 'http://' . $server;
            }
            $results[] = $this->pushBlockToServer($server, $json);
        }

        return $results;
    }

    /**
     * Receive a block pushed by a remote peer (call from your POST handler).
     * Validates and appends the block if it fits the chain tip.
     *
     * @param  string $rawJson   Raw JSON string of the block.
     * @return array  ['ok'=>bool, 'block_index'=>int|null, 'error'=>string|null]
     */
    public function receivePeerBlock(string $rawJson): array
    {
        if ($rawJson === '') {
            return ['ok' => false, 'block_index' => null, 'error' => 'Empty payload.'];
        }

        $block = json_decode($rawJson, true);
        if (!is_array($block)) {
            return ['ok' => false, 'block_index' => null, 'error' => 'Invalid JSON.'];
        }

        // Structural check
        foreach (['index', 'prev_hash', 'timestamp', 'block_hash', 'transfer'] as $key) {
            if (!array_key_exists($key, $block)) {
                return ['ok' => false, 'block_index' => null, 'error' => "Missing field: {$key}."];
            }
        }

        $index = (int)$block['index'];

        // Already have this block?
        if ($this->getBlock($index) !== null) {
            return ['ok' => true, 'block_index' => $index, 'existed' => true, 'error' => null];
        }

        // Hash integrity
        $expectedHash = $this->computeBlockHash($block);
        if ($expectedHash !== $block['block_hash']) {
            return ['ok' => false, 'block_index' => $index, 'error' => 'Block hash mismatch.'];
        }

        // Chain linkage: must extend our current tip
        $tip = $this->getTipBlock();
        if ($tip === null || (int)$tip['index'] + 1 !== $index) {
            return [
                'ok'          => false,
                'block_index' => $index,
                'error'       => "Out-of-order block (expected index " . ((int)($tip['index'] ?? -1) + 1) . ", got {$index}).",
            ];
        }

        if ($tip['block_hash'] !== $block['prev_hash']) {
            return ['ok' => false, 'block_index' => $index, 'error' => 'prev_hash does not match chain tip.'];
        }

        $result = $this->saveBlock($block);
        if (!$result['ok']) {
            return ['ok' => false, 'block_index' => $index, 'error' => $result['error']];
        }

        $this->appendToIndex($result['filename'], $index);

        return ['ok' => true, 'block_index' => $index, 'existed' => false, 'error' => null];
    }

    /**
     * Validate the integrity of the entire chain.
     *
     * @return array ['valid'=>bool, 'broken_at'=>int|null, 'length'=>int, 'errors'=>string[]]
     */
    public function validateChain(): array
    {
        $index   = $this->loadIndex();
        $length  = count($index);
        $errors  = [];
        $prevHash = self::GENESIS_PREV;

        for ($i = 0; $i < $length; $i++) {
            $filename = $index[$i] ?? null;
            if ($filename === null) {
                $errors[] = "Index entry {$i} is missing.";
                return ['valid' => false, 'broken_at' => $i, 'length' => $length, 'errors' => $errors];
            }

            $block = $this->loadBlockFile($filename);
            if ($block === null) {
                $errors[] = "Block file not found: {$filename}";
                return ['valid' => false, 'broken_at' => $i, 'length' => $length, 'errors' => $errors];
            }

            // Index consistency
            if ((int)$block['index'] !== $i) {
                $errors[] = "Block {$filename}: index mismatch (stored={$block['index']}, expected={$i}).";
                return ['valid' => false, 'broken_at' => $i, 'length' => $length, 'errors' => $errors];
            }

            // prev_hash linkage
            if ($block['prev_hash'] !== $prevHash) {
                $errors[] = "Block {$i}: prev_hash mismatch.";
                return ['valid' => false, 'broken_at' => $i, 'length' => $length, 'errors' => $errors];
            }

            // Hash integrity — compute without block_hash field
            $computedHash = $this->computeBlockHash($block);
            if ($computedHash !== $block['block_hash']) {
                $errors[] = "Block {$i}: block_hash tampered.";
                return ['valid' => false, 'broken_at' => $i, 'length' => $length, 'errors' => $errors];
            }

            $prevHash = $block['block_hash'];
        }

        return ['valid' => true, 'broken_at' => null, 'length' => $length, 'errors' => []];
    }

    /**
     * Return all blocks as an array of decoded arrays, oldest first.
     * Pass $includeGenesis = false to skip block 0.
     */
    public function listBlocks(bool $includeGenesis = true): array
    {
        $index  = $this->loadIndex();
        $blocks = [];
        $start  = $includeGenesis ? 0 : 1;

        for ($i = $start; $i < count($index); $i++) {
            $block = $this->loadBlockFile($index[$i]);
            if ($block !== null) {
                $blocks[] = $block;
            }
        }

        return $blocks;
    }

    /**
     * Get a single block by index (int) or block_hash (string).
     * Returns null if not found.
     */
    /** @param int|string $indexOrHash */
    public function getBlock($indexOrHash): ?array
    {
        if (is_int($indexOrHash)) {
            $idx = $this->loadIndex();
            $filename = $idx[$indexOrHash] ?? null;
            return $filename ? $this->loadBlockFile($filename) : null;
        }

        // Search by hash — scan index
        foreach ($this->loadIndex() as $filename) {
            $block = $this->loadBlockFile($filename);
            if ($block !== null && $block['block_hash'] === $indexOrHash) {
                return $block;
            }
        }

        return null;
    }

    /**
     * Returns the number of blocks in the chain (including genesis).
     */
    public function chainLength(): int
    {
        return count($this->loadIndex());
    }

    /**
     * Returns a summary suitable for the Mesh Node ?node_status endpoint.
     */
    public function status(): array
    {
        $validation = $this->validateChain();
        $tip        = $this->getTipBlock();

        return [
            'chain_length'    => $validation['length'],
            'chain_valid'     => $validation['valid'],
            'tip_index'       => $tip['index'] ?? null,
            'tip_hash'        => $tip['block_hash'] ?? null,
            'tip_timestamp'   => $tip['timestamp'] ?? null,
            'blockchain_dir'  => $this->blocksDir,
            'version'         => self::VERSION,
        ];
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  INTEGRATION HELPERS  (drop-in handlers for Mesh Node's endpoints)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Call this inside Mesh Node's successful upload handler.
     * It reads the already-populated $result / $peerResults arrays and records
     * the transfer, then broadcasts the block to peers.
     *
     * Example (paste into index.php just before the final jsonOut):
     *
     *   $bc = new MeshBlockchain();
     *   $bcResult = $bc->handleSuccessfulUpload(
     *       $local, $peerResults, $upload['name'],
     *       $description, $publicKey, $nodeInfo, $servers
     *   );
     *   // Optionally include $bcResult in the JSON response
     *
     * @return array blockchain result (same shape as recordTransfer)
     */
    public function handleSuccessfulUpload(
        array  $local,
        array  $peerResults,
        string $originalFilename,
        string $description,
        string $publicKey,
        string $nodeInfo,
        array  $servers = []
    ): array {
        $peersReached = [];
        $peersFailed  = [];

        foreach ($peerResults as $p) {
            if (!empty($p['ok'])) {
                $peersReached[] = $p['server'] ?? '';
            } else {
                $peersFailed[] = [
                    'server' => $p['server'] ?? '',
                    'error'  => $p['error'] ?? 'unknown',
                ];
            }
        }

        $bcResult = $this->recordTransfer([
            'filename'      => $originalFilename,
            'stored_as'     => $local['filename'] ?? '',
            'hash'          => $local['hash']     ?? '',
            'size'          => $local['size']      ?? 0,
            'description'   => $description,
            'public_key'    => $publicKey,
            'node_info'     => $nodeInfo,
            'peers_reached' => $peersReached,
            'peers_failed'  => $peersFailed,
            'sender_ip'     => $_SERVER['REMOTE_ADDR'] ?? '',
            'existed'       => $local['existed'] ?? false,
        ]);

        if ($bcResult['ok'] && !empty($servers)) {
            $bcResult['broadcast'] = $this->broadcastBlock($bcResult['block_index'], $servers);
        }

        return $bcResult;
    }

    /**
     * Call this at the top of index.php to handle inbound peer block pushes.
     * Returns true if the request was a blockchain peer-push (and has been handled).
     * Returns false if this is a normal request and your code should continue.
     *
     * Example:
     *   $bc = new MeshBlockchain();
     *   if ($bc->handlePeerPushRequest()) exit; // response already sent
     *
     * @return bool  True = handled; false = not a blockchain push request.
     */
    public function handlePeerPushRequest(): bool
    {
        if (
            $_SERVER['REQUEST_METHOD'] !== 'POST' ||
            !isset($_POST[self::PEER_PUSH_PARAM]) ||
            $_POST[self::PEER_PUSH_PARAM] !== '1'
        ) {
            return false;
        }

        $json   = $_POST['block_json'] ?? '';
        $result = $this->receivePeerBlock($json);

        http_response_code($result['ok'] ? 200 : 400);
        header('Content-Type: application/json');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);

        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PRIVATE — BLOCK CONSTRUCTION
    // ══════════════════════════════════════════════════════════════════════════

    private function buildBlockData(
        int    $index,
        string $prevHash,
        float  $timestamp,
        array  $transfer
    ): array {
        return [
            // ── chain fields ─────────────────────────────────────────────────
            'index'       => $index,
            'prev_hash'   => $prevHash,
            'timestamp'   => $timestamp,
            'datetime'    => date('Y-m-d\TH:i:s\Z', (int)$timestamp),
            'version'     => self::VERSION,

            // ── transfer payload ─────────────────────────────────────────────
            'transfer'    => [
                'filename'      => $transfer['filename']      ?? '',
                'stored_as'     => $transfer['stored_as']     ?? '',
                'hash'          => $transfer['hash']          ?? '',
                'size'          => (int)($transfer['size']    ?? 0),
                'description'   => $transfer['description']   ?? '',
                'public_key'    => $transfer['public_key']    ?? '',
                'node_info'     => $transfer['node_info']     ?? '',
                'peers_reached' => (array)($transfer['peers_reached'] ?? []),
                'peers_failed'  => (array)($transfer['peers_failed']  ?? []),
                'sender_ip'     => $transfer['sender_ip']     ?? '',
                'existed'       => (bool)($transfer['existed'] ?? false),
                'extra'         => $transfer['extra']         ?? null,
            ],

            // block_hash filled after construction
            'block_hash'  => '',

            // ── next-block placeholder (updated when next block is written) ──
            'next_hash'   => null,
        ];
    }

    /**
     * Compute the canonical block hash.
     * block_hash and next_hash fields are excluded from the input so the hash
     * is stable even after next_hash is back-filled.
     */
    private function computeBlockHash(array $block): string
    {
        $copy = $block;
        unset($copy['block_hash'], $copy['next_hash']);
        $canonical = json_encode($copy, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash(self::ALGO, $canonical);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PRIVATE — STORAGE
    // ══════════════════════════════════════════════════════════════════════════

    private function blockFilename(int $index): string
    {
        return self::BLOCK_FILE_PREFIX . str_pad((string)$index, 10, '0', STR_PAD_LEFT) . '.json';
    }

    private function blockFilePath(string $filename): string
    {
        return $this->blocksDir . '/' . $filename;
    }

    private function saveBlock(array $block): array
    {
        $index    = (int)$block['index'];
        $filename = $this->blockFilename($index);
        $path     = $this->blockFilePath($filename);

        if (file_exists($path)) {
            // Never overwrite — idempotent
            return ['ok' => true, 'filename' => $filename, 'existed' => true];
        }

        // Back-fill next_hash into the previous block file
        if ($index > 0) {
            $prevFilename = $this->blockFilename($index - 1);
            $prevPath     = $this->blockFilePath($prevFilename);
            if (file_exists($prevPath)) {
                $prevBlock = json_decode((string)file_get_contents($prevPath), true);
                if (is_array($prevBlock) && $prevBlock['next_hash'] === null) {
                    $prevBlock['next_hash'] = $block['block_hash'];
                    file_put_contents(
                        $prevPath,
                        json_encode($prevBlock, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        LOCK_EX
                    );
                }
            }
        }

        $written = file_put_contents(
            $path,
            json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        );

        if ($written === false) {
            return ['ok' => false, 'error' => "Could not write block file: {$filename}"];
        }

        return ['ok' => true, 'filename' => $filename, 'existed' => false];
    }

    private function loadBlockFile(string $filename): ?array
    {
        $path = $this->blockFilePath($filename);
        if (!file_exists($path)) {
            return null;
        }
        $data = json_decode((string)file_get_contents($path), true);
        return is_array($data) ? $data : null;
    }

    private function writeGenesisBlock(): void
    {
        $block = [
            'index'      => 0,
            'prev_hash'  => self::GENESIS_PREV,
            'timestamp'  => microtime(true),
            'datetime'   => date('Y-m-d\TH:i:s\Z'),
            'version'    => self::VERSION,
            'transfer'   => null,
            'block_hash' => '',
            'next_hash'  => null,
            'genesis'    => true,
            'message'    => 'Mesh Blockchain — genesis block',
        ];

        $block['block_hash'] = $this->computeBlockHash($block);
        $filename = $this->blockFilename(0);
        $path     = $this->blockFilePath($filename);

        file_put_contents(
            $path,
            json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );

        $this->appendToIndex($filename, 0);
    }

    // ── Index file: maps sequential position → block filename ─────────────────
    private function loadIndex(): array
    {
        if (!file_exists($this->indexFile)) {
            return [];
        }
        $data = json_decode((string)file_get_contents($this->indexFile), true);
        return is_array($data) ? $data : [];
    }

    private function appendToIndex(string $filename, int $index): void
    {
        $idx = $this->loadIndex();
        // Fill any gaps defensively
        $idx[$index] = $filename;
        ksort($idx);
        file_put_contents(
            $this->indexFile,
            json_encode(array_values($idx), JSON_PRETTY_PRINT),
            LOCK_EX
        );
    }

    private function getTipBlock(): ?array
    {
        $idx = $this->loadIndex();
        if (empty($idx)) {
            return null;
        }
        $last = end($idx);
        return $this->loadBlockFile($last);
    }

    // ── HTTP peer push ─────────────────────────────────────────────────────────
    private function pushBlockToServer(string $server, string $blockJson): array
    {
        $boundary = '----BCBoundary' . bin2hex(random_bytes(12));

        $body  = "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"" . self::PEER_PUSH_PARAM . "\"\r\n\r\n1\r\n";
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"block_json\"\r\n\r\n";
        $body .= $blockJson . "\r\n";
        $body .= "--{$boundary}--\r\n";

        // Point to the same script name on the peer
        $scriptName = basename($_SERVER['SCRIPT_FILENAME'] ?? 'index.php');
        $url        = $server . '/' . $scriptName;

        $ctx = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => implode("\r\n", [
                    "Content-Type: multipart/form-data; boundary={$boundary}",
                    "Content-Length: " . strlen($body),
                    "X-Mesh-Blockchain: 1",
                ]),
                'content'       => $body,
                'timeout'       => $this->httpTimeout,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) {
            return ['ok' => false, 'server' => $server, 'error' => 'Connection failed.'];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return ['ok' => false, 'server' => $server, 'error' => 'Bad response: ' . substr($raw, 0, 120)];
        }

        return array_merge($decoded, ['server' => $server]);
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
//  AUTO-HANDLE PEER PUSH REQUESTS
//  When this file is included/required by index.php and a blockchain peer-push
//  request arrives, handle it immediately and stop further execution.
// ═══════════════════════════════════════════════════════════════════════════════
if (
    PHP_SAPI !== 'cli' &&
    isset($_POST[MeshBlockchain::PEER_PUSH_PARAM]) &&
    $_POST[MeshBlockchain::PEER_PUSH_PARAM] === '1'
) {
    $__bc = new MeshBlockchain();
    $__bc->handlePeerPushRequest();
    exit;
}