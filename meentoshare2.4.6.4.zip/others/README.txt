Quick guide
===========

Easy file sharing with metadata saved in JSON and more.
------------------------------------------------------

1) Upload your files using "index.php" or "index_full.php".
2) Open "indexer.php" and click in "Run Sync Engine". So the JSON files will be migrated to MySQL.
3) Open "feed.php" or "feed_full.php" for a modern view and navigation of content uploaded in your server and in the others.

Main Java tools
1) FileHashBuilder   > Rename all files of "files" directory using hash SHA256 and create the JSON metadata files.
2) StaticSiteBuilder > Create a static website based in the contents of "files" and "info" directories.

