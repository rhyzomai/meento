<?php declare(strict_types=1);

// -------------------------------------------------------------------------------
//  MESH NODE � file replication over HTTP/HTTPS
//  Single-file PHP 7+ application
// -------------------------------------------------------------------------------

// Remove this line to avoid creating duplicate files in the 'users' directory.
@include_once __DIR__ . '/user_files.php';

class MeshConfig
{
    public const DIR_FILES       = __DIR__ . '/files';
    public const DIR_INFO        = __DIR__ . '/info';
    public const FILE_INDEX      = __DIR__ . '/files.txt';
    public const FILE_DATA_JSON  = __DIR__ . '/data.json';
    public const FILE_SERVERS    = __DIR__ . '/servers.txt';
    public const FILE_PUB_KEY    = __DIR__ . '/public_key.txt';
    public const FILE_NODE_INFO  = __DIR__ . '/node_info.txt';

    public const MAX_FILE_SIZE   = 1073741824; // 1 GB in bytes
    public const MAX_TEXT_LEN    = 512;        // Characters
    public const BLOCKED_EXT     = ['php', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar'];
}

class MeshNode
{
    public static function bootstrap(): void
    {
        foreach ([MeshConfig::DIR_FILES, MeshConfig::DIR_INFO] as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
        if (!file_exists(MeshConfig::FILE_INDEX)) {
            file_put_contents(MeshConfig::FILE_INDEX, '');
        }
    }

    public static function handleRequest(): void
    {
        if (isset($_GET['node_status'])) {
            self::handleStatusRequest();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
            $isPeerPush = isset($_POST['peer_push']) && $_POST['peer_push'] === '1';
            self::handleUpload($_FILES['file'], $_POST, $isPeerPush);
        }
    }

    private static function handleStatusRequest(): void
    {
        self::jsonOut([
            'public_key' => self::readOptionalFile(MeshConfig::FILE_PUB_KEY) !== '',
            'node_info'  => self::readOptionalFile(MeshConfig::FILE_NODE_INFO) !== '',
            'peers'      => count(self::loadServers()),
        ]);
    }

    private static function handleUpload(array $upload, array $postData, bool $isPeerPush): void
    {
        // 1. Validate Upload Errors
        if ($upload['error'] !== UPLOAD_ERR_OK) {
            $msg = ($upload['error'] === UPLOAD_ERR_INI_SIZE || $upload['error'] === UPLOAD_ERR_FORM_SIZE)
                ? 'File exceeds server configuration size limits.'
                : 'Upload error code: ' . $upload['error'];
            self::jsonOut(['ok' => false, 'error' => $msg], 400);
        }

        // 2. Validate File Size limit
        if ($upload['size'] > MeshConfig::MAX_FILE_SIZE) {
            self::jsonOut(['ok' => false, 'error' => 'File exceeds the 1GB size limit.'], 400);
        }

        // 3. Validate Extension
        $ext = self::safeExt($upload['name']);
        if (in_array($ext, MeshConfig::BLOCKED_EXT, true)) {
            self::jsonOut(['ok' => false, 'error' => 'PHP files are strictly blocked.'], 400);
        }

        // 4. Sanitize Input Fields
        $description = self::sanitize($postData['description'] ?? $postData['comment'] ?? '');
        $userPubKey  = self::sanitize($postData['public_key'] ?? '');
        $nodeInfo    = self::sanitize($postData['node_info'] ?? self::readOptionalFile(MeshConfig::FILE_NODE_INFO));

        // As per spec: server_public_key is ALWAYS loaded from local file.
        $serverPubKey = self::sanitize(self::readOptionalFile(MeshConfig::FILE_PUB_KEY));

        // 5. Store Locally
        $local = self::storeLocally(
            $upload['tmp_name'],
            $upload['name'],
            $description,
            $userPubKey,
            $serverPubKey,
            $nodeInfo
        );

        if (!$local['ok']) {
            self::jsonOut($local, 500);
        }

        // 6. Handle successful local storage
        if (!$local['existed']) {
            self::appendFilesAndDataJson($local['hash']);
        }

        if ($isPeerPush) {
            self::jsonOut($local, 200);
        }

        // 7. Browser Request: Respond immediately, then background propagate
        $servers = self::loadServers();
        $storedPath = MeshConfig::DIR_FILES . '/' . $local['filename'];

        $responsePayload = json_encode(array_merge($local, [
            'peers_total' => count($servers),
            'peers'       => [],
        ]), JSON_UNESCAPED_UNICODE);

        http_response_code(200);
        header('Content-Type: application/json');
        header('Content-Length: ' . strlen($responsePayload));
        header('Connection: close');
        echo $responsePayload;

        if (ob_get_level()) {
            ob_end_flush();
        }
        flush();

        // 8. Propagate to peers
        if (!$local['existed']) {
            ignore_user_abort(true);
            foreach ($servers as $server) {
                self::pushToServer($server, $storedPath, $upload['name'], $description, $userPubKey, $nodeInfo);
            }
        }
        exit;
    }

    private static function storeLocally(
        string $tmpPath,
        string $originalName,
        string $description,
        string $userPubKey,
        string $serverPubKey,
        string $nodeInfo
    ): array {
        $ext = self::safeExt($originalName);
        $hash = hash_file('sha256', $tmpPath);
        $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;

        $destFile = MeshConfig::DIR_FILES . '/' . $baseName;
        $destInfo = MeshConfig::DIR_INFO  . '/' . $hash . '.json';

        $existed = file_exists($destFile);

        if (!$existed) {
            if (!copy($tmpPath, $destFile)) {
                return ['ok' => false, 'error' => 'Could not write file to disk.'];
            }
            self::appendIndex($baseName);
        }

        if (!file_exists($destInfo)) {
            $info = [
                'filename'          => self::sanitize($originalName),
                'size'              => (int) filesize($destFile),
                'extension'         => self::sanitize($ext),
                'public_key'        => $userPubKey,
                'server_public_key' => $serverPubKey,
                'node_info'         => $nodeInfo,
                'description'       => $description,
                'date'              => date('c'),
            ];
            file_put_contents($destInfo, json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        return ['ok' => true, 'hash' => $hash, 'filename' => $baseName, 'existed' => $existed];
    }

    private static function pushToServer(
        string $server,
        string $filePath,
        string $filename,
        string $description,
        string $userPubKey,
        string $nodeInfo
    ): void {
        $boundary = '----MeshBoundary' . bin2hex(random_bytes(12));
        $body = '';

        $mime  = @mime_content_type($filePath) ?: 'application/octet-stream';
        $body .= "--{$boundary}\r\n";
        $body .= 'Content-Disposition: form-data; name="file"; filename="' . addslashes($filename) . "\"\r\n";
        $body .= "Content-Type: {$mime}\r\n\r\n";
        $body .= file_get_contents($filePath) . "\r\n";

        $fields = [
            'description' => $description,
            'public_key'  => $userPubKey,
            'node_info'   => $nodeInfo,
            'peer_push'   => '1',
        ];

        foreach ($fields as $name => $value) {
            $body .= "--{$boundary}\r\n";
            $body .= "Content-Disposition: form-data; name=\"{$name}\"\r\n\r\n";
            $body .= $value . "\r\n";
        }
        $body .= "--{$boundary}--\r\n";

        $url = rtrim($server, '/') . '/' . basename(__FILE__);
        $ctx = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => implode("\r\n", [
                    "Content-Type: multipart/form-data; boundary={$boundary}",
                    "Content-Length: " . strlen($body),
                    "X-Mesh-Node: 1",
                ]),
                'content'       => $body,
                'timeout'       => 20,
                'ignore_errors' => true,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        @file_get_contents($url, false, $ctx);
    }

    private static function appendFilesAndDataJson(string $hash): void
    {
        ob_start();
        $prev = error_reporting(0);
        try {
            $infoPath = MeshConfig::DIR_INFO . '/' . $hash . '.json';
            $raw = @file_get_contents($infoPath);
            if ($raw === false) return;

            $info = json_decode($raw, true);
            if (!is_array($info)) return;

            $ext = $info['extension'] ?? '';
            $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
            self::appendIndex($baseName);

            $entry = array_merge(['hash' => $hash], $info);
            $dataJson = MeshConfig::FILE_DATA_JSON;

            if (!file_exists($dataJson)) {
                file_put_contents($dataJson, "[\n]", LOCK_EX);
            }

            $fp = @fopen($dataJson, 'c+');
            if ($fp === false || !flock($fp, LOCK_EX)) {
                if ($fp) fclose($fp);
                return;
            }

            $content = rtrim((string) stream_get_contents($fp));
            $closingPos = strrpos($content, ']');
            $encoded = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $indented = implode("\n", array_map(static function(string $l) { return '    ' . $l; }, explode("\n", $encoded)));

            if ($closingPos === false || trim(substr($content, 1, $closingPos - 1)) === '') {
                $newContent = "[\n" . $indented . "\n]";
            } else {
                $newContent = rtrim(substr($content, 0, $closingPos)) . ",\n" . $indented . "\n]";
            }

            rewind($fp);
            ftruncate($fp, 0);
            fwrite($fp, $newContent);
            flock($fp, LOCK_UN);
            fclose($fp);
        } finally {
            error_reporting($prev);
            ob_end_clean();
        }
    }

    // -- Helper Utilities --

    private static function sanitize(string $input): string
    {
        return substr(trim($input), 0, MeshConfig::MAX_TEXT_LEN);
    }

    private static function safeExt(string $filename): string
    {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return substr(preg_replace('/[^a-z0-9]/', '', $ext), 0, MeshConfig::MAX_TEXT_LEN);
    }

    private static function readOptionalFile(string $path): string
    {
        return file_exists($path) ? trim((string) file_get_contents($path)) : '';
    }

    private static function appendIndex(string $entry): void
    {
        $lines = file_exists(MeshConfig::FILE_INDEX)
            ? array_map('trim', file(MeshConfig::FILE_INDEX, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
            : [];
        if (!in_array($entry, $lines, true)) {
            file_put_contents(MeshConfig::FILE_INDEX, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
    }

    private static function loadServers(): array
    {
        if (!file_exists(MeshConfig::FILE_SERVERS)) return [];
        $lines = file(MeshConfig::FILE_SERVERS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '') {
                if (!preg_match('#^https?://#i', $line)) $line = 'http://' . $line;
                $out[] = rtrim($line, '/');
            }
        }
        return array_unique($out);
    }

    private static function jsonOut(array $data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// -- Application Initialization ------------------------------------------------
MeshNode::bootstrap();
MeshNode::handleRequest();

// -------------------------------------------------------------------------------
//  HTML FRONT-END
// -------------------------------------------------------------------------------
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* -- reset -- */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{color-scheme:dark}

/* -- tokens -- */
:root {
  --bg:        #080C18;
  --bg-card:   #0E1527;
  --bg-input:  #111929;
  --border:    #1E2D52;
  --border-hi: #3B4D7A;
  --accent:    #5B6CFF;
  --accent-dim:#2E3A8A;
  --text:      #C8D4EE;
  --text-dim:  #5A6B8A;
  --text-head: #E8EDF8;
  --green:     #34D399;
  --green-bg:  #0A2318;
  --green-bd:  #1A4D34;
  --red:       #F87171;
  --red-bg:    #220A0A;
  --red-bd:    #4D1A1A;
  --yellow:    #FBBF24;
  --font:      'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
}

body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 1.25rem 3rem;
  font-size: 13px;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}

/* -- layout -- */
.wrap { max-width: 680px; width: 100%; }

/* -- topbar -- */
.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.1rem 0 1.1rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 1.5rem;
  gap: 1rem;
  flex-wrap: wrap;
}

.logo {
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
}

.logo-mark {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--accent);
  text-transform: uppercase;
  border: 1px solid var(--accent-dim);
  padding: 2px 7px;
  border-radius: 3px;
  background: rgba(91,108,255,0.08);
}

.logo-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-head);
  letter-spacing: -0.01em;
}

.logo-sub {
  font-size: 11px;
  color: var(--text-dim);
  letter-spacing: 0.02em;
}

/* -- nav -- */
nav {
  display: flex;
  gap: 0.25rem;
  flex-wrap: wrap;
}

nav a {
  font-size: 11px;
  font-weight: 500;
  color: var(--text-dim);
  text-decoration: none;
  padding: 4px 9px;
  border-radius: 3px;
  letter-spacing: 0.04em;
  transition: color 0.15s, background 0.15s;
  text-transform: lowercase;
}

nav a:hover {
  color: var(--text);
  background: var(--bg-card);
}

nav a.active {
  color: var(--accent);
  background: rgba(91,108,255,0.1);
}

/* -- status bar -- */
.status-bar {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

.sb-pill {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  font-size: 11px;
  color: var(--text-dim);
  background: var(--bg-card);
  border: 1px solid var(--border);
  padding: 5px 10px;
  border-radius: 3px;
  letter-spacing: 0.03em;
}

.sb-pill .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--border-hi);
  flex-shrink: 0;
}

.sb-pill .dot.ok    { background: var(--green); box-shadow: 0 0 6px rgba(52,211,153,0.5); }
.sb-pill .dot.pulse { background: var(--accent); box-shadow: 0 0 6px rgba(91,108,255,0.5); animation: pulse-dot 2s ease-in-out infinite; }
.sb-pill .dot.warn  { background: var(--yellow); }

.sb-val { color: var(--text); font-weight: 600; }

@keyframes pulse-dot {
  0%,100% { opacity:1; } 50% { opacity:0.4; }
}

/* -- section label -- */
.section-label {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--text-dim);
  margin-bottom: 0.6rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.section-label::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

/* -- drop zone -- */
#drop-zone {
  position: relative;
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 2.5rem 1.5rem;
  text-align: center;
  cursor: pointer;
  background: var(--bg-card);
  transition: border-color 0.2s, background 0.2s;
  overflow: hidden;
  outline: none;
  margin-bottom: 1.25rem;
}

#drop-zone::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 60% 50% at 50% 50%, rgba(91,108,255,0.07) 0%, transparent 70%);
  opacity: 0;
  transition: opacity 0.3s;
  pointer-events: none;
}

#drop-zone:hover::before,
#drop-zone:focus::before,
#drop-zone.over::before { opacity: 1; }

#drop-zone:hover,
#drop-zone:focus { border-color: var(--border-hi); }

#drop-zone.over {
  border-color: var(--accent);
  background: rgba(91,108,255,0.06);
}

/* radar rings � the signature element */
.radar {
  position: relative;
  width: 52px;
  height: 52px;
  margin: 0 auto 1.2rem;
}

.radar-icon {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
}

.radar-icon svg {
  width: 22px;
  height: 22px;
  stroke: var(--accent);
  fill: none;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.radar-ring {
  position: absolute;
  border-radius: 50%;
  border: 1px solid var(--accent);
  top: 50%; left: 50%;
  transform: translate(-50%,-50%) scale(0);
  opacity: 0;
}

#drop-zone:hover .radar-ring,
#drop-zone:focus .radar-ring,
#drop-zone.over .radar-ring {
  animation: radar-expand 2s ease-out infinite;
}

.radar-ring:nth-child(1) { width: 52px; height: 52px; animation-delay: 0s !important; }
.radar-ring:nth-child(2) { width: 52px; height: 52px; animation-delay: 0.6s !important; }
.radar-ring:nth-child(3) { width: 52px; height: 52px; animation-delay: 1.2s !important; }

@keyframes radar-expand {
  0%   { transform: translate(-50%,-50%) scale(0.4); opacity: 0.7; }
  100% { transform: translate(-50%,-50%) scale(3.2); opacity: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .radar-ring { animation: none !important; }
}

.dz-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-head);
  margin-bottom: 0.35rem;
  letter-spacing: -0.01em;
}

.dz-meta {
  font-size: 11px;
  color: var(--text-dim);
  letter-spacing: 0.02em;
}

.dz-meta .hl { color: var(--accent); }
.dz-meta .warn { color: var(--red); }

#file-input { display: none; }

/* -- upload panel -- */
#panel {
  display: none;
  border: 1px solid var(--border);
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 1.25rem;
  background: var(--bg-card);
}

.panel-file {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1rem;
  border-bottom: 1px solid var(--border);
}

.file-type-badge {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--accent);
  background: rgba(91,108,255,0.12);
  border: 1px solid var(--accent-dim);
  border-radius: 3px;
  padding: 3px 7px;
  flex-shrink: 0;
  min-width: 42px;
  text-align: center;
  white-space: nowrap;
}

#f-name {
  font-size: 13px;
  color: var(--text-head);
  font-weight: 500;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

#f-size {
  font-size: 11px;
  color: var(--text-dim);
  flex-shrink: 0;
}

.x-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-dim);
  padding: 2px 4px;
  font-size: 14px;
  line-height: 1;
  transition: color 0.15s;
  flex-shrink: 0;
  font-family: var(--font);
}
.x-btn:hover { color: var(--red); }

/* -- optional fields row -- */
.panel-opts {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.6rem 1rem;
  border-bottom: 1px solid var(--border);
  background: var(--bg-input);
  flex-wrap: wrap;
}

.opt-badge {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  padding: 3px 8px;
  border-radius: 3px;
  border: 1px solid var(--border);
  color: var(--text-dim);
  background: var(--bg-card);
  display: flex;
  align-items: center;
  gap: 0.3rem;
  white-space: nowrap;
}

.opt-badge.active {
  color: var(--green);
  border-color: var(--green-bd);
  background: var(--green-bg);
}

.opt-badge svg {
  width: 10px;
  height: 10px;
  stroke: currentColor;
  fill: none;
  stroke-width: 2.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.pk-input {
  flex: 1;
  min-width: 180px;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 3px;
  font-family: var(--font);
  font-size: 11px;
  color: var(--text);
  padding: 5px 10px;
  outline: none;
  transition: border-color 0.2s;
}
.pk-input::placeholder { color: var(--text-dim); }
.pk-input:focus { border-color: var(--accent); }

/* -- description -- */
.panel-desc {
  padding: 0.85rem 1rem;
  border-bottom: 1px solid var(--border);
}

.field-label {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--text-dim);
  margin-bottom: 0.5rem;
  display: block;
}

textarea#comment-box {
  width: 100%;
  min-height: 80px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: 3px;
  font-family: var(--font);
  font-size: 12px;
  color: var(--text);
  padding: 0.6rem 0.75rem;
  resize: vertical;
  outline: none;
  transition: border-color 0.2s;
  line-height: 1.5;
}
textarea#comment-box::placeholder { color: var(--text-dim); }
textarea#comment-box:focus { border-color: var(--accent); }

.field-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 0.4rem;
  font-size: 10px;
  color: var(--text-dim);
}

.ccount.over { color: var(--red); }

/* -- panel footer / send -- */
.panel-send {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1rem;
  gap: 0.75rem;
}

.peer-note {
  font-size: 11px;
  color: var(--text-dim);
}
.peer-note strong { color: var(--text); font-weight: 600; }

.btn-send {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 7px 18px;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 3px;
  font-family: var(--font);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  cursor: pointer;
  transition: opacity 0.2s, transform 0.1s;
  text-transform: lowercase;
  flex-shrink: 0;
}
.btn-send:hover:not(.busy) { opacity: 0.88; }
.btn-send:active:not(.busy) { transform: scale(0.98); }
.btn-send.busy { opacity: 0.4; pointer-events: none; }
.btn-send svg {
  width: 13px; height: 13px;
  stroke: #fff; fill: none;
  stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
}

/* -- progress -- */
#prog-wrap {
  height: 2px;
  background: var(--border);
  display: none;
  margin-bottom: 1rem;
  border-radius: 2px;
  overflow: hidden;
}
#prog-bar {
  height: 100%;
  width: 0%;
  background: var(--accent);
  transition: width 0.1s linear;
}

/* -- status message -- */
#upload-status {
  display: none;
  margin-bottom: 1.25rem;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1.6;
  animation: fadeUp 0.2s ease;
  overflow: hidden;
}

.status-bar-line {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.7rem 1rem;
}

#upload-status.ok .status-bar-line   { background: var(--green-bg); border: 1px solid var(--green-bd); border-radius: 4px 4px 0 0; color: var(--green); }
#upload-status.fail .status-bar-line { background: var(--red-bg); border: 1px solid var(--red-bd); border-radius: 4px; color: var(--red); }

.status-bar-line svg {
  width: 14px; height: 14px;
  stroke: currentColor; fill: none;
  stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  flex-shrink: 0;
}

.status-detail {
  padding: 0.7rem 1rem;
  background: var(--bg-card);
  border: 1px solid var(--green-bd);
  border-top: none;
  border-radius: 0 0 4px 4px;
}

.file-link {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 5px 14px;
  font-size: 11px;
  font-weight: 600;
  text-decoration: none;
  color: var(--accent);
  border: 1px solid var(--accent-dim);
  border-radius: 3px;
  background: rgba(91,108,255,0.08);
  transition: background 0.15s;
  letter-spacing: 0.03em;
  margin-top: 0.5rem;
}
.file-link:hover { background: rgba(91,108,255,0.16); }
.file-link svg {
  width: 11px; height: 11px;
  stroke: currentColor; fill: none;
  stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round;
}

/* -- schema preview -- */
.schema-block {
  border: 1px solid var(--border);
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 2rem;
}

.schema-head {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.85rem;
  background: var(--bg-card);
  border-bottom: 1px solid var(--border);
  font-size: 10px;
  color: var(--text-dim);
  letter-spacing: 0.04em;
}

.schema-head svg {
  width: 11px; height: 11px;
  stroke: var(--text-dim); fill: none;
  stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
}

.schema-path {
  font-size: 10px;
  color: var(--text-dim);
}

.schema-path .path-part { color: var(--text); }
.schema-path .path-hash { color: var(--yellow); }

pre#json-schema {
  padding: 1rem;
  font-family: var(--font);
  font-size: 12px;
  line-height: 1.7;
  color: var(--text);
  overflow-x: auto;
  margin: 0;
  background: var(--bg-input);
}

.jk { color: var(--accent); }
.js { color: var(--green); }
.jn { color: var(--yellow); }
.jc { color: var(--text-dim); font-style: italic; }

/* -- footer -- */
footer {
  border-top: 1px solid var(--border);
  padding-top: 1rem;
  margin-top: 1rem;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.4rem;
  font-size: 10px;
  color: var(--text-dim);
  letter-spacing: 0.04em;
}

footer span { display: flex; align-items: center; gap: 0.6rem; }
footer .sep { color: var(--border-hi); }

@keyframes fadeUp {
  from { opacity:0; transform:translateY(4px); }
  to   { opacity:1; transform:translateY(0); }
}

/* -- responsive -- */
@media (max-width: 480px) {
  .topbar { flex-direction: column; align-items: flex-start; }
  nav a { padding: 4px 7px; }
  .panel-send { flex-direction: column; align-items: stretch; }
  .btn-send { justify-content: center; }
}
</style>
</head>
<body>
<div class="wrap">

<!-- topbar -->
<header class="topbar">
  <div class="logo">
    <span class="logo-mark">node</span>
    <span class="logo-name">mesh</span>
    <span class="logo-sub">/ sha-256 � peer replication</span>
  </div>
  <nav>
    <a href="index.php" class="active">upload</a>
    <a href="view.php">search</a>
    <a href="user_files.php">users</a>
    <a href="servers.php">servers</a>
    <a href="panel.php">panel</a>
    <a href="sync.php">sync</a>
    <a href="dashboard.php">dashboard</a>
    <a href="indexer.php">indexer</a>
    <a href="feed_full.php">feed</a>
    <a href="index_full.php">account</a>
  </nav>
</header>

<!-- node status -->
<div class="status-bar">
  <div class="sb-pill">
    <span class="dot pulse"></span>
    peers <span class="sb-val" id="nb-peers">�</span>
  </div>
  <div class="sb-pill">
    <span class="dot" id="nb-pk-dot"></span>
    public_key.txt <span class="sb-val" id="nb-pk">�</span>
  </div>
  <div class="sb-pill">
    <span class="dot" id="nb-ni-dot"></span>
    node_info.txt <span class="sb-val" id="nb-ni">�</span>
  </div>
</div>

<!-- drop zone -->
<div class="section-label">transmit file</div>

<div id="drop-zone" tabindex="0" role="button" aria-label="Select or drop a file to upload">
  <div class="radar">
    <div class="radar-ring"></div>
    <div class="radar-ring"></div>
    <div class="radar-ring"></div>
    <div class="radar-icon">
      <svg viewBox="0 0 24 24">
        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
    </div>
  </div>
  <p class="dz-title">drop file here or click to select</p>
  <p class="dz-meta">
    max <span class="hl">1 GB</span>
    &nbsp;�&nbsp; propagated to all peers
    &nbsp;�&nbsp; <span class="warn">.php blocked</span>
  </p>
</div>
<input type="file" id="file-input">

<!-- upload panel -->
<div id="panel">

  <div class="panel-file">
    <span class="file-type-badge" id="f-ext">file</span>
    <span id="f-name">�</span>
    <span id="f-size"></span>
    <button class="x-btn" id="x-btn" aria-label="Remove file">?</button>
  </div>

  <div class="panel-opts">
    <input type="text" class="pk-input" id="pk-inline" maxlength="512" placeholder="public key (optional)�" autocomplete="off" spellcheck="false">
    <div class="opt-badge" id="badge-ni">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      node_info
    </div>
    <div class="opt-badge active">
      <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
      metadata ready
    </div>
  </div>

  <div class="panel-desc">
    <label class="field-label" for="comment-box">description</label>
    <textarea id="comment-box" placeholder="optional description for this file�"></textarea>
    <div class="field-meta">
      <span>stored as <span class="jk">"description"</span> in metadata</span>
      <span class="ccount" id="ccount">0 / 512</span>
    </div>
  </div>

  <div class="panel-send">
    <span class="peer-note">broadcasting to <strong id="peer-count">�</strong> peer(s)</span>
    <button class="btn-send" id="send-btn">
      <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      <span>transmit</span>
    </button>
  </div>

</div>

<!-- progress -->
<div id="prog-wrap"><div id="prog-bar"></div></div>

<!-- upload status -->
<div id="upload-status"></div>

<!-- schema reference -->
<div class="section-label">metadata schema</div>

<div class="schema-block">
  <div class="schema-head">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    <span class="schema-path">info/<span class="path-hash">&lt;sha256&gt;</span><span class="path-part">.json</span></span>
  </div>
  <pre id="json-schema">{
  <span class="jk">"filename"</span>:          <span class="js">"photo.jpg"</span>,
  <span class="jk">"size"</span>:              <span class="jn">204800</span>,
  <span class="jk">"extension"</span>:         <span class="js">"jpg"</span>,
  <span class="jk">"public_key"</span>:        <span class="js">"&lt;user input � max 512 chars&gt;"</span>,
  <span class="jk">"server_public_key"</span>: <span class="js">"&lt;loaded from public_key.txt&gt;"</span>,
  <span class="jk">"node_info"</span>:         <span class="js">"&lt;loaded from node_info.txt&gt;"</span>,
  <span class="jk">"description"</span>:       <span class="js">"&lt;user description � max 512 chars&gt;"</span>,
  <span class="jk">"date"</span>:              <span class="js">"2026-06-16T11:25:10-03:00"</span>
}</pre>
</div>

<!-- footer -->
<footer>
  <span>
    mesh node
    <span class="sep">�</span>
    sha-256 content addressing
    <span class="sep">�</span>
    1 GB limit
    <span class="sep">�</span>
    php <?php echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION; ?>
  </span>
  <span>oo � strict types</span>
</footer>

</div><!-- /wrap -->

<script>
(function(){
'use strict';

const dz       = document.getElementById('drop-zone');
const fi       = document.getElementById('file-input');
const panel    = document.getElementById('panel');
const fName    = document.getElementById('f-name');
const fSize    = document.getElementById('f-size');
const fExt     = document.getElementById('f-ext');
const xBtn     = document.getElementById('x-btn');
const commentB = document.getElementById('comment-box');
const ccount   = document.getElementById('ccount');
const sendBtn  = document.getElementById('send-btn');
const peerCnt  = document.getElementById('peer-count');
const upStatus = document.getElementById('upload-status');
const progWrap = document.getElementById('prog-wrap');
const progBar  = document.getElementById('prog-bar');
const badgeNi  = document.getElementById('badge-ni');
const pkInline = document.getElementById('pk-inline');

const MAX_CHARS = 512;
const MAX_BYTES = 1073741824;
const BLOCKED   = ['php','php3','php4','php5','php7','phtml','phar'];

let file = null;
let ns   = { public_key: false, node_info: false, peers: 0 };

// -- fetch node status
fetch(window.location.href + '?node_status=1')
  .then(r => r.json())
  .then(d => {
    ns = d;
    document.getElementById('nb-peers').textContent = d.peers;
    peerCnt.textContent = d.peers;

    const dot = (id, ok) => {
      const el = document.getElementById(id);
      if (el) el.className = 'dot ' + (ok ? 'ok' : 'warn');
    };
    dot('nb-pk-dot', d.public_key);
    dot('nb-ni-dot', d.node_info);
    document.getElementById('nb-pk').textContent = d.public_key ? '? found' : '� missing';
    document.getElementById('nb-ni').textContent = d.node_info  ? '? found' : '� missing';
    badgeNi.className = 'opt-badge' + (d.node_info ? ' active' : '');
  })
  .catch(() => {
    ['nb-peers','nb-pk','nb-ni'].forEach(id => {
      const el = document.getElementById(id); if (el) el.textContent = '?';
    });
    peerCnt.textContent = '?';
  });

function fmt(b) {
  if (b < 1024)       return b + ' B';
  if (b < 1048576)    return (b/1024).toFixed(1) + ' KB';
  if (b < 1073741824) return (b/1048576).toFixed(2) + ' MB';
  return (b/1073741824).toFixed(2) + ' GB';
}

function extOf(n) { return n.includes('.') ? n.split('.').pop().toLowerCase() : ''; }

function setFile(f) {
  if (!f) return;
  const ext = extOf(f.name);
  if (BLOCKED.includes(ext)) { showStatus('fail', 'php files are strictly blocked.'); return; }
  if (f.size > MAX_BYTES)    { showStatus('fail', 'file exceeds the 1 GB size limit.'); return; }

  file = f;
  fName.textContent = f.name;
  fSize.textContent = fmt(f.size);
  fExt.textContent  = ext || 'bin';
  panel.style.display = 'block';
  commentB.value = '';
  updateCount();
  clearStatus();
}

function clearFile() {
  file = null;
  fi.value = '';
  panel.style.display = 'none';
  commentB.value = '';
  pkInline.value = '';
}

dz.addEventListener('click', () => fi.click());
dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') fi.click(); });
fi.addEventListener('change', () => { if (fi.files[0]) setFile(fi.files[0]); });
xBtn.addEventListener('click', clearFile);

['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', e => { if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

function updateCount() {
  const len = [...commentB.value].length;
  ccount.textContent = len.toLocaleString() + ' / ' + MAX_CHARS;
  ccount.classList.toggle('over', len > MAX_CHARS);
}
commentB.addEventListener('input', updateCount);

function clearStatus() {
  upStatus.style.display = 'none';
  upStatus.innerHTML = '';
  upStatus.className = '';
}

function showStatus(type, msg, filename, existed) {
  upStatus.className = type;
  upStatus.style.display = 'block';

  if (type === 'fail') {
    upStatus.innerHTML =
      '<div class="status-bar-line">' +
        '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' +
        esc(msg) +
      '</div>';
    return;
  }

  // ok
  const note = existed ? ' <span style="color:var(--text-dim)">(already stored)</span>' : '';
  upStatus.innerHTML =
    '<div class="status-bar-line">' +
      '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>' +
      'file stored' + note +
    '</div>' +
    '<div class="status-detail">' +
      '<a class="file-link" href="files/' + esc(filename) + '" target="_blank" rel="noopener noreferrer">' +
        '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
        'open file' +
      '</a>' +
    '</div>';
}

sendBtn.addEventListener('click', () => {
  if (!file) return;

  const descText = commentB.value.trim();
  if ([...descText].length > MAX_CHARS) {
    showStatus('fail', 'description exceeds the 512 character limit.'); return;
  }

  const fd = new FormData();
  fd.append('file', file);
  fd.append('description', descText);

  const userPk = pkInline.value.trim();
  if (userPk !== '') fd.append('public_key', userPk.slice(0, MAX_CHARS));

  const xhr = new XMLHttpRequest();
  sendBtn.classList.add('busy');
  sendBtn.querySelector('span').textContent = 'transmitting�';
  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  clearStatus();

  xhr.upload.addEventListener('progress', e => {
    if (e.lengthComputable) progBar.style.width = Math.round(e.loaded / e.total * 100) + '%';
  });

  xhr.addEventListener('load', () => {
    sendBtn.classList.remove('busy');
    sendBtn.querySelector('span').textContent = 'transmit';
    progBar.style.width = '100%';
    setTimeout(() => { progWrap.style.display = 'none'; progBar.style.width = '0%'; }, 600);

    let res;
    try {
      const raw = xhr.responseText.replace(/^[\s\S]*?(\{)/, '$1');
      res = JSON.parse(raw);
    } catch(e) {
      const m = xhr.responseText.match(/"filename"\s*:\s*"([^"]+)"/);
      if (m) { showStatus('ok', '', m[1], false); clearFile(); return; }
      showStatus('fail', 'unexpected server response.'); return;
    }

    if (!res.ok) { showStatus('fail', res.error || 'unknown error.'); return; }
    showStatus('ok', '', res.filename, !!res.existed);
    clearFile();
  });

  xhr.addEventListener('error', () => {
    sendBtn.classList.remove('busy');
    sendBtn.querySelector('span').textContent = 'transmit';
    showStatus('fail', 'network error � could not reach the node.');
    progWrap.style.display = 'none';
  });

  xhr.open('POST', window.location.href);
  xhr.send(fd);
});

function esc(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

})();
</script>
</body>
</html>