﻿<?php
// ==========================================
// 1. CONFIGURATION
// ==========================================
$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'file_indexer';

$files = [];
$error_message = '';

// ==========================================
// 2. DATABASE CONNECTION & QUERY
// ==========================================
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    // Query the registry. We fetch everything to accurately count the hosts in PHP.
    $stmt = $pdo->query("SELECT file_hash, original_filename, file_size, extension, hosts, indexed_at FROM file_registry");
    $files = $stmt->fetchAll();

    // Process and count hosts for each file
    foreach ($files as $key => $file) {
        $hosts_raw = trim($file['hosts']);
        $host_count = 0;

        if (!empty($hosts_raw)) {
            // Check if hosts are stored as a JSON array or comma-separated string
            if (strpos($hosts_raw, '[') === 0) {
                $decoded = json_decode($hosts_raw, true);
                $host_count = is_array($decoded) ? count($decoded) : 0;
            } else {
                // Assuming comma-separated
                $host_array = array_filter(explode(',', $hosts_raw));
                $host_count = count($host_array);
            }
        }
        
        $files[$key]['host_count'] = $host_count;
    }

    // Sort the array in descending order based on host_count (PHP 7 compatible using spaceship operator)
    usort($files, function($a, $b) {
        return $b['host_count'] <=> $a['host_count'];
    });

} catch (PDOException $e) {
    $error_message = "Database Connection/Query Error: " . htmlspecialchars($e->getMessage());
}

// Helper to format bytes
function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow]; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Host Variance Dashboard</title>
    <style>
        :root {
            --bg-color: #f4f7f6;
            --card-bg: #ffffff;
            --text-main: #333333;
            --text-muted: #666666;
            --border-color: #e0e0e0;
            --positive: #2ecc71;
            --negative: #e74c3c;
            --primary: #36a2eb;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            margin: 0;
            padding: 20px;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
        }

        .header-titles h1 {
            margin: 0 0 5px 0;
            color: #2c3e50;
            font-size: 24px;
        }

        .header-titles p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
        }

        .card {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border: 1px solid var(--border-color);
            margin-top: 20px;
        }

        .card h3 {
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 16px;
            color: #2c3e50;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            background-color: #f9fbfb;
            color: var(--text-muted);
            font-weight: 600;
        }

        .key-id {
            font-family: monospace;
            font-weight: bold;
            color: var(--text-main);
        }

        .indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
            background-color: var(--primary);
        }

        .badge {
            background-color: #e3f2fd;
            color: #1565c0;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 13px;
        }

        .error-banner {
            background-color: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>

    <div class="dashboard-header">
        <div class="header-titles">
            <h1>File Distribution Dashboard</h1>
            <p>Files ranked by highest network availability (host count)</p>
        </div>
        <div class="controls">
            <p style="color: var(--text-muted); font-size: 14px;">
                Total Indexed Files: <strong><?= count($files) ?></strong>
            </p>
        </div>
    </div>

    <?php if ($error_message): ?>
        <div class="error-banner">
            <strong>Error:</strong> <?= $error_message ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <h3>Network Performance Metrics (Sorted by Host Availability)</h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>File Hash</th>
                        <th>Original Filename</th>
                        <th>File Size</th>
                        <th>Extension</th>
                        <th>Total Hosts</th>
                        <th>Last Indexed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($files) && empty($error_message)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: var(--text-muted);">No records found in file_registry.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($files as $file): ?>
                            <tr>
                                <td>
                                    <span class="indicator"></span>
                                    <span class="key-id"><?= htmlspecialchars(substr($file['file_hash'], 0, 16)) ?>...</span>
                                </td>
                                <td><?= htmlspecialchars($file['original_filename']) ?></td>
                                <td><?= formatBytes($file['file_size']) ?></td>
                                <td style="text-transform: uppercase;"><?= htmlspecialchars($file['extension']) ?></td>
                                <td><span class="badge"><?= $file['host_count'] ?> Hosts</span></td>
                                <td style="color: var(--text-muted); font-size: 13px;">
                                    <?= htmlspecialchars(date('M j, Y H:i', strtotime($file['indexed_at']))) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>