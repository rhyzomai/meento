<?php
// =============================================
// seed.php — Generates key history data
// Run once after importing schema.sql
// =============================================
require_once 'config.php';

$db = getDB();

function generateWalk($startValue, $steps, $volatility) {
    $data = [$startValue];
    $current = $startValue;
    for ($i = 1; $i < $steps; $i++) {
        $current += (mt_rand() / mt_getrandmax() - 0.5) * $volatility;
        $data[] = round($current, 4);
    }
    return $data;
}

// Clear existing history
$db->exec("DELETE FROM key_history");

$keys = $db->query("SELECT id, all_time_start_value FROM public_keys")->fetchAll();

foreach ($keys as $key) {
    $start = (float)$key['all_time_start_value'];

    // month: 30 data points
    $monthData = generateWalk($start, 30, 15);
    $currentVal = end($monthData);

    // week: last 7 of month
    $weekData = array_slice($monthData, -7);

    // day: 24 points ending at current
    $dayStart = $currentVal + (mt_rand() / mt_getrandmax() - 0.5) * 10;
    $dayData = generateWalk($dayStart, 23, 3);
    $dayData[] = round($currentVal, 4);

    $stmt = $db->prepare("INSERT INTO key_history (public_key_id, timeframe, position_index, value) VALUES (?, ?, ?, ?)");

    foreach ([['day', $dayData], ['week', $weekData], ['month', $monthData]] as $pair) {
        list($tf, $arr) = $pair;
        foreach ($arr as $idx => $val) {
            $stmt->execute([$key['id'], $tf, $idx, $val]);
        }
    }
}

echo "✅ Seed complete. History generated for " . count($keys) . " public keys.\n";
