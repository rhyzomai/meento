<?php
// =============================================
// auth.php — Register / Login / Logout
// =============================================
require_once 'config.php';
sessionStart();

$action = $_POST['action'] ?? '';

// ── LOGOUT ───────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

// ── REGISTER ─────────────────────────────────
if ($action === 'register') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$email || !$password) {
        $_SESSION['auth_error'] = 'All fields are required.';
        header('Location: index.php?tab=register');
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['auth_error'] = 'Invalid email address.';
        header('Location: index.php?tab=register');
        exit;
    }
    if (strlen($password) < 6) {
        $_SESSION['auth_error'] = 'Password must be at least 6 characters.';
        header('Location: index.php?tab=register');
        exit;
    }

    $db = getDB();

    // Check uniqueness
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        $_SESSION['auth_error'] = 'Username or email already in use.';
        header('Location: index.php?tab=register');
        exit;
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password_hash, balance) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $email, $hash, STARTING_BALANCE]);
    $userId = $db->lastInsertId();

    $_SESSION['user_id']  = $userId;
    $_SESSION['username'] = $username;
    header('Location: dashboard.php');
    exit;
}

// ── LOGIN ─────────────────────────────────────
if ($action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $_SESSION['auth_error'] = 'Username and password are required.';
        header('Location: index.php');
        exit;
    }

    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, password_hash FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        $_SESSION['auth_error'] = 'Invalid credentials.';
        header('Location: index.php');
        exit;
    }

    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
    header('Location: dashboard.php');
    exit;
}

header('Location: index.php');
exit;
