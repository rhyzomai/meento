<?php
// =============================================
// api.php — JSON endpoints
// GET  ?action=stats&timeframe=month
// GET  ?action=balance
// GET  ?action=transactions
// POST action=deposit  { key_id, amount }
// =============================================
require_once 'config.php';
sessionStart();

if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated.'], 401);
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? ($_POST['action'] ?? (json_decode(file_get_contents('php://input'), true)['action'] ?? ''));

$db = getDB();

// ── GET stats ────────────────────────────────
if ($method === 'GET' && $action === 'stats') {
    $timeframe = $_GET['timeframe'] ?? 'month';
    if (!in_array($timeframe, ['day','week','month'])) $timeframe = 'month';

    $keys = $db->query("SELECT id, key_id, color, all_time_start_value FROM public_keys ORDER BY id")->fetchAll();

    $result = [];
    foreach ($keys as $key) {
        $stmt = $db->prepare(
            "SELECT value FROM key_history WHERE public_key_id = ? AND timeframe = ? ORDER BY position_index ASC"
        );
        $stmt->execute([$key['id'], $timeframe]);
        $history = array_column($stmt->fetchAll(), 'value');

        $result[] = [
            'id'                 => $key['key_id'],
            'db_id'              => (int)$key['id'],
            'color'              => $key['color'],
            'allTimeStartValue'  => (float)$key['all_time_start_value'],
            'history'            => array_map('floatval', $history)
        ];
    }

    jsonResponse(['success' => true, 'data' => $result]);
}

// ── GET balance ──────────────────────────────
if ($method === 'GET' && $action === 'balance') {
    $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([currentUserId()]);
    $row = $stmt->fetch();
    jsonResponse(['success' => true, 'balance' => (float)$row['balance']]);
}

// ── GET transactions ─────────────────────────
if ($method === 'GET' && $action === 'transactions') {
    $stmt = $db->prepare(
        "SELECT t.id, t.amount, t.balance_before, t.balance_after, t.status, t.created_at,
                pk.key_id
         FROM transactions t
         JOIN public_keys pk ON pk.id = t.public_key_id
         WHERE t.user_id = ?
         ORDER BY t.created_at DESC
         LIMIT 50"
    );
    $stmt->execute([currentUserId()]);
    $rows = $stmt->fetchAll();
    jsonResponse(['success' => true, 'data' => $rows]);
}

// ── POST deposit ─────────────────────────────
if ($method === 'POST') {
    $input   = json_decode(file_get_contents('php://input'), true);
    $keyDbId = isset($input['key_db_id']) ? (int)$input['key_db_id'] : 0;
    $amount  = isset($input['amount'])    ? (float)$input['amount']    : 0;

    if ($keyDbId <= 0 || $amount <= 0) {
        jsonResponse(['success' => false, 'message' => 'Invalid key or amount.'], 400);
    }
    if ($amount > 1000000) {
        jsonResponse(['success' => false, 'message' => 'Amount exceeds maximum per transaction.'], 400);
    }

    // Verify key exists
    $stmt = $db->prepare("SELECT id FROM public_keys WHERE id = ?");
    $stmt->execute([$keyDbId]);
    if (!$stmt->fetch()) {
        jsonResponse(['success' => false, 'message' => 'Public key not found.'], 404);
    }

    $userId = currentUserId();

    // Lock user row for atomic update
    $db->beginTransaction();
    try {
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        $balanceBefore = (float)$user['balance'];

        if ($balanceBefore < $amount) {
            $db->rollBack();
            jsonResponse(['success' => false, 'message' => 'Insufficient balance.'], 422);
        }

        $balanceAfter = round($balanceBefore - $amount, 2);

        // Deduct balance
        $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
        $stmt->execute([$balanceAfter, $userId]);

        // Record transaction
        $stmt = $db->prepare(
            "INSERT INTO transactions (user_id, public_key_id, amount, balance_before, balance_after, status)
             VALUES (?, ?, ?, ?, ?, 'completed')"
        );
        $stmt->execute([$userId, $keyDbId, $amount, $balanceBefore, $balanceAfter]);
        $txId = $db->lastInsertId();

        $db->commit();

        jsonResponse([
            'success'        => true,
            'message'        => 'Deposit successful.',
            'transaction_id' => (int)$txId,
            'balance_before' => $balanceBefore,
            'balance_after'  => $balanceAfter,
            'amount'         => $amount
        ]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Unknown action.'], 400);
