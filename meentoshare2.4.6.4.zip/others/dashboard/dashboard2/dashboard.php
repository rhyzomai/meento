<?php
// =============================================
// dashboard.php — Main application view
// =============================================
require_once 'config.php';
requireLogin();

$db   = getDB();
$stmt = $db->prepare("SELECT username, balance FROM users WHERE id = ?");
$stmt->execute([currentUserId()]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variance — Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:       #0a0c0e;
            --surface:  #111417;
            --surface2: #161a1f;
            --border:   #1f2428;
            --border2:  #252c34;
            --accent:   #e8ff47;
            --accent2:  #47c8ff;
            --text:     #e2e8f0;
            --muted:    #64748b;
            --danger:   #ff4757;
            --positive: #2ecc71;
            --mono:     'Space Mono', monospace;
            --sans:     'DM Sans', sans-serif;
        }

        body {
            font-family: var(--sans);
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }

        /* Grid bg */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(232,255,71,0.025) 1px, transparent 1px),
                linear-gradient(90deg, rgba(232,255,71,0.025) 1px, transparent 1px);
            background-size: 60px 60px;
            pointer-events: none;
            z-index: 0;
        }

        /* ── NAV ─────────────────────────────── */
        nav {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(10,12,14,0.92);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border2);
            padding: 0 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 58px;
        }

        .nav-brand {
            font-family: var(--mono);
            font-size: 16px;
            font-weight: 700;
            letter-spacing: -0.5px;
            color: var(--text);
        }

        .nav-brand span { color: var(--accent); }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .balance-badge {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(46,204,113,0.08);
            border: 1px solid rgba(46,204,113,0.2);
            border-radius: 8px;
            padding: 7px 14px;
        }

        .balance-label {
            font-family: var(--mono);
            font-size: 10px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--muted);
        }

        .balance-amount {
            font-family: var(--mono);
            font-size: 15px;
            font-weight: 700;
            color: var(--positive);
            transition: color .3s;
        }

        .nav-user {
            font-size: 13px;
            color: var(--muted);
        }

        .nav-user strong { color: var(--text); }

        .btn-logout {
            font-family: var(--mono);
            font-size: 11px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--muted);
            background: transparent;
            border: 1px solid var(--border2);
            border-radius: 5px;
            padding: 6px 12px;
            cursor: pointer;
            transition: all .2s;
        }

        .btn-logout:hover {
            color: var(--danger);
            border-color: var(--danger);
        }

        /* ── MAIN ────────────────────────────── */
        main {
            position: relative;
            z-index: 1;
            max-width: 1280px;
            margin: 0 auto;
            padding: 28px 24px 60px;
        }

        /* ── PAGE HEADER ─────────────────────── */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 14px;
        }

        .page-header h1 {
            font-family: var(--mono);
            font-size: 20px;
            color: var(--text);
        }

        .page-header h1 span { color: var(--muted); font-weight: 400; }

        .timeframe-select {
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--surface);
            border: 1px solid var(--border2);
            border-radius: 8px;
            padding: 8px 14px;
        }

        .timeframe-select label {
            font-family: var(--mono);
            font-size: 10px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--muted);
        }

        .timeframe-select select {
            background: transparent;
            border: none;
            color: var(--text);
            font-family: var(--sans);
            font-size: 13px;
            cursor: pointer;
            outline: none;
        }

        .timeframe-select select option { background: #1a1f26; }

        /* ── CARDS GRID ──────────────────────── */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        @media (max-width: 900px) { .dashboard-grid { grid-template-columns: 1fr; } }

        .card {
            background: var(--surface);
            border: 1px solid var(--border2);
            border-radius: 10px;
            padding: 22px;
        }

        .card-title {
            font-family: var(--mono);
            font-size: 11px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 18px;
        }

        .chart-wrap-line { position: relative; height: 320px; }
        .chart-wrap-pie  { position: relative; height: 280px; display: flex; justify-content: center; }

        /* ── KEYS TABLE ──────────────────────── */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        thead th {
            font-family: var(--mono);
            font-size: 10px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--muted);
            padding: 10px 14px;
            text-align: left;
            border-bottom: 1px solid var(--border2);
            white-space: nowrap;
        }

        tbody tr {
            border-bottom: 1px solid var(--border);
            transition: background .15s;
        }

        tbody tr:hover { background: rgba(255,255,255,0.02); }

        tbody td {
            padding: 12px 14px;
            vertical-align: middle;
        }

        .key-cell {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .key-dot {
            width: 9px; height: 9px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        .key-id {
            font-family: var(--mono);
            font-size: 13px;
            font-weight: 700;
            color: var(--text);
        }

        .val-pos { color: var(--positive); font-weight: 500; }
        .val-neg { color: var(--danger);   font-weight: 500; }

        /* Deposit button in table */
        .btn-deposit {
            font-family: var(--mono);
            font-size: 10px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #0a0c0e;
            background: var(--accent);
            border: none;
            border-radius: 5px;
            padding: 6px 12px;
            cursor: pointer;
            white-space: nowrap;
            transition: opacity .15s, transform .1s;
        }

        .btn-deposit:hover { opacity: .85; transform: translateY(-1px); }
        .btn-deposit:active { transform: translateY(0); }

        /* ── TRANSACTIONS TABLE ──────────────── */
        .section-title {
            font-family: var(--mono);
            font-size: 11px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border2);
        }

        .tx-empty {
            text-align: center;
            padding: 30px;
            color: var(--muted);
            font-size: 13px;
            font-style: italic;
        }

        .tx-status {
            display: inline-block;
            font-family: var(--mono);
            font-size: 9px;
            letter-spacing: 1px;
            text-transform: uppercase;
            padding: 3px 7px;
            border-radius: 4px;
            background: rgba(46,204,113,0.12);
            color: var(--positive);
            border: 1px solid rgba(46,204,113,0.25);
        }

        /* ── MODAL ───────────────────────────── */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(4px);
            z-index: 200;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            opacity: 0;
            pointer-events: none;
            transition: opacity .2s;
        }

        .modal-overlay.open {
            opacity: 1;
            pointer-events: all;
        }

        .modal {
            background: var(--surface);
            border: 1px solid var(--border2);
            border-radius: 12px;
            width: 100%;
            max-width: 420px;
            padding: 28px;
            transform: translateY(20px) scale(.97);
            transition: transform .2s;
            position: relative;
        }

        .modal-overlay.open .modal { transform: translateY(0) scale(1); }

        .modal-close {
            position: absolute;
            top: 16px; right: 16px;
            background: none;
            border: none;
            color: var(--muted);
            font-size: 20px;
            cursor: pointer;
            line-height: 1;
            padding: 4px;
            transition: color .15s;
        }

        .modal-close:hover { color: var(--text); }

        .modal-title {
            font-family: var(--mono);
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 4px;
        }

        .modal-subtitle {
            font-size: 12px;
            color: var(--muted);
            margin-bottom: 22px;
        }

        .modal-key-info {
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--bg);
            border: 1px solid var(--border2);
            border-radius: 7px;
            padding: 12px 14px;
            margin-bottom: 20px;
        }

        .modal-key-dot {
            width: 12px; height: 12px;
            border-radius: 50%;
        }

        .modal-key-id {
            font-family: var(--mono);
            font-size: 13px;
            font-weight: 700;
        }

        .modal-key-value {
            margin-left: auto;
            font-family: var(--mono);
            font-size: 13px;
            color: var(--accent2);
        }

        .available-balance {
            font-size: 12px;
            color: var(--muted);
            margin-bottom: 6px;
        }

        .available-balance strong {
            font-family: var(--mono);
            color: var(--positive);
        }

        .amount-input-wrap {
            position: relative;
            margin-bottom: 18px;
        }

        .amount-prefix {
            position: absolute;
            left: 14px; top: 50%;
            transform: translateY(-50%);
            font-family: var(--mono);
            font-size: 14px;
            color: var(--muted);
        }

        #depositAmount {
            width: 100%;
            background: var(--bg);
            border: 1px solid var(--border2);
            border-radius: 7px;
            padding: 13px 14px 13px 30px;
            font-family: var(--mono);
            font-size: 18px;
            color: var(--text);
            outline: none;
            transition: border-color .2s, box-shadow .2s;
        }

        #depositAmount:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(232,255,71,0.08);
        }

        .quick-amounts {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
        }

        .quick-btn {
            flex: 1;
            padding: 7px;
            background: var(--bg);
            border: 1px solid var(--border2);
            border-radius: 5px;
            font-family: var(--mono);
            font-size: 11px;
            color: var(--muted);
            cursor: pointer;
            transition: all .15s;
        }

        .quick-btn:hover {
            border-color: var(--accent);
            color: var(--accent);
        }

        .modal-error {
            background: rgba(255,71,87,0.1);
            border: 1px solid rgba(255,71,87,0.3);
            border-radius: 6px;
            padding: 10px 14px;
            font-size: 13px;
            color: var(--danger);
            margin-bottom: 14px;
            display: none;
        }

        .modal-success {
            background: rgba(46,204,113,0.1);
            border: 1px solid rgba(46,204,113,0.3);
            border-radius: 6px;
            padding: 10px 14px;
            font-size: 13px;
            color: var(--positive);
            margin-bottom: 14px;
            display: none;
        }

        .btn-confirm {
            width: 100%;
            padding: 13px;
            background: var(--accent);
            color: #0a0c0e;
            border: none;
            border-radius: 7px;
            font-family: var(--mono);
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            cursor: pointer;
            transition: opacity .2s;
        }

        .btn-confirm:hover { opacity: .88; }
        .btn-confirm:disabled { opacity: .4; cursor: not-allowed; }

        /* Loading spinner */
        .spinner {
            display: inline-block;
            width: 14px; height: 14px;
            border: 2px solid rgba(0,0,0,0.2);
            border-top-color: #0a0c0e;
            border-radius: 50%;
            animation: spin .6s linear infinite;
            vertical-align: middle;
            margin-right: 6px;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* Toast */
        .toast {
            position: fixed;
            bottom: 28px;
            right: 28px;
            z-index: 300;
            background: var(--surface);
            border: 1px solid var(--border2);
            border-radius: 8px;
            padding: 14px 18px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            transform: translateY(80px);
            opacity: 0;
            transition: all .25s;
            max-width: 320px;
        }

        .toast.show { transform: translateY(0); opacity: 1; }
        .toast.success { border-color: rgba(46,204,113,0.4); }
        .toast.error   { border-color: rgba(255,71,87,0.4);  }

        /* Status text */
        #statusText {
            font-size: 12px;
            font-family: var(--mono);
        }
    </style>
</head>
<body>

<!-- NAV -->
<nav>
    <div class="nav-brand">VARI<span>ANCE</span></div>
    <div class="nav-right">
        <div class="balance-badge">
            <span class="balance-label">Balance</span>
            <span class="balance-amount" id="navBalance">$<?= number_format((float)$user['balance'], 2) ?></span>
        </div>
        <span class="nav-user">Hey, <strong><?= htmlspecialchars($user['username']) ?></strong></span>
        <form method="POST" action="auth.php" style="margin:0">
            <input type="hidden" name="action" value="logout">
            <button type="submit" class="btn-logout">Logout</button>
        </form>
    </div>
</nav>

<!-- MAIN -->
<main>

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1>Key Variance <span>// Performance Monitor</span></h1>
            <div id="statusText" style="color:var(--muted); margin-top:4px;">Loading data...</div>
        </div>
        <div class="timeframe-select">
            <label>Timeframe</label>
            <select id="timeframe" onchange="loadStats()">
                <option value="day">Last 24h</option>
                <option value="week">Last 7 Days</option>
                <option value="month" selected>Last 30 Days</option>
            </select>
        </div>
    </div>

    <!-- Charts -->
    <div class="dashboard-grid">
        <div class="card">
            <div class="card-title">Value Over Time</div>
            <div class="chart-wrap-line">
                <canvas id="lineChart"></canvas>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Current Distribution</div>
            <div class="chart-wrap-pie">
                <canvas id="pieChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Keys Table -->
    <div class="card" style="margin-bottom:20px;">
        <div class="card-title">Performance Metrics — Click a key to deposit</div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Public Key</th>
                        <th>Current Value</th>
                        <th>Period Start</th>
                        <th>Period Change</th>
                        <th>All-Time Start</th>
                        <th>All-Time Change</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="keysTableBody">
                    <tr><td colspan="7" style="padding:30px;text-align:center;color:var(--muted);">Loading…</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Transactions -->
    <div class="card">
        <div class="section-title">Transaction History</div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Public Key</th>
                        <th>Amount</th>
                        <th>Balance Before</th>
                        <th>Balance After</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody id="txTableBody">
                    <tr><td colspan="7" class="tx-empty">No transactions yet.</td></tr>
                </tbody>
            </table>
        </div>
    </div>

</main>

<!-- DEPOSIT MODAL -->
<div class="modal-overlay" id="depositModal">
    <div class="modal">
        <button class="modal-close" onclick="closeModal()">✕</button>
        <div class="modal-title">Deposit to Key</div>
        <div class="modal-subtitle">Funds will be deducted from your balance</div>

        <div class="modal-key-info">
            <div class="modal-key-dot" id="modalKeyDot"></div>
            <span class="modal-key-id" id="modalKeyId">—</span>
            <span class="modal-key-value" id="modalKeyValue">—</span>
        </div>

        <div class="available-balance">
            Available balance: <strong id="modalBalance">$0.00</strong>
        </div>

        <div class="amount-input-wrap">
            <span class="amount-prefix">$</span>
            <input type="number" id="depositAmount" placeholder="0.00"
                   min="0.01" step="0.01" oninput="validateAmount()">
        </div>

        <div class="quick-amounts">
            <button class="quick-btn" onclick="setAmount(10)">$10</button>
            <button class="quick-btn" onclick="setAmount(50)">$50</button>
            <button class="quick-btn" onclick="setAmount(100)">$100</button>
            <button class="quick-btn" onclick="setAmount(250)">$250</button>
        </div>

        <div class="modal-error"  id="modalError"></div>
        <div class="modal-success" id="modalSuccess"></div>

        <button class="btn-confirm" id="confirmBtn" onclick="confirmDeposit()" disabled>
            Confirm Deposit
        </button>
    </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
// ── State ──────────────────────────────────
let dashData    = [];
let lineChart   = null;
let pieChart    = null;
let currentKey  = null;
let userBalance = <?= (float)$user['balance'] ?>;

// ── Helpers ────────────────────────────────
function fmt(n)    { return '$' + parseFloat(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function fmtN(n)   { return parseFloat(n).toFixed(2); }
function pct(s,e)  { return (((e-s)/s)*100).toFixed(2); }

function changeHtml(p) {
    const v = parseFloat(p);
    if (v > 0) return `<span class="val-pos">+${p}%</span>`;
    if (v < 0) return `<span class="val-neg">${p}%</span>`;
    return `<span>${p}%</span>`;
}

function showToast(msg, type = 'success') {
    const t = document.getElementById('toast');
    t.className = 'toast ' + type;
    t.innerHTML = (type === 'success' ? '✓ ' : '✗ ') + msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3500);
}

// ── Load Stats ─────────────────────────────
async function loadStats() {
    const tf = document.getElementById('timeframe').value;
    const status = document.getElementById('statusText');
    status.style.color = 'var(--muted)';
    status.innerText   = 'Fetching data…';

    try {
        const res  = await fetch('api.php?action=stats&timeframe=' + tf);
        const json = await res.json();
        if (!json.success) throw new Error(json.message);

        dashData = json.data;
        status.innerText   = '✔ Data loaded — ' + new Date().toLocaleTimeString();
        status.style.color = 'var(--positive)';

        renderTable(tf);
        renderLineChart(tf);
        renderPieChart();

    } catch(e) {
        status.innerText   = '✖ ' + (e.message || 'Load failed');
        status.style.color = 'var(--danger)';
    }
}

// ── Render Table ───────────────────────────
function renderTable(tf) {
    const processed = dashData.map(k => {
        const h   = k.history;
        const ps  = h[0];
        const cur = h[h.length - 1];
        return {
            ...k,
            currentValue:    cur,
            periodStart:     ps,
            periodChange:    pct(ps, cur),
            allTimeChange:   pct(k.allTimeStartValue, cur)
        };
    }).sort((a,b) => b.currentValue - a.currentValue);

    const tbody = document.getElementById('keysTableBody');
    tbody.innerHTML = '';

    processed.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <div class="key-cell">
                    <div class="key-dot" style="background:${item.color}"></div>
                    <span class="key-id">${item.id}</span>
                </div>
            </td>
            <td style="font-weight:600;font-family:var(--mono)">${fmtN(item.currentValue)}</td>
            <td style="font-family:var(--mono)">${fmtN(item.periodStart)}</td>
            <td>${changeHtml(item.periodChange)}</td>
            <td style="font-family:var(--mono)">${fmtN(item.allTimeStartValue)}</td>
            <td>${changeHtml(item.allTimeChange)}</td>
            <td>
                <button class="btn-deposit"
                    onclick="openModal(${item.db_id}, '${item.id}', '${item.color}', ${item.currentValue})">
                    + Deposit
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// ── Charts ─────────────────────────────────
function renderLineChart(tf) {
    const labelsMap = {
        day:   Array.from({length:24}, (_,i) => `T-${24-i}h`),
        week:  ['Day 1','Day 2','Day 3','Day 4','Day 5','Day 6','Today'],
        month: Array.from({length:30}, (_,i) => `D-${30-i}`)
    };

    const datasets = dashData.map(k => ({
        label:           k.id,
        data:            k.history,
        borderColor:     k.color,
        backgroundColor: k.color,
        borderWidth:     2,
        tension:         0.35,
        pointRadius:     2,
        pointHoverRadius:5
    }));

    if (lineChart) lineChart.destroy();
    lineChart = new Chart(document.getElementById('lineChart').getContext('2d'), {
        type: 'line',
        data: { labels: labelsMap[tf], datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode:'index', intersect:false },
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color:'#94a3b8', font:{ family:'Space Mono', size:10 }, boxWidth:10 }
                }
            },
            scales: {
                x: { ticks:{ color:'#475569', font:{size:10} }, grid:{ color:'rgba(255,255,255,0.04)' } },
                y: { ticks:{ color:'#475569', font:{size:10} }, grid:{ color:'rgba(255,255,255,0.04)' } }
            }
        }
    });
}

function renderPieChart() {
    const data   = dashData.map(k => k.history[k.history.length - 1]);
    const colors = dashData.map(k => k.color);
    const labels = dashData.map(k => k.id);

    if (pieChart) pieChart.destroy();
    pieChart = new Chart(document.getElementById('pieChart').getContext('2d'), {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{ data, backgroundColor: colors, borderWidth:1, borderColor:'#111417' }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position:'bottom',
                    labels:{ color:'#94a3b8', font:{family:'Space Mono', size:10}, boxWidth:10 }
                }
            }
        }
    });
}

// ── Load Transactions ──────────────────────
async function loadTransactions() {
    const res  = await fetch('api.php?action=transactions');
    const json = await res.json();
    if (!json.success) return;

    const tbody = document.getElementById('txTableBody');

    if (!json.data.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="tx-empty">No transactions yet — click a key to deposit.</td></tr>';
        return;
    }

    tbody.innerHTML = '';
    json.data.forEach(tx => {
        const tr = document.createElement('tr');
        const d  = new Date(tx.created_at.replace(' ','T'));
        tr.innerHTML = `
            <td style="font-family:var(--mono);color:var(--muted)">#${tx.id}</td>
            <td><span class="key-id">${tx.key_id}</span></td>
            <td style="font-family:var(--mono);color:var(--accent)">${fmt(tx.amount)}</td>
            <td style="font-family:var(--mono)">${fmt(tx.balance_before)}</td>
            <td style="font-family:var(--mono);color:var(--positive)">${fmt(tx.balance_after)}</td>
            <td><span class="tx-status">${tx.status}</span></td>
            <td style="color:var(--muted);font-size:12px">${d.toLocaleString()}</td>
        `;
        tbody.appendChild(tr);
    });
}

// ── Modal ──────────────────────────────────
function openModal(dbId, keyId, color, value) {
    currentKey = { dbId, keyId, color, value };

    document.getElementById('modalKeyDot').style.background   = color;
    document.getElementById('modalKeyId').innerText            = keyId;
    document.getElementById('modalKeyValue').innerText         = 'Value: ' + fmtN(value);
    document.getElementById('modalBalance').innerText          = fmt(userBalance);
    document.getElementById('depositAmount').value             = '';
    document.getElementById('modalError').style.display        = 'none';
    document.getElementById('modalSuccess').style.display      = 'none';
    document.getElementById('confirmBtn').disabled             = true;
    document.getElementById('confirmBtn').innerHTML            = 'Confirm Deposit';

    document.getElementById('depositModal').classList.add('open');
    document.getElementById('depositAmount').focus();
}

function closeModal() {
    document.getElementById('depositModal').classList.remove('open');
    currentKey = null;
}

// Close on overlay click
document.getElementById('depositModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// Escape key
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

function setAmount(v) {
    document.getElementById('depositAmount').value = v;
    validateAmount();
}

function validateAmount() {
    const input = document.getElementById('depositAmount');
    const val   = parseFloat(input.value);
    const btn   = document.getElementById('confirmBtn');
    const err   = document.getElementById('modalError');

    err.style.display = 'none';

    if (isNaN(val) || val <= 0) {
        btn.disabled = true;
        return;
    }

    if (val > userBalance) {
        err.innerText       = '⚠ Insufficient balance. Available: ' + fmt(userBalance);
        err.style.display   = 'block';
        btn.disabled        = true;
        return;
    }

    btn.disabled = false;
}

async function confirmDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    if (!currentKey || isNaN(amount) || amount <= 0) return;

    const btn     = document.getElementById('confirmBtn');
    const errDiv  = document.getElementById('modalError');
    const okDiv   = document.getElementById('modalSuccess');

    btn.disabled  = true;
    btn.innerHTML = '<span class="spinner"></span>Processing…';
    errDiv.style.display = 'none';
    okDiv.style.display  = 'none';

    try {
        const res  = await fetch('api.php?action=deposit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key_db_id: currentKey.dbId, amount })
        });
        const json = await res.json();

        if (!json.success) {
            errDiv.innerText     = '✖ ' + json.message;
            errDiv.style.display = 'block';
            btn.disabled         = false;
            btn.innerHTML        = 'Confirm Deposit';
            return;
        }

        // Success
        userBalance = json.balance_after;
        document.getElementById('navBalance').innerText  = fmt(userBalance);
        document.getElementById('modalBalance').innerText = fmt(userBalance);

        okDiv.innerText     = `✔ Deposited ${fmt(amount)} to ${currentKey.keyId}. New balance: ${fmt(userBalance)}`;
        okDiv.style.display = 'block';
        btn.innerHTML       = '✔ Done';

        showToast(`Deposited ${fmt(amount)} successfully`, 'success');
        loadTransactions();

        // Auto close after 1.8s
        setTimeout(() => {
            closeModal();
            btn.innerHTML = 'Confirm Deposit';
        }, 1800);

    } catch(e) {
        errDiv.innerText     = '✖ Network error. Please try again.';
        errDiv.style.display = 'block';
        btn.disabled         = false;
        btn.innerHTML        = 'Confirm Deposit';
    }
}

// ── Init ───────────────────────────────────
window.addEventListener('DOMContentLoaded', function() {
    loadStats();
    loadTransactions();
});
</script>
</body>
</html>
