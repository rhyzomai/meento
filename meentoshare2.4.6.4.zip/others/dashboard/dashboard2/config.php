<?php
// =============================================
// config.php — Database connection & constants
// =============================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'variance_db');
define('DB_USER', 'root');       // Change to your MySQL user
define('DB_PASS', '');           // Change to your MySQL password
define('DB_CHARSET', 'utf8mb4');

define('STARTING_BALANCE', 1000.00);
define('APP_NAME', 'Variance Dashboard');

// ── PDO Connection ──────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            // Connect WITHOUT selecting a database first so we can create it if missing
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET,
                DB_USER, DB_PASS, $options
            );
            // Create database if it doesn't exist
            $pdo->exec(
                "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "`
                 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            );
            $pdo->exec("USE `" . DB_NAME . "`");
            // Create tables & seed data if needed
            installSchema($pdo);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ── Auto-install schema ──────────────────────
function installSchema(PDO $pdo) {
    // Users
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username     VARCHAR(50)  NOT NULL UNIQUE,
            email        VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            balance      DECIMAL(18,2) NOT NULL DEFAULT 1000.00,
            created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Public keys
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS public_keys (
            id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            key_id              VARCHAR(20)  NOT NULL UNIQUE,
            color               VARCHAR(10)  NOT NULL DEFAULT '#4bc0c0',
            all_time_start_value DECIMAL(18,2) NOT NULL,
            created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Key history
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS key_history (
            id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            public_key_id  INT UNSIGNED NOT NULL,
            timeframe      ENUM('day','week','month') NOT NULL,
            position_index SMALLINT UNSIGNED NOT NULL,
            value          DECIMAL(18,4) NOT NULL,
            FOREIGN KEY (public_key_id) REFERENCES public_keys(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Transactions
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS transactions (
            id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id        INT UNSIGNED NOT NULL,
            public_key_id  INT UNSIGNED NOT NULL,
            amount         DECIMAL(18,2) NOT NULL,
            balance_before DECIMAL(18,2) NOT NULL,
            balance_after  DECIMAL(18,2) NOT NULL,
            status         ENUM('completed','failed') NOT NULL DEFAULT 'completed',
            created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id)       REFERENCES users(id)       ON DELETE CASCADE,
            FOREIGN KEY (public_key_id) REFERENCES public_keys(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Seed public keys (only if table is empty)
    $count = $pdo->query("SELECT COUNT(*) FROM public_keys")->fetchColumn();
    if ((int)$count === 0) {
        $pdo->exec("
            INSERT INTO public_keys (key_id, color, all_time_start_value) VALUES
                ('0x1A2b...89cF', '#ff6384', 50.00),
                ('0x4F5c...32dA', '#36a2eb', 75.00),
                ('0x7E8d...11bB', '#4bc0c0', 100.00),
                ('0x9C2a...77eF', '#ff9f40', 125.00)
        ");
        // Seed chart history for each key
        seedHistory($pdo);
    }
}

// ── Seed chart history ───────────────────────
function seedHistory(PDO $pdo) {
    $keys = $pdo->query("SELECT id, all_time_start_value FROM public_keys")->fetchAll();
    $stmt = $pdo->prepare(
        "INSERT INTO key_history (public_key_id, timeframe, position_index, value)
         VALUES (?, ?, ?, ?)"
    );

    foreach ($keys as $key) {
        $start = (float)$key['all_time_start_value'];

        // month: 30 points
        $monthData = _randomWalk($start, 30, 15);
        $currentVal = end($monthData);

        // week: last 7 of month
        $weekData = array_slice($monthData, -7);

        // day: 24 points ending at current value
        $dayStart  = $currentVal + (mt_rand() / mt_getrandmax() - 0.5) * 10;
        $dayData   = _randomWalk($dayStart, 23, 3);
        $dayData[] = round($currentVal, 4);

        foreach ([['day',$dayData], ['week',$weekData], ['month',$monthData]] as $pair) {
            list($tf, $arr) = $pair;
            foreach ($arr as $idx => $val) {
                $stmt->execute([$key['id'], $tf, $idx, $val]);
            }
        }
    }
}

function _randomWalk($start, $steps, $volatility) {
    $data    = [$start];
    $current = $start;
    for ($i = 1; $i < $steps; $i++) {
        $current += (mt_rand() / mt_getrandmax() - 0.5) * $volatility;
        $data[]   = round($current, 4);
    }
    return $data;
}

// ── Session helpers ─────────────────────────
function sessionStart() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function isLoggedIn() {
    sessionStart();
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function currentUserId() {
    return $_SESSION['user_id'] ?? null;
}

// ── JSON response helper ────────────────────
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
