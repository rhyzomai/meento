﻿# ServersDiscovery

A single-file, dependency-free Java 8 utility that maintains peer discovery and
health-checking for an HTTP/HTTPS-based DHT-style file cluster.

It keeps a local `servers.txt` of known-good peers, periodically re-verifies
each peer by fetching a random test file and checking its SHA-256 hash, and
crawls peers-of-peers (BFS) to discover new servers via gossip.

> **Run this program ALONGSIDE (or BEFORE) your main application.**
> It is responsible for maintaining `servers.txt` and pruning peers that fail
> the random hash test, which is what keeps the cluster honest.

## Features

- **Self-hosted HTTP + HTTPS servers** (auto-generates a self-signed
  certificate/keystore on first run — no OpenSSL or external libraries
  required).
- **Health checking** — for every candidate peer, fetches `/files.txt`, picks
  a random test vector, downloads `/files/<name>`, and verifies the SHA-256
  hash matches the filename. Peers that fail are removed from the list.
- **BFS peer crawling** — after a peer passes its check, its own
  `/servers.txt` is fetched and the new peers are queued for checking, up to
  a configurable depth (default `2`).
- **Gossip / self-announce** — when you manually `add` a peer, this instance
  introduces itself by POSTing its own announce URLs to that peer's
  `/servers.txt`.
- **Interactive console** for managing peers and settings at runtime.
- **Persistent state** — `servers.txt` (active peers) and `files.txt` (local
  test vectors) are read on startup and rewritten as state changes.

## Requirements

- Java 8 or later (uses only the JDK standard library, including
  `com.sun.net.httpserver` for the embedded HTTP/HTTPS servers).
- No external dependencies, no build tool required.

## Build & Run

```bash
javac ServersDiscovery.java
java ServersDiscovery
```

With custom options:

```bash
java ServersDiscovery -http 8080 -https 8443 -depth 2 -interval 30
```

### CLI Flags

| Flag                | Description                                      | Default              |
|---------------------|---------------------------------------------------|-----------------------|
| `-http <port>`       | HTTP listen port                                  | `8080`                |
| `-https <port>`      | HTTPS listen port                                 | `8443`                |
| `-depth <n>`         | BFS crawl depth for discovery                     | `2`                   |
| `-interval <sec>`    | Seconds between automatic discovery cycles        | `60`                  |
| `-timeout <sec>`     | Per-request connect/read timeout                  | `10`                  |
| `-bind <host>`       | Address to bind the servers to                    | `0.0.0.0`             |
| `-kspass <pass>`     | Password for the auto-generated keystore          | `serversdiscovery`    |
| `-announce-http <url>`  | URL advertised to peers for HTTP             | `http://<host>:<port>`  |
| `-announce-https <url>` | URL advertised to peers for HTTPS            | `https://<host>:<port>` |

## Files Used

| File           | Purpose                                                                 |
|----------------|--------------------------------------------------------------------------|
| `servers.txt`  | List of known/active peer base URLs (one per line, `http://` or `https://`). |
| `files.txt`    | Local test vectors, one `hash.ext` per line, where `hash` is the lower-case hex SHA-256 of the file's contents. |
| `files/`       | Directory containing the actual files referenced in `files.txt`, served at `/files/<name>`. |
| `keystore.jks` | Auto-generated self-signed TLS keystore used by the HTTPS server (created on first run if missing). |

## HTTP Endpoints (served by every node)

| Method | Path             | Description                                                              |
|--------|------------------|----------------------------------------------------------------------------|
| GET    | `/` or `/health` | Basic status: self URLs and current peer count.                          |
| GET    | `/files.txt`     | Returns the local test-vector list.                                      |
| GET    | `/files/<name>`  | Returns the raw bytes of a test file.                                    |
| GET    | `/servers.txt`   | Returns the local peer list.                                             |
| POST/PUT | `/servers.txt` | Accepts newline-separated peer URLs in the body and merges them into the local peer list (used for gossip/self-announce). |

## Interactive Console Commands

| Command          | Description                                              |
|------------------|------------------------------------------------------------|
| `add <url>`      | Manually add a peer and announce ourselves to it.         |
| `remove <url>`   | Remove a peer.                                             |
| `list`           | List all known peers.                                      |
| `check`          | Run a discovery cycle immediately.                          |
| `files`          | List local test vectors loaded from `files.txt`.            |
| `depth <n>`      | Set BFS crawl depth.                                        |
| `interval <s>`   | Set discovery interval (takes effect after restart).        |
| `-options`       | Open sub-prompt to change `http`, `https`, `depth`, `interval`, `timeout`, `bind`, `kspass`, `announce-http`, `announce-https`. |
| `help`           | Show command help.                                          |
| `quit` / `exit`  | Exit the program.                                            |

## How Discovery Works

1. On startup (and every `interval` seconds), a discovery cycle begins from
   the current `servers.txt` list.
2. Each candidate peer is checked: does it serve `/files.txt`? If local test
   vectors exist, a random one is fetched from `/files/<name>` on that peer
   and its SHA-256 is verified against the filename.
3. Peers that pass are kept (and added if new); peers that fail are removed.
4. For each peer that passes, its own `/servers.txt` is fetched to discover
   further peers, which are queued for the next BFS depth level — up to
   `crawlDepth` levels deep.
5. The updated peer list is persisted to `servers.txt` at the end of each
   cycle.

## Security Notes

- The HTTPS server uses a **self-signed certificate** generated at startup
  (valid for `localhost` / `127.0.0.1` plus 10 years); clients connecting to
  it will need to trust or ignore certificate validation.
- There is no authentication on the `/servers.txt` POST/PUT endpoint — any
  reachable client can submit peer URLs to be merged into your list. The
  hash-verification check is what filters out peers that don't actually
  serve the expected files, but this is not a substitute for network-level
  access control if you're operating outside a trusted environment.