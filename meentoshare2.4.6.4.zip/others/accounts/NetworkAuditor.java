import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * NetworkAuditor � UserStore network audit tool
 *
 * For every account in accounts/ this program:
 *  1. Verifies local files: filename must equal sha256(content) + original extension.
 *  2. Checks every server declared in the account's "servers" map:
 *       - Fetches GET <server>/files/<hash>.<ext> and verifies sha256.
 *       - Fetches GET <server>/info/<hash>.json and reads "public_key".
 *  3. Enforces the self-hosting rule:
 *       - Resolves the user's own "user_server" host to IP addresses.
 *       - Any peer server whose host resolves to any of the same IPs is flagged
 *         and its validations are NOT counted toward the user's score.
 *  4. Accumulates per-server statistics across all users.
 *  5. At the end writes a "log" file (plain-text) with:
 *       - Per-user audit summary.
 *       - Server status table for every server that has >= 1 valid file
 *         OR >= 1 awarded earn point across all users.
 *
 * Expected directory layout (relative to working directory):
 *   accounts/   � <userhash>.json  (UserStore v2 format)
 *   files/      � <sha256>.<ext>   (locally hosted files)
 *   log         � written by this program (overwritten each run)
 *
 * Remote nodes must expose:
 *   GET <server>/files/<hash>.<ext>   raw file bytes
 *   GET <server>/info/<hash>.json     JSON with at least {"public_key":"..."}
 *
 * Compatible with Java 8+, zero external dependencies.
 */
public class NetworkAuditor {

    // ------------------------------------------------------------------ //
    //  Configuration
    // ------------------------------------------------------------------ //
    private static final String ACCOUNTS_DIR    = "accounts";
    private static final String FILES_DIR       = "files";
    private static final String LOG_FILE        = "log";
    private static final int    CONNECT_TIMEOUT = 8_000;   // ms
    private static final int    READ_TIMEOUT    = 15_000;  // ms

    // ------------------------------------------------------------------ //
    //  Data model
    // ------------------------------------------------------------------ //

    /** Result of auditing a single file on a single server. */
    static class FileCheckResult {
        final String  serverUrl;
        final String  fileRef;
        final boolean reachable;
        final boolean hashOk;
        final String  remotePublicKey;  // null if not fetched
        final boolean isSelfHosted;     // server IP == user's own IP
        final String  note;

        FileCheckResult(String serverUrl, String fileRef,
                        boolean reachable, boolean hashOk,
                        String remotePublicKey, boolean isSelfHosted, String note) {
            this.serverUrl       = serverUrl;
            this.fileRef         = fileRef;
            this.reachable       = reachable;
            this.hashOk          = hashOk;
            this.remotePublicKey = remotePublicKey;
            this.isSelfHosted    = isSelfHosted;
            this.note            = note;
        }

        /** True only when the check is externally valid (reachable + hash ok + not self). */
        boolean isExternallyValid() {
            return reachable && hashOk && !isSelfHosted;
        }
    }

    /** Aggregated statistics for one server URL across all users. */
    static class ServerStats {
        final String normalizedUrl;
        int  totalChecks      = 0;
        int  validFiles       = 0;   // reachable + hash ok + not self-hosted
        int  invalidFiles     = 0;
        int  selfHostedSkips  = 0;
        int  unreachable      = 0;
        int  earnedPoints     = 0;   // unique (user, file) pairs validated here
        final Set<String> usersServed = new LinkedHashSet<>();

        ServerStats(String normalizedUrl) {
            this.normalizedUrl = normalizedUrl;
        }

        /** Should appear in the log (at least one valid file or earned point). */
        boolean isReportWorthy() {
            return validFiles > 0 || earnedPoints > 0;
        }
    }

    /** Full audit result for one user. */
    static class UserAuditResult {
        final String username;
        final String usernameHash;
        final String userPublicKey;
        final String serverPublicKey;
        final String userServer;
        int localFilesOk      = 0;
        int localFilesBad     = 0;
        int localFilesMissing = 0;
        final List<FileCheckResult> remoteChecks = new ArrayList<>();
        final List<String> warnings = new ArrayList<>();

        UserAuditResult(String username, String usernameHash,
                        String userPublicKey, String serverPublicKey,
                        String userServer) {
            this.username        = username;
            this.usernameHash    = usernameHash;
            this.userPublicKey   = userPublicKey;
            this.serverPublicKey = serverPublicKey;
            this.userServer      = userServer;
        }

        int validRemoteChecks() {
            int n = 0;
            for (FileCheckResult r : remoteChecks) if (r.isExternallyValid()) n++;
            return n;
        }
    }

    // ------------------------------------------------------------------ //
    //  Main
    // ------------------------------------------------------------------ //
    public static void main(String[] args) throws Exception {
        log("=== NetworkAuditor starting � " + timestamp() + " ===");
        log("");

        // Collect local machine IPs once � used to detect self-hosting
        Set<String> localIps = resolveLocalIps();
        log("[local] Machine IP addresses: " + localIps);
        log("");

        // Discover account files
        File accountsDir = new File(ACCOUNTS_DIR);
        if (!accountsDir.isDirectory()) {
            die("accounts/ directory not found. Run from the UserStore root.");
        }

        File[] accountFiles = accountsDir.listFiles(
                f -> f.isFile()
                  && f.getName().endsWith(".json")
                  && !f.getName().endsWith(".tmp.json")
                  && !f.getName().equals("tmp"));
        if (accountFiles == null || accountFiles.length == 0) {
            log("[warn] No account files found in accounts/.");
            writeLogFile(Collections.<UserAuditResult>emptyList(),
                         Collections.<String, ServerStats>emptyMap());
            return;
        }

        // Sort for deterministic output
        Arrays.sort(accountFiles, Comparator.comparing(File::getName));
        log("[accounts] Found " + accountFiles.length + " account(s).\n");

        // Per-server stats accumulated across all users
        Map<String, ServerStats> serverStatsMap = new LinkedHashMap<>();

        // Audit each account
        List<UserAuditResult> results = new ArrayList<>();
        for (File af : accountFiles) {
            UserAuditResult result = auditAccount(af, localIps, serverStatsMap);
            if (result != null) results.add(result);
        }

        // Print summary to stdout
        printSummary(results, serverStatsMap);

        // Write log file
        writeLogFile(results, serverStatsMap);

        log("\n=== NetworkAuditor finished � " + timestamp() + " ===");
    }

    // ------------------------------------------------------------------ //
    //  Account audit
    // ------------------------------------------------------------------ //
    private static UserAuditResult auditAccount(
            File accountFile,
            Set<String> localIps,
            Map<String, ServerStats> serverStatsMap) {

        log("--- Account: " + accountFile.getName() + " ---");

        Map<String, Object> account;
        try {
            account = parseJsonObject(readFile(accountFile));
        } catch (Exception e) {
            log("  [error] Cannot parse account JSON: " + e.getMessage());
            return null;
        }

        String username        = str(account, "username");
        String usernameHash    = str(account, "username_hash");
        String userPublicKey   = str(account, "public_key");
        String serverPublicKey = str(account, "server_public_key");
        String userServer      = str(account, "user_server");

        log("  User     : " + username + " (" + shortHash(usernameHash) + ")");
        log("  Pub key  : " + shortKey(userPublicKey));
        log("  Srv key  : " + shortKey(serverPublicKey));
        log("  Own srv  : " + (userServer.isEmpty() ? "(none)" : userServer));

        UserAuditResult result = new UserAuditResult(
                username, usernameHash, userPublicKey, serverPublicKey, userServer);

        @SuppressWarnings("unchecked")
        List<Object> fileRefsRaw =
                (List<Object>) account.getOrDefault("files", Collections.emptyList());
        List<String> fileRefs = new ArrayList<>();
        for (Object o : fileRefsRaw) fileRefs.add(o.toString());

        @SuppressWarnings("unchecked")
        Map<String, Object> serversMap =
                (Map<String, Object>) account.getOrDefault("servers", Collections.emptyMap());

        log("  Files    : " + fileRefs.size());
        log("  Servers  : " + serversMap.size());

        // -- Resolve user's own server IPs for self-hosting detection --
        Set<String> userServerIps = resolveHostIps(userServer);
        if (!userServerIps.isEmpty()) {
            log("  Own srv IPs: " + userServerIps);
        }

        // -- Step 1: Local file integrity -------------------------------- //
        log("\n  [local integrity]");
        for (String fileRef : fileRefs) {
            String localStatus = checkLocalFile(fileRef);
            if ("ok".equals(localStatus)) {
                result.localFilesOk++;
                log("    OK       " + fileRef);
            } else if ("missing".equals(localStatus)) {
                result.localFilesMissing++;
                log("    MISSING  " + fileRef);
                result.warnings.add("Local file missing: " + fileRef);
            } else {
                result.localFilesBad++;
                log("    BAD HASH " + fileRef + "  (" + localStatus + ")");
                result.warnings.add("Local hash mismatch: " + fileRef);
            }
        }

        // -- Step 2: Remote server checks -------------------------------- //
        if (!serversMap.isEmpty()) {
            log("\n  [remote checks]");
        }

        for (Map.Entry<String, Object> entry : serversMap.entrySet()) {
            String serverAddress = entry.getValue().toString();
            String normalizedUrl = normalizeUrl(serverAddress);

            // Detect self-hosting: resolve server host IPs, compare against user's own
            Set<String> serverIps      = resolveHostIps(normalizedUrl);
            boolean     isSelfHosted   = isSameHost(userServerIps, serverIps, localIps, normalizedUrl, userServer);

            // Also warn if server IP equals any local machine IP
            boolean isLocalMachine = shareAnyIp(serverIps, localIps);

            // Get or create server stats record
            ServerStats stats = serverStatsMap.computeIfAbsent(
                    normalizedUrl, ServerStats::new);
            stats.usersServed.add(usernameHash);

            if (isSelfHosted) {
                log("    SELF-HOST " + serverAddress + " (skipped � same host as user_server)");
                result.warnings.add("Self-hosted server skipped: " + serverAddress);
                stats.selfHostedSkips++;
                // Still check the file for informational purposes but mark it
                for (String fileRef : fileRefs) {
                    stats.totalChecks++;
                    FileCheckResult fcr = checkRemoteFile(
                            normalizedUrl, fileRef, /*isSelf=*/true);
                    result.remoteChecks.add(fcr);
                }
                continue;
            }

            if (isLocalMachine) {
                result.warnings.add("Server " + serverAddress + " resolves to a local machine IP.");
            }

            // Check every file on this server
            for (String fileRef : fileRefs) {
                stats.totalChecks++;
                FileCheckResult fcr = checkRemoteFile(normalizedUrl, fileRef, /*isSelf=*/false);
                result.remoteChecks.add(fcr);

                if (!fcr.reachable) {
                    stats.unreachable++;
                    log("    UNREACHABLE  " + serverAddress + "  ->  " + fileRef);
                } else if (!fcr.hashOk) {
                    stats.invalidFiles++;
                    log("    HASH FAIL    " + serverAddress + "  ->  " + fileRef
                            + "  (pubkey=" + shortKey(fcr.remotePublicKey) + ")");
                    result.warnings.add("Hash mismatch on " + serverAddress + " for " + fileRef);
                } else {
                    stats.validFiles++;
                    stats.earnedPoints++;   // one valid (server, file) pair = 1 point
                    log("    VALID        " + serverAddress + "  ->  " + fileRef
                            + "  pubkey=" + shortKey(fcr.remotePublicKey));

                    // Warn if remote public key differs from account's declared key
                    if (fcr.remotePublicKey != null
                            && !fcr.remotePublicKey.isEmpty()
                            && !fcr.remotePublicKey.equals(userPublicKey)) {
                        log("    [warn] Remote pubkey differs from account pubkey!");
                        result.warnings.add("Public key mismatch on " + serverAddress
                                + " for " + fileRef);
                    }
                }
            }
        }

        log("");
        return result;
    }

    // ------------------------------------------------------------------ //
    //  Local file integrity check
    // ------------------------------------------------------------------ //

    /**
     * Returns "ok", "missing", or the actual hash (if mismatch).
     */
    private static String checkLocalFile(String fileRef) {
        // fileRef = "<sha256hash>.<ext>"
        int dot = fileRef.lastIndexOf('.');
        if (dot < 0) return "bad-ref";

        String expectedHash = fileRef.substring(0, dot);
        File   localFile    = new File(FILES_DIR, fileRef);

        if (!localFile.exists()) return "missing";

        try {
            byte[] data   = readBytes(localFile);
            String actual = sha256Hex(data);
            return actual.equalsIgnoreCase(expectedHash) ? "ok" : "hash=" + actual.substring(0, 16) + "�";
        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    // ------------------------------------------------------------------ //
    //  Remote file check
    // ------------------------------------------------------------------ //
    private static FileCheckResult checkRemoteFile(
            String serverBase, String fileRef, boolean isSelf) {

        int dot = fileRef.lastIndexOf('.');
        String expectedHash = (dot >= 0) ? fileRef.substring(0, dot) : fileRef;

        String fileUrl = serverBase + "/files/" + fileRef;
        String infoUrl = serverBase + "/info/"  + expectedHash + ".json";

        // Fetch file bytes
        byte[] data;
        try {
            data = httpGetBytes(fileUrl);
        } catch (Exception e) {
            return new FileCheckResult(serverBase, fileRef,
                    false, false, null, isSelf, "fetch error: " + e.getMessage());
        }
        if (data == null) {
            return new FileCheckResult(serverBase, fileRef,
                    false, false, null, isSelf, "HTTP non-200");
        }

        // Verify hash
        boolean hashOk;
        try {
            hashOk = sha256Hex(data).equalsIgnoreCase(expectedHash);
        } catch (Exception e) {
            hashOk = false;
        }

        // Fetch public key from info endpoint
        String remotePubKey = null;
        try {
            String infoJson = httpGetString(infoUrl);
            if (infoJson != null) {
                Map<String, Object> info = parseJsonObject(infoJson);
                remotePubKey = str(info, "public_key");
            }
        } catch (Exception ignored) { /* info endpoint is best-effort */ }

        return new FileCheckResult(serverBase, fileRef,
                true, hashOk, remotePubKey, isSelf,
                hashOk ? "ok" : "hash mismatch");
    }

    // ------------------------------------------------------------------ //
    //  Self-hosting detection
    // ------------------------------------------------------------------ //

    /**
     * Returns true if the peer server should be considered "self-hosted" by
     * this user � i.e. its resolved IPs overlap with the user's own server IPs.
     */
    private static boolean isSameHost(
            Set<String> userServerIps,
            Set<String> peerServerIps,
            Set<String> localMachineIps,
            String      peerUrl,
            String      userServerUrl) {

        // Exact URL match (normalized)
        if (!userServerUrl.isEmpty()
                && normalizeUrl(peerUrl).equalsIgnoreCase(normalizeUrl(userServerUrl))) {
            return true;
        }

        // IP overlap between user's server and peer server
        if (!userServerIps.isEmpty() && shareAnyIp(userServerIps, peerServerIps)) {
            return true;
        }

        // Peer resolves to the local machine AND the user declared a user_server �
        // both conditions must be true to avoid false-positives on nodes with no
        // user_server that happen to run the audit locally.
        if (!userServerUrl.isEmpty() && shareAnyIp(peerServerIps, localMachineIps)) {
            return true;
        }

        return false;
    }

    private static boolean shareAnyIp(Set<String> a, Set<String> b) {
        for (String ip : a) if (b.contains(ip)) return true;
        return false;
    }

    // ------------------------------------------------------------------ //
    //  Output � summary to stdout
    // ------------------------------------------------------------------ //
    private static void printSummary(
            List<UserAuditResult> results,
            Map<String, ServerStats> serverStatsMap) {

        log("========================================");
        log(" AUDIT SUMMARY");
        log("========================================");
        for (UserAuditResult r : results) {
            log("\nUser: " + r.username + " (" + shortHash(r.usernameHash) + ")");
            log("  Local files  � OK: " + r.localFilesOk
                    + "  bad: " + r.localFilesBad
                    + "  missing: " + r.localFilesMissing);
            log("  Remote valid � " + r.validRemoteChecks() + "/" + r.remoteChecks.size());
            if (!r.warnings.isEmpty()) {
                for (String w : r.warnings) log("  [!] " + w);
            }
        }

        log("\n--- Server Status ---");
        int reported = 0;
        for (ServerStats s : serverStatsMap.values()) {
            if (s.isReportWorthy()) {
                reported++;
                log("  " + s.normalizedUrl);
                log("    Valid files : " + s.validFiles
                        + "  |  Earned pts: " + s.earnedPoints
                        + "  |  Users: " + s.usersServed.size());
                log("    Invalid: " + s.invalidFiles
                        + "  |  Unreachable: " + s.unreachable
                        + "  |  Self-skipped: " + s.selfHostedSkips);
            }
        }
        if (reported == 0) log("  (no servers with valid files or earned points)");
    }

    // ------------------------------------------------------------------ //
    //  Output � log file
    // ------------------------------------------------------------------ //
    private static void writeLogFile(
            List<UserAuditResult> results,
            Map<String, ServerStats> serverStatsMap) throws IOException {

        StringBuilder sb = new StringBuilder();
        String sep = "=".repeat(72) + "\n";
        String dash = "-".repeat(72) + "\n";

        sb.append(sep);
        sb.append("  NetworkAuditor � Log\n");
        sb.append("  Generated : ").append(timestamp()).append("\n");
        sb.append(sep).append("\n");

        // -- Per-user section -------------------------------------------- //
        sb.append("USER AUDIT RESULTS\n").append(dash);

        for (UserAuditResult r : results) {
            sb.append("\nUsername        : ").append(r.username).append("\n");
            sb.append("Username hash   : ").append(r.usernameHash).append("\n");
            sb.append("Public key      : ").append(r.userPublicKey).append("\n");
            sb.append("Srv public key  : ").append(r.serverPublicKey).append("\n");
            sb.append("User server     : ").append(r.userServer.isEmpty() ? "(none)" : r.userServer).append("\n");

            sb.append("\nLocal file integrity:\n");
            sb.append("  OK      : ").append(r.localFilesOk).append("\n");
            sb.append("  Bad hash: ").append(r.localFilesBad).append("\n");
            sb.append("  Missing : ").append(r.localFilesMissing).append("\n");

            sb.append("\nRemote checks (").append(r.remoteChecks.size()).append(" total):\n");

            // Group by server
            Map<String, List<FileCheckResult>> byServer = new LinkedHashMap<>();
            for (FileCheckResult fc : r.remoteChecks) {
                byServer.computeIfAbsent(fc.serverUrl, k -> new ArrayList<>()).add(fc);
            }
            for (Map.Entry<String, List<FileCheckResult>> e : byServer.entrySet()) {
                sb.append("  Server: ").append(e.getKey()).append("\n");
                for (FileCheckResult fc : e.getValue()) {
                    String status;
                    if (fc.isSelfHosted)      status = "SELF-HOSTED (skipped)";
                    else if (!fc.reachable)   status = "UNREACHABLE";
                    else if (!fc.hashOk)      status = "HASH MISMATCH";
                    else                      status = "VALID";

                    sb.append("    ").append(padRight(status, 24))
                      .append(fc.fileRef).append("\n");

                    if (fc.remotePublicKey != null && !fc.remotePublicKey.isEmpty()) {
                        sb.append("    ").append(padRight("", 24))
                          .append("pubkey: ").append(fc.remotePublicKey).append("\n");
                    }
                    if (fc.note != null && !"ok".equals(fc.note)) {
                        sb.append("    ").append(padRight("", 24))
                          .append("note  : ").append(fc.note).append("\n");
                    }
                }
            }

            if (!r.warnings.isEmpty()) {
                sb.append("\nWarnings:\n");
                for (String w : r.warnings) sb.append("  [!] ").append(w).append("\n");
            }

            sb.append("\n").append(dash);
        }

        // -- Server status section (only report-worthy servers) ----------- //
        sb.append("\nSERVER STATUS (>= 1 valid file or earned point)\n").append(dash);

        boolean anyReported = false;
        for (ServerStats s : serverStatsMap.values()) {
            if (!s.isReportWorthy()) continue;
            anyReported = true;

            sb.append("\nServer URL      : ").append(s.normalizedUrl).append("\n");
            sb.append("Users served    : ").append(s.usersServed.size()).append("\n");
            sb.append("Total checks    : ").append(s.totalChecks).append("\n");
            sb.append("Valid files     : ").append(s.validFiles).append("\n");
            sb.append("Invalid files   : ").append(s.invalidFiles).append("\n");
            sb.append("Unreachable     : ").append(s.unreachable).append("\n");
            sb.append("Self-skipped    : ").append(s.selfHostedSkips).append("\n");
            sb.append("Earned points   : ").append(s.earnedPoints).append("\n");
            sb.append("Health          : ").append(serverHealth(s)).append("\n");
        }

        if (!anyReported) {
            sb.append("(no servers meet the reporting threshold)\n");
        }

        sb.append("\n").append(sep);
        sb.append("END OF LOG\n");
        sb.append(sep);

        // Write to disk
        try (FileOutputStream fos = new FileOutputStream(LOG_FILE);
             OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
             BufferedWriter bw = new BufferedWriter(osw)) {
            bw.write(sb.toString());
        }

        System.out.println("\n[log] Written -> " + new File(LOG_FILE).getAbsolutePath());
    }

    /** Human-readable health label for a server. */
    private static String serverHealth(ServerStats s) {
        if (s.totalChecks == 0) return "NO_DATA";
        int valid = s.validFiles;
        int total = s.totalChecks - s.selfHostedSkips; // exclude self-hosted from denominator
        if (total == 0) return "ALL_SELF_HOSTED";
        double ratio = (double) valid / total;
        if (ratio >= 0.9) return "HEALTHY   (" + valid + "/" + total + ")";
        if (ratio >= 0.5) return "DEGRADED  (" + valid + "/" + total + ")";
        return "POOR      (" + valid + "/" + total + ")";
    }

    // ------------------------------------------------------------------ //
    //  Network helpers
    // ------------------------------------------------------------------ //

    /** Resolve all IP addresses bound to the local machine's network interfaces. */
    private static Set<String> resolveLocalIps() {
        Set<String> ips = new LinkedHashSet<>();
        try {
            Enumeration<NetworkInterface> nifs = NetworkInterface.getNetworkInterfaces();
            if (nifs != null) {
                while (nifs.hasMoreElements()) {
                    NetworkInterface nif = nifs.nextElement();
                    Enumeration<InetAddress> addrs = nif.getInetAddresses();
                    while (addrs.hasMoreElements()) {
                        ips.add(addrs.nextElement().getHostAddress());
                    }
                }
            }
        } catch (SocketException ignored) { }
        // Always include canonical loopback
        ips.add("127.0.0.1");
        ips.add("::1");
        return ips;
    }

    /**
     * Resolve the host of a URL/address string to a set of IP address strings.
     * Returns empty set on failure (no resolution = not same host).
     */
    private static Set<String> resolveHostIps(String urlOrAddr) {
        if (urlOrAddr == null || urlOrAddr.isEmpty()) return Collections.emptySet();
        Set<String> ips = new LinkedHashSet<>();
        try {
            String host = extractHost(urlOrAddr);
            if (host == null || host.isEmpty()) return ips;
            InetAddress[] addresses = InetAddress.getAllByName(host);
            for (InetAddress a : addresses) ips.add(a.getHostAddress());
        } catch (UnknownHostException ignored) { }
        return ips;
    }

    /** Extract hostname from a URL string or return the string itself. */
    private static String extractHost(String input) {
        try {
            if (input.startsWith("http://") || input.startsWith("https://")) {
                return new URL(input).getHost();
            }
        } catch (MalformedURLException ignored) { }
        // Strip port if present  (e.g. "192.168.1.1:8080")
        int colon = input.lastIndexOf(':');
        if (colon > 0 && colon < input.length() - 1) {
            String afterColon = input.substring(colon + 1);
            boolean isPort = afterColon.matches("\\d+");
            if (isPort) return input.substring(0, colon);
        }
        return input;
    }

    /**
     * Normalise a server URL to  "scheme://host[:port]"  (no trailing path).
     * "http://test.com/index.php" -> "http://test.com"
     */
    private static String normalizeUrl(String raw) {
        try {
            URL u = new URL(raw.trim());
            int port = u.getPort();
            String scheme = u.getProtocol();
            boolean defaultPort = (port == 80  && "http".equals(scheme))
                                || (port == 443 && "https".equals(scheme))
                                || (port == -1);
            String base = scheme + "://" + u.getHost();
            if (!defaultPort) base += ":" + port;
            return base;
        } catch (MalformedURLException e) {
            return raw.trim().replaceAll("/+$", "");
        }
    }

    private static byte[] httpGetBytes(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(CONNECT_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "NetworkAuditor/1.0");
        try {
            int status = conn.getResponseCode();
            if (status != 200) return null;
            try (InputStream is = conn.getInputStream()) {
                return toByteArray(is);
            }
        } finally {
            conn.disconnect();
        }
    }

    private static String httpGetString(String urlStr) throws IOException {
        byte[] data = httpGetBytes(urlStr);
        return data != null ? new String(data, StandardCharsets.UTF_8) : null;
    }

    // ------------------------------------------------------------------ //
    //  Crypto helpers
    // ------------------------------------------------------------------ //
    private static String sha256Hex(byte[] data) throws NoSuchAlgorithmException {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder sb = new StringBuilder(64);
        for (byte b : digest) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }

    // ------------------------------------------------------------------ //
    //  File helpers
    // ------------------------------------------------------------------ //
    private static byte[] readBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            return toByteArray(fis);
        }
    }

    private static String readFile(File f) throws IOException {
        return new String(readBytes(f), StandardCharsets.UTF_8);
    }

    private static byte[] toByteArray(InputStream is) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
        return buf.toByteArray();
    }

    // ------------------------------------------------------------------ //
    //  Minimal JSON parser (objects & string / number / boolean / array)
    // ------------------------------------------------------------------ //
    static Map<String, Object> parseJsonObject(String json) {
        json = json.trim();
        if (!json.startsWith("{")) throw new IllegalArgumentException("Not a JSON object");
        ParseState ps = new ParseState(json, 1);
        return parseObject(ps);
    }

    private static Map<String, Object> parseObject(ParseState ps) {
        Map<String, Object> map = new LinkedHashMap<>();
        skipWs(ps);
        while (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) != '}') {
            String key = parseString(ps);
            skipWs(ps);
            expect(ps, ':');
            skipWs(ps);
            Object value = parseValue(ps);
            map.put(key, value);
            skipWs(ps);
            if (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) == ',') {
                ps.pos++;
                skipWs(ps);
            }
        }
        if (ps.pos < ps.src.length()) ps.pos++;
        return map;
    }

    private static List<Object> parseArray(ParseState ps) {
        List<Object> list = new ArrayList<>();
        skipWs(ps);
        while (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) != ']') {
            list.add(parseValue(ps));
            skipWs(ps);
            if (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) == ',') {
                ps.pos++;
                skipWs(ps);
            }
        }
        if (ps.pos < ps.src.length()) ps.pos++;
        return list;
    }

    private static Object parseValue(ParseState ps) {
        skipWs(ps);
        char c = ps.src.charAt(ps.pos);
        if (c == '"') return parseString(ps);
        if (c == '{') { ps.pos++; return parseObject(ps); }
        if (c == '[') { ps.pos++; return parseArray(ps); }
        if (c == 't') { ps.pos += 4; return Boolean.TRUE; }
        if (c == 'f') { ps.pos += 5; return Boolean.FALSE; }
        if (c == 'n') { ps.pos += 4; return null; }
        int start = ps.pos;
        while (ps.pos < ps.src.length()
                && "0123456789.-+eE".indexOf(ps.src.charAt(ps.pos)) >= 0) ps.pos++;
        String num = ps.src.substring(start, ps.pos);
        try { return Long.parseLong(num); }
        catch (NumberFormatException e1) {
            try { return Double.parseDouble(num); }
            catch (NumberFormatException e2) { return num; }
        }
    }

    private static String parseString(ParseState ps) {
        expect(ps, '"');
        StringBuilder sb = new StringBuilder();
        while (ps.pos < ps.src.length()) {
            char c = ps.src.charAt(ps.pos++);
            if (c == '"') break;
            if (c == '\\') {
                char esc = ps.src.charAt(ps.pos++);
                switch (esc) {
                    case '"':  sb.append('"');  break;
                    case '\\': sb.append('\\'); break;
                    case '/':  sb.append('/');  break;
                    case 'n':  sb.append('\n'); break;
                    case 'r':  sb.append('\r'); break;
                    case 't':  sb.append('\t'); break;
                    case 'u': {
                        String hex = ps.src.substring(ps.pos, ps.pos + 4);
                        sb.append((char) Integer.parseInt(hex, 16));
                        ps.pos += 4;
                        break;
                    }
                    default: sb.append(esc);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static void skipWs(ParseState ps) {
        while (ps.pos < ps.src.length()
                && Character.isWhitespace(ps.src.charAt(ps.pos))) ps.pos++;
    }

    private static void expect(ParseState ps, char ch) {
        if (ps.pos >= ps.src.length() || ps.src.charAt(ps.pos) != ch)
            throw new IllegalStateException(
                    "Expected '" + ch + "' at pos " + ps.pos
                    + " (got '"
                    + (ps.pos < ps.src.length() ? ps.src.charAt(ps.pos) : "EOF")
                    + "')");
        ps.pos++;
    }

    private static class ParseState {
        final String src; int pos;
        ParseState(String src, int pos) { this.src = src; this.pos = pos; }
    }

    // ------------------------------------------------------------------ //
    //  Utility
    // ------------------------------------------------------------------ //
    private static String str(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null ? v.toString() : "";
    }

    private static String shortHash(String h) {
        return (h != null && h.length() > 12) ? h.substring(0, 12) + "�" : h;
    }

    private static String shortKey(String k) {
        if (k == null || k.isEmpty()) return "(none)";
        return k.length() > 32 ? k.substring(0, 32) + "�" : k;
    }

    private static String padRight(String s, int width) {
        if (s.length() >= width) return s;
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < width) sb.append(' ');
        return sb.toString();
    }

    private static String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(new Date());
    }

    private static void log(String msg) {
        System.out.println(msg);
    }

    private static void die(String msg) {
        System.err.println("[fatal] " + msg);
        System.exit(1);
    }
}