<?php
/**
 * Meento Share - Login
 */
require_once __DIR__ . '/config.php';

if (current_user($pdo)) {
    header('Location: ' . url('account.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if ($u && password_verify($password, $u['password_hash'])) {
        $_SESSION['user_id'] = (int)$u['id'];
        header('Location: ' . url('account.php'));
        exit;
    } else {
        $error = 'E-mail ou senha incorretos.';
    }
}

echo render_header('Entrar', $pdo);
?>
<div class="card" style="max-width: 460px; margin: 30px auto;">
    <h1>Entrar</h1>
    <?php if ($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="email">E-mail</label>
            <input id="email" type="email" name="email" required autofocus>
        </div>
        <div class="form-group">
            <label for="password">Senha</label>
            <input id="password" type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">Entrar</button>
    </form>
    <p class="text-center muted" style="margin-top:14px;">
        Ainda não tem conta? <a href="<?= url('register.php') ?>">Criar conta via PIX</a>
    </p>
</div>
<?= render_footer(); ?>
