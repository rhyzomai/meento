# 🌿 Meento Share

Sistema de compartilhamento descentralizado de arquivos com monetização por micro-cobrança (R$ 0,01 por view/like) e ativação de conta via PIX.

Site de referência: **https://meshare.lovable.app/**

## ✨ Funcionalidades

- 📂 Lista de arquivos (reaproveitando a tabela `file_registry` do script base)
- 🔍 Busca por nome, descrição ou hash
- 📊 Ranking por **mais vistos** / **mais curtidos** (exclusivo para usuários ativos)
- 👤 Cadastro + login com senha criptografada (`bcrypt`)
- 💸 Ativação de conta via PIX para a chave `meuvendedorvirtual@gmail.com` (titular: **Arthur S.**)
  - Valor único: **R$ 10,00** que vira saldo na conta
- 💰 Cada **view** ou **like** custa **R$ 0,01** do saldo
- 🚫 Mesmo arquivo curtido/visualizado pelo mesmo usuário **NUNCA** é cobrado de novo
- 🧾 Todas as movimentações de saldo ficam registradas em `balance_transactions`
- 🔐 Painel admin (`/admin.php`) para confirmar/rejeitar pagamentos PIX
- 🟢 Tema verde em todas as páginas, layout responsivo

## 🗂 Estrutura

```
meento-share/
├── config.php           # Conexão MySQL + schema auto + helpers
├── install.php          # Verificador de instalação
├── index.php            # Lista de arquivos + busca + view/like
├── register.php         # Cadastro com instruções PIX
├── login.php            # Login
├── logout.php           # Logout
├── account.php          # Painel do usuário (saldo, TXID, histórico)
├── interact.php         # Endpoint AJAX para view/like (atômico)
├── admin.php            # Painel admin
└── README.md
```

## 🗃 Banco de dados

O `config.php` cria automaticamente o banco `meento_share` (configurável) com 5 tabelas:

| Tabela                 | Função                                                                          |
|------------------------|---------------------------------------------------------------------------------|
| `users`                | Contas, saldo, status (`pending`/`active`/`blocked`), flag admin                |
| `payments`             | Cobranças PIX geradas no cadastro, com TXID e status de confirmação             |
| `balance_transactions` | Extrato: cada débito de R$ 0,01 + crédito de R$ 10 na ativação                  |
| `file_interactions`    | View/like do usuário, com `UNIQUE(user_id, file_id, interaction_type)`          |
| `file_registry`        | Mesma estrutura do script base — não precisa indexar arquivos pelo PHP          |

## ⚙️ Instalação

1. **Suba os arquivos** para o diretório público do seu servidor (`public_html`, `htdocs`, etc.).
2. **Edite `config.php`** — ajuste as variáveis no topo:

   ```php
   $db_host = '127.0.0.1';
   $db_user = 'root';
   $db_pass = '';
   $db_name = 'meento_share';

   define('ADMIN_EMAIL',    'admin@meshare.local');
   define('ADMIN_PASSWORD', 'admin123'); // TROQUE!
   ```

3. **Garanta que o MySQL tem permissão para criar o schema** com o usuário configurado.
4. **Acesse qualquer página** (ex.: `/index.php`). O `config.php` cria tudo automaticamente.
5. **(Opcional)** Visite `/install.php` para uma checagem visual.

> **PHP 7.0+** com extensões `pdo_mysql` e `mbstring`. Em hospedagem compartilhada normalmente já vêm ativos.

## 🚀 Como funciona o fluxo

1. Visitante entra em `index.php` e vê a lista (sem contadores, sem poder interagir).
2. Clica em **Criar conta** → preenche formulário → conta fica `pending` e é gerado um pedido PIX de R$ 10.
3. Usuário paga a chave `meuvendedorvirtual@gmail.com` e informa o **TXID** em `account.php`.
4. Admin acessa `admin.php`, revisa o TXID e clica em **✓ Confirmar**.
5. Sistema: marca pagamento como confirmado, ativa a conta, **credita R$ 10,00** no saldo, registra a transação.
6. A partir daí, cada clique em **👁 Visualizar** ou **♥ Curtir** num arquivo:
   - cobra R$ 0,01,
   - registra a transação,
   - e fica **travado pelo índice UNIQUE** para não cobrar de novo pelo mesmo par (usuário, arquivo, ação).

## 🔐 Segurança implementada

- `password_hash` (bcrypt) — `password_verify` no login
- Sessões com cookie `httponly` e `samesite=Lax`
- **Todas** as queries usam `PDO` com **prepared statements**
- `htmlspecialchars` em toda saída de variável
- Transações MySQL com `SELECT ... FOR UPDATE` no saldo para evitar race condition
- `UNIQUE KEY` no banco para garantir idempotência de cobrança

## 🎨 Tema verde

Todas as cores vêm de variáveis CSS em `render_header()` (no `config.php`). Para ajustar:

```css
--green-600: #16a34a;  /* cor principal (botões, links) */
--green-50:  #f0fdf4;  /* fundo dos cards de destaque */
```

## 📥 Populando o `file_registry`

Você pode usar **a mesma rotina de sincronização** do script base. Há duas opções:

1. **Manualmente**: rode seu próprio coletor/sync e insira linhas na tabela.
2. **Reaproveitando o script base**: copie o trecho de "Sync Engine" do script original
   para um arquivo `sync.php` (não incluso aqui porque o foco é o sistema de pagamento).
   A estrutura da tabela é idêntica, então é só plugar.

## 🧪 Teste rápido

1. Crie uma conta qualquer.
2. Faça um pagamento PIX real (ou edite manualmente `payments.status = 'confirmed'` no banco para teste).
3. Entre como admin e confirme o pagamento.
4. Volte para `index.php` e clique em **Visualizar** / **Curtir** em alguns arquivos.
5. Verifique em `account.php` que o saldo diminuiu de R$ 10,00 em R$ 0,01 por interação e
   que um segundo clique no mesmo arquivo **não** desconta de novo.

## 📝 Próximos passos sugeridos

- Integração real com API PIX (Mercado Pago, Gerencianet, etc.) para confirmação automática via webhook.
- Bcrypt-hash do admin inicial mudado em produção.
- Sistema de "boost" de saldo (recargas adicionais além da ativação).

---

Feito com 💚 para a comunidade **Meento Share**.
