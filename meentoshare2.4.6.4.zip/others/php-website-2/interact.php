<?php
/**
 * Meento Share - Endpoint de interação (view / like)
 *
 * Regras:
 *  - Requer login e conta ativa
 *  - Verifica saldo (>= R$ 0,01)
 *  - Usa UNIQUE(user_id, file_id, interaction_type) para impedir contagem duplicada
 *  - Tudo em transação MySQL para atomicidade
 *
 * Saída: JSON { ok: bool, status: string, balance: string, msg: string, already?: bool }
 */
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

$u = current_user($pdo);
if (!$u) { echo json_encode(['ok' => false, 'status' => 'login', 'msg' => 'Faça login.']); exit; }
if ($u['status'] !== 'active') { echo json_encode(['ok' => false, 'status' => 'pending', 'msg' => 'Conta ainda não ativada.']); exit; }

$file_id = isset($_POST['file_id']) ? (int)$_POST['file_id'] : 0;
$type    = isset($_POST['type']) ? $_POST['type'] : '';

if ($file_id <= 0 || !in_array($type, ['view', 'like'], true)) {
    echo json_encode(['ok' => false, 'status' => 'bad_request', 'msg' => 'Parâmetros inválidos.']);
    exit;
}

// Confirma que o arquivo existe
$fs = $pdo->prepare("SELECT id, original_filename FROM file_registry WHERE id = ?");
$fs->execute([$file_id]);
$file = $fs->fetch();
if (!$file) { echo json_encode(['ok' => false, 'status' => 'not_found', 'msg' => 'Arquivo não encontrado.']); exit; }

// Tudo dentro de uma transação para garantir atomicidade
try {
    $pdo->beginTransaction();

    // Trava a linha do usuário para evitar race condition no saldo
    $lock = $pdo->prepare("SELECT id, balance FROM users WHERE id = ? FOR UPDATE");
    $lock->execute([$u['id']]);
    $locked_user = $lock->fetch();

    if ((float)$locked_user['balance'] < PER_INTERACTION_COST) {
        $pdo->rollBack();
        echo json_encode([
            'ok' => false,
            'status' => 'no_balance',
            'msg' => 'Saldo insuficiente. Sua conta precisa de mais créditos.',
            'balance' => brl($locked_user['balance']),
        ]);
        exit;
    }

    // Tenta inserir a interação. UNIQUE impede duplicidade.
    // Se já existir, o INSERT falha com SQLSTATE 23000.
    try {
        $ins = $pdo->prepare("INSERT INTO file_interactions (user_id, file_id, interaction_type) VALUES (?, ?, ?)");
        $ins->execute([$u['id'], $file_id, $type]);
        $new_interaction = true;
    } catch (PDOException $e) {
        // Duplicate key = usuário já interagiu antes com esse arquivo nesse modo
        if ($e->getCode() === '23000' || (isset($e->errorInfo[1]) && $e->errorInfo[1] == 1062)) {
            $pdo->rollBack();
            echo json_encode([
                'ok' => true,
                'already' => true,
                'status' => 'already',
                'msg' => 'Você já ' . ($type === 'like' ? 'curtiu' : 'abriu') . ' este arquivo antes. Sem cobrança.',
                'balance' => brl($locked_user['balance']),
            ]);
            exit;
        }
        throw $e;
    }

    // Desconta o centavo
    $cost = PER_INTERACTION_COST;
    $upd = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
    $upd->execute([$cost, $u['id']]);

    // Registra a transação financeira
    $trdesc = ($type === 'like' ? 'Like' : 'Visualização') . ' no arquivo "' . mb_substr($file['original_filename'], 0, 80) . '"';
    $tr = $pdo->prepare("
        INSERT INTO balance_transactions (user_id, amount, type, description, reference_type, reference_id)
        VALUES (?, ?, 'debit', ?, 'file_interaction', ?)
    ");
    $tr->execute([$u['id'], $cost, $trdesc, $file_id]);

    $pdo->commit();

    // Recalcula saldo
    $balStmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $balStmt->execute([$u['id']]);
    $newBalance = $balStmt->fetchColumn();

    echo json_encode([
        'ok' => true,
        'already' => false,
        'status' => 'charged',
        'msg' => 'Cobrado R$ 0,01 do seu saldo.',
        'balance' => brl($newBalance),
        'type'    => $type,
    ]);
    exit;

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['ok' => false, 'status' => 'error', 'msg' => 'Erro: ' . $e->getMessage()]);
    exit;
}
