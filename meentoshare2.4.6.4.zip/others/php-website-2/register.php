<?php
/**
 * Meento Share - Cadastro
 * Fluxo:
 *  1. Usuário preenche nome, e-mail, senha
 *  2. Conta é criada com status=pending e saldo=0
 *  3. Mostra imediatamente os dados para pagamento PIX
 *  4. Usuário informa o TXID/identificador do comprovante
 *  5. Admin confirma em admin.php e libera R$ 10
 */
require_once __DIR__ . '/config.php';

if (current_user($pdo)) {
    header('Location: ' . url('account.php'));
    exit;
}

$errors = [];
$form = ['full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['full_name'] = trim(isset($_POST['full_name']) ? $_POST['full_name'] : '');
    $email            = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $password          = isset($_POST['password']) ? $_POST['password'] : '';
    $password2         = isset($_POST['password2']) ? $_POST['password2'] : '';

    if (strlen($form['full_name']) < 3)               $errors[] = 'Informe seu nome completo.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))   $errors[] = 'E-mail inválido.';
    if (strlen($password) < 6)                        $errors[] = 'A senha precisa ter pelo menos 6 caracteres.';
    if ($password !== $password2)                     $errors[] = 'As senhas não coincidem.';

    if (empty($errors)) {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'Já existe uma conta com esse e-mail.';
        }
    }

    if (empty($errors)) {
        try {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("
                INSERT INTO users (full_name, email, password_hash, balance, status, is_admin)
                VALUES (?, ?, ?, 0.00, 'pending', 0)
            ");
            $stmt->execute([$form['full_name'], $email, $hash]);
            $user_id = $pdo->lastInsertId();

            // Cria o pedido de pagamento PIX aguardando
            $pstmt = $pdo->prepare("
                INSERT INTO payments (user_id, amount, pix_key, status)
                VALUES (?, ?, ?, 'awaiting')
            ");
            $pstmt->execute([$user_id, ACTIVATION_PRICE, PIX_KEY]);

            // Loga o usuário automaticamente e manda para a conta
            $_SESSION['user_id'] = (int)$user_id;
            $_SESSION['just_registered'] = true;
            header('Location: ' . url('account.php?welcome=1'));
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Erro ao criar conta: ' . $e->getMessage();
        }
    }
}

echo render_header('Criar conta', $pdo);
?>
<div class="card" style="max-width: 540px; margin: 30px auto;">
    <h1>Criar conta no Meento Share</h1>
    <p class="muted">
        Para ativar sua conta e receber <strong>R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?> de saldo</strong>
        para usar em qualquer arquivo do site, faça um pagamento via <strong>PIX</strong> para a chave abaixo
        logo após o cadastro.
    </p>

    <div class="pix-box">
        <div class="muted" style="margin-bottom:6px;">Pague exatamente</div>
        <div style="font-size: 1.8rem; font-weight: 800; color: var(--green-700);">
            R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?>
        </div>
        <div class="muted" style="margin-top:6px;">Para a chave PIX (e-mail):</div>
        <div class="pix-key" id="pixKey"><?= h(PIX_KEY) ?></div>
        <div class="muted" style="margin-top:6px;">Titular: <?= h(PIX_OWNER_NAME) ?></div>
        <button type="button" class="copy-btn" onclick="copyPix()">Copiar chave PIX</button>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert error">
            <ul style="margin:0; padding-left:18px;">
                <?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <div class="form-group">
            <label for="full_name">Nome completo</label>
            <input id="full_name" type="text" name="full_name" value="<?= h($form['full_name']) ?>" required>
        </div>
        <div class="form-group">
            <label for="email">E-mail</label>
            <input id="email" type="email" name="email" value="<?= h($form['email']) ?>" required>
        </div>
        <div class="form-group">
            <label for="password">Senha (mín. 6 caracteres)</label>
            <input id="password" type="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="password2">Repita a senha</label>
            <input id="password2" type="password" name="password2" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">Criar conta e gerar cobrança PIX</button>
    </form>
    <p class="text-center muted" style="margin-top:14px;">
        Já tem conta? <a href="<?= url('login.php') ?>">Entrar</a>
    </p>
</div>

<script>
function copyPix() {
    var k = document.getElementById('pixKey').textContent.trim();
    navigator.clipboard.writeText(k).then(function(){
        var b = document.querySelector('.copy-btn');
        var old = b.textContent; b.textContent = 'Copiado ✓';
        setTimeout(function(){ b.textContent = old; }, 1500);
    });
}
</script>

<?= render_footer(); ?>
