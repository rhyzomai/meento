<?php
/**
 * Meento Share - Painel administrativo
 *  - Lista pagamentos aguardando confirmação
 *  - Permite confirmar (credita R$ 10 e ativa a conta) ou rejeitar
 */
require_once __DIR__ . '/config.php';
$admin = require_admin($pdo);

$flash_ok = '';
$flash_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_id'], $_POST['action'])) {
    $pid   = (int)$_POST['payment_id'];
    $act   = $_POST['action'];

    $pStmt = $pdo->prepare("SELECT p.*, u.email, u.full_name, u.status AS user_status FROM payments p JOIN users u ON u.id = p.user_id WHERE p.id = ?");
    $pStmt->execute([$pid]);
    $p = $pStmt->fetch();

    if (!$p) {
        $flash_err = 'Pagamento não encontrado.';
    } elseif (!in_array($act, ['confirm', 'reject'], true)) {
        $flash_err = 'Ação inválida.';
    } else {
        try {
            $pdo->beginTransaction();

            if ($act === 'confirm') {
                if ($p['status'] === 'confirmed') {
                    $pdo->rollBack();
                    $flash_err = 'Esse pagamento já estava confirmado.';
                } else {
                    // Marca como confirmado
                    $pdo->prepare("UPDATE payments SET status='confirmed', confirmed_at=NOW(), confirmed_by=? WHERE id=?")
                        ->execute([$admin['id'], $pid]);

                    // Ativa usuário (se ainda não ativo) e credita saldo
                    $pdo->prepare("UPDATE users SET status='active', activated_at=NOW(), balance = balance + ? WHERE id = ?")
                        ->execute([$p['amount'], $p['user_id']]);

                    // Lançamento de crédito
                    $pdo->prepare("
                        INSERT INTO balance_transactions (user_id, amount, type, description, reference_type, reference_id)
                        VALUES (?, ?, 'credit', 'Ativação da conta via PIX', 'payment', ?)
                    ")->execute([$p['user_id'], $p['amount'], $pid]);

                    $pdo->commit();
                    $flash_ok = 'Pagamento confirmado! Saldo creditado e conta ativada.';
                }
            } else {
                // Rejeitar
                $pdo->prepare("UPDATE payments SET status='rejected', confirmed_at=NOW(), confirmed_by=? WHERE id=?")
                    ->execute([$admin['id'], $pid]);
                $pdo->commit();
                $flash_ok = 'Pagamento rejeitado.';
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $flash_err = 'Erro: ' . $e->getMessage();
        }
    }
}

$pending = $pdo->query("
    SELECT p.*, u.email, u.full_name, u.status AS user_status, u.balance
    FROM payments p
    JOIN users u ON u.id = p.user_id
    WHERE p.status = 'awaiting'
    ORDER BY p.id DESC
")->fetchAll();

$recent = $pdo->query("
    SELECT p.*, u.email, u.full_name
    FROM payments p
    JOIN users u ON u.id = p.user_id
    WHERE p.status IN ('confirmed','rejected')
    ORDER BY p.id DESC
    LIMIT 20
")->fetchAll();

echo render_header('Admin · Pagamentos', $pdo, 'admin');
?>

<?php if ($flash_ok):  ?><div class="alert success"><?= h($flash_ok) ?></div><?php endif; ?>
<?php if ($flash_err): ?><div class="alert error"><?= h($flash_err) ?></div><?php endif; ?>

<div class="card">
    <h1>Painel administrativo</h1>
    <p class="muted">Confirme manualmente os pagamentos PIX recebidos na chave
        <strong><?= h(PIX_KEY) ?></strong> (<?= h(PIX_OWNER_NAME) ?>).</p>
</div>

<div class="card">
    <h2>Aguardando confirmação (<?= count($pending) ?>)</h2>
    <?php if (empty($pending)): ?>
        <p class="muted">Nenhum pagamento aguardando. ✨</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Usuário</th>
                    <th>E-mail</th>
                    <th>Valor</th>
                    <th>TXID</th>
                    <th>Observação</th>
                    <th>Criado em</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($pending as $p): ?>
                <tr>
                    <td>#<?= (int)$p['id'] ?></td>
                    <td><?= h($p['full_name']) ?></td>
                    <td><?= h($p['email']) ?></td>
                    <td><?= h(brl($p['amount'])) ?></td>
                    <td><code><?= h($p['txid'] ?: '—') ?></code></td>
                    <td><?= h($p['receipt_note'] ?: '—') ?></td>
                    <td><?= h($p['created_at']) ?></td>
                    <td><span class="badge badge-warn"><?= h(strtoupper($p['user_status'])) ?></span></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                            <button name="action" value="confirm" class="btn btn-primary btn-sm" onclick="return confirm('Confirmar pagamento e liberar saldo?')">✓ Confirmar</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                            <button name="action" value="reject" class="btn btn-danger btn-sm" onclick="return confirm('Rejeitar pagamento?')">✗ Rejeitar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Histórico recente</h2>
    <?php if (empty($recent)): ?>
        <p class="muted">Sem histórico ainda.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Usuário</th>
                    <th>Valor</th>
                    <th>Status</th>
                    <th>Confirmado em</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $p): ?>
                <tr>
                    <td>#<?= (int)$p['id'] ?></td>
                    <td><?= h($p['full_name']) ?> &lt;<?= h($p['email']) ?>&gt;</td>
                    <td><?= h(brl($p['amount'])) ?></td>
                    <td>
                        <?php if ($p['status'] === 'confirmed'): ?>
                            <span class="badge badge-ext">CONFIRMADO</span>
                        <?php else: ?>
                            <span class="badge badge-danger">REJEITADO</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($p['confirmed_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?= render_footer(); ?>
