<?php
/**
 * Meento Share - Página inicial (lista de arquivos)
 *
 * - Lógica de busca e paginação reaproveitada do script base
 * - Adiciona tema verde, login opcional, e botões View / Like que custam R$ 0,01
 * - Só usuários ativos e logados podem interagir e ver contadores
 */
require_once __DIR__ . '/config.php';

$u = current_user($pdo);
$isActive = ($u && $u['status'] === 'active');

$limit = 100;
$page  = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$sort   = isset($_GET['sort']) && in_array($_GET['sort'], ['recent', 'popular', 'liked'], true) ? $_GET['sort'] : 'recent';

if ($search !== '') {
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM file_registry WHERE original_filename LIKE ? OR description LIKE ? OR file_hash LIKE ?");
    $count_stmt->execute(["%$search%", "%$search%", "%$search%"]);
} else {
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM file_registry");
    $count_stmt->execute();
}
$total_rows  = $count_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_rows / $limit));

// Monta ORDER BY
$order_by = 'indexed_at DESC';
if ($isActive) {
    if ($sort === 'popular') {
        $order_by = '(SELECT COUNT(*) FROM file_interactions WHERE file_id = f.id AND interaction_type=\'view\') DESC, indexed_at DESC';
    } elseif ($sort === 'liked') {
        $order_by = '(SELECT COUNT(*) FROM file_interactions WHERE file_id = f.id AND interaction_type=\'like\') DESC, indexed_at DESC';
    }
}

if ($search !== '') {
    $sql = "SELECT f.* FROM file_registry f
            WHERE f.original_filename LIKE ? OR f.description LIKE ? OR f.file_hash LIKE ?
            ORDER BY $order_by LIMIT ? OFFSET ?";
    $data_stmt = $pdo->prepare($sql);
    $data_stmt->bindValue(1, "%$search%", PDO::PARAM_STR);
    $data_stmt->bindValue(2, "%$search%", PDO::PARAM_STR);
    $data_stmt->bindValue(3, "%$search%", PDO::PARAM_STR);
    $data_stmt->bindValue(4, $limit, PDO::PARAM_INT);
    $data_stmt->bindValue(5, $offset, PDO::PARAM_INT);
} else {
    $sql = "SELECT f.* FROM file_registry f ORDER BY $order_by LIMIT ? OFFSET ?";
    $data_stmt = $pdo->prepare($sql);
    $data_stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $data_stmt->bindValue(2, $offset, PDO::PARAM_INT);
}
$data_stmt->execute();
$results = $data_stmt->fetchAll();

// Pré-carrega contadores e estados do usuário se ativo
$stats = [];           // file_id => ['views' => N, 'likes' => N]
$userInteractions = [];// file_id => ['view' => bool, 'like' => bool]
if ($isActive && !empty($results)) {
    $ids = array_map(function($r) { return (int)$r['id']; }, $results);
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $st  = $pdo->prepare("SELECT file_id, interaction_type, COUNT(*) c FROM file_interactions WHERE file_id IN ($in) GROUP BY file_id, interaction_type");
    $st->execute($ids);
    foreach ($st->fetchAll() as $row) {
        $fid = (int)$row['file_id'];
        if (!isset($stats[$fid])) $stats[$fid] = ['views' => 0, 'likes' => 0];
        if ($row['interaction_type'] === 'view') $stats[$fid]['views'] = (int)$row['c'];
        if ($row['interaction_type'] === 'like') $stats[$fid]['likes'] = (int)$row['c'];
    }
    $st2 = $pdo->prepare("SELECT file_id, interaction_type FROM file_interactions WHERE user_id = ? AND file_id IN ($in)");
    $st2->execute(array_merge([$u['id']], $ids));
    foreach ($st2->fetchAll() as $row) {
        $fid = (int)$row['file_id'];
        if (!isset($userInteractions[$fid])) $userInteractions[$fid] = [];
        $userInteractions[$fid][$row['interaction_type']] = true;
    }
}

echo render_header('Arquivos compartilhados', $pdo, 'home');
?>

<div class="card" style="background: linear-gradient(135deg, var(--green-50), white);">
    <h1 style="margin-bottom:6px;">🌿 Meento Share</h1>
    <p class="muted" style="margin:0 0 14px;">
        Hub descentralizado de arquivos. Cada <strong>view</strong> ou <strong>like</strong> custa
        <strong>R$ 0,01</strong> do seu saldo. Você só paga uma vez por arquivo e por tipo de ação.
        <?php if (!$u): ?>
            <a href="<?= url('register.php') ?>">Crie sua conta</a> e pague a taxa única de ativação de
            <strong>R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?></strong> via PIX para começar.
        <?php elseif (!$isActive): ?>
            Sua conta ainda não está ativa. Pague o PIX em
            <a href="<?= url('account.php') ?>">Minha conta</a> para liberar seu saldo de
            R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?>.
        <?php endif; ?>
    </p>
    <form method="GET" action="index.php" style="display:flex; gap:8px; flex-wrap: wrap;">
        <input type="text" name="q" value="<?= h($search) ?>" placeholder="Buscar por nome, descrição ou hash..." style="flex:1; min-width:220px;">
        <?php if ($isActive): ?>
            <select name="sort">
                <option value="recent"  <?= $sort==='recent'?'selected':'' ?>>Mais recentes</option>
                <option value="popular" <?= $sort==='popular'?'selected':'' ?>>Mais vistos</option>
                <option value="liked"   <?= $sort==='liked'?'selected':'' ?>>Mais curtidos</option>
            </select>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Buscar</button>
        <?php if ($search !== ''): ?>
            <a href="<?= url('index.php') ?>" class="btn btn-secondary">Limpar</a>
        <?php endif; ?>
    </form>
</div>

<p class="muted">
    <?= number_format($total_rows, 0, ',', '.') ?> arquivo(s) encontrado(s).
    <?= $isActive ? 'Ordenação: ' . ($sort === 'popular' ? 'mais vistos' : ($sort === 'liked' ? 'mais curtidos' : 'mais recentes')) . '.' : '' ?>
</p>

<?php if (count($results) > 0): ?>
    <?php foreach ($results as $row):
        $fid = (int)$row['id'];
        $hosts_list = json_decode($row['hosts'], true);
        if (!is_array($hosts_list)) $hosts_list = [];
        $views = isset($stats[$fid]) ? $stats[$fid]['views'] : 0;
        $likes = isset($stats[$fid]) ? $stats[$fid]['likes'] : 0;
        $userViewed = !empty($userInteractions[$fid]['view']);
        $userLiked  = !empty($userInteractions[$fid]['like']);
    ?>
    <div class="card" data-file-id="<?= $fid ?>">
        <div class="card-header">
            <h3 class="file-title"><?= h($row['original_filename']) ?></h3>
            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <span class="badge badge-ext"><?= h(strtoupper($row['extension'])) ?></span>
                <?php if ($isActive): ?>
                    <span class="badge badge-stat" title="Visualizações">👁 <?= number_format($views, 0, ',', '.') ?></span>
                    <span class="badge badge-stat" title="Curtidas">♥ <?= number_format($likes, 0, ',', '.') ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="file-meta">
            <strong>Hash:</strong> <?= h($row['file_hash']) ?>
            &nbsp;·&nbsp;
            <strong>Tamanho:</strong> <?= number_format($row['file_size'], 0, ',', '.') ?> bytes
            &nbsp;·&nbsp;
            <strong>Indexado:</strong> <?= h($row['indexed_at']) ?>
        </div>

        <?php if (!empty($row['description'])): ?>
            <div class="file-desc"><?= h($row['description']) ?></div>
        <?php endif; ?>

        <?php if (!empty($hosts_list)): ?>
            <div class="hosts-section">
                <span class="host-label">Locais de download:</span>
                <?php foreach ($hosts_list as $host): ?>
                    <a href="<?= h($host) ?>/files/<?= h($row['server_filename']) ?>" target="_blank" class="host-link">
                        <?= h(str_replace(['http://','https://'], '', $host)) ?> ↗
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="actions-row">
            <?php if (!$u): ?>
                <a href="<?= url('login.php') ?>" class="btn btn-primary">Entrar para interagir (R$ 0,01)</a>
            <?php elseif (!$isActive): ?>
                <a href="<?= url('account.php') ?>" class="btn btn-primary">Ativar conta para interagir</a>
            <?php else: ?>
                <button class="btn btn-primary btn-sm" data-act="view" <?= $userViewed ? 'disabled' : '' ?>>
                    <?= $userViewed ? '✓ Visualizado' : '👁 Visualizar (R$ 0,01)' ?>
                </button>
                <button class="btn btn-ghost btn-sm" data-act="like" <?= $userLiked ? 'disabled' : '' ?>>
                    <?= $userLiked ? '♥ Curtido' : '♥ Curtir (R$ 0,01)' ?>
                </button>
                <span class="muted" data-balance-box>
                    Saldo: <strong data-balance><?= h(brl($u['balance'])) ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++):
                $link = 'index.php?q=' . urlencode($search) . '&sort=' . urlencode($sort) . '&page=' . $i;
            ?>
                <a href="<?= h($link) ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

<?php else: ?>
    <div class="card empty">
        Nenhum arquivo encontrado<?= $search !== '' ? ' para "<strong>' . h($search) . '</strong>"' : '' ?>.
    </div>
<?php endif; ?>

<script>
(function(){
    function fmtBRL(v){
        // server already sends "R$ X,XX"
        return v;
    }
    function showToast(msg, ok){
        var t = document.createElement('div');
        t.textContent = msg;
        t.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:9999; padding:12px 18px; border-radius:8px; color:white; font-weight:600; box-shadow:0 4px 12px rgba(0,0,0,0.2); background:' + (ok ? '#16a34a' : '#dc2626');
        document.body.appendChild(t);
        setTimeout(function(){ t.style.opacity = '0'; t.style.transition = 'opacity 0.4s'; }, 2200);
        setTimeout(function(){ t.remove(); }, 2700);
    }
    document.querySelectorAll('.card[data-file-id]').forEach(function(card){
        var fileId = card.getAttribute('data-file-id');
        card.querySelectorAll('button[data-act]').forEach(function(btn){
            btn.addEventListener('click', function(){
                if (btn.disabled) return;
                var act = btn.getAttribute('data-act');
                btn.classList.add('is-loading');
                var fd = new FormData();
                fd.append('file_id', fileId);
                fd.append('type', act);
                fetch('interact.php', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r){ return r.json(); })
                    .then(function(res){
                        btn.classList.remove('is-loading');
                        if (!res.ok) {
                            showToast(res.msg || 'Erro', false);
                            if (res.status === 'no_balance' || res.status === 'pending') {
                                setTimeout(function(){ window.location.href = 'account.php'; }, 1200);
                            }
                            return;
                        }
                        if (res.already) {
                            showToast(res.msg, true);
                        } else {
                            // Marca como interagido
                            btn.disabled = true;
                            if (act === 'view') btn.textContent = '✓ Visualizado';
                            if (act === 'like') btn.textContent = '♥ Curtido';
                            // Atualiza saldo em todos os cards
                            document.querySelectorAll('[data-balance]').forEach(function(el){ el.textContent = res.balance; });
                            // Incrementa contador do card
                            var stat = card.querySelector('.badge-stat[title="' + (act==='view'?'Visualizações':'Curtidas') + '"]');
                            if (stat) {
                                var n = parseInt((stat.textContent.match(/\d+/) || ['0'])[0].replace(/\./g,''), 10) || 0;
                                stat.textContent = (act==='view' ? '👁 ' : '♥ ') + (n+1).toLocaleString('pt-BR');
                            }
                            showToast(res.msg, true);
                        }
                    })
                    .catch(function(){
                        btn.classList.remove('is-loading');
                        showToast('Erro de rede.', false);
                    });
            });
        });
    });
})();
</script>

<?= render_footer(); ?>
