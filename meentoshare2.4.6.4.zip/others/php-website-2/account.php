<?php
/**
 * Meento Share - Minha conta
 *  - Mostra saldo
 *  - Status da ativação
 *  - Lista de transações
 *  - Permite enviar/atualizar o TXID do PIX
 */
require_once __DIR__ . '/config.php';

$u = require_login($pdo);
$isActive = ($u['status'] === 'active');
$justRegistered = !empty($_SESSION['just_registered']);
unset($_SESSION['just_registered']);

// Pagamento mais recente
$payStmt = $pdo->prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$payStmt->execute([$u['id']]);
$payment = $payStmt->fetch();

// Atualização do TXID / comprovante
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payment'])) {
    $txid    = trim(isset($_POST['txid']) ? $_POST['txid'] : '');
    $note    = trim(isset($_POST['receipt_note']) ? $_POST['receipt_note'] : '');

    if (!$payment || $payment['status'] === 'rejected') {
        // Cria novo pedido
        $pdo->prepare("INSERT INTO payments (user_id, amount, pix_key, txid, receipt_note, status)
                       VALUES (?, ?, ?, ?, ?, 'awaiting')")
            ->execute([$u['id'], ACTIVATION_PRICE, PIX_KEY, $txid, $note]);
        flash_set('success', 'Comprovante enviado! Aguarde a confirmação do admin.');
    } else {
        // Atualiza o pedido existente
        $pdo->prepare("UPDATE payments SET txid = ?, receipt_note = ?, status='awaiting' WHERE id = ?")
            ->execute([$txid, $note, $payment['id']]);
        flash_set('success', 'Comprovante atualizado. Aguardando nova confirmação.');
    }
    header('Location: ' . url('account.php'));
    exit;
}

// Lista de transações
$txStmt = $pdo->prepare("SELECT * FROM balance_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 50");
$txStmt->execute([$u['id']]);
$txs = $txStmt->fetchAll();

// Estatísticas
$stat = $pdo->prepare("
    SELECT
      SUM(CASE WHEN interaction_type='view' THEN 1 ELSE 0 END) AS views,
      SUM(CASE WHEN interaction_type='like' THEN 1 ELSE 0 END) AS likes
    FROM file_interactions WHERE user_id = ?
");
$stat->execute([$u['id']]);
$stats = $stat->fetch() ?: ['views' => 0, 'likes' => 0];

echo render_header('Minha conta', $pdo, 'account');
?>

<?php if (isset($_GET['welcome']) || $justRegistered): ?>
    <div class="alert success">
        🎉 Conta criada! Agora finalize o pagamento via PIX para liberar seus
        <strong>R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?></strong> de saldo.
    </div>
<?php endif; ?>

<?php if (!$isActive): ?>
    <div class="card" style="border-left: 5px solid var(--green-500);">
        <h1>Complete sua assinatura</h1>
        <p>
            Para liberar <strong>R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?> de saldo</strong> na sua conta
            e desbloquear visualizações, likes, contadores e o ranking de relevância dos arquivos,
            faça um pagamento via PIX:
        </p>

        <div class="pix-box">
            <div class="muted" style="margin-bottom:6px;">Valor exato da assinatura</div>
            <div style="font-size: 1.8rem; font-weight: 800; color: var(--green-700);">
                R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?>
            </div>
            <div class="muted" style="margin-top:10px;">Chave PIX (e-mail):</div>
            <div class="pix-key" id="pixKey"><?= h(PIX_KEY) ?></div>
            <div class="muted" style="margin-top:6px;">Titular: <?= h(PIX_OWNER_NAME) ?></div>
            <button type="button" class="copy-btn" onclick="copyPix()">Copiar chave PIX</button>
        </div>

        <h2 style="margin-top:24px;">Já pagou? Envie o comprovante</h2>
        <p class="muted">
            Após o pagamento, preencha o <strong>TXID</strong> ou identificador da transação
            (visível no seu app do banco) e clique em <em>Enviar para análise</em>.
            O admin confirmará e seu saldo de R$ <?= number_format(ACTIVATION_PRICE, 2, ',', '.') ?>
            será creditado automaticamente.
        </p>

        <form method="POST">
            <input type="hidden" name="update_payment" value="1">
            <div class="form-group">
                <label for="txid">TXID / Identificador do PIX</label>
                <input id="txid" type="text" name="txid" value="<?= h(isset($payment['txid']) ? $payment['txid'] : '') ?>" placeholder="Ex.: MEENTO12345">
            </div>
            <div class="form-group">
                <label for="receipt_note">Observação (opcional)</label>
                <textarea id="receipt_note" name="receipt_note" rows="2" placeholder="Horário do pagamento, banco, etc."><?= h(isset($payment['receipt_note']) ? $payment['receipt_note'] : '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar para análise</button>
        </form>

        <?php if ($payment): ?>
            <p class="muted" style="margin-top:14px;">
                Status atual do pedido: <strong><?= h(strtoupper($payment['status'])) ?></strong>
            </p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="card" style="background: linear-gradient(135deg, var(--green-100), white);">
        <h1>Olá, <?= h($u['full_name']) ?> 👋</h1>
        <p class="muted" style="margin:0;">Sua conta está ativa. Cada view e like custa R$ 0,01 — você só paga uma vez por arquivo.</p>
    </div>
<?php endif; ?>

<div class="kpi">
    <div class="card">
        <div class="kpi-label">Saldo atual</div>
        <div class="kpi-value" data-balance><?= h(brl($u['balance'])) ?></div>
    </div>
    <div class="card">
        <div class="kpi-label">Arquivos visualizados</div>
        <div class="kpi-value"><?= number_format((int)$stats['views'], 0, ',', '.') ?></div>
    </div>
    <div class="card">
        <div class="kpi-label">Arquivos curtidos</div>
        <div class="kpi-value"><?= number_format((int)$stats['likes'], 0, ',', '.') ?></div>
    </div>
    <div class="card">
        <div class="kpi-label">Total de transações</div>
        <div class="kpi-value"><?= number_format(count($txs), 0, ',', '.') ?></div>
    </div>
</div>

<div class="card">
    <h2>Histórico de transações</h2>
    <?php if (empty($txs)): ?>
        <p class="muted">Nenhuma transação ainda. Comece a interagir com os arquivos para ver o histórico aqui.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Descrição</th>
                    <th>Tipo</th>
                    <th style="text-align:right;">Valor</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($txs as $t): ?>
                <tr>
                    <td><?= h($t['created_at']) ?></td>
                    <td><?= h($t['description']) ?></td>
                    <td>
                        <span class="badge <?= $t['type']==='credit'?'badge-ext':'badge-warn' ?>">
                            <?= $t['type']==='credit' ? 'CRÉDITO' : 'DÉBITO' ?>
                        </span>
                    </td>
                    <td style="text-align:right; font-weight:600; color:<?= $t['type']==='credit' ? 'var(--green-700)' : 'var(--danger)' ?>;">
                        <?= $t['type']==='credit' ? '+' : '-' ?><?= h(brl($t['amount'])) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script>
function copyPix(){
    var k = document.getElementById('pixKey').textContent.trim();
    navigator.clipboard.writeText(k).then(function(){
        var b = document.querySelector('.copy-btn');
        var old = b.textContent; b.textContent = 'Copiado ✓';
        setTimeout(function(){ b.textContent = old; }, 1500);
    });
}
</script>

<?= render_footer(); ?>
