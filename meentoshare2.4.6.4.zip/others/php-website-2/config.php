﻿<?php
/**
 * Meento Share - Configuração Global
 * Compatível com PHP 7+
 *
 * - Configura conexão com MySQL
 * - Cria database e todas as tabelas automaticamente
 * - Disponibiliza $pdo, helpers de sessão e helpers financeiros
 */

// ==========================================
// 1. CONFIGURAÇÃO (EDITE ANTES DE PUBLICAR)
// ==========================================
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'meento_share';

// (Opcional) Use um socket Unix em vez de TCP. Em produção, use TCP ou aponte para o socket do seu servidor.
// Exemplo: $db_socket = '/var/run/mysqld/mysqld.sock';
$db_socket = null;

// Chave PIX para receber o pagamento de ativação
define('PIX_KEY', 'minhachavepix');
define('PIX_OWNER_NAME', 'admin');
define('ACTIVATION_PRICE', 10.00); // R$ 10
define('PER_INTERACTION_COST', 0.01); // R$ 0,01 por view/like

// Credenciais de admin (altere!)
define('ADMIN_EMAIL', 'admin@meshare.local');
define('ADMIN_PASSWORD', 'admin123'); // TROQUE EM PRODUÇÃO

// Caminho base (caso rode em subpasta, ajuste aqui). Deixe vazio para raiz.
define('BASE_URL', '');

// ==========================================
// 2. SESSÃO SEGURA
// ==========================================
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ==========================================
// 3. CONEXÃO + CRIAÇÃO DO SCHEMA
// ==========================================
try {
    if (!empty($db_socket)) {
        $dsn = "mysql:unix_socket=$db_socket;charset=utf8mb4";
    } else {
        $dsn = "mysql:host=$db_host;charset=utf8mb4";
    }
    $pdo = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$db_name`");

    // Tabela de usuários
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(120) NOT NULL,
            email VARCHAR(180) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            status ENUM('pending','active','blocked') NOT NULL DEFAULT 'pending',
            is_admin TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            activated_at TIMESTAMP NULL,
            INDEX (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Tabela de pagamentos (PIX)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            pix_key VARCHAR(180) NOT NULL,
            txid VARCHAR(120) DEFAULT NULL,
            receipt_note TEXT,
            status ENUM('awaiting','confirmed','rejected') NOT NULL DEFAULT 'awaiting',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            confirmed_at TIMESTAMP NULL,
            confirmed_by INT DEFAULT NULL,
            INDEX (user_id),
            INDEX (status),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Tabela de transações de saldo (qualquer débito/crédito)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS balance_transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            type ENUM('credit','debit') NOT NULL,
            description VARCHAR(255) NOT NULL,
            reference_type VARCHAR(50) DEFAULT NULL,
            reference_id INT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id),
            INDEX (created_at),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Tabela de interação por arquivo (view/like) — UNIQUE impede contagem duplicada
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS file_interactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            file_id INT NOT NULL,
            interaction_type ENUM('view','like') NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user_file_type (user_id, file_id, interaction_type),
            INDEX (file_id),
            INDEX (user_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Tabela do registro de arquivos (mesma estrutura do script base)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS file_registry (
            id INT AUTO_INCREMENT PRIMARY KEY,
            file_hash VARCHAR(255) UNIQUE NOT NULL,
            server_filename VARCHAR(255) NOT NULL,
            original_filename VARCHAR(255) NOT NULL,
            file_size INT NOT NULL,
            extension VARCHAR(50) NOT NULL,
            public_key TEXT,
            node_info TEXT,
            description TEXT,
            hosts TEXT NOT NULL,
            indexed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (indexed_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Garante conta admin
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([ADMIN_EMAIL]);
    if (!$stmt->fetch()) {
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_BCRYPT);
        $ins = $pdo->prepare("
            INSERT INTO users (full_name, email, password_hash, balance, status, is_admin, activated_at)
            VALUES ('Administrador', ?, ?, 0, 'active', 1, NOW())
        ");
        $ins->execute([ADMIN_EMAIL, $hash]);
    }

} catch (PDOException $e) {
    die("<div style='font-family:sans-serif;padding:30px;background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;margin:20px;border-radius:8px;'>
            <strong>Erro de conexão com o banco de dados:</strong>
            " . htmlspecialchars($e->getMessage()) . "
            <br><br>Edite as credenciais no início de <code>config.php</code>.
         </div>");
}

// ==========================================
// 4. HELPERS
// ==========================================
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function url($path) {
    return BASE_URL . $path;
}

function current_user($pdo) {
    if (empty($_SESSION['user_id'])) return null;
    static $cached = null;
    if ($cached !== null) return $cached;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $u = $stmt->fetch();
    $cached = $u ?: null;
    return $cached;
}

function require_login($pdo) {
    $u = current_user($pdo);
    if (!$u) {
        header('Location: ' . url('login.php'));
        exit;
    }
    return $u;
}

function require_active_user($pdo) {
    $u = require_login($pdo);
    if ($u['status'] !== 'active') {
        header('Location: ' . url('account.php') . '?msg=pending');
        exit;
    }
    return $u;
}

function require_admin($pdo) {
    $u = require_login($pdo);
    if (empty($u['is_admin'])) {
        http_response_code(403);
        die('Acesso restrito ao administrador.');
    }
    return $u;
}

function brl($v) { return 'R$ ' . number_format((float)$v, 2, ',', '.'); }

function flash_set($key, $msg)    { $_SESSION['flash'][$key] = $msg; }
function flash_get($key)          { if (!empty($_SESSION['flash'][$key])) { $m = $_SESSION['flash'][$key]; unset($_SESSION['flash'][$key]); return $m; } return null; }

/**
 * Cria o cabeçalho HTML padrão (verde) e devolve o HTML pronto.
 */
function render_header($title, $pdo, $active_nav = '') {
    $u = current_user($pdo);
    $nav_link = function($file, $label, $key) use ($active_nav) {
        $cls = $active_nav === $key ? 'nav-link active' : 'nav-link';
        return '<a class="' . $cls . '" href="' . url($file) . '">' . $label . '</a>';
    };
    $right = '';
    if ($u) {
        $balance = brl($u['balance']);
        $right .= '<div class="user-chip">';
        $right .= '<span class="balance">💰 ' . $balance . '</span>';
        $right .= '<span class="user-name">' . h($u['full_name']) . '</span>';
        $right .= '<a class="nav-link-mini" href="' . url('logout.php') . '">Sair</a>';
        $right .= '</div>';
    } else {
        $right .= '<a class="nav-link" href="' . url('login.php') . '">Entrar</a>';
        $right .= '<a class="btn btn-primary btn-sm" href="' . url('register.php') . '">Criar conta</a>';
    }
    $nav = '';
    $nav .= $nav_link('index.php', 'Início', 'home');
    if ($u) $nav .= $nav_link('account.php', 'Minha conta', 'account');
    if ($u && !empty($u['is_admin'])) $nav .= $nav_link('admin.php', 'Admin', 'admin');

    $flash_ok  = flash_get('success');
    $flash_err = flash_get('error');

    return <<<HTML
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meento Share · {$title}</title>
<style>
:root {
  --green-50:#f0fdf4; --green-100:#dcfce7; --green-200:#bbf7d0;
  --green-300:#86efac; --green-400:#4ade80; --green-500:#22c55e;
  --green-600:#16a34a; --green-700:#15803d; --green-800:#166534;
  --green-900:#14532d;
  --text:#0f172a; --text-soft:#475569; --border:#d1fae5;
  --bg:#f7fdf9; --card:#ffffff;
  --danger:#dc2626; --danger-bg:#fee2e2; --danger-border:#fca5a5;
  --warn-bg:#fef3c7; --warn-text:#92400e;
}
* { box-sizing: border-box; }
body { font-family: system-ui,-apple-system,"Segoe UI",sans-serif; background:var(--bg); color:var(--text); margin:0; line-height:1.5; }
a { color: var(--green-700); text-decoration: none; }
a:hover { text-decoration: underline; }
.container { max-width: 1100px; margin: 0 auto; padding: 20px; }
.topbar { background: linear-gradient(135deg, var(--green-700), var(--green-500)); color:white; box-shadow: 0 2px 6px rgba(0,0,0,0.08); }
.topbar-inner { max-width: 1100px; margin:0 auto; padding: 14px 20px; display:flex; align-items:center; justify-content:space-between; gap:14px; flex-wrap: wrap; }
.brand { display:flex; align-items:center; gap:10px; font-weight: 700; font-size: 1.3rem; }
.brand-logo { width:34px; height:34px; background:white; color:var(--green-700); border-radius:8px; display:flex; align-items:center; justify-content:center; font-weight:800; }
.nav { display:flex; align-items:center; gap: 6px; flex-wrap: wrap; }
.nav-link, .nav-link-mini { color: white; padding: 8px 12px; border-radius:6px; font-size:0.92rem; font-weight: 500; opacity: 0.92; }
.nav-link:hover, .nav-link-mini:hover { background: rgba(255,255,255,0.18); text-decoration: none; opacity: 1; }
.nav-link.active { background: rgba(255,255,255,0.25); opacity: 1; }
.btn { display:inline-block; padding: 9px 16px; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; font-size: 0.95rem; text-decoration: none; transition: all 0.15s; }
.btn-sm { padding: 6px 12px; font-size: 0.85rem; }
.btn-primary { background: var(--green-600); color: white; }
.btn-primary:hover { background: var(--green-700); text-decoration: none; }
.btn-secondary { background: #475569; color: white; }
.btn-secondary:hover { background: #334155; text-decoration: none; }
.btn-ghost { background: var(--green-100); color: var(--green-800); }
.btn-ghost:hover { background: var(--green-200); text-decoration: none; }
.btn-danger { background: var(--danger); color: white; }
.btn-danger:hover { background: #b91c1c; text-decoration: none; }
.btn[disabled], .btn.is-loading { opacity:0.6; pointer-events:none; }
.user-chip { display:flex; align-items:center; gap: 10px; background: rgba(255,255,255,0.15); padding: 6px 10px; border-radius: 999px; }
.user-chip .balance { font-weight:700; font-size: 0.9rem; }
.user-chip .user-name { font-size: 0.88rem; opacity:0.95; }
.user-chip .nav-link-mini { font-size: 0.82rem; padding: 4px 8px; }
h1 { font-size: 1.6rem; margin: 0 0 10px; }
h2 { font-size: 1.25rem; margin: 0 0 10px; }
h3 { font-size: 1.05rem; margin: 0 0 6px; }
.card { background: var(--card); border: 1px solid var(--border); border-radius: 10px; padding: 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
.card-header { display:flex; justify-content:space-between; align-items:flex-start; gap: 10px; flex-wrap: wrap; }
.file-title { font-size: 1.15rem; font-weight: 600; margin: 0; }
.file-meta { font-size: 0.82rem; color: var(--text-soft); margin: 6px 0 12px; font-family: ui-monospace, "Cascadia Mono", Menlo, monospace; }
.file-desc { background: var(--green-50); padding: 10px 14px; border-radius: 6px; font-size: 0.9rem; margin-bottom: 14px; color: #166534; border-left: 3px solid var(--green-400); }
.badge { display:inline-block; padding: 3px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
.badge-ext { background: var(--green-100); color: var(--green-800); }
.badge-stat { background: #ecfdf5; color: var(--green-800); }
.badge-warn { background: var(--warn-bg); color: var(--warn-text); }
.badge-danger { background: var(--danger-bg); color: var(--danger); }
.details-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; font-size: 0.85rem; margin-bottom: 14px; border-top: 1px dashed var(--border); padding-top: 10px; }
.hosts-section { display:flex; flex-wrap: wrap; gap: 8px; align-items:center; margin-top: 10px; }
.host-label { font-size: 0.85rem; font-weight: 600; color: var(--text-soft); }
.host-link { font-size: 0.85rem; padding: 4px 10px; background: var(--green-50); color: var(--green-700); border: 1px solid var(--green-200); border-radius: 4px; }
.host-link:hover { background: var(--green-600); color: white; text-decoration: none; }
.actions-row { display:flex; gap: 8px; align-items:center; flex-wrap: wrap; margin-top: 12px; padding-top: 12px; border-top: 1px dashed var(--border); }
.alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 18px; font-weight: 500; word-break: break-word; }
.alert.success { background: var(--green-100); color: var(--green-800); border: 1px solid var(--green-200); }
.alert.error   { background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger-border); }
.alert.info    { background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; }
.alert.warn    { background: var(--warn-bg); color: var(--warn-text); border: 1px solid #fde68a; }
input[type="text"], input[type="email"], input[type="password"], input[type="number"], textarea, select {
    width: 100%; padding: 10px 12px; border: 1px solid var(--border); border-radius: 6px; font-size: 0.95rem; font-family: inherit;
}
input:focus, textarea:focus, select:focus { outline: 2px solid var(--green-400); border-color: var(--green-500); }
label { display:block; font-size: 0.88rem; font-weight: 600; margin-bottom: 5px; color: var(--text-soft); }
.form-group { margin-bottom: 14px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); font-size: 0.9rem; }
th { background: var(--green-50); color: var(--green-800); font-weight: 600; }
.pagination { display:flex; justify-content:center; gap: 5px; margin-top: 25px; }
.pagination a { padding: 8px 12px; border: 1px solid var(--border); background:white; color: var(--text); border-radius: 6px; font-size: 0.9rem; }
.pagination a.active { background: var(--green-600); color: white; border-color: var(--green-600); }
.kpi { display:flex; gap: 14px; flex-wrap: wrap; margin-bottom: 18px; }
.kpi .card { flex: 1; min-width: 180px; }
.kpi .kpi-label { color: var(--text-soft); font-size: 0.85rem; }
.kpi .kpi-value { font-size: 1.6rem; font-weight: 700; color: var(--green-700); }
.text-soft { color: var(--text-soft); }
.text-center { text-align: center; }
.divider { height: 1px; background: var(--border); margin: 20px 0; }
.muted { color: var(--text-soft); font-size: 0.88rem; }
.pix-box { background: var(--green-50); border: 2px dashed var(--green-400); border-radius: 10px; padding: 16px; text-align:center; margin: 14px 0; }
.pix-key { font-family: ui-monospace, "Cascadia Mono", Menlo, monospace; font-size: 1.1rem; font-weight: 700; color: var(--green-800); word-break: break-all; }
.empty { text-align:center; padding: 40px; color: var(--text-soft); }
.copy-btn { cursor:pointer; border:none; background: var(--green-600); color:white; padding: 4px 10px; border-radius:4px; font-size: 0.78rem; }
.copy-btn:hover { background: var(--green-700); }
</style>
</head>
<body>
<header class="topbar">
    <div class="topbar-inner">
        <div class="brand">
            <div class="brand-logo">M</div>
            <span>Meento Share</span>
        </div>
        <nav class="nav">{$nav}</nav>
        <div class="nav" style="gap:8px;">{$right}</div>
    </div>
</header>
<div class="container">
HTML
        . ($flash_ok  ? '<div class="alert success">' . h($flash_ok)  . '</div>' : '')
        . ($flash_err ? '<div class="alert error">'   . h($flash_err) . '</div>' : '');
}

function render_footer() {
    return <<<HTML
</div>
<footer style="text-align:center; padding: 30px 20px; color: var(--text-soft); font-size: 0.85rem;">
    Meento Share · Compartilhamento descentralizado · Tema verde
</footer>
</body>
</html>
HTML;
}
